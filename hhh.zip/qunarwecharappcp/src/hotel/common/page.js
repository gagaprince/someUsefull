/**
 * Created by lqq.li on 16/12/15.
 */

var validator = require('../utils/validator.js');
var util = require('../utils/util.js');

/*
*   正常页面跳转推荐使用pageTo方法,若不知道当前页面从哪里来,只是想返回上一级,可以使用pageBack
*   目前只支持 跳转主流程页面,即:hotel/xx/xx类似页面,其他页面看后续需不需要补充,再做处理
*/

module.exports = (function() {
	/**
	 * 因微信页面栈最多不能超过5层,故将页面跳转抽离出来,方便控制层级
	 *参数解析:
	 *  pageName: 页面中Page()函数中的参数 ,每个页面都需要自定义一个唯一标示
	 *  param: 跳转链接所需参数,可以为拼接好的url param,也可以直接传入对象
	 *  destoryThis: 是否销毁当前页面
	 *  canBack: 是否要重新打开页面而不是返回,默认为false
	 **/
	function pageTo(pageName, param, destoryThis, canBack) {

		if (!pageName) {
			return;
		}

		// 参数序列化
		if (param) {
			param = validator.isString(param) ? param : util.param2query(param)
		}

		var allPages = getCurrentPages(), // 所有history栈中的页面
			isBack = false,
			targetCount = 0;   // 目标跳转页面的页面数

		for (var i = 0; i < allPages.length; i++) {
			if (allPages[i].pageName == pageName) {
				isBack = true;
				targetCount = allPages.length - i - 1;
				break;
			}
		}

		// 若为纯粹的页面返回(不带任何参数)
		if (isBack && (!param || canBack)) {
			wx.navigateBack({
				delta: targetCount
			});
			return;
		}

		// 查看堆栈内是否超过5个,有则销毁当前页面,重新打开
		if (allPages.length >= 5 || allPages[allPages.length-1].pageName == pageName || destoryThis) {
			wx.redirectTo({
				url: '/hotel/pages/hotel/' + pageName + '/' + pageName + '?' + param
			});
			return;
		}

		// 打开新页面
		wx.navigateTo({
			url: '/hotel/pages/hotel/' + pageName + '/' + pageName + '?' + param,
			success: function () {
			}
		});
	}

	/*
	* 纯粹的返回
	* 参数解析:
	*   delta: 回调的层级,默认值为1
	*/
	function pageBack(delta) {
		wx.navigateBack({
			delta: delta || 1
		});
	}
	return {
		to: pageTo,
		back: pageBack
	}
})();
