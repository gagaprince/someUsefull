/**
 * Created by lqq.li on 16/12/2.
 */

/**
 * 使用说明:
 *      1.  在目标页面 js,wxml,wxss 分别引入对应的pop-up文件
 *              js: var popUp = require('../../../common/component/pop-up/pop-up.js');
 *              wxss: @import "../../../common/component/pop-up/pop-up.wxss";
 *              wxml: <import src="../../../common/component/pop-up/pop-up.wxml"/>
 *      2.  wxml中记得实例化模板哦  eg: <template is="qt-dialog-box" data="{{...alert}}"/>
 *      3.  如果只是普通的使用,比如一个提示title + 一个content,或者 无title + 一个content, eg:
 *              popUp.showPopUp.call(this,{
					title: '订单提交',
					content: '测试测试测试测试测试测试'
				});
            若有有其他需求,比如content格式较为复杂,eg: xxxx
                popUp.showPopUp.call(this,{
					title: '订单提交',
					content: [
						{
							subTitle: '免费取消',
							subImgClass: 'icon-c icon-price',
							text: '免费取消免费取消免费取消'
						},{
							subTitle: '免费取消',
							subImgClass: 'icon-c icon-price',
							text: '免费取消免费取消免费取消'
						}
					]
				});
 *      4.  自己可以配置的参数 见: defaultOptions
 */
var validator = require('../../../utils/validator.js');
var extend = require('../../../../common/utils/object/extend.js');

module.exports = (() => {
	var defaultOptions = {
			width: '80%',
			maxHeight: getApp().globalData.deviceInfo.HeightRpx * 0.75,
			noHeader: true,
			isShowDialog: true,
			content: '',
			title: '温馨提示',
			contentCenter: false,  // 提示文案是否居中对齐,只对纯文本生效
			autoHide: 1000   // 是否自动隐藏,若是,则值为毫秒数
		};

	function showPopUp(options) {
		// var autoHide = defaultOptions.autoHide;
		extend(false,defaultOptions, options);

		defaultOptions.onlyText = validator.isString(options.content) ? true : false;
		this.setData({alert: defaultOptions});

		// 动画
		this.dialogAnimation = wx.createAnimation({
			duration: 300,
			timingFunction: 'ease'
		});
		this.dialogAnimation.opacity(1).step();
		this.setData({"alert.dialogAnimation": this.dialogAnimation.export()});

		// 弹框自动隐藏,因作用域局限,后期再做考虑
		//var me = this;
		//if(autoHide && autoHide > 0) {
		//	setTimeout(function () {
		//		hidePopUp().call(me);
		//	}, autoHide);
		//}
	}

	function hidePopUp() {
		this.dialogAnimation.opacity(0).step();
		this.setData({"alert.dialogAnimation": this.dialogAnimation.export()});
		setTimeout(function () {
			this.setData({"alert.isShowDialog": false});
		}.bind(this), 300);
	}

	return {
		// 弹框展示
		showPopUp: showPopUp,

		// 弹框隐藏
		hidePopUp: hidePopUp
	}

})();
