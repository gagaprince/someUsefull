var util = require('../../../../common/utils.js');
var Network = require('../../../../common/comps/network/network.js');
var EventEmitter = require('../../../../common/EventEmitter.js');
var HotelDef = require('../../../constants/define.js');
var requester = require('../../../../common/requester.js');
var localStorage = require('../../../utils/localStorage.js');
var watcher = require('../../../../common/watcher.js');

var CONSTANTS = require('../../../constants/define.js');
var HOTEL_EVENT_NAME = HotelDef.HOTEL_EVENT_NAME;
var HOTEL_PLACEHOLDER = CONSTANTS.HOTEL_PLACEHOLDER;

var keywordsPlaceHolder = HOTEL_PLACEHOLDER.HOTEL_INDEX_KEYWORDS;
var HOTEL_CACHE_KEY = CONSTANTS.HOTEL_CACHE_KEY;
var LOCALSTORAGE_MAX_COUNT = 19; //保存最大记录数
var historyKeywordData;
var API = {
    SUGGEST_KEYWORDS: '/api/hotel/suggest/k'
}
var iconMap = {
    搜索历史: 'q-browse-history',
    机场车站: 'airportstation',
    热门景点: 'touristspots',
    热门位置: 'tradearea',
    地铁站点: 'subwapstation',
    品牌酒店: 'q-near-hotel',
    特色主题: 'featuretheme'
};

Page({
    data: {
        //搜索框文本
        keywords: '',
        historyKeywordData: '',
        suggestListData: [],
        navigateKeywordData: [],
        hideKeywordList: false,
        hideSuggestList: true,
        opacity: '0'
    },
    options: {
        cityname: '',
        keywords: ''
    },
    //搜索缓存，同一个搜索关键词只请求一次
    searchCache: {},
    /*
      五个区域中选择关键词后的处理函数。
      1.将当前选中关键词添加到localstorage历史关键词列表 —— TOUCH_HISTORY_KEYWORD
      3.与搜索页通信，反写选中关键词。
      4.关闭关键词列表页。
    */
    returnKeywords: function(e) {
        var dataSet = e.currentTarget.dataset,
            selectedKeywords = dataSet.keywords;
        if (!selectedKeywords) {
            wx.navigateBack();
        }
        this.storeSelectedKeyword(selectedKeywords);
        // 如果选中的关键词与之前一样，则不触发
        this.options.keywords == selectedKeywords ? '' : EventEmitter.dispatch(HOTEL_EVENT_NAME.KEYWORDS_SELECT,
            selectedKeywords);
        localStorage.set(HOTEL_CACHE_KEY.TOUCH_KEYWORD_SELECT, selectedKeywords);
        wx.navigateBack();
    },
    clearHistory: function(e) {
        var me = this;
        historyKeywordData = '';
        me.setData({
            historyKeywordData: ''
        });
        localStorage.set('TOUCH_HISTORY_KEYWORD', '');
    },
    storeSelectedKeyword: function(selectedKeywords) {
        historyKeywordData = historyKeywordData.filter(function(item) {
            return item.qname != selectedKeywords;
        });
        historyKeywordData.unshift({
            dname: selectedKeywords,
            qname: selectedKeywords
        });
        while (historyKeywordData.length > LOCALSTORAGE_MAX_COUNT)
            historyKeywordData.pop();
        localStorage.set('TOUCH_HISTORY_KEYWORD', historyKeywordData);
    },
    clearSearchText: function(e) {
        //搜索酒店名、地名、地标
        this.setData({
            keywords: ''
        });
    },
    //输入关键字。--合并用户300ms间的输入
    handleSuggest: util.debounce(function(e) {
        //隐藏城市列表，展示搜索结果列表
        this.setData({
            hideKeywordList: true,
            hideSuggestList: false
        });
        //如果已经缓存直接取缓存，反之请求数据。
        var searchKey = e.detail.value.trim(),
            suggestData = this.searchCache[searchKey];
        suggestData ?
            this.setData({
                suggestListData: suggestData
            }) :
            this.getSuggestData(searchKey);
    }, 300),
    inputKeyword: function(e) {
        this.inputKeywordsText = e.detail.value;
        this.handleSuggest(e);
    },
    //请求搜索列表数据
    getSuggestData: function(key) {
        var me = this;
        if (!key) {
            me.setData({
                hideKeywordList: false,
                hideSuggestList: true
            });
            return;
        };
        //请求搜索列表数据。
        requester.request({
            service: API.SUGGEST_KEYWORDS,
            bizType: 'hotel',
            param: {
                city: me.options.city,
                keywords: key
            },
            success: function(res) {
                if (res.data && res.data.ret && res.data.data) {
                    var convData = me.convertFormatSuggestData(res.data.data);
                    me.searchCache[key] = convData;
                    me.setData({
                        suggestListData: convData
                    });
                }
            }
        });
    },
    convertFormatSuggestData: function(data) {
        var newData = [];
        if (data.length > 0) {
            data.forEach(function(item, index) {
                newData.push(item.ahead);
            });
        }
        return newData;
    },
    //用户输入关键词，并确定
    confirmSelect: function() {
        var kw = this.inputKeywordsText ? this.inputKeywordsText.trim() : this.data.keywords.trim();
        if (kw) {
            this.storeSelectedKeyword(kw);
        }
        kw != this.options.keywords && EventEmitter.dispatch(HOTEL_EVENT_NAME.KEYWORDS_SELECT, kw || keywordsPlaceHolder);
        localStorage.set(HOTEL_CACHE_KEY.TOUCH_KEYWORD_SELECT, kw || '');
        wx.navigateBack();
    },
    /*
     * 对导航关键词列表进行“修整”，便于渲染
     * 0. 渲染出两部分，一部分为折叠的，一部分为展开的
     * 1. 增加一个节点为展开折叠控制按钮
     * 2. 节点数控制为4的倍数
     * 3. 控制节点增加类型属性，共有3种控制类型
     *     blank 空白, fold 折叠状态, expand 展开状态
     */
    expandNavigateKeywordData: function(species) {
        var newSpecies = {
            status: 'fold',
            type: species.type || '-', //统计用
            icon: iconMap[species.title],
            title: species.title,
            foldValues: [],
            expandValues: []
        };


        function splitLine4(lst) {
            var sp = [];
            var line = [];
            var item;
            while (item = lst.shift()) {
                line.push(item);
                if (line.length == 4) {
                    sp.push(line);
                    line = [];
                }
            }
            return sp;
        }

        if (!species.values.length)
            return {};

        //构造折叠状态的列表
        if (species.values.length <= 8) {
            var values = species.values.slice(0);
            while (values.length % 4)
                values.push({
                    type: 'blank'
                });
            newSpecies.foldValues = splitLine4(values);
            return newSpecies;
        } else {
            var values = species.values.slice(0, 7);
            values.push({
                type: 'fold'
            });
            newSpecies.foldValues = splitLine4(values);
        }

        //构造展开状态的列表
        var values = species.values.slice(0);
        //先放置一个“占位”元素，因为“1. 增加一个节点为展开折叠控制按钮”
        values.push({
            type: 'blank'
        });
        while (values.length % 4 != 0)
            values.push({
                type: 'blank'
            });
        values[values.length - 1].type = 'expand';
        newSpecies.expandValues = splitLine4(values);
        return newSpecies;
    },
    toggleFoldAndExpand: function(e) {
        var dataSet = e.currentTarget.dataset,
            index = dataSet.index,
            title = dataSet.title,
            operation = dataSet.operation;
        if (title === '搜索历史') {
            var history = this.data.historyKeywordData;
            history.status = operation;
            this.setData({
                historyKeywordData: history
            });
        } else {
            var allKW = this.data.navigateKeywordData;
            if (allKW[index]) {
                allKW[index].status = operation;
                this.setData({
                    navigateKeywordData: allKW
                });
            }
        }
    },
    onLoad: function(options) {
        var me = this;
        me.options = options;
        watcher.pv({
            "page": "hotel-list-keywords"
        });
    },
    /*
    页面加载完成
    1. 读取本地历史关键词列表并渲染它们
    2. 获取城市对应的关键词列表并渲染它们
    */
    onReady: function() {
        var me = this;
        Network.showNetwork.call(me, {
            status: 4
        });
        //历史记录在程序整个生命期内只读一次，并且需要时才读，所以把它安排为全局变量
        if (!historyKeywordData)
            historyKeywordData = localStorage.get(HOTEL_CACHE_KEY.TOUCH_HISTORY_KEYWORD) || [];

        me.data.historyKeywordData = me.expandNavigateKeywordData({
            title: '搜索历史',
            values: historyKeywordData
        });
        me.setData({
            keywords: me.options.keywords,
            historyKeywordData: me.data.historyKeywordData
        });
        requester.request({
            service: '/api/hotel/navigate',
            bizType: 'hotel',
            param: {
                city: me.options.city
            },
            success: function(res) {
                if (res.data && res.data.ret &&
                    res.data.data &&
                    res.data.data.datas) {
                    var allKW = res.data.data.datas.map(function(species) {
                        return me.expandNavigateKeywordData(species);
                    });
                    Network.hideNetwork.call(me, function() {
                        me.setData({
                            navigateKeywordData: allKW,
                            opacity: '1'
                        });
                    });
                } else {
                    Network.hideNetwork.call(me, function() {
                        me.setData({
                            opacity: '1'
                        });
                        if (historyKeywordData.length == 0) {
                            me.setData({
                                loadingTip: '没有查询到数据'
                            });
                        }
                    });
                }
            },
            fail: function(err) {
                Network.hideNetwork.call(me, function() {
                    me.setData({
                        opacity: '1'
                    });
                    if (historyKeywordData.length == 0) {
                        me.setData({
                            loadingTip: '网络错误,请稍后重试'
                        });
                    }
                });
            }
        });
    }
});
