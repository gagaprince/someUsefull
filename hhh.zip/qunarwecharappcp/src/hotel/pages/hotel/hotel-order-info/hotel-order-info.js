var EventEmitter = require('../../../../common/EventEmitter.js');
var HotelDef = require('../../../constants/define.js');
var request = require('../../../../common/requester.js').request;
var util = require('../../../utils/util.js');
var popUp = require('../../../common/component/pop-up/pop-up.js');
var priceInfoUtil = require('./js/price-info-util.js')();
var validate = require('./js/validate.js');
var extend = require('../../../../common/utils/object/extend.js');
var Network = require('../../../../common/comps/network/network.js');

var sideBar = require('../../../../common/comps/side-bar/sidebar-select.js');
var Pay = require('../../../../common/pay.js');
var page = require('../../../common/page.js');
var localStorage = require('../../../utils/localStorage.js');
var watcher = require('../../../../common/watcher.js');

var app = getApp();

var HOTEL_CACHE_KEY = HotelDef.HOTEL_CACHE_KEY;
var HOTEL_EVENT_NAME = HotelDef.HOTEL_EVENT_NAME;

Page({
    submitActive: false,
    requestData: {},
    firstData: {},
    data: {
        sidebar: {},
        roomSelectData: {
            title: '房间数选择',
            curValue: 1,
            curIndex: 0,
            data: []
        },
        timeSelectData: {
            title: '最晚到店',
            tips: '',
            data: 'firstData.arriveTimes',
            vouchMonth: 0,
            currencySign: 'firstData.roomInfo.currencySign'
        },
        price: {
            vouchCount: 0,
            vouchType: 0, // 担保类型
            vouchRule: '',
            vouchBy: { // 超时担保还是超量担保
                time: false,
                count: false
            },
            info: {}, // 当前房间数对应的priceInfo
            payTypeDesc: '在线支付', // 支付类型
            payType: 0, // 0-预付,1-现付
            ptType: '', // 优惠类型 1,3 立减; 2,4 可返
            ptTypeDesc: '', //优惠类型说明
            currencySign: ''
        },
        // 价格明细 数据
        detailFees: {},
        networkData: {
            status: 0,
            loadingDesc: '加载中...',
            showButton: false
        },
        priceDetailStatus: 'up',
        gjRoomData: {}
    },
    localStorage: {
        guestInfo: localStorage.get(HOTEL_CACHE_KEY.GUESTS_INFO) || {
            // 国际
            gj: {
                firstName: '',
                lastName: '',
                mobile: ''
            },
            // 国内
            gn: {
                name: '',
                mobile: ''
            }
        }
    },
    onLoad: function(param) {
        this.pageParam = extend(false, {}, param);
        this.request();
        watcher.pv({ "page": "hotel-order-info" });
    },
    // 初始请求数据
    request: function() {
        var me = this;

        Network.showNetwork.call(me, {
            status: 4,
            loadingDesc: '加载中...'
        });

        request({
            service: '/hotel/hotelorderinfo.c',
            bizType: 'hotel',
            param: me.pageParam,
            success: function(res) {
                if (!res.data.ret) {
                    Network.hideNetwork.call(me);
                    return;
                }
                me.init(res.data);
                Network.hideNetwork.call(me);
            },
            fail: function() {
                Network.hideNetwork.call(me, function() {
                    Network.showNetwork.call(me, {
                        status: -1,
                        loadingDesc: '网络失败，请重试',
                        showButton: true,
                        networkRetry: 'request',
                        height: '100%'
                    });
                });
            }
        });
    },
    // 数据处理
    init: function(data) {
        var firstData = data.data,
            roomInfo = firstData.roomInfo,
            requestData = data.req;

        // 若返回酒店数据为空,则直接提示错误且返回
        if (!firstData || util.isEmptyObject(roomInfo)) {
            this.setData({
                firstData: {}
            });
            return;
        }

        wx.setNavigationBarTitle({
            title: roomInfo.hotelName
        });

        this.firstData = firstData;
        this.requestData = requestData;


        this.checkPriceChange();

        if (firstData.breakfast && firstData.breakfast.detail.length > 0) {
            firstData.breakfast.canClick = true
        }

        if (roomInfo.staydays) {
            roomInfo.staydays = firstData.roomInfo.staydays.split('<span>').join('').split('</span>').join('');
        }

        // 若需要输入儿童数/国家/城市/地址/邮编,则显示报价已满
        var inputInfo = roomInfo.inputInfo;
        if (inputInfo && (inputInfo.needChildrenInfo ||
                inputInfo.needContactCountry == 1 || inputInfo.needContactCountry == 2 ||
                inputInfo.needContactCity == 1 || inputInfo.needContactCity == 2 ||
                inputInfo.needContactAddress == 1 || inputInfo.needContactAddress == 2 ||
                inputInfo.needContactZipCode == 1 || inputInfo.needContactZipCode == 2)) {
            this.setData({
                firstData: {}
            });
            return;
        } else {
            this.setRoomArray();
        }

        this.setData({
            firstData: firstData,
            requestData: requestData,
            price: extend(true, this.data.price, {
                vouchCount: roomInfo.vouchRule ? roomInfo.vouchRule.length : 0,
                info: firstData.priceInfos[0],
                payTypeDesc: roomInfo.payTypeDesc, // 支付类型
                payType: roomInfo.payType, // 0-预付,1-现付
                ptType: roomInfo.ptType, // 优惠类型 1,3 立减; 2,4 可返
                ptTypeDesc: roomInfo.ptTypeDesc, //优惠类型说明
                currencySign: roomInfo.currencySign
            })
        });

        this.initGuestsInfo();
        this.initEmailInfo();
        this.initCardInfo();
        this.initPhoneInfo();
        this.initInvoiceInfo();
        this.initTimeInfo();

        priceInfoUtil.refreshPrice.call(this);
        this.initWarmTips();
    },
    // 检测是否有变价提醒
    checkPriceChange: function() {
        var priceChange = this.firstData.roomInfo.priceChange;
        if (priceChange) {
            wx.showModal({
                title: '变价提示',
                content: priceChange,
                showCancel: false
            })
        }
    },

    /* 初始化页面数据 start*/
    initEmailInfo: function() {
        var inputInfo = this.firstData.roomInfo.inputInfo || {},
            needBookingEmail = inputInfo.needBookingEmail,
            needContactEmail = inputInfo.needContactEmail,
            isShow = needBookingEmail || needContactEmail == 1 || needContactEmail == 2;

        this.setData({
            emailInfo: {
                show: isShow,
                isReqire: needBookingEmail || needContactEmail == 2,
                value: '',
                emailFocus: false
            }
        })
    },
    initPhoneInfo: function() {
        var guestsLocal = this.localStorage.guestInfo;
        this.setData({
            phoneInfo: {
                value: this.data.guestsName.needEnglishGuestName ? guestsLocal.gj.mobile : guestsLocal.gn.mobile,
                phoneFocus: false
            }
        })
    },
    initCardInfo: function() {
        var roomInfo = this.firstData.roomInfo || {};
        this.setData({
            cardInfo: {
                show: roomInfo.needIdCard,
                value: '',
                cardFocus: false
            }
        })
    },
    initGuestsInfo: function() {
        var inputInfo = this.firstData.roomInfo.inputInfo || {},
            needEnglishGuestName = inputInfo && inputInfo.needEnglishGuestName,
            roomCount = this.requestData.roomCount,
            firstValue = [],
            moreValue = [],
            guestsLocal = this.localStorage.guestInfo,
            baseNameObj = needEnglishGuestName ? {
                guest1: '',
                guest2: ''
            } : {
                guest1: ''
            };

        for (var i = 0; i < roomCount; i++) {
            if (i == 0) {
                needEnglishGuestName ?
                    guestsLocal.gj.firstName ?
                    firstValue.push({
                        guest1: guestsLocal.gj.firstName,
                        guest2: guestsLocal.gj.lastName
                    }) :
                    firstValue.push(util.clone(baseNameObj)) :
                    guestsLocal.gn.name ?
                    firstValue.push({
                        guest1: guestsLocal.gn.name
                    }) :
                    firstValue.push(util.clone(baseNameObj));
            } else {
                moreValue.push(util.clone(baseNameObj));
            }
        }

        this.setData({
            guestsName: {
                needEnglishGuestName: needEnglishGuestName,
                baseNameObj: baseNameObj,
                firstValue: firstValue,
                moreValue: moreValue
            }
        });
    },
    initInvoiceInfo: function() {
        var invoiceInfo = this.firstData.roomInfo.invoiceInfo,
            invoiceText = (invoiceInfo.invoiceGetType == 2 || invoiceInfo.invoiceGetType == 3) ?
            invoiceInfo.invoiceGetLabel :
            '请前往去哪儿旅行客户端领取';
        this.setData({
            invoiceInfo: {
                show: invoiceInfo.invoiceGetType != 0,
                text: invoiceText
            }
        })
    },
    /* 初始化页面数据 end */

    /* 根据输入更新数据 start */
    setGuestsName: function(e) {
        var dataset = e.currentTarget.dataset,
            guestsInfo = this.data.guestsName,
            needEnglishGuestName = guestsInfo.needEnglishGuestName,
            index = dataset.index,
            namePart = dataset.namepart || '',
            value = e.detail.value;

        if (!needEnglishGuestName) {
            index == 'first' ?
                guestsInfo.firstValue[0].guest1 = value :
                guestsInfo.moreValue[index].guest1 = value;
            return;
        }

        index == 'first' ?
            guestsInfo.firstValue[0][namePart] = value :
            guestsInfo.moreValue[index][namePart] = value;

    },
    setPhoneValue: function(e) {
        var value = e.detail.value;

        this.setData({
            'phoneInfo.value': value
        })
    },
    setEmailValue: function(e) {
        var value = e.detail.value;

        this.setData({
            'emailInfo.value': value
        })
    },
    setCardValue: function(e) {
        var value = e.detail.value;

        this.setData({
            'cardInfo.value': value
        })
    },
    /* 根据输入更新数据 end */

    /* 提示信息部分  start */
    initWarmTips: function() {
        var roomInfo = this.firstData.roomInfo,
            weakTips = roomInfo.weakTips,
            hasMore = false;

        if (roomInfo.specialNotes) {
            weakTips.push({
                title: "特殊说明",
                desc: roomInfo.specialNotes,
                name: "",
                isHide: true
            });
        }

        for (var i in weakTips) {
            weakTips[i].ellipsis = ellipsis(weakTips[i].desc);
            weakTips[i].tipsIconStatus = weakTips[i].ellipsis ? 'down' : 'up';
            weakTips[i].showEllipsis = weakTips[i].ellipsis ? true : false;
            if (weakTips[i].isHide == true) {
                hasMore = true;
            }
        }

        this.setData({
            warmInfo: {
                data: weakTips,
                'hasMore': function(weakTips) {
                    for (var i in weakTips) {
                        if (weakTips[i].isHide == true) {
                            return true;
                        }
                    }

                }(weakTips)
            }
        });
    },
    showMoreTips: function() {
        var weakTips = this.data.warmInfo.data;

        popUp.showPopUp.call(this, ({
            noHeader: true,
            content: ((weakTips) => {
                var result = [];
                for (var i in weakTips) {
                    weakTips[i].isHide && result.push({
                        text: weakTips[i].title + '：' + weakTips[i].desc
                    });
                }
                return result;
            })(weakTips)
        }));
    },
    toggleShowTips: function(e) {
        var index = e.currentTarget.dataset.index,
            // 是否可toggle
            click = e.currentTarget.dataset.click,
            weakTips = this.data.warmInfo.data;

        if (!click) {
            return;
        }
        this.setData({
            'warmInfo.data': ((weakTips, index) => {
                var data = weakTips.slice();
                data[index].showEllipsis = !data[index].showEllipsis;
                data[index].tipsIconStatus = data[index].tipsIconStatus == 'up' ? 'down' : 'up';
                return data;
            })(weakTips, index)
        });
    },
    // 取消规则更新
    cancellationTipsChange: function() {
        var weakTips = this.data.warmInfo.data;

        for (var i in weakTips) {
            if (weakTips[i].name == 'cancellation') {
                weakTips[i].desc = this.firstData.roomInfo.cancellation;
                weakTips[i].ellipsis = ellipsis(weakTips[i].desc);
            }
        }

        this.setData({
            'warmInfo.data': weakTips
        });
    },
    /* 提示信息部分  end */

    /** 入住时间 start **/
    // 初始化
    initTimeInfo: function() {
        var data = this.firstData.arriveTimes;
        if (!data || util.isEmptyObject(data)) {
            return false;
        }

        this.setData({
            timeSelectData: extend(true,this.data.timeSelectData, {
                curValue: data.times[data.defaultKey],
                curIndex: data.defaultKey,
                tips: data.arriveWarmTips,
                data: data.times,
                currencySign: this.firstData.roomInfo.currencySign
            })
        });

    },
    timeChange: function() {
        sideBar.showSideBar.call(this, {
            data: this.data.timeSelectData,
            showSideBar: true,
            selectEvent: 'timeSelect',
            layerEvent: 'commonSideBarHidden'
        });
    },
    timeSelect: function(e) {
        var me = this,
            data = e.currentTarget.dataset;

        me.setData({
            'timeSelectData.curIndex': data.index,
            'timeSelectData.curValue': {
                value: data.value,
                key: data.key
            },
            'sidebar.data': this.data.timeSelectData
        });

        setTimeout(function() {
            sideBar.hideSideBar.call(me);
        }, 300);
    },
    /** 入住时间 end **/

    /* 房间数选择  start */
    // 获取房间数数据 单选
    setRoomArray: function(curValue) {
        var curNum = curValue || this.requestData.roomCount,
            priceInfos = this.firstData.priceInfos,
            curIndex = 0,
            result = [];

        for (var i in priceInfos) {
            if (curNum == priceInfos[i].bookNum) {
                curIndex = i;
            }

            result.push({
                key: priceInfos[i].bookNum + '间',
                value: priceInfos[i].bookNum
            });
        }

        this.setData({
            roomSelectData: extend(true,this.data.roomSelectData, {
                data: result,
                curValue: curNum,
                curIndex: curIndex
            })
        });
    },
    // 房间数选择弹层
    roomCountChange: function(e) {
        this.setRoomArray(e.currentTarget.dataset.num);
        sideBar.showSideBar.call(this, {
            data: this.data.roomSelectData,
            showSideBar: true,
            selectEvent: 'roomSelect',
            layerEvent: 'commonSideBarHidden'
        });
    },
    // 房间数选择
    roomSelect: function(e) {
        var me = this,
            priceInfos = me.data.firstData.priceInfos,
            data = e.currentTarget.dataset;
        me.setData({
            'roomSelectData.curIndex': data.index,
            'roomSelectData.curValue': data.value,
            'sidebar.data': this.data.roomSelectData
        });

        Object.keys(priceInfos).forEach((index) => {
            if (priceInfos[index].bookNum == data.value) {
                me.data.price.info = priceInfos[index];
                return false;
            }
        });

        setTimeout(function() {
            sideBar.hideSideBar.call(me);
        }, 300);

        this.refreshGuestsInfo();
        this.roomToPrice();
    },

    // 房间数改变同步改变价格
    roomToPrice: function() {
        priceInfoUtil.refreshPrice.call(this);
    },
    // 根据房间数同步入住人信息
    refreshGuestsInfo: function() {
        var moreValue = this.data.guestsName.moreValue,
            baseNameObj = this.data.guestsName.baseNameObj,
            moreRoomCount = this.data.roomSelectData.curValue - 1;

        if (moreRoomCount < moreValue.length) {
            moreValue = moreValue.slice(0, moreRoomCount);
        } else {
            for (var i = moreValue.length; i < moreRoomCount; i++) {
                moreValue.push(util.clone(baseNameObj));
            }
        }

        this.setData({
            'guestsName.moreValue': moreValue
        });
    },
    /* 房间数选择 end */

    // 入住人提示弹层
    showGuestTips: function() {
        popUp.showPopUp.call(this, {
            noHeader: false,
            title: '入住人填写说明',
            content: [{
                    text: '1. 房间入住人需为入住手续办理人,且所填写姓名与所持证件一致,订单提交后入住人无法更改'
                },
                {
                    text: '2. 只能填写英文或拼音,限3-20字符'
                },
                {
                    text: '3. 入住人姓名不能重复填写'
                }
            ]
        });
    },

    // 部分含早弹层
    showBreakDetail: function() {
        popUp.showPopUp.call(this, {
            noHeader: false,
            contentCenter: true,
            title: '早餐明细',
            content: (function(me) {
                var breakfast = me.firstData.breakfast.detail || [],
                    result = [];

                for (var i in breakfast) {
                    result.push({
                        text: breakfast[i].date + ' ----------------- ' + breakfast[i].value
                    });
                }

                return result;
            })(this)
        });
    },

    /* 价格明细展示与隐藏 start */
    priceDetailShow: function() {
        // 如若当前属于展示状态,则隐藏
        if (this.data.detailFees.show) {
            this.setData({
                detailFees: {
                    show: false
                },
                priceDetailStatus: 'up'
            });
            return;
        }
        var detailData = priceInfoUtil.getDetailFeeData.call(this);
        this.setData({
            detailFees: {
                show: true,
                detailData: detailData
            },
            priceDetailStatus: 'down'
        });
    },
    priceDetailHide: function() {
        this.setData({
            detailFees: {
                show: false
            },
            priceDetailStatus: 'up'
        });
    },
    /* 价格明细展示与隐藏 end */

    /* 订单提交 */

    // 提交订单前处理入住人信息跟接口数据保持一致
    getGuestsList: function() {
        var guestsName = this.data.guestsName,
            guestsList = guestsName.firstValue.concat(guestsName.moreValue),
            result = {};

        for (var i = 0; i < guestsList.length; i++) {

            if (guestsList[i].guest2) {
                result['guest' + (i + 1)] = guestsList[i].guest1 + '/' + guestsList[i].guest2;
                i == 0 ? this.localStorage.guestInfo.gj = {
                    firstName: guestsList[i].guest1,
                    lastName: guestsList[i].guest2,
                    mobile: this.data.phoneInfo.value
                } : '';
            } else {
                result['guest' + (i + 1)] = guestsList[i].guest1;
                i == 0 ? this.localStorage.guestInfo.gn = {
                    name: guestsList[i].guest1,
                    mobile: this.data.phoneInfo.value
                } : '';
            }
        }

        return result;
    },
    submit: function() {
        if (this.submitActive) {
            return;
        }
        this.submitActive = true;

        watcher.click({
            "page": "hotel-order-info",
            "action-type": "pay-order"
        });

        var me = this,
            email = this.data.emailInfo,
            mobile = this.data.phoneInfo,
            card = this.data.cardInfo,
            guestsName = this.data.guestsName;
            // cookies = app.cookies;

        // 校验信息
        if (guestsName.needEnglishGuestName ?
            !validate.separateNameValidate.call(this, guestsName) :
            !validate.singleNameValidate.call(this, guestsName)) {

            me.submitActive = false;
            return false;
        }
        if (!validate.telephoneValidate.call(this, mobile) ||
            email.show && !validate.emailValidate.call(this, email) ||
            card.show && !validate.idCardValidate.call(this, card.value)) {
            me.submitActive = false;
            return false;
        }

        var guestsList = this.getGuestsList();

        localStorage.set(HOTEL_CACHE_KEY.GUESTS_INFO, this.localStorage.guestInfo);

        var requestData = this.data.requestData,
            roomInfo = this.data.firstData.roomInfo,
            price = this.data.price,
            commitParam = {
                tag: requestData.tag || '',
                city: requestData.city || '',
                keywords: requestData.keywords || '',
                checkInDate: requestData.checkInDate || '',
                checkOutDate: requestData.checkOutDate || '',
                wrapperId: requestData.wrapperId || '',
                roomId: requestData.roomId || '',
                logicBit: requestData.logicBit || '',
                mobilePriceType: requestData.mobilePriceType || '',
                hotelId: roomInfo.hotelID || '',
                seq: requestData.seq || '',
                planId: requestData.planId || '',
                bd_ssid: requestData.bb_ssid || '',
                bd_sign: requestData.bd_sign || '',
                countryCode: roomInfo.countryCode || '',
                currencySign: roomInfo.currencySign || '',
                type: requestData.type || 0,
                needBookingEmail: roomInfo.inputInfo ? roomInfo.inputInfo.needBookingEmail : false,
                otherRequire: '',
                payMoney: price.info.totalPrice, // totalPrice
                totalPrize: price.info.totalPrize,
                referTotalPrice: price.info.referTotalPrice,
                referCurrencySign: roomInfo.referCurrencySign,
                extra: encodeURIComponent(roomInfo.extraParam), // 跟guestInfos同时出现
                guestInfos: this.data.guestInfos || '',
                cancellation: roomInfo.cancellation,
                isInvoice: 0,
                invoiceGetType: roomInfo.invoiceInfo.invoiceGetType, //看需不需要
                roomCount: this.data.roomSelectData.curValue,
                arriveTime: this.data.timeSelectData.curValue.key + '|' + this.data.timeSelectData.curValue.value,
                idCard: card.value,
                bedTypeKey: '',
                email: email.value,
                mobile: mobile.value,
                userFriendCoupons: false,
                userCityCoupons: false
            };

        Network.showNetwork.call(me, {
            status: 3,
            loadingDesc: '提交订单中'
        });

        request({
            service: '/api/hotel/hotelbook',
            bizType: 'hotel',
            method: 'POST',
            header: {
                'content-type': 'application/x-www-form-urlencoded'
            },
            param: extend(false, commitParam, guestsList),
            success: function(res) {
                res = res.data;

                if (res.msg && res.msg != '') {
                    Network.hideNetwork.call(me);
                    wx.showModal({
                        title: '提示',
                        content: res.msg || '提交订单失败,请检查数据并重试',
                        showCancel: false
                    });
                    me.submitActive = false;
                    return;
                }

                if (!res.ret && res.data && res.data.pageto) {
                    wx.redirectTo({
                        url: decodeURIComponent(res.data.pageto.replace('pages/hotel/', '../'))
                    });
                    return;
                }

                if (res.data && res.data.pageto && res.data.pageto.indexOf('http') !== -1) {
                    me.getCashierUrl(res.data);
                } else {
                    wx.redirectTo({
                        url: decodeURIComponent(res.data.pageto.replace('pages/hotel/hotel-order-result/hotel-order-result', '../hotel-order-detail/hotel-order-detail'))
                    });
                }

            },
            fail: function() {
                Network.hideNetwork.call(me);
                wx.showModal({
                    title: '提示',
                    content: '提交订单失败,请稍后重试',
                    showCancel: false
                });
                me.submitActive = false;

            }
        });
    },
    // 获取收银台地址,并调起微信支付
    getCashierUrl: function(param) {
        var me = this,
            orderNo = param.orderno,
            vtoken = param.touchordertoken,
            mobile = param.mobile,
            openId = app.user.openId;

        request({
            service: param.pageto.split('qunar.com')[1],
            bizType: 'hotel',
            method: 'POST',
            header: {
                'content-type': 'application/x-www-form-urlencoded'
            },
            param: {
                orderNo: orderNo,
                vtoken: vtoken,
                openId: openId // 待补充
            },
            success: function(res) {
                res = res.data;

                if (!res.ret || !res.data) {
                    Network.hideNetwork.call(me);
                    wx.showModal({
                        title: '提示',
                        content: res.msg || '获取支付地址失败,请稍后重试',
                        showCancel: false,
                        success: function() {
                            page.to('hotel-order-detail', {
                                orderNum: orderNo,
                                smobile: mobile
                            }, true);
                        }
                    });
                    return;
                }

                Network.hideNetwork.call(me);
                Pay.openCashier({
                    cashierUrl: res.data,
                    openId: openId,
                    bd_source: app.globalData.bd_source,
                    success: function(res) {
                    },
                    fail: function() {
                    },
                    complete: function(res) {
                        //支付complete'

                        page.to('hotel-order-detail', {
                            orderNum: orderNo,
                            smobile: mobile
                        }, true);
                    }
                });
            },
            fail: function(err) {
                //获取收银地址失败
                Network.hideNetwork.call(me);
                page.to('hotel-order-detail', {
                    orderNum: orderNo,
                    smobile: mobile
                }, true);

            }
        });
    },


    //弹框事件
    dialogBoxClick: function() {
        popUp.hidePopUp.call(this);
    },
    dialogLayerClick: function() {
        this.dialogBoxClick();
    },

    commonSideBarHidden: function() {
        sideBar.hideSideBar.call(this);
    }
});

function ellipsis(text) {
    return text.length > 52 ? text.slice(0, 48) : false;
}
