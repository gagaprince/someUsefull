/**
 * Created by lqq.li on 16/12/6.
 */
var util = require('../../../../utils/util.js');
module.exports = () => {

	// 价格渲染
	function refreshPrice() {
		var price = this.data.price,
			priceInfo = price.info,
			discountDesc = (() => {
				if (price.ptTypeDesc) {
					return price.ptTypeDesc
						.replace("{rprice}", priceInfo.totalPrize)
						.replace("{price}", +priceInfo.totalPrize + +priceInfo.totalPrice)
				}
				return '';
			})(),
			priceData = {};
		switch (price.payType) {
			// 预付
			case 0:
				// 预付定金
				if (priceInfo.prepayAmount != '') {
					priceData = {
						type: '定金',
						payPrice: parseInt(parseFloat(price.info.prepayAmount) * 100) / 100,
						discountDesc: '到店再付' + ' ' + price.currencySign + priceInfo.overagePrice,
						submitText: '提交订单',
						showDetail: true
					};

				} else {

					this.setData({
						'price.prepay': Math.round(parseFloat(price.info.totalPrice) * 100) / 100
					});

					priceData = {
						type: price.payTypeDesc,
						payPrice: price.prepay,
						discountDesc: discountDesc,
						submitText: '去支付',
						showDetail: (!discountDesc && priceInfo.taxation == 0 ? false : true)
					};
				}
				break;

			// 现付
			case 1:
				priceData = {
					type: price.payTypeDesc,
					payPrice: parseInt(parseFloat(price.info.totalPrice) * 100) / 100,
					discountDesc: discountDesc,
					submitText: '提交订单',
					showDetail: (discountDesc ? true : false)
				};
				break;

		}

		this.setData({
			'price.show': priceData
		});
	}

	// 价格明细数据
	function detailData() {
		let price = this.data.price,
			detailFees = util.clone( this.data.firstData.detailFees ),
			curPrice = price.info,
			roomInfo = this.data.firstData.roomInfo,
			getListData = (item) => {
				for (var j in item.list) {
					var pre = item.list[j];
					pre.name = pre.name.replace('{booknum}', this.data.roomSelectData.curValue);

					switch (pre.text) {
						// 税费
						case 'taxation_fee':
							pre.price = price.currencySign + '' + curPrice.taxation;
							break;

						// 房费 (totalPrice - 税费 + 立减 = 房费)
						case 'room_fee':
							pre.price = Math.round(parseFloat(curPrice.totalPrice) * 100);
							if (roomInfo.ptType == 1 || roomInfo.ptType == 3) {
								pre.price = pre.price + parseInt(parseFloat(curPrice.totalPrize) * 100);
							}

							if (curPrice.taxation) {
								pre.price = pre.price - curPrice.taxation * 100;
							}
							pre.price = price.currencySign + '' + pre.price / 100;
							break;

						// 立减
						case 'ppb_cut':
							pre.price = price.currencySign + '' + curPrice.totalPrize;
							break;
						default :
							pre.isHide = true;
					}
				}
			};

		for (var i in detailFees) {
			var item = detailFees[i];
			switch (item.text) {

				// 在线付款
				case 'prepay':

					item.price = price.currencySign + '' + price.prepay;
					item.list && item.list.length && getListData(item);
					break;

				// 总价
				case 'totalpay':
					item.price = price.currencySign + '' + price.info.totalPrice;
					item.list && item.list.length && getListData(item);
					break;

				// 到店支付
				case 'front_pay':
					item.price = price.currencySign + '' + price.info.totalPrice;
					item.list && item.list.length && getListData(item);
					break;

				// 离店可返现金
				case 'cashback':
					if (this.data.price.ptType) {
						item.price = price.currencySign + '' + curPrice.totalPrize;
						item.list && item.list.length && getListData(item);
					} else {
						item.isHide = true;
					}

					break;

				// 在线担保
				case 'guarantee_pay':
					if (price.hasVouch) {
						item.price = price.currencySign + '' + curPrice.totalVouchMoney;
						item.list && item.list.length && getListData(item);
					} else {
						item.isHide = true;
					}
					break;

				// 到店付余款
				case 'leavepay':
					item.price = price.currencySign + '' + curPrice.overagePrice;
					item.list && item.list.length && getListData(item);
					break;

				// 定金
				case 'partypay':
					item.price = price.currencySign + '' + curPrice.prepayAmount;
					item.list && item.list.length && getListData(item);
					break;
			}
		}
		return detailFees;
	}

	return {
		refreshPrice: refreshPrice,
		getDetailFeeData: detailData
	}
};