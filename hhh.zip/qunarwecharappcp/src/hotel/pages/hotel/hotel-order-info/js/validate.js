/**
 * Created by lqq.li on 16/12/6.
 */

module.exports = (() => {

	// 单个中文姓名校验
	function singleNameValidate(guestsName) {
		var guestsList = guestsName.firstValue.concat(guestsName.moreValue),
			guest = '';

		for (var i in guestsList) {
			guest = guestsList[i].guest1;
			if (!guest) {
				wx.showModal({
					title: '提示',
					content: '请填写入住人姓名',
					showCancel: false
				});
				return false;
			}

			if (/[\u4e00-\u9fff]+/.test(guest) ? guest.length < 2 : guest.length < 3 ) {
				wx.showModal({
					title: '提示',
					content: '请填写正确入住人姓名',
					showCancel: false
				});
				return false;
			}

		}

		return true;
	}

	// 分离的英文姓名校验
	function separateNameValidate(guestsName) {
		var guestsList = guestsName.firstValue.concat(guestsName.moreValue);

		for (var i in guestsList) {
			if (!guestsList[i].guest1 || !guestsList[i].guest2) {
				wx.showModal({
					title: '提示',
					content: '请填写入住人姓名',
					showCancel: false
				});
				return false;
			}

			if (/[\u4e00-\u9fff]+/.test(guestsList[i].guest1) || /[\u4e00-\u9fff]+/.test(guestsList[i].guest1)) {
				wx.showModal({
					title: '提示',
					content: '入住人只能填写英文或拼音',
					showCancel: false
				});
				return false;
			}
		}
		return true;
	}

	// 手机号校验
	function telephoneValidate(phoneInfo) {
		var me = this;
		if (!/^\d{11}$/.test(phoneInfo.value)) {
			wx.showModal({
				title: '提示',
				content: '请填写正确的手机号码',
				showCancel: false,
				success: function () {
					me.setData({
						'phoneInfo.phoneFocus': true
					});
				}
			});
			return false;
		}
		return true;
	}

	// 邮箱校验
	function emailValidate(email) {
		var me = this;

		// 若邮箱是选填 且 值为空,则校验通过
		if (!email.isReqire && !email.value) {
			return true;
		}

		if (email.value && !/^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/.test(email.value)) {
			wx.showModal({
				title: '提示',
				content: '请填写正确的电子邮箱地址',
				showCancel: false,
				success: function () {
					me.setData({
						'emailInfo.emailFocus': true
					});
				}
			});
			return false;
		}
		return true;
	}

	//	身份证号校验
	function idCardValidate(value) {
		if (!/^(\d{18,18}|\d{15,15}|\d{17,17}[xX])$/.test(value)) {
			wx.showModal({
				title: '提示',
				content: '请填写18位有效身份证号',
				showCancel: false,
				success: function () {}
			});
			return false;
		}
		return true;
	}

	// 城市校验
	function cityValidate(city) {

		// 选填则通过校验
		if (!city.isReqire) {
			return true;
		}

		if (!city.value) {
			wx.showModal({
				title: '提示',
				content: '请输入城市',
				showCancel: false,
				success: function () {}
			});
			return false;
		}
		return true;
	}

	// 地址校验
	function addressValidate(address) {

		// 选填则通过校验
		if (!address.isReqire) {
			return true;
		}
		if (!address.value) {
			wx.showModal({
				title: '提示',
				content: '请输入地址',
				showCancel: false,
				success: function () {}
			});
			return false;
		}
		return true;
	}

	// 邮编校验
	function zipCodeValidate(zcode) {

		// 选填则通过校验
		if (!zcode.isReqire) {
			return true;
		}

		if (!zcode.value || !(/\d{1,10}/.test(zcode.value))) {
			wx.showModal({
				title: '提示',
				content: '请输入1-10位邮政编码',
				showCancel: false,
				success: function () {}
			});
			return false;
		}
		return true;
	}

	return {
		singleNameValidate: singleNameValidate,
		separateNameValidate: separateNameValidate,
		telephoneValidate: telephoneValidate,
		emailValidate: emailValidate,
		idCardValidate: idCardValidate,
		cityValidate: cityValidate,
		addressValidate: addressValidate,
		zipCodeValidate: zipCodeValidate
	}

})();