var Network = require('../../../../common/comps/network/network.js');
var EventEmitter = require('../../../../common/EventEmitter.js');
var CONSTANTS = require('../../../constants/define.js');
var dateFormat = require('../../../../common/utils/date/format.js');
var request = require('../../../../common/requester.js').request;
var validator = require('../../../utils/validator.js');
var util = require('../../../utils/util.js');
var commonUtil = require('../../../../common/utils.js');
var navigate = require('../../../common/page.js');
var extend = require('../../../../common/utils/object/extend.js');
var watcher = require('../../../../common/watcher.js');

var isArray = validator.isArray;
var isObject = validator.isObject;

Page({
    pageName: 'hotel-detail',
    data: {
        checkInDate: '',
        checkOutDate: '',
        dateMap: {
            dayMonthStrIn: '',
            dayMonthStrOut: '',
            dayNight: 1
        },
        commonParam: {},
        detail: {},
        roomTypes: [],
        networkData: {
            status: 0,
            loadingDesc: '加载中...',
            showButton: false
        },
        loadProductRoom: false,
        opacity: '0',
        facilityOpacity: '0'
    },

    onLoad: function(options) {
        this.hotelName = options.hotelName;
        delete options.hotelName;
        this.initPageParam(options);
        this._initListener();
    },

    onUnload: function() {
        this._dateListener && this._dateListener.removeListener();
    },

    onReady: function() {
        var self = this;
        var checkInDate = this.pageParam.checkInDate;
        var checkOutDate = this.pageParam.checkOutDate;

        Network.showNetwork.call(self, {
            status: 4
        });
        this.requestHoteldetail(true);
        this.setData({
            dateMap: {
                dayNight: self.getNightsBetweenDate(new Date(checkInDate), new Date(checkOutDate)),
                dayMonthStrIn: dateFormat(new Date(checkInDate), 'm月d日'),
                dayMonthStrOut: dateFormat(new Date(checkOutDate), 'm月d日')
            }
        });
        watcher.pv({
            "page": "hotel-detail"
        });
    },
    onShareAppMessage: function() {
        var me = this,
            params = {
                seq: me.pageParam.seq
            };

        return commonUtil.share.getParam({
            url: '/hotel/pages/hotel/hotel-detail/hotel-detail?' + util.param2query(params),
            title: '去哪儿-' + me.hotelName,
            desc: '出门在外，住好一点~'
        });
    },
    initPageParam: function(param) {
        if (!isObject(param)) {
            return;
        }
        var pageParam = {
            sort: param.sort || '0',
            type: param.type || '0',
            seq: param.seq || '',
            extra: param.extra || '',
            city: param.city || '',
            location: param.location || '',
            checkInDate: param.checkInDate || '',
            checkOutDate: param.checkOutDate || ''
        };
        this.pageParam = pageParam;

    },
    _initListener: function() {
        var me = this;
        me._dateListener = EventEmitter.addListener(
            CONSTANTS.HOTEL_EVENT_NAME.ARRIVA_DEPARTURE_DATE_SELECT,
            me.didSelectDate.bind(me)
        );
    },
    didSelectDate: function(res) {
        var me = this;
        var startDate = new Date(res.startDate);
        var endDate = new Date(res.endDate);
        me.setData({
            roomTypes: [],
            noRoomTypes: false,
            dateMap: {
                dayNight: me.getNightsBetweenDate(startDate, endDate),
                dayMonthStrIn: dateFormat(startDate, 'm月d日'),
                dayMonthStrOut: dateFormat(endDate, 'm月d日')
            }
        });
        this.pageParam.checkInDate = startDate;
        this.pageParam.checkOutDate = endDate;
        me.requestRoomTypes();
    },

    preivewImage: function(e) {
        var target = e.currentTarget;
        var pics = target.dataset && target.dataset.pics || [];

        if (isArray(pics) && pics.length > 0) {
            wx.previewImage({
                current: pics[0],
                urls: pics
            })
        }
    },
    handleDateSelect: function() {
        var params = {
            date: dateFormat(new Date(this.pageParam.checkInDate), 'yyyy-mm-dd'),
            eDate: dateFormat(new Date(this.pageParam.checkOutDate), 'yyyy-mm-dd'),
            isDoubleSelect: true,
            eventType: CONSTANTS.HOTEL_EVENT_NAME.ARRIVA_DEPARTURE_DATE_SELECT,
            calendarDays: 90,
            sText: '入住',
            eText: '离店'
        };
        wx.navigateTo({
            url: '/common/pages/calendar/calendar?data=' + JSON.stringify(params)
        });
    },
    handleTypeTap: function(e) {
        var dataset = e.currentTarget.dataset;
        var index = JSON.parse(dataset.index || 0);
        var visibility = JSON.parse(dataset.visibility || 'false');
        var hasloaded = JSON.parse(dataset.hasloaded || 'false');
        var roomTypes = this.data.roomTypes.slice();
        var name = dataset.name;
        var self = this;
        !roomTypes[index].visibility && this.setData({
            loadProductRoom: true,
            tapIndex: index
        });
        if (hasloaded) {
            var visibility = roomTypes[index].visibility;
            setTimeout(function() {
                roomTypes[index].visibility = !visibility;
                self.setData({
                    loadProductRoom: false,
                    roomTypes
                });
            }, visibility ? 0 : 300)
            return;
        }

        this.requestProductRooms(index, visibility, name);
    },
    handleGoImagelistTap: function(e) {
        var param = {
                seq: this.pageParam.seq
            },
            totalNum = e.currentTarget.dataset.totalnum;

        if (totalNum == 0) {
            return;
        }
        var imageCount = this.data.detail.info && this.data.detail.info.imageCount || 0;
        if (imageCount !== 0) {
            navigate.to('hotel-detail-imagelist', param);
        }
    },

    handleSkipToHotelOrder: function(e) {
        var self = this;
        var dataset = e.currentTarget.dataset;
        var urlparams = dataset.urlparams;
        var fromSource = self.requestData.fromSource;

        if (fromSource) {
            urlparams += '&fromSource=' + fromSource;
        }
        navigate.to('hotel-order-info', urlparams);
    },

    requestHoteldetail: function(isFirst) {
        var self = this,
            param = extend(true, {}, self.pageParam);
        param.checkInDate = param.checkInDate == '' ? '' : dateFormat(new Date(this.pageParam.checkInDate), 'yyyy-mm-dd');
        param.checkOutDate = param.checkOutDate == '' ? '' : dateFormat(new Date(this.pageParam.checkOutDate), 'yyyy-mm-dd');
        if (typeof isFirst != 'boolean') {
            Network.showNetwork.call(self, {
                status: 3,
                loadingDesc: '加载中...'
            });
        }

        request({
            service: '/hotel/hoteldetail.c',
            bizType: 'hotel',
            param,
            success: function(result) {
                var res = result.data;
                if (!res || !res.ret) {
                    Network.showNetwork.call(self, {
                        status: -1,
                        loadingDesc: '网络请求失败，请重试',
                        showButton: true,
                        networkRetry: 'requestHoteldetail'
                    });
                    return;
                }
                self.requestData = res.req || {};

                self.processDate(res.commonParam);
                self.mapHotelDetailToState(res);
                self.requestRoomTypes();
                Network.hideNetwork.call(self, function() {
                    self.setData({
                        opacity: '1'
                    });
                    self.fetchFacilitiesInfo();
                });
            },
            fail: function() {
                Network.showNetwork.call(self, {
                    status: -1,
                    loadingDesc: '网络请求失败，请重试',
                    showButton: true,
                    networkRetry: 'requestHoteldetail'
                });
            }
        });
    },
    processDate: function(commonParam) {
        if (!this.pageParam.checkInDate) {
            var checkInDate = commonParam.currentDateStr,
                checkOutDate = commonParam.tomorrowDateStr;
            this.setData({
                'dateMap.dayMonthStrIn': dateFormat(new Date(checkInDate), 'm月d日'),
                'dateMap.dayMonthStrOut': dateFormat(new Date(checkOutDate), 'm月d日'),
                'dateMap.dayNight': 1
            });
            this.pageParam.checkInDate = new Date(checkInDate);
            this.pageParam.checkOutDate = new Date(checkOutDate);
        }
    },
    mapHotelDetailToState: function(res) {
        var self = this;
        var info = res.data.info;
        var hasAddress = info && (info.add || info.area || info.distance);
        info.address = hasAddress;
        self.setData({
            commonParam: res.commonParam,
            detail: res.data
        });
    },

    requestRoomTypes: function() {
        var self = this;
        var param = {
            fromSource: self.requestData.fromSource || '',
            seq: self.requestData.seq,
            checkInDate: dateFormat(new Date(this.pageParam.checkInDate), 'yyyy-mm-dd'),
            checkOutDate: dateFormat(new Date(this.pageParam.checkOutDate), 'yyyy-mm-dd'),
            type: 0
        };

        this.setData({
            showRoomType: true,
            roomTypes: []
        });
        request({
            service: '/api/hotel/hoteldetail/price',
            bizType: 'hotel',
            param: param,
            success: function(result) {
                var res = result.data;
                if (!res || !res.ret) {
                    return;
                }
                var roomTypes = res.data.price;
                self.mapRoomTypesToState(roomTypes);
            }
        });
    },

    mapRoomTypesToState: function(data) {
        var self = this;

        isArray(data) && data.length > 0 && data.forEach(function(type, index) {
            var hasPics = isArray(type.images) && type.images.length !== 0;
            var pics = hasPics ? util.pluckArrByKey(type.images, 'url') : []
            var addtionProps = {
                hasloaded: false,
                productRooms: [],
                hasPics: hasPics,
                pics: pics,
                picCount: pics.length,
                nameStr: util.ellipsisString(type.name, 13),
                tinyPic: hasPics ? type.images[0].smallUrl : self.data.detail.info.imgurl
            }
            extend(false, type, addtionProps);

        });
        this.setData({
            roomTypes: data,
            noRoomTypes: data.length == 0,
            showRoomType: false
        });
    },

    requestProductRooms: function(index, visibility, name) {
        var self = this;
        var requestData = self.requestData;
        var param = {
            fromSource: requestData.fromSource || '',
            seq: requestData.seq,
            room: name || '',
            checkInDate: dateFormat(new Date(self.pageParam.checkInDate), 'yyyy-mm-dd'),
            checkOutDate: dateFormat(new Date(self.pageParam.checkOutDate), 'yyyy-mm-dd'),
            type: 0,
            desc: 'price'
        }

        request({
            service: '/api/hotel/hoteldetail/price',
            bizType: 'hotel',
            param: param,
            success: function(result) {
                var res = result.data;
                if (!res.ret) {
                    return;
                }
                self.mapProductRoomsToState(res.data, index, visibility);
            },
            complete: function() {
                self.setData({
                    loadProductRoom: false
                });
            }
        });
    },

    mapProductRoomsToState: function(data, index, visibility) {
        var arr = data.price;
        var roomTypes = this.data.roomTypes.slice();
        var productRooms = [];
        var tag = data.tag;

        //过滤掉touch不支持的报价(touch处理是跳客户端) 且产品房型只取5条
        if (isArray(arr) && arr.length > 0) {
            productRooms = arr.filter(function(item) {
                return !item.is5discount;
            }).slice(0, 5);
        }

        productRooms.forEach(function(room) {
            room.orderUrlParams = room.orderInfoUrl.split('?')[1].replace('%s', tag); //fromSource

            if (isArray(room.basicInfoList) && room.basicInfoList.length > 0) {
                var descList = util.pluckArrByKey(room.basicInfoList, 'desc') || [];
                room.basicInfoStr = descList.join('|');
            }

        });

        roomTypes[index].visibility = true;
        roomTypes[index].hasloaded = true;
        roomTypes[index].productRooms = productRooms;

        this.setData({
            roomTypes
        });
    },

    getNightsBetweenDate: function(dateA, dateB) {
        return (dateB.getTime() - dateA.getTime()) / (24 * 3600 * 1000)
    },

    toComment: function() {
        if (this.data.detail.info.commentCount == '0') {
            return;
        }
        watcher.pv({
            "page": "hotel-comment-list"
        });
        wx.navigateTo({
            url: 'sub-page/comment-list/comment-list?seq=' + this.requestData.seq + '&name=' + (this.data.detail.info.name || '')
        })
    },

    toHotelMap: function() {
        watcher.pv({
            "page": "hotel-detail-map"
        });
        if (!this.data.detail.info.gpoint) {
            return;
        }
        var info = this.data.detail.info,
            gpointArr = info.gpoint.split(',');

        wx.openLocation({
            name: info.name || '酒店名称',
            address: info.add || '酒店地址',
            latitude: parseFloat(gpointArr[0]),
            longitude: parseFloat(gpointArr[1])
            // scale: 28
        });

    },

    formatFacilities: function(data) {
        var lst = [];
        data.facilities.forEach(function(i) {
            i.datas.forEach(function(k) {
                lst.push(k.item);
            });
        });
        return {
            facilitiesTextList: lst,
            hotelDesc: {
                desc: data.desc,
                phone: data.phone
            }
        }
    },

    // 酒店设施
    fetchFacilitiesInfo: function() {
        var me = this;
        request({
            service: '/api/hotel/hoteldetail/info',
            bizType: 'hotel',
            param: {
                seq: me.pageParam.seq
            },
            success: function(res) {
                if (!res.data ||
                    !res.data.ret ||
                    !res.data.data) {
                    // 没有数据
                    return;
                }
                if (!res.data.data.facilities) {
                    // 暂无设施详情哦,待酒店补充
                    return;
                }
                me.setData(me.formatFacilities(res.data.data));
                me.setData({
                    facilityOpacity: '1'
                });
            },
            fail: function() {
                // do nothing
            }
        });
    }
});
