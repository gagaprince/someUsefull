var Network = require('../../../../../../common/comps/network/network.js');
var CONSTANTS = require('../../../../../constants/define.js');
var request = require('../../../../../../common/requester.js').request;
var util = require('../../../../../utils/util.js');

var deviceInfo = getApp().globalData.deviceInfo;

Page({
    param: {},
    bigImgs: [],
    requestActive: false,
    data: {
        activeTabType: '0', // 对应tab的 'data-commenttype' 属性
        commentsArray: [],
        scrollTop: 0,
        listHeight: 0
    },
    onLoad: function(param) {
        var me = this;

        wx.setNavigationBarTitle({
            title: param.name || '酒店点评'
        });

        Network.showNetwork.call(this, {
            status: 4
        });

        me.param = param;
        this.init();

        // 将点评列表部分的高度设置为获取到的页面高度减去头部高度
        util.processSystemInfo(me.setListHeight);

    },
    init: function() {
        var me = this;
        me.requestList({
            seq: me.param.seq
        }, '', function(data) {
            var comments = data.commentData.comments;

            me.setData({
                score: data.commentData.score,
                scorePercentage: parseFloat(data.commentData.score) / 5 * 100,
                totalPageNum: data.totalPageNum,
                currentPageNum: data.currentPageNum,
                commentsArray: me.data.commentsArray.concat(me.formatComments(comments)),
                tabCount: {
                    allTotal: data.commentData.allTotal,
                    goodTotal: data.commentData.goodTotal,
                    mediumTotal: data.commentData.mediumTotal,
                    badTotal: data.commentData.badTotal
                }
            })
        });
    },
    setListHeight: function(HeightRpx) {
        this.setData({
            listHeight: (HeightRpx - 177) + 'rpx'
        });
    },
    requestList: function(param, preCallBack, sucCallBack) {
        var me = this;
        if (me.requestActive) {
            return false;
        }
        me.requestActive = true;
        preCallBack && preCallBack.call(me);
        request({
            service: '/api/hotel/hoteldetail/comment',
            bizType: 'hotel',
            param: param,
            success: function(res) {
                me.requestActive = false;

                res = res.data;
                if (!res || !res.ret) {
                    return ;
                }

                sucCallBack.call(me, res.data);

                Network.hideNetwork.call(me, function() {
                    me.setData({
                        opacity: '1'
                    });
                });
            },
            fail: function() {
                me.requestActive = false;
                Network.hideNetwork.call(me, function() {
                    Network.showNetwork.call(me, {
                        status: -1,
                        zIndex: 20,
                        loadingDesc: '网络失败，请重试',
                        showButton: true,
                        networkRetry: 'init'
                    });
                    me.setData({
                        hotelListData: []
                    });
                });
            }
        })
    },
    switchTab: function(e) {
        var me = this,
            commentType = e.currentTarget.dataset.commenttype;

        this.bigImgs = [];

        this.setData({
            activeTabType: commentType
        });

        this.requestList({
            seq: this.param.seq,
            commentType: commentType,
            commentPage: 1
        }, function() {
            Network.showNetwork.call(me, {
                status: 3,
                loadingDesc: '加载中...'
            });
        }, function(data) {
            var comments = data.commentData.comments;

            me.setData({
                scrollTop: 0,
                totalPageNum: data.totalPageNum,
                currentPageNum: data.currentPageNum,
                commentsArray: me.formatComments(comments),
                tabCount: {
                    allTotal: data.commentData.allTotal,
                    goodTotal: data.commentData.goodTotal,
                    mediumTotal: data.commentData.mediumTotal,
                    badTotal: data.commentData.badTotal
                }
            })
        })
    },
    loadMore: function() {
        var me = this;
        if (me.data.currentPageNum == me.data.totalPageNum) {
            return;
        }

        this.requestList({
            seq: me.param.seq,
            commentType: me.data.activeTabType,
            commentPage: me.data.currentPageNum + 1
        }, function() {
            me.setData({
                loading: true
            });
        }, function(data) {
            var comments = data.commentData.comments;

            me.setData({
                loading: false,
                totalPageNum: data.totalPageNum,
                currentPageNum: data.currentPageNum,
                commentsArray: me.data.commentsArray.concat(me.formatComments(comments))
            });

            setTimeout(function() {
                me.setData({
                    scrollView: 'c_' + comments[0].commentId
                });
            }, 300);
        })
    },
    toggleComment: function(e) {
        var index = e.currentTarget.dataset.index,
            toggle = e.currentTarget.dataset.toggle,
            commentsArray = this.data.commentsArray;

        if (!toggle) {
            return;
        }

        commentsArray[index].showEllipsis = !commentsArray[index].showEllipsis;
        commentsArray[index].arrowUp = !commentsArray[index].arrowUp;

        this.setData({
            'commentsArray': commentsArray
        })
    },
    previewImage: function(e) {
        var me = this,
            data = e.currentTarget.dataset,
            index = data.index || 0,
            url = e.currentTarget.dataset.bigurl || CONSTANTS.DEFAULT_IMG;
        wx.previewImage({
            current: url,
            urls: me.bigImgs[index]
        });
    },

    formatComments(comments) {
        var me = this,
            bigImgsLenght = me.bigImgs.length;

        for (var i = 0, length = comments.length; i < length; i++) {
            me.bigImgs[bigImgsLenght + i] = [];

            // 是否文本过长需要收起
            if (comments[i].content.length > 99) {
                comments[i].showEllipsis = true;
                comments[i].arrowUp = false;
                comments[i].ellipsis = comments[i].content.slice(0, 97) + '…';
            } else {
                comments[i].showEllipsis = false;
            }

            if (comments[i].imgs.length) {
                comments[i].imgs.forEach(function(item) {
                    me.bigImgs[bigImgsLenght + i].push(item.url);
                });
            }


            // 点评文本是否换行较多不是很美观,将换行做一定控制
            comments[i].ellipsis = comments[i].ellipsis && comments[i].ellipsis.replace(/\n{1,}/g, '\n') || '';
            comments[i].content = comments[i].content.replace(/\n{2,}/g, '\n\n');
        }
        return comments;
    }
});
