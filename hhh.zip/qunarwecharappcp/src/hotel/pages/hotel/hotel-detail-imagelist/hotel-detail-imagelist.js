var request = require('../../../../common/requester.js').request;
var util = require('../../../utils/util.js');
var network = require('../../../../common/comps/network/network.js');
var CONSTANTS = require('../../../constants/define.js');
var watcher = require('../../../../common/watcher.js');

Page({
    pageName: 'hotel-detail-imagelist',
    data: {
        imageMapList: [],
        imageList: [],
        networkData: {},
        opacity: '0'
    },

    onLoad: function(options) {
        this.hotelSeq = options.seq; //'beijing_city_2584';//
    },

    onReady: function() {
        var self = this;
        network.showNetwork.call(self, {
            status: 4
        });
        self.getImageList(true);
        watcher.pv({ "page": "hotel-detail-imagelist" });
    },
    getImageList: function(isFirst) {
        var self = this;
        if (typeof isFirst != 'boolean') {
            network.showNetwork.call(self, {
                status: 3,
                loadingDesc: '加载中...'
            });
        };
        request({
            service: '/api/hotel/hoteldetail/image',
            bizType: 'hotel',
            param: {
                seq: self.hotelSeq
            },
            success: function(result) {
                var res = result.data;
                if (res.ret && res.data.images && res.data.images.length > 0) {
                    self.mapImagesDataToState(res.data.images);
                }
            },
            fail: function() {
                network.hideNetwork.call(self, function() {
                    network.showNetwork.call(self, {
                        status: -1,
                        showButton: true,
                        loadingDesc: '网络失败,请重试',
                        networkRetry: 'getImageList',
                        height: '100%'
                    });
                });

            }
        });
    },
    mapImagesDataToState: function(images) {
        var result = [];
        var bigs = [];
        var imgs = [];
        var self = this;

        images.map(function(list) {
            result = result.concat(list.imgNodes)
        });

        imgs = util.pluckArrByKey(result, 'big'); //取大图用于预览地址
        imgs.forEach(function(item){
            bigs.push('https:'+ item);
        });

        network.hideNetwork.call(self, function() {
            self.setData({
                imageMapList: result,
                imageList: bigs,
                opacity: '1'
            });
        });
    },

    previewImage: function(e) {
        var self = this;
        var target = e.currentTarget;
        var url = target.dataset && target.dataset.bigurl || CONSTANTS.DEFAULT_IMG;
        wx.previewImage({
            current: url,
            urls: self.data.imageList
        });
    }
})
