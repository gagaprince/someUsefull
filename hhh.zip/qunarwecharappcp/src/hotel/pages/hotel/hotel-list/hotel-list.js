var Network = require('../../../../common/comps/network/network.js');
var request = require('../../../../common/requester.js').request;
var EventEmitter = require('../../../../common/EventEmitter.js');
var util = require('../../../utils/util.js');
var commonUtil = require('../../../../common/utils.js');
var extend = require('../../../../common/utils/object/extend.js');
var dateFormat = require('../../../../common/utils/date/format.js');
var validator = require('../../../utils/validator.js');
var localStorage = require('../../../utils/localStorage.js');
var navigate = require('../../../common/page.js');
var filterSideBar = require('./filter-sidebar/filter-sidebar.js');
var watcher = require('../../../../common/watcher.js');

var CONSTANTS = require('../../../constants/define.js');
var HOTEL_CACHE_KEY = CONSTANTS.HOTEL_CACHE_KEY;
var HOTEL_EVENT_NAME = CONSTANTS.HOTEL_EVENT_NAME;
var HOTEL_PLACEHOLDER = CONSTANTS.HOTEL_PLACEHOLDER;
var keywordsPlaceHolder = HOTEL_PLACEHOLDER.HOTEL_INDEX_KEYWORDS;

var API = {
    FIRST_DATA: '/hotel/hotellist.c',
    HOTEL_LIST: '/api/hotel/hotellist',
    HOTEL_INDEX_SUGGEST: '/api/hotel/suggest/c',
    HOTEL_INDEX_CITY: '/api/hotel/city/en'
};

Page({
    pageName: 'hotel-list',
    data: {
        priceIndex: 0,
        sortText: '推荐排序',
        starPriceText: '星级价格',
        keywordsPlaceHolder,
        loadText: '',
        hotelListData: [],
        opacity: '0',
        listHeight: 0,
        scrollTop: 0,
        filterData: {
            data: {
                conditionType: ''
            }
        }
    },
    //筛选条件集合
    filterCondition: {},
    //入住离店日期全局变量
    dateParam: {
        startDate: '',
        endDate: ''
    },
    //排序数据
    SORT_DATA: [],
    //筛选数据集合
    RENAR_DATA: [{}, {
        data: {
            starData: [{
                    dname: '不限',
                    qname: '0',
                    checked: true
                },
                {
                    dname: '经济型',
                    qname: '1',
                    checked: false
                },
                {
                    dname: '二星/实惠',
                    qname: '5',
                    checked: false
                },
                {
                    dname: '三星/舒适',
                    qname: '2',
                    checked: false
                },
                {
                    dname: '四星/高档',
                    qname: '3',
                    checked: false
                }, {
                    dname: '五星/豪华',
                    qname: '4',
                    checked: false
                }
            ],
            priceData: [{
                display: '不限',
                data: {
                    MIN: '',
                    MAX: ''
                }
            }, {
                display: '0-150',
                data: {
                    MIN: 0,
                    MAX: 150
                }
            }, {
                display: '150-300',
                data: {
                    MIN: 150,
                    MAX: 300
                }
            }, {
                display: '300-500',
                data: {
                    MIN: 300,
                    MAX: 500
                }
            }, {
                display: '500-800',
                data: {
                    MIN: 500,
                    MAX: 800
                }
            }, {
                display: '800+',
                data: {
                    MIN: 800,
                    MAX: ''
                }
            }]
        }
    }],
    confirmStarSelect: {
        '不限': true
    },
    //共几页
    totalPage: 0,
    _initListener: function() {
        var me = this;
        me._cityListener = EventEmitter.addListener(HOTEL_EVENT_NAME.CITY_SELECT, me.didSelectCity.bind(me));
        me._dateListener = EventEmitter.addListener(HOTEL_EVENT_NAME.ARRIVA_DEPARTURE_DATE_SELECT, me.didSelectDate.bind(me));
        me._keywordListener = EventEmitter.addListener(HOTEL_EVENT_NAME.KEYWORDS_SELECT, me.didSelectKeywords.bind(me));
    },
    onLoad: function(params) {
        var me = this,
            localCity = localStorage.get(HOTEL_CACHE_KEY.TOUCH_CITY) || '',
            localDate = localStorage.get(HOTEL_CACHE_KEY.TOUCH_CHECKIN_CHECKOUT) || {},
            localKeyword = localStorage.get(HOTEL_CACHE_KEY.TOUCH_KEYWORD_SELECT) || '',
            options = {};
        //如果没有传参数
        if (util.isEmptyObject(params)) {
            options.city = localCity == '' ? '北京' : localCity;
            options.keywords = localKeyword;
        } else {
            options.city = params.city;
            options.keywords = params.keywords || '';
        }

        localStorage.set(HOTEL_CACHE_KEY.TOUCH_CITY, options.city);
        localStorage.set(HOTEL_CACHE_KEY.TOUCH_KEYWORD_SELECT, options.keywords);

        me._initListener();
        util.processSystemInfo(me.setListHeight);

        //获取入离店时间
        if (!util.isEmptyObject(localDate)) {
            me.dateParam = localDate;
            extend(true, options, {
                checkInDate: dateFormat(new Date(me.dateParam.startDate), 'mm-dd'),
                checkOutDate: dateFormat(new Date(me.dateParam.endDate), 'mm-dd')
            });
        } else {
            extend(true, options, {
                checkInDate: '',
                checkOutDate: ''
            });
        }

        me.setData(extend(true, {
            starSelectObj: {
                '不限': true
            }
        }, options));

        me.filterCondition = extend(true, {
            extra: {}
        }, options);
    },
    onReady: function() {
        var me = this;
        Network.showNetwork.call(me, {
            status: 4
        });
        //请求首屏数据
        me.loadData(function() {
            me.filterCondition.page = 1;
        }, function(res) {
            var data = res.data,
                req = res.req,
                commonParam = res.commonParam;

            me.SORT_DATA = data.sort;
            me.totalPage = data.totalPage;
            req.extra = req.extra ?
                validator.isObject(req.extra) ?
                req.extra :
                JSON.parse(decodeURIComponent(req.extra)) : {};

            me.filterCondition = req;
            Network.hideNetwork.call(me, function() {
                //校验日期
                me.validateDate(commonParam);
                me.setData({
                    checkInDate: dateFormat(new Date(me.dateParam.startDate), 'mm-dd'),
                    checkOutDate: dateFormat(new Date(me.dateParam.endDate), 'mm-dd')
                });
                if (data.hotels.length) {
                    me.setData({
                        //渲染酒店列表
                        hotelListData: data.hotels,
                        opacity: '1',
                        loadText: me.totalPage > 1 ? '查看更多' : '没有更多啦'
                    });
                } else {
                    Network.showNetwork.call(me, {
                        status: -1,
                        top: '104rpx',
                        height: 'auto',
                        zIndex: 9,
                        loadingDesc: '没有筛选到符合条件的酒店，请扩大筛选范围重新搜索'
                    });
                    me.setData({
                        hotelListData: data.hotels,
                        opacity: '1'
                    });
                }
            });
        }, true);

        watcher.pv({
            "page": "hotel-list"
        });
    },
    onUnload: function(param) {
        this._dateListener && this._dateListener.removeListener();
        this._cityListener && this._cityListener.removeListener();
        this._keywordListener && this._keywordListener.removeListener();
    },
    onShareAppMessage: function() {
        var params = {
            city: this.data.city,
            keywords: this.data.keywords || ''
        };
        return commonUtil.share.getParam({
            url: '/hotel/pages/hotel/hotel-list/hotel-list?' + util.param2query(params),
            title: '去哪儿' + params.city + '市精选酒店',
            desc: '总有一款适合你'
        })
    },
    setListHeight: function(HeightRpx) {
        this.setData({
            listHeight: (HeightRpx - 200) + 'rpx'
        });
    },
    didSelectDate: function(param) {
        var me = this;
        //同步全局变量
        me.dateParam.startDate = dateFormat(new Date(param.startDate), 'yyyy-mm-dd');
        me.dateParam.endDate = dateFormat(new Date(param.endDate), 'yyyy-mm-dd');
        //同步展示日期
        me.setData({
            checkInDate: dateFormat(new Date(me.dateParam.startDate), 'mm-dd'),
            checkOutDate: dateFormat(new Date(me.dateParam.endDate), 'mm-dd')
        });
        //同步缓存
        localStorage.set(HOTEL_CACHE_KEY.TOUCH_CHECKIN_CHECKOUT, param);
        me.reloadHotel();
    },
    didSelectCity: function(param) {
        this.setData({
            city: param.city,
            keywords: ''
        });
        localStorage.set(HOTEL_CACHE_KEY.TOUCH_KEYWORD_SELECT, '');
        localStorage.set(HOTEL_CACHE_KEY.TOUCH_CITY, param.city);

        this.filterCondition.city = param.city;

        this.setData({
            sortText: '推荐排序',
            LAText: '位置区域'
        });

        this.filterCondition.sort = 0;
        this.filterCondition.keywords = '';
        this.filterCondition.extra.LA = '';
        this.reloadHotel();
    },
    didSelectKeywords: function(keywords) {
        this.filterCondition.keywords = keywords;
        this.setData({
            keywords
        });
        this.reloadHotel();
    },
    //选择城市
    selectCity: function(e) {
        watcher.click({
            "page": "hotel-list",
            "action-type": "change-city"
        });
        var params = {
            type: 3, // 0:机票 1:火车票 2:汽车票 3:酒店
            cityListService: API.HOTEL_INDEX_CITY,
            citySuggestService: API.HOTEL_INDEX_SUGGEST,
            eventType: HOTEL_EVENT_NAME.CITY_SELECT,
            placeholder: "请输入城市名称或首字母"
        };
        wx.navigateTo({
            url: '/common/pages/citySelector/citySelector?data=' + JSON.stringify(params)
        });
    },
    //选择入离店日期
    selectDate: function(e) {
        watcher.click({
            "page": "hotel-list",
            "action-type": "change-date"
        });
        var params = {
            date: dateFormat(new Date(this.dateParam.startDate), 'yyyy-mm-dd'),
            eDate: dateFormat(new Date(this.dateParam.endDate), 'yyyy-mm-dd'),
            eventType: HOTEL_EVENT_NAME.ARRIVA_DEPARTURE_DATE_SELECT,
            isDoubleSelect: true,
            calendarDays: 90,
            sText: '入住',
            eText: '离店'
        };
        wx.navigateTo({
            url: '/common/pages/calendar/calendar?data=' + JSON.stringify(params)
        });
    },
    //选择关键词
    selectKeyword: function(e) {
        var keywords = e.currentTarget.dataset.keywords == '' ? '' : e.currentTarget.dataset.keywords,
            city = this.data.city;
        wx.navigateTo({
            url: '../../common/keyword/keyword?city=' +
                city +
                '&keywords=' + keywords
        });
    },
    clearkeyword: function() {
        localStorage.set(HOTEL_CACHE_KEY.TOUCH_KEYWORD_SELECT, '');
        EventEmitter.dispatch(HOTEL_EVENT_NAME.KEYWORDS_SELECT, '');
    },
    showFilter: function(e) {
        var conditionType = e.currentTarget.dataset.type,
            me = this,
            options = {};
        if (me.data.filterData.data.conditionType == conditionType) {
            filterSideBar.hideSideBar.call(me, true);
            return;
        }
        switch (conditionType) {
            case 'sort':
                options = {
                    data: {
                        conditionData: me.SORT_DATA,
                        conditionType,
                        curValue: me.data.sortText
                    },
                    selectEvent: {
                        selectSort: 'selectSort'
                    }
                };
                break;
            case 'starprice':
                options = {
                    data: {
                        conditionType,
                        starData: me.data.starData || me.RENAR_DATA[1].data.starData,
                        priceData: me.RENAR_DATA[1].data.priceData,
                        starSelectObj: me.confirmStarSelect || {
                            '不限': true
                        },
                        priceIndex: me.confirmPrice || '0'
                    },
                    selectEvent: {
                        selectPrice: 'selectPrice',
                        selectStar: 'selectStar',
                        confirmSelect: 'confirmSelect',
                        cancelSelect: 'cancelSelect'
                    }
                };
                break;
        }
        filterSideBar.showSideBar.call(me, options);
    },
    //选择排序
    selectSort: function(e) {
        watcher.click({
            "page": "hotel-list",
            "action-type": "change-sort"
        });
        var data = e.currentTarget.dataset,
            me = this;
        if (data.dname == this.data.sortText) {
            filterSideBar.hideSideBar.call(me, true);
            return;
        }
        filterSideBar.hideSideBar.call(me, true, function() {
            me.setData({
                sortText: data.dname
            });
            me.filterCondition.sort = data.qname;
            me.reloadHotel();
        })
    },
    //选择价格
    selectPrice: function(e) {
        watcher.click({
            "page": "hotel-list",
            "action-type": "change-price"
        });
        var data = e.currentTarget.dataset,
            filterData = this.data.filterData.data,
            index = data.index,
            me = this;
        filterSideBar.hideSideBar.call(me, false, function() {
            me.setData({
                'filterData.data.priceIndex': index == filterData.priceIndex ? 0 : index
            });
        })
    },
    //选择星级
    selectStar: function(e) {
        watcher.click({
            "page": "hotel-list",
            "action-type": "change-star"
        });
        var data = e.currentTarget.dataset,
            filterData = this.data.filterData.data,
            dname = data.dname,
            me = this;

        if (dname == '不限') {
            filterData.starSelectObj = {
                '不限': true
            };
        } else {
            filterData.starSelectObj[dname] ? delete filterData.starSelectObj[dname] : filterData.starSelectObj[dname] = true;
            util.isEmptyObject(filterData.starSelectObj) ? filterData.starSelectObj = {
                '不限': true
            } : filterData.starSelectObj['不限'] && delete filterData.starSelectObj['不限'];
        }
        filterSideBar.hideSideBar.call(me, false, function() {
            me.setData({
                'filterData.data.starSelectObj': filterData.starSelectObj
            });
        })
    },

    //清除星级价格选择
    cancelSelect: function() {
        var filterData = this.data.filterData.data,
            priceIndex = filterData.priceIndex,
            me = this;
        if (priceIndex == 0 && util.isEmptyObject(filterData.starSelectObj)) {
            return;
        }
        filterSideBar.hideSideBar.call(me, false, function() {
            me.setData({
                'filterData.data.starSelectObj': {
                    '不限': true
                },
                'filterData.data.priceIndex': 0
            });
        })
        this.filterCondition.extra.L = [];
    },
    confirmSelect: function() {
        var starArr = [],
            filterData = this.data.filterData.data,
            starData = filterData.starData,
            priceData = filterData.priceData,
            priceIndex = filterData.priceIndex,
            starSelectObj = filterData.starSelectObj,
            starPriceText = '',
            me = this;

        if (priceIndex == 0 && starSelectObj['不限']) {
            starPriceText = '星级价格';
        } else {
            if (priceIndex != 0) {
                starPriceText += priceData[priceIndex].display;
            }
            if (!starSelectObj['不限']) {
                for (var key in starSelectObj) {
                    starPriceText += key;
                }
            }
        }
        starData.forEach(function(item) {
            starSelectObj[item.dname] && starArr.push(item.qname);
        });
        this.confirmStarSelect = starSelectObj;
        this.confirmPrice = priceIndex;
        filterSideBar.hideSideBar.call(me, true, function() {
            me.setData({
                starPriceText
            });
        })
        this.filterCondition.extra.L = starArr.join(',');
        this.filterCondition.extra.MIN = priceData[priceIndex].data.MIN;
        this.filterCondition.extra.MAX = priceData[priceIndex].data.MAX;
        this.reloadHotel();
    },
    //单击遮罩层响应方法
    tapMask: function() {
        var me = this;
        me.setData({
            'filterData.showSideBar': false
        });
    },
    /*加载酒店列表
    beforeCallback:请求返回前的loading效果
    sucCallback:数据返回后的处理方法
    param:请求参数
    isFirstData：是否请求首屏数据。
      true:url为.c
      false:url为api
    */
    loadData: function(beforeCallback, sucCallback, isFirstData) {
        var url = isFirstData ? API.FIRST_DATA : API.HOTEL_LIST,
            me = this;

        beforeCallback && beforeCallback();
        initFilterData(this.filterCondition.extra);
        var param = extend(true, {}, this.filterCondition);
        param.extra = validator.isObject(param.extra) ?
            JSON.stringify(param.extra) : param.extra;
        param.city = param.city ? param.city : '';
        param.keywords = param.keywords ? param.keywords : '';
        param.checkOutDate = param.checkOutDate == '' ? '' : dateFormat(new Date(this.dateParam.endDate), 'yyyy-mm-dd');
        param.checkInDate = param.checkInDate == '' ? '' : dateFormat(new Date(this.dateParam.startDate), 'yyyy-mm-dd');
        request({
            service: url,
            bizType: 'hotel',
            param,
            method: 'POST',
            success: function(res) {
                var res = res.data;
                if (!res.ret) {
                    Network.showNetwork.call(me, {
                        status: -1,
                        showButton: true,
                        loadingDesc: '网络失败,请重试',
                        networkRetry: 'reloadHotel',
                        height: '100%'
                    });
                    me.setData({
                        hotelListData: []
                    });
                    return;
                }
                sucCallback && sucCallback(res);
            },
            fail: function() {
                Network.hideNetwork.call(me, function() {
                    Network.showNetwork.call(me, {
                        status: -1,
                        loadingDesc: '网络失败，请重试',
                        showButton: true,
                        networkRetry: 'reloadHotel',
                        height: '100%'
                    });
                    me.setData({
                        hotelListData: []
                    });
                });
            }
        });
    },
    loadMoreData: function() {
        var page = parseInt(this.filterCondition.page, 10),
            me = this;
        if (page >= me.totalPage) {
            return;
        }
        this.loadData(function() {
            me.filterCondition.page = page + 1;
            Network.showNetwork.call(me, {
                status: 3,
                loadingDesc: '加载中...'
            });
        }, function(res) {
            var data = me.data.hotelListData;
            data.push(...res.data.hotels);
            me.scrollId = res.data.hotels[0].id;
            Network.hideNetwork.call(me, function() {
                me.setData({
                    hotelListData: data,
                    loadText: me.filterCondition.page < me.totalPage ? '查看更多' : '没有更多啦'
                });
                setTimeout(function() {
                    me.setData({
                        scrollView: me.scrollId
                    });
                }, 300);
            });
            me.totalPage = res.data.totalPage;
        }, false);
    },
    reloadHotel: function(from) {
        var me = this;
        me.loadData(function() {
            me.filterCondition.page = 1;
            Network.showNetwork.call(me, {
                status: 3,
                loadingDesc: '加载中...'
            });
            me.setData({
                hotelListData: [],
                loadText: ''
            });
        }, function(res) {
            var data = res.data;
            me.totalPage = data.totalPage;
            Network.hideNetwork.call(me, function() {
                if (!data.hotels.length) {
                    Network.showNetwork.call(me, {
                        status: -1,
                        top: '104rpx',
                        bottom: '97rpx',
                        height: 'auto',
                        zIndex: '',
                        loadingDesc: '没有筛选到符合条件的酒店，请扩大筛选范围重新搜索',
                        networkRetry: 'reloadHotel',
                        loadingDescColor: '#00BCD4'
                    });
                    me.SORT_DATA = data.sort;
                    me.setData({
                        scrollTop: 0,
                        hotelListData: data.hotels,
                        opacity: '1'
                    });
                } else {
                    me.SORT_DATA = data.sort;
                    me.setData({
                        scrollTop: 0,
                        hotelListData: data.hotels,
                        loadText: me.totalPage > 1 ? '查看更多' : '没有更多啦',
                        opacity: '1'
                    });
                }
            });
        }, false);
    },
    handleGodetail: function(e) {
        var seq = e.currentTarget.dataset.id,
            filterCondition = this.filterCondition,
            hotelName = e.currentTarget.dataset.hotelname,
            extra = encodeURIComponent(validator.isObject(filterCondition.extra) ?
                JSON.stringify(filterCondition.extra) : filterCondition.extra),
            param = {
                city: filterCondition.city,
                checkInDate: this.dateParam.startDate,
                checkOutDate: this.dateParam.endDate,
                type: filterCondition.type || '0',
                sort: filterCondition.sort || '0',
                seq: seq, //'beijing_city_2810',
                extra,
                hotelName
            };
        navigate.to('hotel-detail', param);
    },
    validateDate: function(commonParam) {
        var me = this,
            current = commonParam.currentDateStr,
            tommorrow = commonParam.tomorrowDateStr;

        //如果缓存中有日期，则校验缓存的时间。
        if (me.dateParam.startDate) {
            var startDate = me.dateParam.startDate,
                endDate = me.dateParam.endDate;
            //如果今天的日期大于缓存中的起始日期，则缓存中日期作废。
            if (getNightsBetweenDate(startDate, current) > 0) {
                startDate = current;
                endDate = tommorrow;
            }
            //同步全局变量
            me.dateParam.startDate = new Date(startDate);
            me.dateParam.endDate = new Date(endDate);
            //同步缓存
            localStorage.set(HOTEL_CACHE_KEY.TOUCH_CHECKIN_CHECKOUT, {
                startDate: new Date(startDate),
                endDate: new Date(endDate)
            });
        } else {
            //如果没有缓存日期，则直接使用后端返回的起始时间。
            //同步全局变量
            me.dateParam.startDate = new Date(current);
            me.dateParam.endDate = new Date(tommorrow);
            //同步缓存
            localStorage.set(HOTEL_CACHE_KEY.TOUCH_CHECKIN_CHECKOUT, {
                startDate: new Date(current),
                endDate: new Date(tommorrow)
            });
        }
    }
});

function initFilterData(data) {
    for (var key in data) {
        var item = data[key];
        validator.isObject(item) ? util.isEmptyObject(item) && delete data[key] : !item && delete data[key];
    }
}



function getNightsBetweenDate(dateA, dateB) {
    return (new Date(dateB).getTime() - new Date(dateA).getTime()) / (24 * 3600 * 1000)
}
