var extend = require('../../../../../common/utils/object/extend.js');
/*
筛选面板组件：
功能：该组件用于酒店列表四个筛选项的渲染。
数据结构：
data:{
  curValue:{},当前用户选择，用于高亮展示。
  conditionType:'',判断面板类型，对应相应渲染template
  conditionData:[]，渲染数据。
}
showSideBar:boolean, 是否展示面板标志位
selectEvent:[],面板交互响应方法名，string[]
layerEvent:‘’，单击遮罩层区域的响应方法名，string
*/
module.exports = (function() {
    var defaultOptions = {
        data: {
            curValue: '',
            conditionType: '', //排序类型
            conditionData: [] //排序数据
        },
        showSideBar: true,
        selectEvent: '',
        layerEvent: 'tapMask'
    };

    function showSideBar(options) {
        extend(false,defaultOptions, options);
        // defaultOptions = util.extend(defaultOptions, options);
        this.setData({
            filterData: defaultOptions
        });
    }

    function hideSideBar(hideFlag, callback) {
        hideFlag && this.setData({
            'filterData.showSideBar': false,
            'filterData.data.conditionType':''
        });
        callback && callback();
    }

    return {
        showSideBar,
        hideSideBar
    }
})();
