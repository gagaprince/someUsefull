var request = require('../../../../common/requester.js').request;
var util = require('../../../utils/util.js');
var popUp = require('../../../common/component/pop-up/pop-up.js');
var navigate = require('../../../common/page.js');
var Network = require('../../../../common/comps/network/network.js');
var Pay = require('../../../../common/pay.js');
var watcher = require('../../../../common/watcher.js');
var app = getApp();

Page({
    pageName: 'hotel-order-detail',
    data: {
        dialogTexts: {},
        opacity: '0',
        hideDetailpop: true,
        hideMask: true
    },
    options: {},
    originData: {},
    // 取消订单
    cancelOrder: function() {
        watcher.click({
            "page": "hotel-order-detail",
            "action-type": "cancel-order"
        });
        var me = this;
        wx.showModal({
            title: '提示',
            content: '你确定要取消该订单吗？',
            showCancel: true,
            success: function(res) {
                if (res.confirm) {
                    me.dealOrder('cancel');
                }
            }
        });
    },
    // 申请退款
    refundOrder: function() {
        var me = this;
        wx.showModal({
            title: '提示',
            content: '是否确认退掉全部房间？退款金额：￥' +
                me.data.feeDetail.totalPrice + '元',
            showCancel: true,
            success: function(res) {
                if (res.confirm) {
                    me.dealOrder('refund');
                }
            }
        });
    },
    // 查看订单取消规则
    showCancelTip: function() {
        var me = this;
        var cancelRule = me.originData.order.cancelRule,
            extraRule = me.originData.order.extra.alertMsg,
            cancel = me.data.feeDetail.hascancel,
            extra = me.data.feeDetail.hasextra,
            msgs = [];

        if (cancel) {
            msgs.push({
                subTitle: cancelRule.cancelName,
                subImgClass: 'qt-orange icon-c icon-tanhao',
                text: cancelRule.cancelRule
            });
        }
        if (extra && extraRule) {
            msgs.push({
                subTitle: me.originData.order.orderInfo.ptTypeDesc,
                subImgClass: 'qt-blue icon-c icon-price',
                text: extraRule
            });
        }

        popUp.showPopUp.call(me, {
            content: msgs
        });
    },
    // 展示费用明细
    showFeeDetail: function() {
        var me = this;
        var detailObj = me.originData.order.discountInfo;
        me.setData({
            detailData: detailObj,
            hideDetailpop: false,
            hideMask: false
        });
    },
    // 查看担保规则
    showVouchRule: function() {
        var me = this;
        var vouchRule = me.originData.order.orderInfo.vouchInfo.vouchRule;
        popUp.showPopUp.call(me, {
            content: [{
                subTitle: '担保规则',
                subImgClass: 'qt-blue icon-c icon-price',
                text: vouchRule
            }]
        });
    },
    //前往酒店和联系酒店
    getOtherInfo: function(e) {
        var me = this;
        var dataSet = e.currentTarget.dataset,
            type = dataSet.type;
        switch (type) {
            case 'hotel':
                var hotelInfo = me.originData.order.hotelInfo;
                var param = {
                    city: hotelInfo.cityName || '',
                    seq: hotelInfo.hotelSeq || '',
                    firstRoomName: hotelInfo.roomName || '',
                    isLM: 0,
                    extra: '{re:rebooking}'
                };
                navigate.to('hotel-detail', param, false, true);
                break;
        }
    },
    // 展示用户其他要求
    showRequire: function() {
        var me = this;
        me.data.hideUserOtherRequire = !me.data.hideUserOtherRequire;
        me.setData({
            hideUserOtherRequire: me.data.hideUserOtherRequire
        });
    },
    // 展示更多发票信息
    showInvoiceDetail: function() {
        var me = this;
        me.data.hideInvoiceDetail = !me.data.hideInvoiceDetail;
        me.setData({
            hideInvoiceDetail: me.data.hideInvoiceDetail
        });
    },
    // 微信支付 -- 立即支付，继续支付，追加支付
    wxPayAction: function(e) {
        watcher.click({
            "page": "hotel-order-detail",
            "action-type": "pay-order"
        });
        var me = this;
        var dataSet = e.currentTarget.dataset,
            url = dataSet.url;

        Network.showNetwork.call(me, {
            status: 3,
            loadingDesc: '调起支付中'
        });
        request({
            service: url,
            bizType: 'hotel',
            method: 'POST',
            header: {
                'content-type': 'application/x-www-form-urlencoded'
            },
            success: function(res) {
                res = res.data;
                if (!res.ret || !res.data) {
                    Network.hideNetwork.call(me);
                    wx.showModal({
                        title: '提示',
                        content: res.msg || '获取支付地址失败,请稍后重试',
                        showCancel: false
                    });
                    return;
                }
                Network.hideNetwork.call(me);
                Pay.openCashier({
                    cashierUrl: res.data,
                    openId: app.user.openId,
                    bd_source: app.globalData.bd_source,
                    success: function(res) {
                        navigate.to('hotel-order-detail', me.options);
                    },
                    fail: function(error) {
                        //人为失败
                    }
                });
            },
            fail: function(err) {
                Network.hideNetwork.call(me);
                wx.showModal({
                    title: '提示',
                    content: '调起支付失败，请稍后重试。',
                    showCancel: false
                });
            }
        });
    },
    agentPhoneClick: function(e) {
        var dataSet = e.currentTarget.dataset,
            phoneNumber = dataSet.phone;
        if (!phoneNumber) {
            return;
        }
        wx.showModal({
            title: phoneNumber,
            showCancel: true,
            confirmText: '呼叫',
            cancelColor: '#3CC51F',
            confirmColor: '#3CC51F',
            success: function(res) {
                if (res.confirm) {
                    wx.makePhoneCall({
                        phoneNumber: phoneNumber
                    });
                }
            }
        });
    },
    /*
     * @params
     *  {
     *      orderNum: '10098895909',
     *      wrapperId: 'wapqunarqta',
     *      type:0
     *  }
     */
    onLoad: function(options) {
        var me = this;
        me.options = options;
    },
    onReady: function() {
        var me = this;
        Network.showNetwork.call(me, {
            status: 4
        });
        request({
            service: '/hotel/hotelorderdetail.c',
            bizType: 'hotel',
            param: me.options,
            success: function(res) {
                var result = convertFormatOrder(res);
                Network.hideNetwork.call(me, function() {
                    if (result.isEmptyResponse) {
                        Network.showNetwork.call(me, {
                            status: -2,
                            loadingDesc: '没有查询到订单详情'
                        });
                        return;
                    } else {
                        me.originData = res.data.data;
                        result.opacity = '1';
                        me.setData(result);
                    }
                });
            },
            fail: function(err) {
                Network.hideNetwork.call(me, function() {
                    Network.showNetwork.call(me, {
                        status: -1,
                        loadingDesc: '网络错误,请稍后重试'
                    });
                });
            }
        });
        watcher.pv({ "page": "hotel-order-detail" });
    },
    getToken: function(callback) {
        var me = this;
        request({
            service: '/api/hotel/hotelordertoken',
            bizType: 'hotel',
            param: {
                orderNo: me.data.feeDetail.orderNo,
                smobile: me.data.feeDetail.smobile
            },
            success: function(res) {
                if (res && res.data && res.data.ret && res.data.data) {
                    var token = res.data.data;
                    callback(null, token);
                } else {
                    callback({
                        message: '操作失败，请重试'
                    }, null);
                }
            },
            fail: function() {
                callback({
                    message: '网络错误，请稍后再试'
                }, null);
            }
        })
    },
    dealOrder: function(type) {
        var me = this;
        var msg = type === 'cancel' ? '订单取消成功' : '订单退款成功';
        me.getToken(function(err, token) {
            if (err) {
                wx.showModal({
                    title: '提示',
                    content: err.message,
                    showCancel: false
                });
                return;
            }
            request({
                service: '/api/hotel/hotelorderdeal',
                bizType: 'hotel',
                param: {
                    token: token,
                    opType: type === 'cancel' ? 1 : 2,
                    wrapperId: me.options.wrapperId
                },
                success: function(res) {
                    if (res.data && res.data.ret) {
                        wx.showModal({
                            title: '提示',
                            content: msg,
                            showCancel: false,
                            success: function(res) {
                                navigate.to('hotel-order-detail', me.options);
                            }
                        });
                    } else {
                        wx.showModal({
                            title: '提示',
                            content: res.data && res.data.msg || 'error',
                            showCancel: false
                        });
                    }
                },
                fail: function() {
                    wx.showModal({
                        title: '提示',
                        content: '网络错误，请稍后再试',
                        showCancel: false
                    });
                }
            });
        });
    },
    tapMask: function(e) {
        var data = {
            hideMask: true
        };
        if (!this.data.hideDetailpop) {
            data.hideDetailpop = true;
        }
        this.setData(data);
    },
    tapDetailpop: function(e) {
        this.setData({
            hideMask: true,
            hideDetailpop: true
        });
    },
    //弹框事件
    dialogBoxClick: function() {
        popUp.hidePopUp.call(this);
    },
    dialogLayerClick: function() {
        this.dialogBoxClick();
    }
});

/*
  1. 完成渲染数据的清洗，组装
  2. 业务按照展现页面由上而下划分
        功能如下：
        isEmptyResponse     数据是否为空
        orderStatus         订单状态
        feeDetail           费用明细
        hotelInfo           房间信息
        invoiceInfo         发票信息
        orderInfo           订单信息
        aheadWarmTips       温馨提示
        otherHelp           拨打客服电话
*/
function convertFormatOrder(res) {
    var result = {};
    if (!res.data.ret ||
        !res.data.data ||
        !res.data.data.order) {
        result.isEmptyResponse = true;
        return result;
    }

    var data = res.data.data;
    var order = res.data.data.order;
    var orderInfo = res.data.data.order.orderInfo;
    var hotelInfo = res.data.data.order.hotelInfo;

    //订单状态，区分booking订单和非booking订单
    result.orderStatus = {
        status: orderInfo.orderStatus || '',
        mPushCheckInTips: orderInfo.mPushCheckInTips || '',
        orderWarmTips: orderInfo.orderWarmTips || '',
        //是否超时。首先是非booking订单，然后判断是否超时
        isExpired: (!data.isBookingWrapper) && (!!order.ifAdditionalPay)
    };

    //支付和费用明细
    result.feeDetail = {
        ifAdditionalPay: order.ifAdditionalPay || '',
        guara: order.guara, //担保
        hasPayAmount: order.hasPayAmount,
        currentPayAmount: order.currentPayAmount,
        payType: orderInfo.payType,
        totalPrice: orderInfo.totalPrice,

        isBookingWrapper: data.isBookingWrapper,

        currencySign: orderInfo.currencySign,

        //担保规则
        showVouch: order.extra.showVouch &&
            orderInfo.vouchInfo &&
            orderInfo.vouchInfo.vouchMoney &&
            (orderInfo.onlineType != 2) &&
            !data.isBookingWrapper || '',
        vouchInfo: orderInfo.vouchInfo || '',

        // showVouch: true,
        // vouchInfo: orderInfo.vouchInfo,

        //取消规则
        hascancel: !!order.cancelRule,
        cancelType: order.cancelRule.cancelType,
        cancelName: order.cancelRule.cancelName,
        //返现规则
        hasextra: !!orderInfo.ptTypeDesc,
        ptTypeDesc: orderInfo.ptTypeDesc,

        //支付
        payAction: order.payAction && object2array(order.payAction) || '',
        //取消订单
        ifCancel: order.ifCancel,
        smobile: orderInfo.smobile,

        //申请退款
        ifRefund: order.ifRefund,
        orderNo: orderInfo.orderNo,

        //担保支付等提示
        danbaoTip: order.danbao_tip || '',

        //去客户端领取返现
        cashBackTip: order.cashBackTip || ''

    };

    //房间信息
    result.hotelInfo = {
        name: hotelInfo.hotelName,
        address: hotelInfo.hotelAddress,
        roomName: hotelInfo.roomName,
        hotelPhone: hotelInfo.hotelPhone || '',
        bedType: hotelInfo.bedType || '',
        wifi: hotelInfo.wifi || '',
        webfree: hotelInfo.webfree || '',
        breakfast: hotelInfo.breakfast || '',

        staytime: orderInfo.staytime || '',
        orderNo: orderInfo.orderNo,
        userInfo: {
            guestNames: orderInfo.guestNames || '',
            contactPhone: orderInfo.contactPhoneObj &&
                orderInfo.contactPhoneObj.display || '',
            contactEmail: orderInfo.contactEmail || '',
            otherRequire: orderInfo.otherRequire || ''
        }
    };

    //发票信息
    result.invoiceInfo = order.invoiceInfo &&
        order.invoiceInfo.invoiceGetType &&
        (order.invoiceInfo.invoiceGetType != 0) &&
        order.invoiceInfo ||
        '';

    //订单信息,区分booking订单和非booking订单
    result.orderInfo = {
        orderNo: orderInfo.orderNo,
        isBookingWrapper: data.isBookingWrapper,
        //如果是代理商，则取到代理商名字等
        //TODO: 不是代理商也要展示头像？
        otaName: order.otaInfo && order.otaInfo.otaName,
        otaLogo: order.otaInfo && order.otaInfo.otaLogo,
        orderDate: orderInfo.orderDate,
        //Booking.com订单编码
        otaOrderNo: orderInfo.otaOrderNo,
        //Booking.com订单查询密码
        otaOrderNoCode: orderInfo.otaOrderNoCode
    };

    //温馨提示
    result.warmtips = {
        aheadWarmTips: orderInfo.aheadWarmTips || '',
        activityDesc: orderInfo.activityDesc || ''
    };

    //拨打客服电话
    result.otherHelp = {
        servicePhones: order.servicePhones.filter(function(item) {
            return item.title && item.telephone;
        })
    };
    return result;
}

function object2array(obj) {
    var arr = [];
    for (var key in obj)
        arr.push({
            key: key.replace('&nbsp;&yen;', ' ￥'),
            value: obj[key]
        })
    return arr;
}
