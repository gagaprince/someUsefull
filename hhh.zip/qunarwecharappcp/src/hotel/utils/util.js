/**
 * {a:"1","b":2,c:"%E4%B8%AD%E5%9B%BD"}  =>  a=1&b=2&c="中国"
 * @param param
 * @returns {*}
 */
function param2query(param) {
    if (typeof param !== 'object') {
        return '';
    }
    var queries = [];
    for (var i in param)
        if (param.hasOwnProperty(i)) {
            param[i] && queries.push(i + '=' + param[i])
        }
    return queries.join('&');
}

function ellipsisString(str, len) {
    if (!str || str.length <= len) {
        return str;
    }
    return str.substring(0, len) + '...';
}

function isEmptyObject(obj) {
    for (var key in obj) {
        return !key;
    }
    return true;
}

/**
 * var stooges = [{name: 'moe', age: 40}, {name: 'larry', age: 50}];
 * pluckArrByKey(stooges, 'name');
 * => ["moe", "larry", "curly"]
 * @returns Array
 */
function pluckArrByKey(arr, propertyName) {
    var result = [];
    result = arr.map(function(item) {
        return item[propertyName];
    });
    return result;
}

function objLength(obj) {
    var count = 0;
    for (var key in obj) {
        if (key) {
            count++;
        }
    }
    return count;
}

function processSystemInfo(callback) {
    wx.getSystemInfo({
        success: function(res) {
            var HeightRpx = res.windowHeight * 750 / res.windowWidth
            callback && callback(HeightRpx);
        }
    });
}

/** 可以用于任何对象( 数组，字符串，数字，对象) 的深层复制 **/
function clone(target) {
    return JSON.parse(JSON.stringify(target));
}
module.exports = {
    processSystemInfo,
    isEmptyObject,
    param2query,
    ellipsisString,
    pluckArrByKey,
    objLength,
    clone
}
