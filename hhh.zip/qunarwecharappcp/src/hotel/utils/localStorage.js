module.exports = {
    get: function(key) {
        try {
            return wx.getStorageSync(key);
        } catch(err) {
            return null;
        }
    },
    set: function(key, data) {
        try {
            return wx.setStorageSync(key, data);
        } catch(err) {
            return null;
        }
    }
};