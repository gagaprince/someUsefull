'use strict';
let typeOf = (val) => {
  if (typeof val === 'string' || val instanceof String) {
    return 'string';
  }
  // array
  if (typeof Array.isArray !== 'undefined' && Array.isArray(val)) {
    return 'array';
  }
};

let isObject = (obj) => {
    return Object.prototype.toString.call(obj) === '[object Object]';

};

let isArray = (arr) => {
    return typeOf(arr) === 'array';
};

let isString = (str) => {
    return typeOf(str) === 'string';
};

module.exports = {
    isArray,
    isObject,
    isString
};
