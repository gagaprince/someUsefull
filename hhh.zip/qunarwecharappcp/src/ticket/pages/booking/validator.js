var Validator = require("../../utils/validator.js");
var OrderValidator = function() {};

OrderValidator.validateTextInput = function(val, type) {
    var ret = false;
	switch(type) {
		case "name":
			ret = Validator.validateName(val);
			break;
		case "mobile":
			ret = Validator.validateMobile(val);
			break;
		case "numbers":
			ret = Validator.validateNumbers(val);
			break;
		case "idcard":
			ret = this.checkIdCard(val);
			break;
		case "email":
			ret = Validator.validateEmail(val);
			break;
		case "date":
			ret = Validator.validateDate(val);
			break;
		case "hoteldate":
			ret = Validator.validateDate(val);
			break;
		case "passport":
			ret = Validator.validatePassCard(val);
			break;
		case "pinyin":
			ret = Validator.validatePinyin(val);
			break;
		case "taibao":
			ret = Validator.validateTaibao(val);
			break;
		case "gangao":
			ret = Validator.validateGangao(val);
			break;
        case "taiwan":
            ret = Validator.validateTaiwan(val);
            break;
        case "rutai":
            ret = Validator.validateRutai(val);
            break;
        case "nationality":
            ret = Validator.validateNationality(val);
            break;
		case "zipcode":
			ret = Validator.validateZipcode(val);
			break;
		case "address":
			if(!val || val.length < 4) {
				ret = false;
			}
			break;
		case "need":
			ret = Validator.validateNeed(val);
			break;
		default:
			break;
	}

	return ret;
};

OrderValidator.checkIdCard_ = function(num) {
	num = num.toUpperCase();

	//身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X。
	if (!(/(^\d{15}$)|(^\d{17}([0-9]|X)$)/.test(num))) {
		return -1;
	}

	//校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
	//下面分别分析出生日期和校验位

	var len, re;
	len = num.length;
	if (len == 15) {

		re = new RegExp(/^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/);
		var arrSplit = num.match(re);

		//检查生日日期是否正确
		var dtmBirth = new Date('19' + arrSplit[2] + '/' + arrSplit[3] + '/' + arrSplit[4]);
		var bGoodDay = (dtmBirth.getYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));

		if (!bGoodDay) {
			return -2;
		} else {
			return 1;
		}
	}

	if (len == 18) {

		re = new RegExp(/^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/);
		var arrSplit = num.match(re);

		//检查生日日期是否正确
		var dtmBirth = new Date(arrSplit[2] + "/" + arrSplit[3] + "/" + arrSplit[4]);
		var bGoodDay = (dtmBirth.getFullYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));

		if (!bGoodDay) {
			return -2;
		} else {
			//检验18位身份证的校验码是否正确。
			//校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
			var valnum;
			var arrInt = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
			var arrCh = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];
			var nTemp = 0,
				i;
			for (i = 0; i < 17; i++) {
				nTemp += num.substr(i, 1) * arrInt[i];
			}

			valnum = arrCh[nTemp % 11];

			if (valnum != num.substr(17, 1)) {
				return -2;
			}

			return 1;
		}
	}

	return -2;
};

OrderValidator.checkIdCard = function(sId) {
	return this.checkIdCard_(sId) == 1;
};

OrderValidator.MessageMap = {
	name: "请填写真实姓名",
	mobile: "请填写正确的手机号码",
	idcard: "请填写正确的身份证号",
	email: "请填写正确的邮箱",
	date: "请选择游玩日期",
	hoteldate: "请选择酒店入住日期",
	pinyin: "请填写姓名拼音",
	taibao: "请填写正确的台胞证号",
	passport: "请填写正确的护照号码",
	zipcode: "请填写正确的邮政编码",
	gangao: "请填写正确的港澳通行证号",
	enteroption:"请选择入园日期",
    taiwan: "请填写正确的台湾通行证",
    rutai: "请填写正确的入台证",
    nationality: "国籍请填写20以内汉字"
};

module.exports = OrderValidator;