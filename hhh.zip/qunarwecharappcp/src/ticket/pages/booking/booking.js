var NumberInput = require('../../components/numberinput/numberinput.js'),
    EventEmitter = require('../../../common/EventEmitter.js'),
    PassengerContainer = require('../../components/passenger/passenger.js'),
    Contact = require('../../components/contact/contact.js'),
    ProductDetailLayer = require('../../components/productdetail/productdetail.js'),
    OrderValidator = require('./validator.js'),
    Pay = require("../../../common/pay.js"),
    User = require("../../../common/user.js"),
    Requester = require("../../../common/requester.js"),
    Config = require("../../config.js"),
    Watcher = require('../../../common/watcher.js'),
    Network = require('../../../common/comps/network/network.js'),
    Navigation = require('../../../common/navigation.js'),
    app = getApp();

Page({
    data: {
        windowHeight: "",
        numberinput: {},
        contact: {},
        passengerContainer: {},
        selectCategory: {},
        price: "",
        coupon: "",
        useDate: "",
        calendarChecked: false,
        count: "",
        dateCard: {},
        discounts: "",
        realPayment: "",
        passengerCount: 0,
        refundDesc: "",
        productType: "",
        showRefundTips: false,
        showPriceDetail: false,
        teamType: "",
        dto: {}
    },

    numberinputObj_: {},
    calendar: null,
    latitude: '',
    longitude: '',

    onShow: function() {
        Watcher.pv({ "page": "ticket_booking"});
    },

    onLoad: function(data) {
        this.requestParam_ = {};
        this.productId_ = data.pid || "1296609469";
        this.requestParam_.pid = data.pid || "1296609469";
        if (data.sightid) {
            this.requestParam_.sid = data.sightid;
        }
        if (data.priceid) {
            this.requestParam_.priceId = data.priceid
        }
        this._listener = EventEmitter.addListener("dateChange", this.handleSelectDate);
        this.initPageHeight();
        this.getPreOrderInfo(this.requestParam_);
        this.ProductDetailLayer = new ProductDetailLayer(this, false);
        this.getLocationInfo();
    },

    getLocationInfo: function() {
        var this_ = this;
        wx.getLocation({
            type: 'wgs84',
            success: function(response) {
                this_.latitude = response.latitude,
                this_.longitude = response.longitude
            }
        });
    },

    initPageHeight: function() {
        var app = getApp();
        var deviceInfo = app.globalData.deviceInfo;
        this.setData({
            windowHeight: deviceInfo.windowHeight
        });
    },

    handleShowProdDetail: function(e) {
        var data = e.currentTarget.dataset;
        this.ProductDetailLayer.getData(data.pid);
    },

    bindCloseProdDetailTap: function() {
        this.ProductDetailLayer.close();
    },

    getPreOrderInfo: function(param) {
        var this_ = this;
        Network.showNetwork.call(this_, {
            status: 4
        });
        Requester.request({
            host: Config.requestPath,
            service: Config.preOrderUrl,
            param: param || {},
            method: "GET",
            success: function(res) {
                Network.hideNetwork.call(this_);
                this_.handleGetInfoSuccess(res.data);
            },
            fail: function(formData) {
                this_.handleGetInfoError();
            },
            complete: function() {
                wx.hideToast();
            }
        });
    },

    handleGetInfoSuccess: function(res) {
        if (!res.ret) {
            wx.showModal({
                title: "提示",
                content: res.errmsg,
                showCancel: false
            });
            return;
        }
        this.decorateData(res.data);
        this.initNumberInput();
        this.initPassengerContainer();
        var num = this.getNumberInput("number1").getValue();
        this.handleNumberChange(num);
    },

    handleGetInfoError: function() {
        var this_ = this;
        wx.showModal({
            title: "提示",
            content: "获取数据失败，请检查网络后重试",
            confirmText: "重试",
            success: function(res) {
                if (res.confirm) {
                    this_.getPreOrderInfo(this_.requestParam_);
                }
            }
        });
    },

    clearDate: function() {
        //清理之前的日期选择
        wx.removeStorage({
            key: 'ticket_date',
            success: function() {}
        });
        wx.getStorageSync('ticket_date');
    },

    decorateData: function(data) {
        var data = data || {},
            numberinput = {
                key: "number1",
                max: data.maxBuyCount || 999,
                min: data.minBuyCount || 1,
                value: 1,
                minusCallback: "handleClickMinus",
                plusCallback: "handleClickPlus",
                inputCallback: "bindKeyInput"
            };
        this.clearDate();
        //压缩尺寸数据contact
        this.mobileRule = data.mobileRule;
        this.userRule = data.userRule;
        this.userPinyinRule = data.userPinyinRule;
        this.emailRule = data.emailRule;
        this.postAddressRule = data.postAddressRule;
        this.couponContent = data.couponContent;
        //压缩尺寸后端传配置passenger
        this.dmCardInfo = data.cardInfo;
        this.dmInputName = data.inputName;
        this.dmInputNamePinyin = data.inputNamePinyin;
        this.dmInputMobile = data.inputMobile;
        this.dmInputIdNo = data.inputIdNo;
        this.dmInputNationality = data.inputNationality;
        this.dmInputDateOfBirth = data.inputDateOfBirth;
        this.dmInputSex = data.inputSex;
        this.dmInputUserDefine1 = data.inputUserDefine1;
        this.dmInputUserDefine2 = data.inputUserDefine2;
        // 联系人
        this.contact = new Contact(this, "contact", data.needContactMobile, data.needContactName, data.needContactPinyin, data.needContactEmail, data.needContactPostalInfo);
        var contactInfo = this.contact.getContactInfo();
        if (data.needTravellerInfo) {
            var passengerContainer = {
                passenger: {
                    cardTypes: [],
                    showCardTypes: false,
                    currCard: {},
                    needPassengerName: data.needPassengerName,
                    needPassengerPinyin: data.needPassengerPinyin,
                    needPassengerMobile: data.needPassengerMobile,
                    needPassengerNationality: data.needPassengerNationality,
                    needPassengerDateOfBirth: data.needPassengerDateOfBirth,
                    needPassengerSex: data.needPassengerSex,
                    needPassengerIDCard: data.needPassengerIDCard,
                    needPassengerPassport: data.needPassengerPassport,
                    needPassengerTaiwanPermit: data.needPassengerTaiwanPermit,
                    needPassengerHKAndMacauPermit: data.needPassengerHKAndMacauPermit,
                    needPassengerMTPFTWResidents: data.needPassengerMTPFTWResidents,
                    needPassengerTaiwanEntryPermit: data.needPassengerTaiwanEntryPermit,
                    needPassengerUserDefinedItem1: data.needPassengerUserDefinedItem1,
                    needPassengerUserDefinedItem2: data.needPassengerUserDefinedItem2,
                    passengerUserDefinedItem1: data.passengerUserDefinedItem1,
                    passengerUserDefinedItem2: data.passengerUserDefinedItem2,
                    "inputs": {}
                },
                passengerList: [],
                passengerInfoPerNum: data.passengerInfoPerNum
            };
        }
        var selectCategory = data.categoryInfo || {},
            categoryList = selectCategory.categoryList || [],
            refundDesc = "";

        for (var i in categoryList) {
            var category = categoryList[i];
            if (category.type === "CALENDAR") {
                var values = category.values || [];
                values.splice(2, 1);
                for (var j in values) {
                    var value = values[j];
                    value.callback = "handleClickOtherDate";
                    value.valid = true;
                }
            }
        }

        if (data.canRefundType == '随心退') {
            refundDesc = "可以退款";
        } else if (data.canRefundType == '条件退') {
            refundDesc = "退款有限制条件";
        } else if (data.canRefundType == '不可退') {
            refundDesc = "不可退款";
        }
        this.data.couponInfo = this.initCoupons(data);
        this.setData({
            numberinput: numberinput,
            contact: contactInfo,
            passengerContainer: passengerContainer,
            selectCategory: data.categoryInfo,
            price: data.qunarPrice,
            productType: data.productType,
            teamType: data.teamType,
            refundDesc: refundDesc,
            couponInfo: this.data.couponInfo,
            dto: data
        });
    },

    initNumberInput: function() {
        var numberinput = this.data.numberinput;
        this.numberinputObj_ = new NumberInput(this, "numberinput", numberinput.max, numberinput.min, numberinput.value);
    },

    getNumberInput: function(key) {
        return this.numberinputObj_;
    },

    handleClickPlus: function(e) {
        var target = e.target,
            dataset = target.dataset,
            key = dataset.key,
            numberinput = this.getNumberInput(key);
        if (numberinput) {
            numberinput.stepUp();
            this.handleNumberChange(numberinput.getValue());
        }
    },

    handleClickMinus: function(e) {
        var target = e.target,
            dataset = target.dataset,
            key = dataset.key,
            numberinput = this.getNumberInput(key);
        if (numberinput) {
            numberinput.stepDown();
            this.handleNumberChange(numberinput.getValue());
        }
    },

    bindKeyInput: function(e) {
        var target = e.target,
            value = e.detail.value,
            dataset = target.dataset,
            key = dataset.key,
            numberinput = this.getNumberInput(key);
        numberinput.setValue(value);
        this.handleNumberChange(numberinput.getValue());
    },

    handleClickOtherDate: function(e) {
        var curDate = "",
            value = wx.getStorageSync('ticket_date');
        curDate = value ? JSON.parse(value).date : "";
        //config
        var params = {
            bizType: 'ticket', // 业务线
            eventType: "dateChange", // 选择日期成功之后触发的事件，通过监听这个事件来得到响应
            storageType: "ticket_date", // 将选中的日期放到这个storage里面。
            date: curDate,
            calendarDays: 90, // 日历展示多少天
            url: encodeURIComponent('/ticket/qwechat/sight/newCalendar.json'), // 请求日历数据的url，一定要encode
            reqData: { // 请求日历数据的 参数
                productId: this.productId_
            }
        };
        // 传的时候将JSON.stringify(params) 放到data参数上面

        Navigation.goTo('ticketBooking', {
            url: '/common/pages/calendar/calendar',
            data: {
                data: JSON.stringify(params)
            }
        });
    },

    handleSelectDate: function(data) {
        var dataset = data,
            price = dataset.price,
            date = dataset.date,
            coupon = dataset.coupon,
            disabled = dataset.disabled;
        if (!disabled) {
            this.changeDate(date, price, coupon);
        }
    },

    changeDate: function(date, price, coupon) {
        // 更新使用日期，价钱和返现
        this.setData({
            useDate: date,
            calendarChecked: true,
            price: price,
            coupon: coupon
        });
        this.calculateMoney();
        // 更新退款说明和库存
        this.getRemainAndRefundInfo(date);
    },

    calculateMoney: function() {
        var num = this.getNumberInput().getValue(),
            total = parseInt(Math.round(this.data.price * num * 100)) / 100,
            discounts = 0,
            realPayment = total - discounts;
        //如果是活动产品，需要减掉可用券
        var couponInfo = this.data.couponInfo;
        var this_ = this;
        if (couponInfo && couponInfo.coupons && couponInfo.coupons.length && couponInfo.couponListStr) {
            wx.showToast({
                icon: "loading",
                title: "正在计算价格...",
                duration: 3000
            });
            var params = {
                "priceId": this.requestParam_.priceId,
                "productId": this.requestParam_.pid,
                "productCount": num,
                "useDate": this.data.useDate,
                "selectedInfos": couponInfo.couponListStr
            };
            Requester.request({
                host: Config.requestPath,
                service: Config.orderCalCouponUrl,
                param: params || {},
                method: "GET",
                success: function(res) {
                    realPayment = res.data.data.couponInfo.orderPrice;
                    res.data.data.couponInfo.couponListStr = couponInfo.couponListStr;
                    var status = "0";
                    try {
                        if(!JSON.parse(res.data.data.couponInfo.couponListStr)[0].couponNo) {
                            status = "1";
                            res.data.data.couponInfo.currentTitle = "不使用优惠券";
                        }
                    } catch (ex) {

                    }
                    res.data.data.couponInfo.coupons.push({
                        "info":{
                            "strategyId":"",
                            "couponNo":"",
                            "activiyNo":""
                            },
                        "price":"",//面额
                        "title":"不使用优惠券",
                        "desc":"",
                        "status": status,
                        "timeDesc":""
                    });
                    this_.setData({
                        realPayment: realPayment,
                        count: num,
                        couponInfo: res.data.data.couponInfo
                    });
                },
                fail: function(formData) {
                    
                },
                complete: function() {
                    wx.hideToast();
                }
            });
        } else {
            this.setData({
                realPayment: realPayment,
                count: num
            });
        }
    },

    initCoupons: function(data) {
        var couponInfo = data.couponInfo;
        var showTitle = '',
            couponListStr = '',
            index = 0,
            temp = '';
        if (couponInfo && couponInfo.coupons && couponInfo.coupons.length) {
            //不选优惠券
            couponInfo.coupons.push({
                "info":{
                    "strategyId":"",
                    "couponNo":"",
                    "activiyNo":""
                    },
                "price":"",//面额
                "title":"不使用优惠券",
                "desc":"",
                "status":"0",
                "timeDesc":""
            });
            //默认选第一张，如果前几张是不可用的券需要选中最近一张可用的
            for (var i = 0; i < couponInfo.coupons.length; i++) {
                if (couponInfo.coupons[i].status != -1) {
                    index = i;
                    break;
                }
            }
            showTitle = couponInfo.coupons[index].title;
            temp = couponInfo.coupons[index].info;
            couponListStr = [{
                "strategyId": temp.strategyId,
                "couponNo": temp.couponNo,
                "activiyNo": temp.activiyNo
            }];
            couponInfo.coupons[index].status = 1;
            couponInfo.currentTitle = showTitle;
            couponInfo.couponListStr = JSON.stringify(couponListStr);
            return couponInfo;
        } else {
            return {};
        }
        
    },

    handleShowCoupons: function() {
        if (this.data.couponInfo && this.data.couponInfo.showCoupons) {
            this.data.couponInfo.showCoupons = false;
        } else {
            this.data.couponInfo.showCoupons = true;
        }
        this.setData({
            couponInfo: this.data.couponInfo
        });
    },

    handleChangeCoupons: function(e) {
        var value = e.detail.value;
        var valarr = value.split("#");
        var dataObj = [{
            "strategyId": valarr[0],
            "couponNo": valarr[1],
            "activiyNo": valarr[2]
        }];
        for (var i = 0; i < this.data.couponInfo.coupons.length; i++) {
            if(this.data.couponInfo.coupons[i].info.couponNo == valarr[1]) {
                this.data.couponInfo.coupons[i].status = 1;
                this.data.couponInfo.currentTitle = this.data.couponInfo.coupons[i].title;
                break;
            }
        }
        this.data.couponInfo.showCoupons = false;
        this.data.couponInfo.couponListStr = JSON.stringify(dataObj);
        this.calculateMoney();
        this.setData({
            couponInfo: this.data.couponInfo
        });
    },

    initPassengerContainer: function() {
        if (!this.passengerContainer) {
            var data = this.data.passengerContainer || {};
            this.passengerContainer = new PassengerContainer(this, "passengerContainer", data.passengerList, data.passenger, data.passengerInfoPerNum);
            this.passengerContainer.init();
        }
    },

    handleShowCardType: function(e) {
        var index = e.currentTarget.dataset.passengerIndex;
        this.passengerContainer.showCardTypes(index);
    },

    handleChangeCardType: function(e) {
        var type = e.detail.value;
        var index = e.currentTarget.dataset.passengerIndex;
        this.passengerContainer.changeCardType(index, type);
    },

    handleNumberChange: function(num) {
        this.calculateMoney();
        this.passengerContainer.changeNumber(num);
    },

    // 下单部分
    handleSubmitOrder: function(e) {
        var detail = e.detail,
            formData = detail.value || {};
        this.contactMobile = formData.contactMobile;
        if (this.data.teamType == 0 && !this.data.useDate) {
            wx.showToast({
                title: "请选择游玩日期"
            });
        } else if (this.contact.validateAllInputs() && this.passengerContainer.validateAllInputs()) {
            this.submitOrder(formData);
        }
    },

    submitOrder: function(formData) {

        if (this.data.submiting == true) {
            return;
        }

        this.changeSubmitStatus(true);

        formData = formData || {};

        if (app.globalData.tkt_newuser) {
            formData.isNewUser = true;
        }
        
        if (app.globalData.tkt_bdid) {
            formData.bdId = app.globalData.tkt_bdid;
        }

        if (this.latitude) {
            formData.lat = this.latitude;
            formData.lng = this.longitude;
        }

        var this_ = this;

        Requester.request({
            host: Config.requestPath,
            service: Config.submitOrderUrl,
            param: formData,
            method: "POST",
            success: function(response) {
                var response = response.data;
                this_.handleSubmitSuccess(response);
            },
            fail: function(formData) {
                wx.showModal({
                    title: "提示",
                    content: "下单失败，请检查网络后重试",
                    confirmText: "重试",
                    success: function(res) {
                        if (res.confirm) {
                            this_.submitOrder(formData);
                        }
                    }
                });
            },
            complete: function() {
                this_.changeSubmitStatus(false);
            }
        });
        Watcher.click({"page": "ticket_booking", "action-type": "ticket_pay"});
    },

    changeSubmitStatus: function(isSubmiting) {
        this.setData({
            submiting: isSubmiting
        });
    },

    handleSubmitSuccess: function(response) {
        var this_ = this;

        if (!response.ret || !response.data) {
            wx.showModal({
                title: "下单失败",
                content: response.errmsg,
                showCancel: false
            });
            return;
        }else {
            // 首单统计参数变更
            app.globalData.tkt_newuser = false;
        }
        if (response.data.goToCashier && response.data.cashierUrl) {
            var payStatus = "",
                opt = {
                    cashierUrl: response.data.cashierUrl,
                    openId: response.data.openId,
                    bd_source: "wx",
                    success: function(res) {
                        payStatus = 1;
                    },
                    fail: function(error) {
                        payStatus = 0;
                    },
                    complete: function() {
                        var result, text = '';
                        if (payStatus == 1) {
                            result = '_success';
                            text = '支付成功，';
                        } else if (payStatus == 0) {
                            result = '_fail';
                            text = '支付失败，';
                        } else {
                            result = '_cancel';
                            text = '支付取消，';
                        }

                        wx.showToast({
                            icon: "loading",
                            title: text + "，正在跳转订单详情页...",
                            duration: 3000
                        });

                        Navigation.goTo('ticketBooking', {
                            url: Config.routes.orderdetail,
                            data: {
                                orderId: response.data.orderId,
                                mobile: this_.contactMobile
                            },
                            complete: function() {
                                wx.hideToast();
                            }
                        });
                    }
                };

            Pay.openCashier(opt);

        } else {
            wx.showToast({
                icon: "loading",
                title: "下单成功，正在跳转订单详情页...",
                duration: 3000
            });
            Navigation.goTo('ticketBooking', {
                url: Config.routes.orderdetail,
                data: {
                    orderId: response.data.orderId,
                    mobile: this_.contactMobile
                },
                complete: function() {
                    wx.hideToast();
                }
            });
        }
    },

    // 展示分类产品有效期validDayOfWeekAndTimeRange
    handleShowMoreValidDay: function(e) {
        wx.showModal({
            title: "有效期",
            content: e.target.dataset.content,
            showCancel: false
        });
    },

    handleShowCouponRule: function() {
        wx.showModal({
            title: "代金券使用规则",
            content: this.couponContent,
            showCancel: false
        });
    },

    handleCallCustomer: function(e) {
        wx.makePhoneCall({
            phoneNumber: e.target.dataset.phone
        });
    },

    getRemainAndRefundInfo: function(useDate) {
        // 设置的最大最少购买数量跟日期无关，退款、购买限制和库存跟日期有关
        var this_ = this;
        wx.request({
            header: {"content-type": "application/x-www-form-urlencoded"},
            url: Config.remainAndRefundUrl,
            data: {
                productId: this.productId_,
                useDate: useDate,
                maxBuyCount: this.numberinputObj_.getMax(),
                minBuyCount: this.numberinputObj_.getMin()
            },
            method: "POST",
            dataType: "json",
            success: function(response) {
                var response = response.data;
                this_.getRemainAndRefundSuccess.apply(this_, [response]);
            },
            fail: function(formData) {
                // 不给用户提示
                console.log("退款信息和库存接口请求失败");
            }
        })
    },

    getRemainAndRefundSuccess: function(response) {
        if (!response.ret || !response.data) {
            // 不给用户提示
            return;
        }
        var lastRefundInfo = response.data.lastRefundInfo || {};
        var remainCountInfo = response.data.remainCountInfo || {};
        this.resetRefundInfo(lastRefundInfo);
        this.resetRemainInfo(remainCountInfo);
    },

    resetRefundInfo: function(lastRefundInfo) {
        var lastRefundInfo = lastRefundInfo || {};
        var refundDesc = "";
        var showRefundTips = false;

        if (lastRefundInfo.canRefund) {
            if (lastRefundInfo.hasLastRefundLimit) {
                refundDesc = "退款有限制条件";
            } else {
                refundDesc = "可以退款";
            }
        } else {
            refundDesc = "不可退款";
            //判断产品退款状态,产品设置为可退但当前日期不可退将更新状态,显示不可退款的tips
            var preOrderInfo = this.data.dto;
            if (preOrderInfo.canRefund && preOrderInfo.teamType == '0') {
                // teamType为0是日历模式，为1是分类模式,展示不同的提示信息
                var showRefundTips = true;
            }

            this.setData({
                refundDesc: refundDesc,
                showRefundTips: showRefundTips
            });
        }
    },

    resetRemainInfo: function(remainCountInfo) {
        var remainCountInfo = remainCountInfo || {};

        this.setData({
            "dto.limitDesc": remainCountInfo.limitDesc || "",
            "dto.remainCount": remainCountInfo.remainCount || ""
        });
    },

    // validate
    handleContactInputValue: function(e) {
        var value = e.detail.value;
        var dataset = e.currentTarget.dataset;
        var key = dataset.key;
        this.contact.setInputValue(key, value);
    },

    handleContactInputBlur: function(e) {
        var value = e.detail.value;
        var dataset = e.currentTarget.dataset;
        var key = dataset.key;
        this.contact.validateInput(key, value);
    },

    handleClickContactErrorMsg: function(e) {
        var dataset = e.currentTarget.dataset;
        var key = dataset.key;
        this.contact.focus(key);
    },

    handlePassengerInputBlur: function(e) {
        var dataset = e.currentTarget.dataset;
        var index = dataset.index;
        var key = dataset.key;
        var value = e.detail.value;
        this.passengerContainer.validateInput(index, key, value);
    },
    handleClickPassengerErrorMsg: function(e) {
        var dataset = e.currentTarget.dataset;
        var index = dataset.index;
        var key = dataset.key;
        this.passengerContainer.focus(index, key);
    },
    handlePassengerInputValue: function(e) {
        var dataset = e.currentTarget.dataset;
        var index = dataset.index;
        var key = dataset.key;
        var value = e.detail.value;
        this.passengerContainer.setInputValue(index, key, value);
    }
});
