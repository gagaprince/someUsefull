var TICKET_CONFIG = require('../../config.js'),
    Watcher = require('../../../common/watcher.js'),
    Utils = require('../../../common/utils.js'),
    app = getApp(),
    Navigation = require('../../../common/navigation.js');

Page({

    data: {
        "aroundSight": {},
        "suggestList": {},
        "hotSight": {},
        "isIos": app.globalData.deviceInfo.isIOS,
        "searchValue":"",
        "isInit": false,
        "isShowAround": true,
        "isShowSuggest": false
    },

    sendingStatus: false,
    latitude: '',
    longitude: '',


    onShareAppMessage: function () {
        return Utils.share.getParam({
            url: TICKET_CONFIG.routes.list + '?bd_origin=ticket_list_share',
            title: "去哪儿网门票",  
            desc: "玩乐景点门票一网打尽！尽享优惠和便利~",   
            jumpType: 'navigateTo'  
        });
    },

    onLoad: function (data) {
        wx.showToast({
            title: '加载中',
            icon: 'loading',
            duration: 30000
        });
        this.getLocationInfo();
    },

    onShow: function(param) {
        Watcher.pv({ "page": "ticket_list" });
    },

    getLocationInfo: function() {
        var this_ = this;
        wx.getLocation({
            type: 'wgs84',
            success: function(response) {
                this_.latitude = response.latitude,
                this_.longitude = response.longitude
                this_.getNearBySights();
            },
            fail: function(err) {
                this_.getNearBySights();
            }
        });
    },

    getNearBySights: function() {
        var this_ = this,
            data =  {};

        wx.request({
            url: TICKET_CONFIG.getAroundSight,
            data: {
                lat: this_.latitude,
                lng: this_.longitude
            },
            header: {'content-type': 'application/json'},
            success: function(response) {
                response = response.data;
                var result = response.data;
                wx.hideToast();
                this_.setData({
                    "isInit": true,
                    "isShowAround": true,
                    "aroundSight": result.aroundSight,
                    "hotSight": result.hotSight
                });
            }
        });
    },

    handleClearInput: function(e) {
        this.setData({
            searchValue: "",
            isShowAround: true,
            isShowSuggest: false
        });
    },

    bindDetailViewTap: function(e) {
        var target = e.currentTarget,
            sightId = target.dataset.sightid;

        Navigation.goTo('ticketBooking', {
            url: TICKET_CONFIG.routes.detail,
            data: {
                sightid: sightId,
            }
        });
    },

    bindKeyInput: function(e) {
        var key = e.detail.value;
        if (key.trim() == "") {
            this.setData({
                isShowAround: true,
                isShowSuggest: false
            });
        }else if(!this.sendingStatus) {
            this.sendingStatus = true;

            var this_ = this;

            wx.request({
                url: TICKET_CONFIG.getSuggestList,
                data: {
                    key: key,
                    lat: this.latitude,
                    lng: this.longitude
                },
                header: {'content-type': 'application/json'},
                success: function(response) {
                    this_.sendingStatus = false;
                    this_.setData({
                        "isShowAround": false,
                        "isShowSuggest": true,
                        "suggestList": response.data.data
                    });
                }
            });
        }
    }
});