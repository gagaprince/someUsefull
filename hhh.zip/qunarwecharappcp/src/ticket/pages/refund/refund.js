var Config = require('../../config.js'),
    NumberInput = require('../../components/numberinput/numberinput.js'),
    Watcher = require('../../../common/watcher.js'),
    app = getApp();

Page({

    data: {},

    decorateData: function(data) {
        var numberinput = {
            key: "refundQuantity",
            max: data.order.maxQuantity || 999,
            min: 1,
            value: data.order.canRefundQuantity,
            minusCallback: "handleClickMinus",
            plusCallback: "handleClickPlus",
            inputCallback: "bindKeyInput"
        };
        return numberinput;
    },

    initNumberInput: function() {
        var numberinput = this.data.numberinput;
        this.numberinputObj_ = new NumberInput(this, "numberinput", numberinput.max, numberinput.min, numberinput.value);
    },

    getNumberInput: function(key) {
        return this.numberinputObj_;
    },

    handleNumberChange: function(num) {
        var that = this;
        wx.request({
            url: Config.orderRefundComputeMoneyUrl,
            data: {
                displayId: this.orderId,
                refundQuantity: num,
                mobile: this.mobile
            },
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                wx.hideToast();
                that.data.order.customerReceiveMoney = res.data.data.customerReceiveMoney;
                that.setData({
                    "order": that.data.order
                });
            }
        });
    },

    refundSubmit: function(e) {
        if (this.sending) {
            return;
        }

        this.sending = true;

        var formData = e.detail.value,
            this_ = this;

        wx.request({
            url: Config.orderSubmitRefundUrl,
            data: {
                oid: this.orderId,
                refundReason: formData.refundReason,
                refundDesc: formData.refundDesc,
                refundQuantity: this.getNumberInput("refundQuantity").getValue(),
                mobile: this.mobile
            },
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                wx.hideToast();
                if (res.data.ret) {
                    wx.showModal({
                        title: '提示',
                        content: res.data.data.message,
                        complete: function() {
                            wx.navigateBack({
                                delta: 1
                            })
                        }
                    });
                }else {
                    wx.showModal({
                        title: '提示',
                        content: res.data.errmsg
                    });
                }
            },
            complete: function(){
                this_.sending = false;
            }
        });
    },

    handleClickPlus: function(e) {
        var target = e.target,
            dataset = target.dataset,
            key = dataset.key,
            numberinput = this.getNumberInput(key);
        if (numberinput) {
            numberinput.stepUp();
            this.handleNumberChange(numberinput.getValue());
        }
    },

    handleClickMinus: function(e) {
        var target = e.target,
            dataset = target.dataset,
            key = dataset.key,
            numberinput = this.getNumberInput(key);
        if (numberinput) {
            numberinput.stepDown();
            this.handleNumberChange(numberinput.getValue());
        }
    },

    bindKeyInput: function(e) {
        var target = e.target,
            value = e.detail.value,
            dataset = target.dataset,
            key = dataset.key,
            numberinput = this.getNumberInput(key);
        numberinput.setValue(value);
        this.handleNumberChange(numberinput.getValue());
    },

    getRefundInfo: function() {
        var that = this;
        wx.showToast({
            title: '加载中',
            icon: 'loading',
            duration: 10000
        });
        wx.request({
            url: Config.orderRefundUrl,
            data: {
                oid: this.orderId
            },
            header: {'content-type': 'application/json'},
            success: function(res) {
                wx.hideToast();
                var data = res.data.data;
                var numberData = that.decorateData(res.data.data);
                data.numberinput = numberData;
                that.setData(data);
                that.initNumberInput(data);
                var num = that.getNumberInput("refundQuantity").getValue();
                that.handleNumberChange(num);
            }
        });
    },
    
    onLoad: function(data) {
        this.orderId = data.orderId;
        this.mobile = data.mobile;
        this.getRefundInfo();
    },

    onShow: function() {
        Watcher.pv({ "page": "ticket_refund"});
    }
});
