var orderDetailPage = function() {};

orderDetailPage.CodeMode = {
    'ONE_TO_ONE': '一票一码',
    'MANY_TO_ONE': '一单一码'
};

orderDetailPage.prototype = {
    rebuldData: function(response) {
        var response = response.data;
        var rebuldData = {};
        //basic
        rebuldData['productInfo'] = response.productInfo || {};
        rebuldData['hasShutcut'] = (response.actionList || []).length > 0 ? true : false;
        rebuldData['actionList'] = this.decorateActionList(response.actionList || []);
        //usage
        rebuldData['ticketDescList'] = this.decorateTicketData(response.ticketDesc || []);
        rebuldData['canSendCode'] = response.hasCoupon || false;
        rebuldData['productOnSale'] = response.productOnSale || false;
       
        //refund
        rebuldData['refundInfo'] = this.decorateOrderInfoData(response.refundInfo || {});

        //payment
        rebuldData['itemList'] = this.decoratePaymentData(response.payInfoItemList || []);
        //order
        rebuldData['orderInfo'] = response.orderInfo || {};
        rebuldData['passengerSpecs'] = response.passengerSpecs || false;
        rebuldData['orderInfoSpecs'] = response.orderInfoSpecs || false;

        //pay
        rebuldData['hasOperation'] = (response.cancelOrPay || []).length > 0 ? true : false;
        rebuldData['operationList'] = this.decorateOperationData(response.cancelOrPay || []);
        return rebuldData;
    },

    decorateActionList: function(actionList) {
        var shortCutType = {
            'REJECT_REFUND': '拒绝商家退款',
            'ACCESS_REFUND': '同意商家退款'
        };
        var access = null;
        var reject = null;
        for (var i = 0, l = actionList.length; i < l; i++) {
            var actionItem = actionList[i];
            if (!actionItem.type) {
                continue;
            }
            access = shortCutType[actionItem.type] === shortCutType.ACCESS_REFUND;
            reject = shortCutType[actionItem.type] === shortCutType.REJECT_REFUND;
            if (access || reject) {
                actionItem.isSupplierRefund = true;
            }
            if (access) {
                actionItem.accessRefund = true;
            }
            if (reject) {
                actionItem.rejectRefund = true;
            }
        }
        return actionList;
    },

    decorateTicketData: function(ticketDescList) {
        for (var i = 0, len = ticketDescList.length; i < len; i++) {
            var ticketDesc = ticketDescList[i],
                phone = ticketDesc.supplierPhone || '',
                callphone = ticketDesc.supplierCallPhone || '',
                orderEticketInfo = ticketDesc.orderEticketInfo || {},
                eticketMode = orderEticketInfo.eticketMode || '',
                eticketList = orderEticketInfo.etickets || [],
                carnivalInfo = ticketDesc.carnivalInfoDto || {},
                eticketType = null,
                codeType = {
                    'NO_CODE': '无码',
                    'Q_CODE': 'qunar发码',
                    'S_CODE': '供应商码',
                    'S_PIC': '供应商二维码',
                    'S_STRING': '供应商文本'
                };

            ticketDesc.supplierPhone = phone ? phone.replace(/转/, '-') : '';
            ticketDesc.supplierCallPhone = callphone ? callphone : '';
            this.supplierPhone_ = ticketDesc.supplierPhone; // 用于 退款提示框
            ticketDesc.isSight = true;
            if (ticketDesc.isSight) {
                for (var k = 0, kl = eticketList.length; k < kl; k++) {
                    var eticket = eticketList[k],
                        eticketType = eticket.eticketType,
                        eticketString = eticket.eticketString || "";
                    if (orderDetailPage.CodeMode[eticketMode] === orderDetailPage.CodeMode.MANY_TO_ONE) {
                        eticket.hasMultiSheets = true;
                    }

                    if (codeType[eticketType] === codeType.Q_CODE) {
                        eticket.showUseStatus = true;
                        if (eticketString) {
                            eticket.renderQrcode = eticketString;
                            eticket.eticketPic = false;
                        }
                    }
                }

                if (kl > 5 && eticketList[kl - 1]) {
                    ticketDesc.orderEticketInfo.hasMultiCode = true;
                }

                if (ticketDesc.inParkDate || kl > 0) {
                    ticketDesc.hasSightInfo = true;
                }

                if (carnivalInfo) {
                    this.decorateCarnivalInfo(carnivalInfo);
                }
            }

            if (ticketDesc.sightAddress || ticketDesc.inParkDescription) {
                ticketDesc.hasSightSubInfo = true;
            }

        }

        return ticketDescList;
    },

    decorateCarnivalInfo: function(carnivalInfo) {
        if (!carnivalInfo) {
            return;
        }
        var playingLocs = carnivalInfo.playingLocs;
        var assembleLocs = carnivalInfo.assembleLocs;
        if (playingLocs && playingLocs.length > 1) {
            for (var i = 0; i < playingLocs.length; i++) {
                playingLocs[i].index = i + 1;
            }
        }
        if (assembleLocs && assembleLocs.length > 1) {
            for (var i = 0; i < assembleLocs.length; i++) {
                assembleLocs[i].index = i + 1;
            }
        }
    },

    decorateOrderInfoData: function(refundInfo) {
        if (refundInfo && refundInfo.activity && refundInfo.activity.label == "不可退") {
            refundInfo.activity.noRefund = true;
        }
        if (refundInfo && (refundInfo.refundContent || refundInfo.desc)) {
            refundInfo.showRefundBtn = true;
        }
        return refundInfo;
    },

    decoratePaymentData: function(itemList) {
        var priceType = {
            'TOTAL': '1',
            'POST': '2',
            'RED_PACKET': '3',
            'ACTUAL': '4'
        };
        for (var i = 0, l = itemList.length; i < l; i++) {
            if (itemList[i].type == priceType.TOTAL) {
                itemList[i].isCost = true;
            } else {
                itemList[i].isCost = false;
            }
            if (itemList[i].type == priceType.RED_PACKET) {
                itemList[i].minus = true;
            } else {
                itemList[i].minus = false;
            }
            if (i + 1 == l) {
                itemList[i].isLastChild = true;
            } else {
                itemList[i].isLastChild = false;
            }
        }
        return itemList;
    },

    decorateOperationData: function(operationList) {
        var actionType = {
            'CANCEL_ORDER': '取消订单'
        };
        for (var i = 0, l = operationList.length; i < l; i++) {
            if (!operationList[i].type) {
                continue;
            }
            if (actionType[operationList[i].type] === actionType.CANCEL_ORDER) {
                operationList[i].isCancelOrder = true;
            }
        }
        return operationList;
    }
};

module.exports = new orderDetailPage();