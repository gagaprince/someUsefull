var Config = require('../../config.js');
var Pay = require("../../../common/pay.js");
var Requester = require("../../../common/requester.js");
var ProductDetailLayer = require('../../components/productdetail/productdetail.js');
var Watcher = require('../../../common/watcher.js');
var Network = require('../../../common/comps/network/network.js');
var Navigation = require('../../../common/navigation.js');
var order = require('./datareset.js');

var pageData = {
    data: {
        productInfo: {imgUrl: "http://s.qunarzz.com/piao_topic/image/common/default/140x140.png"},
        payInfoItemList: [{}],
        actionList: [{}],
        ticketDesc: [{}],
        orderInfo: {
            passengers: [{}],
            activity: {}
        },
        refundInfo: {activity: {}},
        cancelOrPay: [],
        passengerSpecs:[],
        orderInfoSpecs: []
    }
};

pageData["data"] = order.rebuldData(pageData);

pageData["productLayerInfo"] = {
    "productDetailShow": false,
    "productDetails": {},
    "dw": 290,
    "dh": 350
};

Page({

    data: pageData,

    bindCloseProdDetailTap: function() {
        this.ProductDetailLayer.close();
    },

    canvasIdErrorCallback: function(e) {
        console.error(e.detail.errMsg)
    },

    handleCallTel: function(e) {
        wx.makePhoneCall({
            phoneNumber: e.currentTarget.dataset.tel
        });
    },

    bindProdDetailTap: function(event) {
        this.ProductDetailLayer.getData("", this.orderId);
    },

    handleSendCertificate: function() {
        wx.request({
            url: Config.orderCouponcodeUrl,
            data: {orderId: this.orderId},
            header: {'content-type': 'application/json'},
            success: function(res) {
                if (res.data && res.data.ret) {
                    wx.showModal({
                        title: '提示',
                        content: res.data.data[0].message,
                        success: function(opt) {}
                    });
                }else if (res.data && !res.data.ret) {
                    wx.showModal({
                        title: '提示',
                        content: res.data.errmsg
                    });
                }
            }
        });
    },

    bindRefundDetailClick: function() {
        var refundDesc = this.data.data.refundInfo.desc || '',
            refundContent = this.data.data.refundInfo.refundContent || '';
        if (refundContent) {
            refundContent = refundContent + "\n";
        }
        wx.showModal({
            title: "退款规则",
            content: (refundContent + refundDesc)
        });
    },

    handleRefund: function() {
        Navigation.goTo('ticketOrderDetail', {
            url: Config.routes.refund,
            data: {
                orderId: this.orderId,
                mobile: this.contactMobile
            }
        });
    },

    handleAnotherTicket: function(e) {
        var sightid = e.currentTarget.dataset.sightid;

        Navigation.goTo('ticketOrderDetail', {
            url: Config.routes.detail,
            data: {
                sightid: sightid
            }
        });
    },

    handlePay: function() {
        wx.showToast({
            title: '正在打开支付，请稍候',
            icon: 'loading',
            duration: 1000
        });

        var this_ = this;

        Requester.request({
            host: Config.requestPath,
            service: Config.orderPaymentUrl,
            param:  {oid: this.orderId},
            method: "POST",
            dataType: "json",
            success: function(res) {
                res = res.data;
                if (res.ret && res.data) {
                    var options = {
                        bd_source: "wx",
                        cashierUrl: res.data.cashierUrl,
                        openId: res.data.openId,
                        success: function(res) {
                            this_.getOrderInfo();
                        },
                        complete: function(res) {
                            this_.getOrderInfo();
                        }
                    }
                    Pay.openCashier(options)
                }
            }
        });
        Watcher.click({"page": "ticket_orderdetail", "action-type": "ticket_continuepay"});
    },

    handleCancelOrder: function() {
        var this_ = this;

        Requester.request({
            host: Config.requestPath,
            service: Config.orderCancleOrderUrl,
            param:  {
                orderId: this.orderId,
                mobile: this.contactMobile
            },
            method: "POST",
            dataType: "json",
            success: function(res) {
                if (res.data && res.data.ret) {
                    wx.showModal({
                        title: "提示",
                        content: "订单已取消",
                        complete: function() {
                            this_.getOrderInfo();
                        }
                    });
                }
            }
        });

        Watcher.click({"page": "ticket_orderdetail", "action-type": "ticket_cancelorder"});
    },

    handleApplyRefund: function() {
        var this_ = this;
        wx.showModal({
            title: "提示",
            content: "是否同意商家发起的退款?",
            success: function(opt) {
                if (opt.confirm) {
                    this_.doSupplierRefund("accept");
                }
            }
        });
    },

    handleRefuseRefund: function() {
        var this_ = this;
        wx.showModal({
            title: "提示",
            content: "是否拒绝商家发起的退款?",
            success: function(opt) {
                if (opt.confirm) {
                    this_.doSupplierRefund("reject");
                }
            }
        });
    },

    doSupplierRefund: function(optStr) {
        var this_ = this;

        Requester.request({
            host: Config.requestPath,
            service: Config.orderUserApproveUrl,
            param:  {
                displayId: this.orderId,
                suggestion: optStr,
                mobile: this.contactMobile
            },
            method: "GET",
            dataType: "json",
            success: function(res) {
                if (res.data && res.data.ret) {
                    wx.showModal({
                        title: "提示",
                        content: "操作成功",
                        complete: function() {
                            this_.getOrderInfo();
                        }
                    });
                } else {
                    wx.showModal({
                        title: "提示",
                        content: res.data.errmsg,
                        complete: function() {
                            this_.getOrderInfo();
                        }
                    });
                }
            }
        });
    },

    onLoad: function(data) {
        this.orderId = data.orderId;
        this.contactMobile = data.mobile;
        this.ProductDetailLayer = new ProductDetailLayer(this, false);
        Network.showNetwork.call(this, {status: 4});
    },

    onShow: function() {
        var this_ = this;
        // 延迟一秒，尽量避免订单还未处理完
        setTimeout(function(){
            this_.getOrderInfo();
        }, 1000);
        Watcher.pv({ "page": "ticket_orderdetail"});
    },

    onPullDownRefresh: function() {
        this.getOrderInfo();
    },

    getOrderInfo: function() {
        var this_ = this;
        Requester.request({
            host: Config.requestPath,
            service: Config.orderDetailUrl,
            param:  {
                orderId: this.orderId,
                mobile: this.contactMobile
            },
            method: "GET",
            dataType: "json",
            success: function(res) {
                if (res.data.ret) {
                    Network.hideNetwork.call(this_);
                    this_.setData({
                        "data": order.rebuldData(res.data)
                    });
                    wx.stopPullDownRefresh();
                } else {
                    wx.showModal({
                        title: "提示",
                        content: res.data.errmsg
                    });
                }
            }
        });
    }
});