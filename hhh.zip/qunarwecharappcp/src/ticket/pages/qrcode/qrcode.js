var User = require("../../../common/user.js"),
    Utils = require('../../../common/utils.js'),
    Network = require('../../../common/comps/network/network.js'),
    Requester = require("../../../common/requester.js"),
    Config = require('../../config.js'),
    Watcher = require('../../../common/watcher.js'),
    Navigation = require('../../../common/navigation.js'),
    app = getApp();

Page({

    data: {
        showDefault: true,
        hasCoupon: false,
        buttonText: '',
        resultMessage: '',
        validUseTime: '',
        couponMoney: '',
        time: 10
    },

    autorized: false,
    login: false,
    timerSwitch: true,

    linkInfo: {},
    sightId: '',
    bdId: '',
    key: '',

    onLoad: function(params) {
        this.key = params.key;
        Network.showNetwork.call(this, { status: 4, loadingDesc: '加载中...' });
        this.getLinkInfo();
    },

    onShow: function(data) {
        this.qunarLogin();
    },

    getParam: function(from, name) {
        var reg = new RegExp('\\b' + name + '\=([^\&\#\?]*)');
        var m = from.match(reg);
        return m ? m[1] || '' : '';
    },

    getLinkInfo: function() {
        var this_ = this;
        wx.request({
            header: { "content-type": "application/x-www-form-urlencoded" },
            url: Config.qrcodeInfoUrl,
            data: { key: this.key },
            method: "GET",
            dataType: "json",
            success: function(response) {
                response = response.data;
                if (response.ret && response.data) {
                    this_.linkInfo = response.data;
                    this_.sightId = this_.getParam(this_.linkInfo.url, 'sightId');
                    this_.bdId = this_.getParam(this_.linkInfo.url, 'bd_id');
                    app.globalData.tkt_bdid = this_.bdId;
                    this_.checkLogin();
                    Utils.bdOrigin.setV(this_.getParam(this_.linkInfo.url, 'bd_origin'));
                } else {
                    Network.showNetwork.call(this_, { status: -2, loadingDesc: '无法获得二位码信息', showButton: true, networkRetry: 'getLinkInfo' });
                }
            },
            fail: function(formData) {
                Network.showNetwork.call(this_, { status: -2, loadingDesc: '网络请求失败', showButton: true, networkRetry: 'getLinkInfo' });
            }
        });
    },

    checkLogin: function() {
        var this_ = this;
        User.login(function(response) {
            if (response.ret) {
                this_.autorized = true;
                this_.qunarLogin();
                // 未登录发一次pv
                if (!response.data || !response.data.wechat || !response.data.wechat.isQunarUser) {
                    Watcher.pv({ "page": "qwticket_unlogin_" + this_.sightId});
                }
            } else {
                Network.showNetwork.call(this_, { status: -2, loadingDesc: '登录信息获取失败', showButton: true, networkRetry: 'getLinkInfo' });
            }
        });
    },

    qunarLogin: function() {
        var this_ = this;
        if (this.autorized && !this.login) {
            User.showQunarUserLogin({
                templateName: "template_promote",
                rules: this.linkInfo.rules,
                success: function(response) {
                    if (response.ret) {
                        this_.login = true;
                        this_.getCoupon();
                        Watcher.pv({ "page": "qwticket_login_" + this_.sightId});
                    } else {
                        Network.showNetwork.call(this_, { status: -2, loadingDesc: '获取用户信息失败', showButton: false });
                    }
                },
                fail: function(response) {
                    Network.showNetwork.call(this_, { status: -2, loadingDesc: '好可惜，因微信授权失败，暂不能享受优惠！可通过【微信】→【小程序】→删除“去哪儿机票火车票酒店”小程序重新扫码，即享立减优惠~', showButton: false });
                }
            });
        }
    },

    getCoupon: function() {
        var this_ = this;

        Requester.request({
            host: Config.requestPath,
            service: Config.getCouponUrl,
            param: {
                bdId: this.bdId,
                sightId: this.sightId
            },
            method: "POST",
            success: function(response) {
                response = response.data;
                if (response.ret && response.data) {
                    this_.handleCouponSuccess(response.data);
                } else {
                    Network.showNetwork.call(this_, { status: -2, loadingDesc: '领券失败，请重新尝试', showButton: false });
                }
            },
            fail: function(formData) {
                Network.showNetwork.call(this_, { status: -2, loadingDesc: '网络失败，请重新领券', showButton: false });
            }
        });
    },

    handleCouponSuccess: function(response) {

        this.setData({
            showDefault: false,
            hasCoupon: response.hasCoupon,
            rules: response.rules,
            buttonText: response.buttonText,
            resultMessage: response.resultMessage,
            validUseTime: response.validUseDate,
            couponMoney: response.couponMoney
        });

        // 未领代金券
        if (response.hasCoupon) {
            Watcher.pv({ "page": "qwticket_uncoupon_" + this.sightId});
        }else {
            Watcher.pv({ "page": "qwticket_coupon_" + this.sightId});
        }

        // 首单带到订单里
        app.globalData.tkt_newuser = response.isNewUser ? true : false;

        var this_ = this;

        if (this.timerSwitch) {
            this.timerSwitch = false;
            this.timer = setInterval(function(){
                var time = this_.data.time - 1;
                this_.setData({time: time});
                if (time <= 0) {
                    clearInterval(this_.timer);
                    Navigation.goTo('ticketQrcode', {
                        url: this_.linkInfo.url
                    });
                }
            },1000)
        }
    },

    handleBtnTap: function() {
        if (this.timer) {
            clearTimeout(this.timer);
            this.setData({time: 0});
        }
        Navigation.goTo('ticketQrcode', {
            url: this.linkInfo.url
        });
    },

    onHide: function(){
        this.login = false; 
    }

})