var ProductDetailLayer = require('../../components/productdetail/productdetail.js'),
    TICKET_CONFIG = require('../../config.js'),
    Watcher = require('../../../common/watcher.js'),
    Utils = require('../../../common/utils.js'),
    Network = require('../../../common/comps/network/network.js'),
    Navigation = require('../../../common/navigation.js');

Page({
    
    data: {
        "showPage": false,
        "ticketInfo": {},
        "productLayerInfo": {},
        "commentInfo": {},
        "sightInfo": {"coverImage": "http://simg1.qunarzz.com/piao/images/camel_440_285.jpg"}
    },

    onShareAppMessage: function () {
        return Utils.share.getParam({
            url: TICKET_CONFIG.routes.detail + "?sightid=" + this.data.sightInfo.sightId + "&bd_origin=ticket_detail_share",
            title: "去哪儿网门票",  
            desc: "买" + this.data.sightInfo.sightName + "门票来去哪儿网网，玩乐景点门票一网打尽！尽享优惠和便利~",
            jumpType: 'navigateTo'  
        });
    },

    onLoad: function (data) {
        Network.showNetwork.call(this, {status: 4});
        this.sightId = data.sightid || data.sightId;
        this.isPromote =  data.bd_id ? true : false;
        this.productDetailLayer = new ProductDetailLayer(this, true);
    },

    onShow: function() {
        var this_ = this;
        wx.request({
            url: TICKET_CONFIG.sightDetailUrl,
            data: {
                sightId: this.sightId,
                qrcode: this.isPromote
            },
            header: {'content-type': 'application/json'},
            success: function(response) {
                response = response.data;
                if(response.data && response.ret) {
                    Network.hideNetwork.call(this_);
                    var pageData = response.data;
                    this_.setData({
                        "showPage": true,
                        "activityTicketInfo": pageData.activityTicketInfo,
                        "ticketInfo": pageData.ticketInfo,
                        "commentInfo": pageData.commentInfo,
                        "sightInfo": pageData.sightInfo
                    });
                }
            }
        });
        Watcher.pv({ "page": "qwticket_detail_" + this.sightId});
    },

    handleShowAllInfo: function(e) {
        var target = e.currentTarget,
            showType = target.dataset.type;
        this.data.sightInfo[showType].showAll = true;
        this.setData(this.data);
    },

    handleShowAllTickets: function(e) {
        var target = e.currentTarget,
            typeId = target.dataset.typeid;
        for (var i = 0; i < this.data.ticketInfo.ticketZoneList.length; i++) {
            var tmp = this.data.ticketInfo.ticketZoneList[i].priceList;
            for (var j = 0; j < tmp.length; j++) {
                if (tmp[j].typeId == typeId) {
                    tmp[j].fold = (tmp[j].fold && tmp[j].fold == true) ? false : true;
                } else {
                    tmp[j].fold = false;
                }
            }
        }
        this.setData(this.data);
    },

    bindCloseProdDetailTap: function() {
        this.productDetailLayer.close();
    },

    bindBookingTap: function(e) {
        var data = e.currentTarget.dataset;

        Navigation.goTo('ticketDetail', {
            url: TICKET_CONFIG.routes.booking,
            data: {
                sightid: data.sightid,
                priceid: data.priceid,
                pid: data.pid
            }
        });
    },

    bindProdDetailTap: function(event) {
        var data = event.currentTarget.dataset;
        this.productDetailLayer.getData(data.pid, "", {
            "sightid": data.sightid,
            "priceid": data.priceid,
            "pid": data.pid
        });
    }
    
});