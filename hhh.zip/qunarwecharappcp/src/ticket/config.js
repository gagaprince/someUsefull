var requestPath = "https://wxapp.qunar.com/ticket/qwechat";

module.exports = {

    requestPath: requestPath,
    getAroundSight: requestPath + "/getAroundAndHotSight.json",
    getSuggestList: requestPath + "/sight/suggest.json",
	productDetailUrl: requestPath + "/product/getProductInfoByProductId.json",
	productDetailForOrderUrl: requestPath + "/product/getProductInfoByOrderId.json",
	sightDetailUrl: requestPath + "/sight/sightDetail.json",
	preOrderUrl: "/order/orderForm.json",
    calendarUrl: requestPath + "/sight/calendar.json",
    orderCouponcodeUrl: requestPath + "/order/couponcode.json",
    orderPaymentUrl: "/payment.json",
    orderCancleOrderUrl: "/order/cancelOrder.json",
    orderDetailUrl: "/order/detail.json",
    orderUserApproveUrl: "/order/userApprove.json",
    orderRefundComputeMoneyUrl: requestPath + "/order/computeRefundReceiveMoney.json",
    orderSubmitRefundUrl: requestPath + "/order/refund/submit.json",
    orderRefundUrl: requestPath + "/order/refund.json",
    remainAndRefundUrl: requestPath + "/order/getCountAndRefundInfo.json",
    submitOrderUrl: "/order/submit.json",
    orderCalCouponUrl: "/calCoupon.json",
    qrcodeInfoUrl: requestPath + "/getUrlAndMessage.json",
    getCouponUrl:  "/getCoupon.json",

    routes: {
        list: "/ticket/pages/list/list",
        detail: "/ticket/pages/detail/detail",
        booking: "/ticket/pages/booking/booking",
        orderdetail: "/ticket/pages/orderdetail/orderdetail",
        refund: "/ticket/pages/refund/refund"
    },
    
    pageIds: {
        list: 800,
        detail: 801,
        booking: 804,
        orderdetail: 809,
        refund: 918
    }

};