function formatTime(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()

  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()


  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
};

function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
};

function objectExtend(target, /*optional*/source, /*optional*/deep) {
    target = target || {}; 
    var sType = typeof source, i = 1, options; 
    if(sType === 'undefined' || sType === 'boolean') { 
        deep = sType === 'boolean' ? source : false; 
        source = target; 
        target = this; 
    } 
    if(typeof source !== 'object' && Object.prototype.toString.call(source) !== '[object Function]') {
        source = {}; 
    } 
    while(i <= 2) { 
        options = i === 1 ? target : source; 
        if( options != null ) { 
            for( var name in options ) { 
            var src = target[name], copy = options[name]; 
            if(target === copy) 
                continue; 
            if(deep && copy && typeof copy === 'object' && !copy.nodeType) 
                target[name] = objectExtend(src || 
            (copy.length != null ? [] : {}), copy, deep); 
            else if(copy !== undefined) 
                target[name] = copy; 
            } 
        } 
        i++; 
    } 
    return target; 
}; 

module.exports = {
  formatTime: formatTime,
  objectExtend: objectExtend
}
