var Validator = {};

Validator.REG_NAME = /^.+$/;
Validator.REG_PHONE = /^1\d{10}$/;
Validator.REG_EMAIL = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
Validator.REG_ID_CARD = /^\d{15}|\d{18}|\d{17}x$/;
Validator.REG_DATE = /^\d{4}-\d{1,2}-\d{1,2}$/;
Validator.REG_PASS_CARD = /^[a-zA-Z]([0-9]{7,8})$/;
Validator.REG_GA_CARD = /^[a-zA-Z]([0-9]{8})$/;
Validator.REG_TAIBAO_CARD = /^[0-9]{8}$/;
Validator.REG_TAIWAN_CARD = /^[a-zA-Z]([0-9]{8})$/;
Validator.REG_RUTAI_CARD = /^[0-9]{11}$/;
Validator.REG_PINYIN = /^[a-zA-Z0-9\s\.\_\-]{2,60}$/;
Validator.REG_ZIPCODE = /^[0-9]{6}$/;
Validator.REG_NUMBER = /\d/;
Validator.REG_NATIONALITY = /^[\u4E00-\u9FA5]{1,20}$/;
Validator.REG_NEED = /^.+$/;

Validator.validateNeed = function(str) {
	var str = this.trim(str);
	return Validator.REG_NEED.test(str);
};

Validator.validateName = function(str) {
	var str = this.trim(str);
	return Validator.REG_NAME.test(str);
};

Validator.validateEmail = function(str) {
	var str = this.trim(str);
	return Validator.REG_EMAIL.test(str);
};

Validator.validateMobile = function(str) {
	var str = this.trim(str);
	return Validator.REG_PHONE.test(str);
};

Validator.validateNumbers = function(str) {
	var str = this.trim(str);
	return Validator.REG_NUMBER.test(str);
};

Validator.validateIdCard = function(str) {
	var str = this.trim(str);
	return Validator.REG_ID_CARD.test(str);
};

Validator.validateDate = function(str) {
	var str = this.trim(str);
	return Validator.REG_DATE.test(str);
};

Validator.validatePinyin = function(str) {
	var str =  this.trim(str);
	return Validator.REG_PINYIN.test(str);
}

Validator.validatePassCard = function(str) {
	var str =  this.trim(str);
	return Validator.REG_PASS_CARD.test(str);
}

Validator.validateTaibao = function(str) {
	var str =  this.trim(str);
	return Validator.REG_TAIBAO_CARD.test(str);
}

Validator.validateTaiwan = function(str) {
    var str =  this.trim(str);
    return Validator.REG_TAIWAN_CARD.test(str);
}

Validator.validateRutai = function(str) {
    return Validator.REG_RUTAI_CARD.test(str);
} 

Validator.validateGangao = function(str) {
	var str =  this.trim(str);
	return Validator.REG_GA_CARD.test(str);
}

Validator.validateZipcode = function(str) {
	var str =  this.trim(str);
	return Validator.REG_ZIPCODE.test(str);
}

Validator.validateNationality = function(str) {
    var str = this.trim(str);
    return Validator.REG_NATIONALITY.test(str);
}

Validator.trim = function(str) {
    return str == null ? "" : String.prototype.trim.call(str);
}

module.exports = Validator;