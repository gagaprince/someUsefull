var OrderInput = require("../input/input.js");
var Contact = function(context, dataObjName, needContactMobile, needContactName, needContactPinyin, needContactEmail, needContactPostalInfo) {
    this.dataObjName_ = dataObjName;
    this.context_ = context;

    this.mobileRule = this.context_.mobileRule;
    this.userRule = this.context_.userRule;
    this.userPinyinRule = this.context_.userPinyinRule;
    this.emailRule = this.context_.emailRule;
    this.postAddressRule = this.context_.postAddressRule;

    this.needContactMobile_ = needContactMobile;
    this.needContactName_ = needContactName;
    this.needContactPinyin_ = needContactPinyin;
    this.needContactEmail_ = needContactEmail;
    this.needContactPostalInfo_ = needContactPostalInfo;
    this.inputsInfo_ = {};
    this.inputsObj_ = {};
    this.createInputsInfo();
};
Contact.prototype.contactMobileError_ = false;
Contact.prototype.contactNameError_ = false;
Contact.prototype.contactPinyinError_ = false;
Contact.prototype.contactEmailError_ = false;
Contact.prototype.contactPostalInfoError_ = false;
Contact.prototype.getContactInfo = function() {
    var contact = {
        "needContactMobile": this.needContactMobile_,
        "needContactName": this.needContactName_,
        "needContactPinyin": this.needContactPinyin_,
        "needContactEmail": this.needContactEmail_,
        "needContactPostalInfo": this.needContactPostalInfo_,
        "contactMobileError": this.contactMobileError_,
        "contactNameError": this.contactNameError_,
        "contactPinyinError": this.contactPinyinError_,
        "contactEmailError": this.contactEmailError_,
        "contactPostalInfoError": this.contactPostalInfoError_,
        "contactMobileFocus": false,
        "contactNameFocus": false,
        "contactPinyinFocus": false,
        "contactEmailFocus": false,
        "contactPostalInfoFocus": false,
        "inputs": this.inputsInfo_
    };
    return contact;
};
Contact.prototype.getInputsInfo = function() {
    return this.inputsInfo_ || {};
};
Contact.prototype.createInputsInfo = function() {
    var a = [this.needContactMobile_,this.needContactName_,this.needContactPinyin_,this.needContactEmail_,this.needContactPostalInfo_];
    var b = [this.mobileRule,this.userRule,this.userPinyinRule,this.emailRule,this.postAddressRule];
    for (var i = 0; i < a.length; i++) {
        if(a[i]){
            var input = JSON.parse(b[i]);
            this.inputsInfo_[input.key] = input;
            this.inputsObj_[input.key] = new OrderInput(this.context_, this.dataObjName_+"."+input.key, input.key, input.type, input.placeholder, input.validate);
        }
    }
};
Contact.prototype.setInputValue = function(key, value) {
    if(this.inputsObj_[key]) {
        this.inputsObj_[key].setValue(value);
    }
};
Contact.prototype.validateAllInputs = function() {
    for(var i in this.inputsObj_) {
        var input = this.inputsObj_[i];
        var ret = input.validate(input.getValue());
        if(!ret) {
            input.showErrorToast();
            return false;
        }
    }
    return true;
};
Contact.prototype.validateInput = function(key, value) {
    if(this.inputsObj_[key]) {
        var ret = this.inputsObj_[key].validate(value);
        if(!ret) {
            var data = {};
            data[this.dataObjName_+".inputs."+key+".error"] = true;
            data[this.dataObjName_+".inputs."+key+".focus"] = false;
            this.context_.setData(data);
        }
    }
};
Contact.prototype.focus = function(key) {
    if(this.inputsObj_[key]) {
        var ret = this.inputsObj_[key].validate();
        if(!ret) {
            var data = {};
            data[this.dataObjName_+".inputs."+key+".error"] = false;
            data[this.dataObjName_+".inputs."+key+".focus"] = true;
            this.context_.setData(data);
        }
    }
};
Contact.prototype.setData = function(attr, value) {
    var data = {};
    var key = attr ? (this.dataObjName_ + '.' + attr) : this.dataObjName_;
    data[key] = value;
    this.context_.setData(data);
};
module.exports = Contact;