var OrderInput = require("../input/input.js");
var Util = require("../../utils/util.js");

var PassengerContainer = function(context, dataObjName, list, passenger, passengerInfoPerNum) {
    this.context_ = context;
    this.dataObjName_ = dataObjName;
    this.passengerList_ = list || [];
    this.passenger_ = passenger || {};
    this.passengerInfoPerNum_ = passengerInfoPerNum || 1;
    this.inputObjList_ = [];
};

PassengerContainer.prototype.init = function() {
    this.initCardTypes();
}

PassengerContainer.prototype.changeNumber = function(num) {
    var num = num || 1,
        calLength = Math.ceil(num / this.passengerInfoPerNum_),
        currLength = this.passengerList_.length;
    // 当前条数 如果大于计算值 要删除
    if(currLength > calLength) {
        for(var i = currLength-1; i > calLength-1; i--) {
            this.passengerList_.pop();
            this.inputObjList_.pop();
        }
        this.setData("passengerList", this.passengerList_);
    } else if(currLength < calLength) {
        var passenger = Util.objectExtend({}, this.passenger_, true);
        for(var i = currLength; i < calLength; i++) {
            this.passengerList_.push(passenger);
        }
        this.createInputsInfo(this.passengerList_.length-1);
        this.setData("passengerList", this.passengerList_);
    }
};

PassengerContainer.prototype.getPassenger = function(index) {
    return this.passengerList_[index] ? this.passengerList_[index] : null;
};

PassengerContainer.prototype.getPassengerCount = function() {
    return this.passengerList_.length;
};

PassengerContainer.prototype.initCardTypes = function() {
    var cardTypes = [];
    var cards = JSON.parse(this.context_.dmCardInfo);
    var p = this.passenger_;
    var a = [p.needPassengerIDCard,p.needPassengerPassport,p.needPassengerTaiwanPermit,p.needPassengerGAIDCard,p.needPassengerMTPFTWResidents,p.needPassengerTaiwanEntryPermit];
    var b = [0,1,4,8,9,10];
    for (var i = 0; i < a.length; i++) {
        if(a[i]) {
            var t = b[i];
            cardTypes.push(cards[t]);
        }
    }
    if(cardTypes.length) {
        this.passenger_.cardTypes = cardTypes;
        this.passenger_.showCardTypes = false;
        this.passenger_.currCard = cardTypes[0];
        this.setData("passenger", this.passenger_);
    }
};

PassengerContainer.prototype.getCardByType = function(value) {
    for(var i in this.passenger_.cardTypes) {
        var card = this.passenger_.cardTypes[i];
        if(card.value == value) {
            return card;
        }
    }
};

PassengerContainer.prototype.showCardTypes = function(index) {
    var passenger = this.getPassenger(index);
    if(passenger) {
        passenger.showCardTypes = !passenger.showCardTypes
        this.setData("passengerList["+index+"]", passenger);
    }
};

PassengerContainer.prototype.changeCardType = function(index, type) {
    var passenger = this.getPassenger(index);
    var card = this.getCardByType(type);
    if(passenger && card) {
        passenger.showCardTypes = false;
        passenger.currCard = card;
        if(passenger.inputs && passenger.inputs.idNo) {
            var input = passenger.inputs["idNo"];
            input.validate = passenger.currCard.validator;
            input.placeholder = "请填写正确的"+passenger.currCard.name+"号码";
            this.inputObjList_[index]["idNo"].setPlaceholder(input.placeholder);
            this.inputObjList_[index]["idNo"].setValidator(input.validate);
        }
        this.setData("passengerList["+index+"]", passenger);
    }
};

PassengerContainer.prototype.createInputsInfo = function(index) {
    // for(var i = 0, len = this.passengerList_.length; i < len; i++) {
        var i = index;
        var passenger = this.passengerList_[i];
        var inputsGroup = {};
        this.inputObjList_[i] = {};
        if(passenger.needPassengerName) {
            // key为每个Input的键，name为传给后端的input name属性
            var input = JSON.parse(this.context_.dmInputName);
            input.name = "name"+i;
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        if(passenger.needPassengerPinyin) {
            // key为每个Input的键，name为传给后端的input name属性
            var input = JSON.parse(this.context_.dmInputNamePinyin);
            input.name = "namePinyin"+i;
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        if(passenger.needPassengerMobile) {
            // key为每个Input的键，name为传给后端的input name属性
            var input = JSON.parse(this.context_.dmInputMobile);
            input.name = "mobile"+i;
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        if(passenger.cardTypes && passenger.cardTypes.length) {
            // key为每个Input的键，name为传给后端的input name属性
            var input = JSON.parse(this.context_.dmInputIdNo);
            input.name = "idNo"+i;
            input.validate = passenger.currCard.validator;
            input.placeholder = "请填写正确的"+passenger.currCard.name+"号码";
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        if(passenger.needPassengerNationality) {
            // key为每个Input的键，name为传给后端的input name属性
            var input = JSON.parse(this.context_.dmInputNationality);
            input.name = "nationality"+i;
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        if(passenger.needPassengerDateOfBirth) {
            // key为每个Input的键，name为传给后端的input name属性
            var input = JSON.parse(this.context_.dmInputDateOfBirth);
            input.name = "dateOfBirth"+i;
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        if(passenger.needPassengerSex) {
            // key为每个Input的键，name为传给后端的input name属性
            var input = JSON.parse(this.context_.dmInputSex);
            input.name = "sex"+i;
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        if(passenger.needPassengerUserDefinedItem1) {
            // key为每个Input的键，name为传给后端的input name属性
            var input = JSON.parse(this.context_.dmInputUserDefine1);
            input.name = "userDefineI"+i;
            input.placeholder = passenger.passengerUserDefinedItem1;
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        if(passenger.needPassengerUserDefinedItem2) {
            // key为每个Input的键，name为传给后端的input name属性
             var input = JSON.parse(this.context_.dmInputUserDefine2);
            input.name = "userDefineII"+i;
            input.placeholder = passenger.passengerUserDefinedItem2;
            inputsGroup[input.key] = input;

            this.inputObjList_[i][input.key] = new OrderInput(this.context_, this.dataObjName_+".passengerList["+i+"]"+input.name, input.name, input.type, input.placeholder, input.validate);
        }
        
        passenger["inputs"] = inputsGroup;
    // }
};

PassengerContainer.prototype.setInputValue = function(index, key, value) {
    var inputObj = this.inputObjList_[index];
    if(inputObj && inputObj[key]) {
        inputObj[key].setValue(value);
    }
};

PassengerContainer.prototype.validateAllInputs = function() {
    for(var i = 0, l = this.inputObjList_.length; i < l; i++) {
        var inputObj = this.inputObjList_[i];
        for(var key in inputObj) {
            var input = inputObj[key];
            var ret = input.validate(input.getValue());
            if(!ret) {
                input.showErrorToast();
                return false;
            }
        }
    }
    return true;
};

PassengerContainer.prototype.validateInput = function(index, key, value) {
    // for(var i = 0, len = this.inputObjList_.length; i < len; i++) {
        var inputsGroup = this.inputObjList_[index] || {};
        if(inputsGroup[key]) {
            var ret = inputsGroup[key].validate(value);
            if(!ret) {
                this.setData("passengerList["+index+"].inputs."+key+".error", true);
                this.setData("passengerList["+index+"].inputs."+key+".focus", false);
            }
        }
    // }
};

PassengerContainer.prototype.focus = function(index, key) {
    // for(var i = 0, len = this.inputObjList_.length; i < len; i++) {
        var inputsGroup = this.inputObjList_[index] || {};
        if(inputsGroup[key]) {
            this.setData("passengerList["+index+"].inputs."+key+".focus", true);
            this.setData("passengerList["+index+"].inputs."+key+".error", false);
        }
    // }
};

PassengerContainer.prototype.setData = function(attr, value) {
    var data = {};
    var key = attr ? (this.dataObjName_ + '.' + attr) : this.dataObjName_;
    data[key] = value;
    this.context_.setData(data);
};

module.exports = PassengerContainer;