var NumberInput = function(context, dataObjName, max, min, value) {
	this.context_ = context;
	this.dataObjName_ = dataObjName || "";
	this.setMax(max);
	this.setMin(min);
	this.setValue(value);
};

NumberInput.prototype.max_ = 999999;
NumberInput.prototype.min_ = -999999;
NumberInput.prototype.value_ = 0;

NumberInput.prototype.setMax = function(max) {
	max = parseInt(max, 10);
	if(max >= this.min_) {
		this.max_ = max;
		this.setData("max", this.max_);
	}
};

NumberInput.prototype.setMin = function(min) {
	min = parseInt(min, 10);
	if(min <= this.max_) {
		this.min_ = min;
		this.setData("min", this.min_);
	}
};

NumberInput.prototype.setValue = function(value) {
	value = parseInt(value, 10);
	if(isNaN(value) || value == Number.NaN) {
		value = 0;
	}
	value = Math.min(Math.max(value, this.min_), this.max_);
    if(value != this.value_) {
        this.value_ = value;
		this.setData("value", this.value_);
    
        // $(this).trigger("change", this, this);
    }
};

NumberInput.prototype.getValue = function() {
	return this.value_;
};

NumberInput.prototype.getMax = function(max) {
	return this.max_;
};

NumberInput.prototype.getMin = function(max) {
	return this.min_;
};

NumberInput.prototype.stepUp = function() {
	var value = this.getValue();
	this.setValue(++value);
};

NumberInput.prototype.stepDown = function() {
	var value = this.getValue();
	this.setValue(--value);
};

NumberInput.prototype.setData = function(attr, value) {
	var data = {};
	var key = attr ? (this.dataObjName_ + '.' + attr) : this.dataObjName_;
	data[key] = value;
	this.context_.setData(data);
};

module.exports = NumberInput;