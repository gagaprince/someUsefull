var config = require('../../config.js');

var ProductDetailLayer = function(context, showBookingBtn) {
	this.context_ = context;
    this.showBookingBtn = showBookingBtn;
    this.data = {};
    this.dw = 290;
    this.dh = 350;
    this.getProdWindowSize();
};

ProductDetailLayer.prototype.show = function() {
    this.context_.setData({
          productLayerInfo: {
            "productDetailShow": true
          }
    });
};

ProductDetailLayer.prototype.close = function() {
	this.context_.setData({
          productLayerInfo: {
            "productDetailShow": false
          }
    });
};

ProductDetailLayer.prototype.decorateIntroData = function(data) {
    var data = data,
        activitys = data.activitys || [],
        infos = data.infos || {},
        infosSingle = [];
    // 仅预订时间区分
    for (var i = 0, l = activitys.length; i < l; i++) {
        if (activitys[i].type == 9) {
            activitys[i].limitTime = true;
        } else {
            activitys[i].limitTime = false;
        }
    }
    // 需要单独展示的说明
    for (var j = 0, jl = infos.length; j < jl; j++) {
        var info = infos[j];
        
        // typeSign标识单独展示
        if(info.typeSign) {
            infosSingle.push(info);
            info.single = true;
        } else {
            info.single = false;
        }
        // 区分退款的icon
        if(info.type == 13) {
            info.isIcon = true;
            if(info.typeName == "不可退") {
                info.notRefund = true;
            }
        }
    }
    data.activitys = activitys;
    data.infos = infos;
    data.infosSingle = infosSingle;
    // 展示预定按钮及支付
    if(typeof data.payWay != "undefined" && typeof data.qunarPrice != "undefined") {
        switch(data.payWay) {
            case "PREPAY": 
                data.showBookBtn = true;
                data.payWayStr = "在线支付";
                break;
            case "CASHPAY":
                data.showBookBtn = true;
                data.pwaWayStr = "景区支付";
                break;
        }
    }
    if (!this.showBookingBtn) {
         data.showBookBtn = false;
    }
    return data;
};

ProductDetailLayer.prototype.getProdWindowSize = function () {
    var app = getApp();
    var deviceInfo = app.globalData.deviceInfo;
    this.dw = deviceInfo.windowWidth;
    this.dh = deviceInfo.windowHeight;
};

ProductDetailLayer.prototype.getData = function(pid, oid, bookingData) {
    var url = "";
    var param = {};
    var that = this;
    if(oid) {
        url = config.productDetailForOrderUrl;
        param = {
            orderId: oid
        };
    } else {
        url = config.productDetailUrl;
        param = {
            productId: pid
        };
    }
    wx.request({
      url: url,
      data: param,
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
        that.context_.setData({
          "productLayerInfo":{
            "productDetailShow": true,
            "productDetails": that.decorateIntroData(res.data.data),
            "dw": that.dw,
            "dh": that.dh,
            "detailBookingInfo": (bookingData ? bookingData : {})
          }
        });
      }
    });
};

ProductDetailLayer.prototype.setData = function(attr, value) {
	var data = {};
	this.context_.setData(data);
};

module.exports = ProductDetailLayer;