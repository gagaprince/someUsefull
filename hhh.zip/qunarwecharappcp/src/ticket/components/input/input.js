var OrderValidator = require('../../pages/booking/validator.js');
var OrderInput = function(context, dataObjName, name, type, placeholder, validate) {
    this.context_ = context;
    this.dataObjName_ = dataObjName;
    this.name_ = name;
    this.type_ = type;
    this.placeholder_ = placeholder;
    this.validator_ = validate;
};

OrderInput.prototype.name_ = "";
OrderInput.prototype.type_ = "text";
OrderInput.prototype.placeholder_ = "";
OrderInput.prototype.validator_ = "";
OrderInput.prototype.value_ = "";
OrderInput.prototype.isError_ = false;
OrderInput.prototype.isFocus_ = false;

OrderInput.prototype.init = function() {

};

OrderInput.prototype.setValue = function(value) {
    this.value_ = value;
};

OrderInput.prototype.getValue = function() {
    return this.value_;
};

OrderInput.prototype.setValidator = function(validator) {
    this.validator_ = validator;
    this.setData("validate", this.validator_);
};

OrderInput.prototype.setPlaceholder = function(placeholder) {
    this.placeholder_ = placeholder;
    this.setData("placeholder", this.placeholder_);
};

OrderInput.prototype.validate = function(value) {
    return OrderValidator.validateTextInput(value, this.validator_);
};

OrderInput.prototype.showErrorToast = function(value) {
    wx.showToast({
        title: OrderValidator.MessageMap[this.validator_] || "请检查页面中必填项目"
    });
};

OrderInput.prototype.setData = function(attr, value) {
    var data = {};
    var key = attr ? (this.dataObjName_ + '.' + attr) : this.dataObjName_;
    data[key] = value;
    this.context_.setData(data);
};

module.exports = OrderInput;