var inputSpace = {};
inputSpace.insertSpace = function(str, insertMark) {
    str = this.replaceSpace(str);
    if (!(/[0-9]/.test(str))) { //没有数字 直接返回
        return str;
    }
    var value = str.split('');
    for(var i = 0,len = insertMark.length; i < len;i++) {
        var item = insertMark[i];
        if(value.length - 1>= item) {
            if (value[item] != ' ') {
                value.splice(item, 0, ' ');
            }
        }
    }
    return value.join('');
};
inputSpace.replaceSpace = function(str) {
    return str.replace(/\s/g, '');
};

module.exports = inputSpace;