var extend = require('../../common/utils/object/extend.js');
var user = require("../../common/user.js");
var utils = require("../../common/utils.js");
var md5 = require("./md5");
var app = getApp(),
    globalData = app.globalData || {},
    deviceInfo = globalData.deviceInfo || {};
function QWatcher(page) {
    var self = this;

    if(!global.__fightVid__) {
        user.getUserInfo(function(res) {
            if (res.ret && res.data) {
                var wechat = res.data.wechat;
                var openId = wechat.openId;
                var timeStamp = new Date().getTime().toString();
                global.__fightVid__ = md5(openId + timeStamp);
                self._vid = global.__fightVid__;
            }
        });
    }
    else {
        self._vid = global.__fightVid__;
    }

    self._page = page;
    self.pageStart();
    self.pageView();
    self._endPage = false;
}
QWatcher.prototype.pageView = function() {
    var params = {
        r: 'pageview'
    };
    sendData.call(this, params);
}
QWatcher.prototype.addCount = function(target, extra) {
    var params = {};
    extend(true, params, extra);
    if (target) {
        params.r = target;
    }
    sendData.call(this, params);
}
QWatcher.prototype.addTime = function(target, time, extra) {
    var params = {};
    extend(true, params, extra);
    params.r = target;
    params.time = time;
    sendData.call(this, params);
}
//页面驻留时间
QWatcher.prototype.pageStart = function() {
    var self = this;
    self._pageStartTime = new Date().getTime();
    self._endPage = false;
}
QWatcher.prototype.pageEnd = function(target) {
    var self = this;
    //多次调用只发一次
    if(!self._endPage) {
        self._endPage = true;
        var duringTime = new Date().getTime() - self._pageStartTime;
        target = target || 'page_stay_time';
        self.addTime(target, duringTime);
    }

}
function sendData(params) {
    var me = this;
    params = params || {};
    params.p = me._page;
    params.et = me._pageStartTime;
    params.at = new Date().getTime();
    params.os = deviceInfo.platform || 'other';
    params.bd_origin = utils.bdOrigin.getV() || ''; //渠道
    var query = [];
    var vid = me._vid ||'';
    for (var key in params) {
        query.push(key + '=' + params[key]);
    }
    //https://logflight.qunar.com/l.gif?
    var url = 'https://wxapp.qunar.com/flight/watcher/l.gif?' + query.join('&');

    // wx.getImageInfo({
    //     src: url,
    //     success:function(res) {
    //         //console.info('flight watcher success!\n'+ url);
    //     }
    // });
    user.getUserInfo(function(res) {
        var cookies = '';
        if (res.ret && res.data) {
            var wechat = res.data.wechat;
            var openId = wechat.openId;
            cookies = 'QN602=' + vid + ';QN601=' + _genFakeMD5(openId) + ';';
        }
        wx.request({
            url: url,
            header: {Cookie: cookies},
            method: 'GET',
            success: function(res) {

            }
        });
    });
}
//用openId补位成32位假的MD5
function _genFakeMD5(openId) {
    var len = openId.length;
    var fakeMD5 = openId;
    if(len < 32) {
        var short = 32 - len;
        fakeMD5 += Array(short + 1).join('0');
    }
    else if(len > 32) {
        fakeMD5 = fakeMD5.substr(0, 32);
    }
    return fakeMD5;
}


module.exports = QWatcher;
