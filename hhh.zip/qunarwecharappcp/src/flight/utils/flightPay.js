/**
 * Created by kaijian.lei on 17/03/20.
 */
var Pay = require("../../common/pay");
var constant = require('../constant');
var WATCHER = constant.WATCHER,
    COLOR = constant.COLOR;
/*
opt = {
    orderData: orderData,
    page: this,
    name: BOOKING / ORDERDETAIL
}
*/
function flightPay(opt) {
    var page = opt.page;
    var pageName = opt.name;
    var orderData = opt.orderData;
    var orderTokenInfo = orderData.tokenInfo;
    var orderNo = (orderData.priceInfo && orderData.priceInfo.orderNo) || '';
    var mobile = (orderData.contacter && orderData.contacter.phone) || '';
    var sign = orderData.sign;
    var app = getApp();
    var openId = app.user.openId;
    var payStatus = -1;
    var s_time = new Date().getTime();

    if (!orderTokenInfo || !orderTokenInfo.cashierUrl || !orderTokenInfo.token) {
        page.hideLoading();
        //BOOKING页支付失败跳转详情页
        if(pageName === 'BOOKING') {
            wx.showModal({
                title: '小驼提示',
                content: '发起支付请求失败，稍后再试。\n',
                showCancel: false,
                confirmColor: COLOR.TEXT,
                success: function(res) {
                    page.showLoading(1,'支付失败，正在跳转订单详情');
                    setTimeout(function(){
                        page._gotoOrderDetail(orderNo, mobile, sign);
                    },2000);
                }
            });
        }
        else {
            page.singleModal('发起支付请求失败，稍后再试。');
        }
        return;
    }

    var opt = {
        cashierUrl: orderTokenInfo.cashierUrl,
        openId: openId,
        bd_source:"wx",
        success: function(res){
            payStatus = 1;
            //页面已卸载
            if (page.data.unLoad || page.data.config.unLoad) {
                return;
            }
        },
        fail: function(error){
            payStatus = 0;
            //页面已卸载
            if (page.data.unLoad || page.data.config.unLoad) {
                return;
            }
        },
        complete: function() {
            //页面已卸载
            if (page.data.unLoad || page.data.config.unLoad) {
                return;
            }
            var result, text = '';
            //支付状态
            if(payStatus == 1) {
                result = '_success';
                text = '支付成功，';
            }
            else if(payStatus == 0) {
                result = '_fail';
                text = '支付失败，';
            }
            else {
                result = '_cancel';
                text = '支付取消，';
            }
            page._qWatcher.addCount(WATCHER[pageName].WX_PAY_REQ + result);
            page._qWatcher.addTime(WATCHER[pageName].WX_PAY_REQ + '_time', new Date().getTime() - s_time);
            if(pageName === 'BOOKING') {
                page.showLoading(1,text + '正在跳转订单详情');
                setTimeout(function(){
                    page._gotoOrderDetail(orderNo, mobile, sign);
                },2000);
            }
            else {
                page.loadData(page.data.params);
            }
            
        },
        beforeOpen: function() {
        },
        afterOpen: function() {
            page.hideLoading();
        }
    };
    Pay.openCashier(opt);
}
module.exports = flightPay;