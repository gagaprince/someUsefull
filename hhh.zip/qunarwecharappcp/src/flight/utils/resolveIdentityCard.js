module.exports = function (value) {
    var len,
        arrSplit,
        y, m, d, gender; // 1 male 0 female
        len = value.length;
    if (len === 15) {
        arrSplit = value.match(/^(?:\d{6})(\d{2})(\d{2})(\d{2})(?:\d{3})$/);
        y = parseInt('19' + arrSplit[1], 10);
        m = parseInt(arrSplit[2], 10);
        d = parseInt(arrSplit[3], 10);
        gender = value.charAt(len - 1) % 2;
    } else if (len === 18) {
        arrSplit = value.match(/^(?:\d{6})(\d{4})(\d{2})(\d{2})(?:\d{3})(?:[0-9]|X)$/i);
        y = parseInt(arrSplit[1], 10);
        m = parseInt(arrSplit[2], 10);
        d = parseInt(arrSplit[3], 10);
        gender = value.charAt(len - 2) % 2;
    }
    var birthday = y + '-' + m + '-' + d;
    return {
        birth: birthday,
        gender: gender
    };
}