var extend = require('../../common/utils/object/extend.js');
var inputSpace = require('./inputSpace.js');
var resolveIdentityCard = require('./resolveIdentityCard.js');
var checkers = {
    name: {
        rules: 'noempty|character|maxLength|minLength|symbolPlace|zh-en|space',
        relationData: {
            maxLength: 27,
            minLength: 2,
            preText: '乘机人姓名'
        }
    },
    idCard: {
        rules: 'noempty|idCard|ageType|uniqueId',
        relationData: {
            preText: '乘机人身份证'
        }
    },
    mobile: {
        rules: 'noempty|mobile',
        relationData: {
            preText: '联系人手机号'
        }
    },
    contactName: {
        rules: 'noempty|maxLength|minLength',
        relationData: {
            maxLength: 22,
            minLength: 2,
            preText: '联系人姓名'
        }
    }
}

var validator = {
    "noempty": function(value, relationData){
        if(value === undefined || value === ""){
            return relationData.preText + "不能为空";
        }
        return true;
    },
    "mobile": function(value, relationData){
        value = inputSpace.replaceSpace(value);
        if(!(/^1\d{10}$/.test(value))){
            return relationData.preText + "格式不正确";
        }else{
            return true;
        }
    },
    'maxLength': function (value, relationData) {
        if( value.length > relationData.maxLength) {
            return relationData.preText + '最大长度为' + relationData.maxLength + '位';
        }
        else {
            return true;
        }
    },
    'space': function (value, relationData) {
        if ( !/^[\u4e00-\u9fa5].*$/i.test( value ) ) {
            return true;
        } else {
            if (/[\/ ]/i.test(value)) {
                return relationData.preText + "请去掉姓名中的空格或“/”";
            } else {
                return true;
            }
        }
    },
    'character': function(value, relationData) {
        var str = inputSpace.replaceSpace(value);
        for (var i = 0, len = str.length; i < len; i++) {
            if ((/[\u4e00-\u9fa5\ue844-\ue863a-z \/]/i).test(str.charAt(i))) {
                continue;
            } else {
                var message = "姓名中不能包含“" + str.charAt(i) + "”";
                return message;
            }
        }
        return true;
    },
    'zh-en':function(value, relationData) {
        if ( /^[\u4e00-\u9fa5\ue844-\ue863].*$/i.test( value ) ) {
            return true;
        }
        else {
            if (/[^\/ a-z]/i.test( value )) {
                return relationData.preText + '英文后不能使用汉字';
            } else if(!/^[a-z]+\/[a-z ]*$/i.test( value )) {
                return relationData.preText + "英文请在姓与名之间用\"/\"分隔";
            } else {
                return true;
            }
        }
    },
    'minLength': function (value,relationData) {
        if( /^[\u4e00-\u9fa5\ue844-\ue863].*$/i.test( value) ){ //中文姓名
            if (value.length < 2) {
                return relationData.preText + '中文最短长度为2个汉字';
            }
            else {
                return true;
            }
        }else{ //英文姓名
            if (value.replace('/', '').length < 3) {
                return relationData.preText + '英文最短长度为3个字母';
            }
            else {
                return true;
            }
        }
    },
    'symbolPlace': function (value, relationData) {
        if (/^\/|\/$/.test(value)) {
            return relationData.preText + '不能以“/”开头或结尾';
        }
        return true;
    },
    'idCard': function (value,relationData) {
        var len, arrSplit, result, y, m, d; // 1 male 0 female
        value = inputSpace.replaceSpace(value);
        len = value.length;
        result = true;
        if (len === 15) {
            arrSplit = value.match(/^(?:\d{6})(\d{2})(\d{2})(\d{2})(?:\d{3})$/);
            if (!arrSplit) {
                result = false;
            }
            else {
                y = parseInt('19' + arrSplit[1], 10);
                m = parseInt(arrSplit[2], 10);
                d = parseInt(arrSplit[3], 10);
            }
        } else if (len === 18) {
            //检验18位身份证的校验码是否正确。
            //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10
            var weight = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2],
                check = '10X98765432';
            for (var i = 0, temp = 0; i < 17; i++) {
                temp += value.charAt(i) * weight[i];
            }
            if (check.charAt(temp % 11) !== value.charAt(17).toUpperCase()) {
                result = false;
            }
            arrSplit = value.match(/^(?:\d{6})(\d{4})(\d{2})(\d{2})(?:\d{3})(?:[0-9]|X)$/i);

            if (!arrSplit) {
                result = false;
            }
            else {
                y = parseInt(arrSplit[1], 10);
                m = parseInt(arrSplit[2], 10);
                d = parseInt(arrSplit[3], 10);
            }
        }
        else {
            result = false;
        }
        var date = new Date(y, m - 1, d);

        if (y !== date.getFullYear() || m !== date.getMonth() + 1 || d !== date.getDate()) {
            result = false;
        }

        if (result === false) {
            return relationData.preText + '号码格式不正确';
        }
        else {
            return result;
        }
    },
    'ageType': function (value,relationData) {
        value = inputSpace.replaceSpace(value);
        var info = resolveIdentityCard(value);
        var age = _getAge(info.birth, relationData.depDate);
        if (age < 12) {
            return '暂不支持12岁以下儿童购买';
        }
        else {
            return true;
        }
    },
    'uniqueId': function (value, relationData) {
        var passengerList = relationData.passengerList,
        repeatNum = 0;
        if (passengerList && passengerList.length) {
            for (var i = 0,len = passengerList.length; i < len; i++) {
                if (value === passengerList[i].idCard) {
                    repeatNum++;
                }
                if (repeatNum >= 2) {
                    return relationData.preText + '号码重复';
                }
            }
        }
        return true;
    }
}

function _getAge(birthday, time) {
    var birthDate = new Date(birthday.replace(/-/g,'/')),
        timeDate = new Date(time.replace(/-/g,'/')),
        age = timeDate.getFullYear() - birthDate.getFullYear();
    if (timeDate.getMonth() < birthDate.getMonth() || (timeDate.getMonth() === birthDate.getMonth() && (timeDate.getDate() < birthDate.getDate()))) {
        age -= 1;
    }
    return age;
}

module.exports = function(name, value, relationData ) {
    var ckItem = checkers[name],
        rules = ckItem.rules.split("|"),
        data = {},//Object.assign({},ckItem.relationData,relationData),
        result = true;
        extend(true,data, ckItem.relationData, relationData);
    for (var i = 0,len = rules.length;i < len;i++ ) {
        if (rules[i]) {
            result = validator[rules[i]](value, data);
            if(result !== true){
                return result;
            }
        }
    }
    return '';
}
