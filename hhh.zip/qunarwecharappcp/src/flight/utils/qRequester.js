var user = require("../../common/user.js");
var app = getApp(),
    globalData = app.globalData || {},
    deviceInfo = globalData.deviceInfo || {};
var config = app.config || {}  //require('../../common/config.js');
var extend = require('../../common/utils/object/extend.js');
var constant = require('../constant.js');
var requester = require('../../common/requester');
//var HOST = constant.HOST;
//add watcher
function request(obj) {
    user.getUserInfo(function(res) {
        if (!res.ret || !res.data) {
            //获取用户标识失败
            res = {
                data: {
                    wechat: {
                        openId: '',
                        uinonId: ''
                    },
                    qunar: {
                        _q: '',
                        _v: '',
                        _t: '',
                        _s:'',
                        _i:'',
                        token: ''
                    }
                }
            }
        }
        var wechat = res.data.wechat;
        var qunarInfo = res.data.qunar;

        var c = {
            bd_origin: globalData.bd_origin || "", //渠道
            bd_source: 'wx',
            openId: wechat.openId || "",
            unionId: wechat.unionId || "",
            _q: qunarInfo. _q || '',
            _v: qunarInfo._v || '',
            _t: qunarInfo._t || '',
            _s: qunarInfo._s || '',
            _i: qunarInfo._i || '',
            token: qunarInfo.token || '',
            _model: deviceInfo.model || '',
            _version: deviceInfo.version || '',
            _platform: deviceInfo.platform || ''
        };
        var service = obj.service;
        var param = obj.param || {};
        for (var key in c) {
            param[key] = c[key];
            if (obj.data) {
                obj.data[key] = c[key];
            }
        }

        if (!service || !service.length) {
            console.error('service 为空');
            return false;
        }
        var queryComponents = [];
        for (var key in param) {
            var value = param[key] || '';
            queryComponents.push(key + '=' + encodeURI(value));
        }
        var url = (obj.host ? obj.host : config.settings.requestDomain) + service + "?" + queryComponents.join('&');
        var watcher = obj.watcher,
        target = obj.target,
        hasWatcher = !!watcher && !!target,
        _sTime = new Date().getTime();
        wx.request({
            url: url,
            data: obj.data,
            header: obj.header || {"Content-Type": "application/json"},
            method: (obj.method && obj.method.toUpperCase()) || 'GET',
            success: function(res) {
                if (hasWatcher) {
                    if (res && res.data && res.data.status === 0) {
                        watcher.addCount(target + '_success');
                    }
                    else {
                        watcher.addCount(target + '_fail');
                    }
                }
                if (obj.success) {
                    obj.success(res);
                }
            },
            fail: function(error) {
                if (hasWatcher) {
                    watcher.addCount(target + '_fail');
                }
                if (obj.fail) {
                    obj.fail(error);
                }
            },
            complete: function() {
                if(hasWatcher) {
                    watcher.addTime(target + '_time', new Date().getTime() - _sTime);
                }
                if (obj.complete) {
                    obj.complete();
                }
            }
        });
    });
    return true;
}

function watcherWrapper(obj){
    user.getUserInfo(function(res){
        var {target, watcher, success, fail, complete} = obj;
        var wechat = res.data.wechat;
        var hasWatcher = !!watcher && !!target;
        var _sTime = new Date().getTime();
        obj.data = obj.data || {};
        obj.data.wxUnionId = wechat.unionId;
        obj.data.wxOpenId  = wechat.openId;
        extend(true, obj.data, requester.getParamC());
        if(hasWatcher) {
            obj.success = function(res) {
                if (res && res.data && res.data.status === 0) {
                    watcher.addCount(target + '_success');
                }
                else {
                    watcher.addCount(target + '_fail');
                }
                if (success) {
                    success(res);
                }
            }
            obj.fail = function(error) {
                watcher.addCount(target + '_fail');
                if (fail) {
                    fail(error);
                }
            }
            obj.complete = function() {
                watcher.addTime(target + '_time', new Date().getTime() - _sTime);
                if (complete) {
                        complete();
                    }
            }
        }
        requester.request(obj);
    });
}

module.exports = {
    request: watcherWrapper
};
