var HOSTS = {
    beta: 'https://wxapp.beta.qunar.com',
    production:'https://wxapp.qunar.com'
};
var ENV = 'production';
module.exports = {
    event: {
        'FLIGHT_CALENDAR_DATE_CHANGE': 'FLIGHT_CALENDAR_DATE_CHANGE',
        'CALENDAR_DATE_CHANGE': 'CALENDAR_DATE_CHANGE',
        'FLIGHT_CITY_CHANGE': 'FLIGHT_CITY_CHANGE',
        'FLIGHT_SEARCHLIST_DATE_CHANGE': 'FLIGHT_SEARCHLIST_DATE_CHANGE',
        'SEARCHLIST_DATE_CHANGE_FLIGHT': 'SEARCHLIST_DATE_CHANGE_FLIGHT'
    },
    STORAGE_KEY: {
        'FLIGHT_DEP_DATE': 'FlightDepDate',
        'FLIGHT_DEP_CITY': 'FlightDepCity',
        'FLIGHT_ARR_CITY': 'FlightArrCity',
        'FLIGHT_HISTORY_CITY': 'FlightHistoryCity',
        'FLIGHT_HOT_CITY': 'FlightHotCity',
        'FLIGHT_PASSENGER_FILL': 'FlightFillData'
    },
    API_URLS: {
        BOOKING: '/flight/booking/oneWay',
        CREATE_ORDER: '/flight/createOrder/createOrder',
        PAY_METHOD: '',
        CITY_LIST: '/flight/citylist',
        FLIGHT_SUGGEST: '/flight/suggest/livesearch2.jsp',
        ORDER_DETAIL: '/flight/orderDetail/orderDetail',
        CANCEL_ORDER: '/flight/cancelOrder/cancelOrder'
    },
    WATCHER: {
        HOME: {
            PV : 'wechat_home',
            SHARE: 'home_share',
            SEARCH_CLICK: 'search_button_click',
            CHOOSE_DATE_CLICK: 'search_date_click',
            CITY_EXCHANGE_CLICK: 'city_exchange_click',
            DEPCITY_CLICK: 'depcity_click',
            ARRCITY_CLICK: 'arrcity_click'
        },
        BOOKING: {
            PV: 'wechat_booking',
            ADD_PSG_CLICK: 'add_passenger_click',
            DEL_PSG_CLICK: 'del_passenger_click',
            CREATE_ORDER_CLICK: 'create_order_click',
            NAME_NOTICE_CLICK: 'name_notice_click',
            INSURE_NOTICE_CLICK: 'insure_notice_click',
            BOOKING_REQ: 'booking_request',
            CREATE_ORDER_REQ: 'create_order_request',
            WX_PAY_REQ: 'create_order_wechat_pay',
            INSURE_OPEN: 'booking_insure_open',
            INSURE_CLOSE: 'booking_insure_close',
            PRICE_DETAIL: 'show_price_detail',
            SHARE: 'booking_share'
        },
        ORDERDETAIL: {
            PV: 'wechat_order_detail',
            ORDER_DETAIL_REQ: 'order_detail_request',
            WX_PAY_REQ: 'order_detail_pay',
            SHOW_PRICE_DETAIL: 'order_detail_show_price_detail',
            CANCEL_ORDER_REQ: 'cancel_order_request',
            CANCEL_ORDER: 'cancel_order'
        },
        SUGGEST: {
            PV: 'wechat_suggest',
            TAP_HISTORY: 'tap_history_city',
            TAP_HOT: 'tap_hot_city',
            TAP_SEARCH_RESULT: 'tap_search_city',
            TAP_CURRENT: 'tap_current_city'
        }
    },
    HOST: HOSTS[ENV],
    PASSENGER: {
        NO_DEL: -1,
        ANIMATION_TIME: 300,
        MAX_NUM: 9
    },
    ERRORMESSAGE: {
        NETWORK: '世界上最遥远的距离就是没网',
        SERVER: '小驼累了，点击刷新试试'
    },
    COLOR: {
        TEXT:'#1fbcd2',
        COMMON: '#00bcd4'
    }
};