/**
 * Created by kaijian.lei on 16/11/18.
 */
module.exports = {
	"tips": {     //顶部提示
        "hasTips": true,  //没有提示  false
        "content": [
            {
                "text": "您选购的机票需要申请，在申请成功后代理商会给你的账号里您选购的机票需要申请，在申请成功后代理商会给你的账号里"
            },{
                "text": "您选购的机票需要申请，在申请成功后代理商会给你的账号里"
            }   
        ]
    },
    "orderStatus": 0,   　// 支付状态 0待支付  
    "orderStatusDesc": '待支付',
    "timelimit": "15",     // 剩余时间
    "priceInfo": {         
        "price": 100,      　//订单总价
        "orderId": '12121212121',  //订单号
        "vendor": '代理商信息'  //代理商
    },
    "priceDetail": [{    //订单详情
        "type": '成人票',   
        "price": 200,
        "oil": 30,
        "airportFee": 50,
        "num": 3
    },{
        "type": '儿童票',
        "price": 100,
        "oil": 30,
        "airportFee": 50,
        "num": 3
    }],
    "tgqInfo": {    　　// 退改签
        "title": "退改签说明",
        "infos": [
            {
                "title": "退票费",
                "contents": [
                    "起飞前。。。",
                    "起飞后。。"
                ]
            }
        ]
    },
    "flightInfo": [{
        "flightNo": "3U8888",
        "cabin": "经济舱",
        "planeModule": "空客A320",
        "planeModuleCode": "320",
        "depAirportCode": "KMG",
        "arrAirportCode": "HKG",
        "depDate": "2017-02-24",
        "depWeek": "周三",
        "depTime": "07:45",
        "arrDate": "2017-02-22",
        "arrTime": "09:55",
        "arrWeek": "周三",
        "depTerminal": "T1",
        "arrTerminal": "T2",
        "actFlightNo": "CZ12306",
        "actFlightCompany": "川航",
        "codeShare": true,
        "airCompanyFullName": "中国国际航空公司",
        "airCompany": "国航",
        "depCity": "昆明",
        "arrCity": "香港",
        "depAirportFullName": "昆明长水国际机场",
        "arrAirportFullName": "香港国际机场",
        "depAirport": "长水机场",
        "arrAirport": "香港机场",
        "depCityCode": "KMG",
        "arrCityCode": "HKG",
        "crossDays": "",
        "flightTime": "2小时10分钟",
        "onTimeRate": "80%",
        "meal": false,
        "stop": true,
        "stopInfos": "广州"
    }],
    "passenger": [{   //乘机人信息
    	"name": '张三',
    	'userType': '成人票',
        'cardType': '身份证',
        'cardId': '1212121212122',
    	'tiketNum': '12121212121212'
    },{
    	"name": '张三',
        'userType': '成人票',
        'cardType': '身份证',
        'cardId': '1212121212122',
        'tiketNum': '12121212121212'
    }],
    "contacter": {  //联系人信息
    	"name": 'zzzdsfas',
    	"phone": '12121212'
    },
    "insureInfos": [  //保险
     	{
     		"type": '航意险',
     		"price": 30,
     		'num': 2,
            "passenger": '周一，周二，周三，周四，周五，周一，周二，周三，周四，'
     	},
     	{
     		"type": '延误险',
     		"price": 30,
     		'num': 2,
            "passenger": '周一，周二，周三，周四，周五'
     	}
    ]
};