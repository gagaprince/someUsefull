var data = require('./data.js');
var Status = require('../../../common/templates/status/status.js');
var PopModal = require('../../templates/popModal/popModal.js');
var TotalPrice = require('../../templates/totalPrice/totalPrice.js');
var QWatcher = require('../../utils/qWatcher.js');
// var requester = require('../../../common/requester.js');
var requester = require('../../utils/qRequester.js');
var constant = require('../../constant.js');
var Pay = require("../../../common/pay.js");
var flightPay = require("../../utils/flightPay");

var STORAGE_KEY = constant.STORAGE_KEY,
    COLOR = constant.COLOR,
    PASSENGER = constant.PASSENGER,
    WATCHER = constant.WATCHER,
    ERRORMSG = constant.ERRORMESSAGE,
    PHONE = 1,
    ID = 2,
    API_URLS = constant.API_URLS;

Page({
    data: {
        "isPop": false,
        statusData:{
            status: 0,
            statusDesc:'加载中...'
        },
        lastNavTime: 0,
        config: {}
    },
    //页面卸载
    onUnload: function () {
        var self = this;
        self._qWatcher.pageEnd();
        self.setData({
            config: {
                unLoad: true
            }
        });
    },
    onLoad: function (params) {
        for (var key in params) {
            params[key] = params[key];
        }
        var self = this;
        self._qWatcher = new QWatcher(WATCHER.ORDERDETAIL.PV);
        self.showLoading();
        self.loadData(params);
        self.params = params;
    },
    showLoading: function(type,desc) {
        type = type || 4;
        this._status = new Status(this);
        this._status.show(type, desc);
    },
    hideLoading: function () {
        this._status.hide();
    },
    loadData: function(params) {
        var self = this;
        requester.request({
            service: API_URLS.ORDER_DETAIL,
            //host: constant.HOST,
            param: params,
            watcher: self._qWatcher,
            target: WATCHER.ORDERDETAIL.ORDER_DETAIL_REQ,
            success: function (res) {
                if (res && res.data && res.data.status == 0) {
                    var data = res.data.data;
                    self.clearData(data, params);

                }
                else {
                    self.showLoading(-2, ERRORMSG.SERVER);
                }
            },
            fail: function (error) {
                self.showLoading(-2, ERRORMSG.NETWORK);
            },
            complete: function () {
                //关闭loading
            }
        });
   },
   clearData: function(data, params) {
        var self = this;
        var needOpenPay = params.needOpenPay;
        data.contacter.phone = self.encryptInfo(data.contacter.phone, PHONE);
        for (var i = 0, len = data.passengers.length; i < len; i++) {
            data.passengers[i].cardId = self.encryptInfo(data.passengers[i].cardId, ID);
        }
        //参数存入data里
        data.params = params;
        data.params.needOpenPay = false;
        self.setData(data);
        if (data.insureInfos) {
            wx.setStorage({
                key: 'insureInfos',
                data: data.insureInfos
            });
        }
        //存储退改签信息
        if (data.tgqInfo) {
            wx.setStorage({
                key: 'tgqInfo',
                data: data.tgqInfo
            });
        }
        self.hideLoading();
        if (needOpenPay) {
            self.showLoading(1,'正在发起支付请求...');
            flightPay({
                orderData: self.data,
                page: self,
                name: 'ORDERDETAIL'
            });
            // self._payRequest();
        }
   },
   encryptInfo: function(text, type) {
       if (type === PHONE) {
           return text.substring(0, 3) + Array(5).join('*') + text.substring(7);
       }
       if (type === ID) {
           var len = text.length;
           if (len === 15) {
               return text.substring(0, 4) + Array(9).join('*') + text.substring(len - 3);
           }
           else {
               return text.substring(0, 4) + Array(12).join('*') + text.substring(len - 3);
           }
       }
   },
   tapPirceEvent: function(e){
        this._qWatcher.addCount(WATCHER.ORDERDETAIL.SHOW_PRICE_DETAIL);
        this._totalPrice = new TotalPrice(this);
        var totalPrice =  {
            "title":"价格明细",
            "priceDetail": this.data.priceDetail,
            "priceInfo": this.data.priceInfo,
            "insure": this.data.insureInfos
        };

        this._totalPrice.showModal(totalPrice);
    },
    bindLink: function(e) {
        var self = this,
            data = self.data,
            lastNavTime = data.lastNavTime,
            dataset = e.target.dataset,
            type = dataset.type,
            now = new Date().getTime(),
            url = "../viewInfo/viewInfo?from=detail&type=" + type;
            //避免多次点击
        if (now - lastNavTime >= 500) {
            lastNavTime = now;
            self.setData({
                lastNavTime: lastNavTime
            })
            wx.navigateTo({
                url: url
            });
        }
    },
    tapPopEvent: function(e){
        this._popModal = new PopModal(this);

        var popData =  {
            "title":"提示",
            "contents": this.data.tips.content
        };

        this._popModal.showModal(popData);
    },
    networkRetry: function() {
        this.loadData(this.params);
    },
    payTap: function(e) {
        this.showLoading(1,'正在发起支付请求...');
        flightPay({
            orderData: this.data,
            page: this,
            name: 'ORDERDETAIL'
        });
        // this._payRequest();
    },
    cancelTap: function() {
        var self = this;
        wx.showModal({
            title: '小驼提示',
            content: '确定要取消订单吗？\n',
            showCancel: true,
            confirmColor: COLOR.TEXT,
            success: function(res) {
                if (res.confirm) {
                    self.cancelRequest();
                    self._qWatcher.addCount(WATCHER.ORDERDETAIL.CANCEL_ORDER);
                }
            }
        });
    },
    cancelRequest: function() {

        var self = this;
        self.showLoading(1, '正在为您取消订单');
        var params = self.params;
        requester.request({
            service: API_URLS.CANCEL_ORDER,
            param: params,
            watcher: self._qWatcher,
            target: WATCHER.ORDERDETAIL.CANCEL_ORDER_REQ,
            success: function (res) {
                if (res && res.data && res.data.status == 0) {
                    var data = res.data.data;
                    self.cancelOrder(data);
                }
                else {
                    self.cancelOrder({cancelStatus:-1});
                }
            },
            fail: function (error) {
                self.cancelOrder({cancelStatus:-1});
            }
        });
    },
    cancelOrder: function(opt) {
        var self = this;
        //取消成功
        if (opt && opt.cancelStatus == 0) {
            self.showLoading(1, opt.msg || '取消订单成功');
        }
        else {
            self.showLoading(1, opt.msg || '取消订单失败');
        }
        setTimeout(function(){
            self.hideLoading();
            self.loadData(self.params);
        }, 1000);
    },
    singleModal: function(content, title) {
        wx.showModal({
            title: title || '小驼提示',
            content: content + '\n',
            showCancel: false,
            confirmColor: COLOR.TEXT
        });
    },
    _payRequest: function() {
        this.showLoading(1,'正在发起支付请求...');
        var self = this,
            orderData = self.data,
            orderTokenInfo = orderData.tokenInfo;
        if (!orderTokenInfo || !orderTokenInfo.cashierUrl || !orderTokenInfo.token) {
            self.hideLoading();
            self.singleModal('发起支付请求失败，稍后再试。');
            return;
        }
        var user = getApp().user,
            openId = user.openId,
            s_time = new Date().getTime();
        var payStatus = -1;
        var opt = {
            cashierUrl: orderTokenInfo.cashierUrl,
            openId: openId,
            bd_source:"wx",
            success: function(res){
                payStatus = 1;
                //页面已卸载
                if (self.data.config.unLoad) {
                    return;
                }
                self.singleModal('支付成功.');
                self.hideLoading();
            },
            fail: function(error){
                payStatus = 0;
                //页面已卸载
                if (self.data.config.unLoad) {
                    return;
                }
                // self.singleModal('支付失败，请稍候再试.');
                self.hideLoading();
            },
            complete: function() {
                //页面已卸载
                if (self.data.config.unLoad) {
                    return;
                }
                var result;
                //支付状态
                if(payStatus == 1) {
                    result = '_success';
                }
                else if(payStatus == 0) {
                    result = '_fail';
                }
                else {
                    result = '_cancel';
                }
                self._qWatcher.addCount(WATCHER.ORDERDETAIL.WX_PAY_REQ + result);
                self._qWatcher.addTime(WATCHER.ORDERDETAIL.WX_PAY_REQ + '_time', new Date().getTime() - s_time);
                self.loadData(self.data.params);
            },
            beforeOpen: function() {
            },
            afterOpen: function() {
                self.hideLoading();
            }
        };
        Pay.openCashier(opt);
    }
})
