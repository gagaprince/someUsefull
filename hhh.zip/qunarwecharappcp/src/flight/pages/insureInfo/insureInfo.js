Page({
    data: {
        
    },
    //事件处理函数
    bindViewTap: function() {

    },
    onLoad: function () {
        var that = this;
        wx.getStorage({
          key: "insureInfos",
          success: function(res) {
            that.setData({
                insureInfos: res.data
              })
          } 
        });
    }
})