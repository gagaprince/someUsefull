var extend = require('../../../common/utils/object/extend.js');
var resolveIdentityCard = require('../../utils/resolveIdentityCard.js');
var inputSpace = require('../../utils/inputSpace.js');

//生单数据paser
var dataPaser = function(data) {
    var booking = data.booking,
        fill = data.fill,
        insureInfo = booking.insureInfo,
        orderData = {};
    //priceInfo
    orderData.priceInfo = booking.priceInfo;
    orderData.vendorInfo = booking.vendorInfo;
    orderData.flightInfo = booking.flightInfo;
    orderData.sign = booking.sign;
    //bookingTag & extparam
    orderData.bookingTag = booking.bookingTag;
    orderData.extparam = booking.extparam;
    //passengers
    var passengers = [];
    for (var i = 0, len = fill.passengerList.length; i < len; i++) {
        var psg = fill.passengerList[i],
            idCard = inputSpace.replaceSpace(psg.idCard),
            baseInfo = resolveIdentityCard(idCard),
            temp = {
                name: psg.name,
                ageType: 0,          //目前只有成人
                gender: baseInfo.gender,
                birthday: baseInfo.birth,
                cardType: 1,        //目前只有身份证
                cardNum: idCard,
                products: []
            };

        //insure
        for (var j = 0; j < fill.insure.length; j++) {
            if (fill.insure[j].value) {
                var ins = {
                    type: insureInfo[j].type,
                    price: insureInfo[j].price,
                    count: 1
                };
                if (insureInfo[j].hasPrefer) {
                    ins.prefer = insureInfo[j].prefer;
                }
                temp.products.push(ins);
            }
        }
        passengers.push(temp);
    }
    orderData.passengers = passengers;

    //contact
    orderData.contact = {
        name: fill.contact.contactName,
        phone: inputSpace.replaceSpace(fill.contact.mobile)
    };
    return orderData;
}

module.exports = dataPaser;
