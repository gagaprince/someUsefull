/**
 * Created by kaijian.lei on 16/11/17.
 */
var app = getApp();
var Status = require('../../../common/templates/status/status.js');
var PopModal = require('../../templates/popModal/popModal.js');
var extend = require('../../../common/utils/object/extend.js');
// var requester = require('../../../common/requester.js');
// var Pay = require("../../../common/pay.js");
var flightPay = require("../../utils/flightPay");
var utils = require("../../../common/utils.js");
// var mockData = require('./mock.js');
var dateFormat = require('../../../common/utils/date/format.js');
var inputSpace = require('../../utils/inputSpace.js');
var validater = require('../../utils/validate.js');
var QWatcher = require('../../utils/qWatcher.js');
var requester = require('../../utils/qRequester.js');
var constant = require('../../constant.js');
var orderPaser = require('./createOrderPaser.js');
var EventEmitter = require('../../../common/EventEmitter.js');

var STORAGE_KEY = constant.STORAGE_KEY,
    PASSENGER = constant.PASSENGER,
    WATCHER = constant.WATCHER,
    ERRORMESSAGE = constant.ERRORMESSAGE,
    COLOR = constant.COLOR,
    API_URLS = constant.API_URLS;
Page({
    data: {
        "booking": {
        },
        "fill": {
            passengerList: [{
                name: '',
                idCard: '',
                onFocus: false,
                nameErrorMsg:'',
                idCardErrorMsg:'',
                passengerClass: 'passenger-item'
            }],
            contact:{
                contactName:'',
                contactNameErrorMsg:'',
                mobile: '',
                mobileErrorMsg:''
            },
            insure:[],
            totalPrice: '',
            ticketPrice: '',
            agreements: true
        },
        "config": {
            showAddPsgBtn: true,
            showPriceDetail: false,
            insureService: '',
            readyDelIndex: PASSENGER.NO_DEL,
            bookingSuccess: 0,
            ErrorMsg: '小驼累了，重新选择一个航班试试',
            lastNavTime:0
        },
        statusData:{
            status: 0,
            statusDesc:'加载中...'
        }
    },
    singleModal: function(content, title) {
        wx.showModal({
            title: title || '小驼提示',
            content: content + '\n',
            showCancel: false,
            confirmColor: COLOR.TEXT
        });
    },
    isShowLoading: function() {
        return this._status.isShow();
    },
    showLoading: function(type,desc) {
        type = type || 4;
        this._status.show(type, desc);
    },
    hideLoading: function () {
        this._status.hide();
    },
    /**
     * 加载数据
     * @param params
     */
    loadData: function (params) {
        this.showLoading(4);
        var self = this,
            config = self.data.config;
        self.setData({
            params: params
        });
        var data = {};
        extend(true, data, params);
        requester.request({
            service: API_URLS.BOOKING,
            param: data,
            watcher: self._qWatcher,
            target: WATCHER.BOOKING.BOOKING_REQ,
            success: function (res) {
                //页面卸载，终止
                if (self.data.config.unLoad) {
                    return;
                }
                if (res && res.data && res.data.status == 0) {
                    //booking成功
                    config.bookingSuccess = 1;
                    self.setData({
                        booking: res.data.data,
                        config: config
                    });
                    self.hideLoading();
                    self.clearData(res.data.data);
                    //重算价格
                    self._calcPrice();
                }
                else {
                    config.bookingSuccess = -1;
                    config.ErrorMsg = res.data.message || config.ErrorMsg;
                    self.setData({
                        config: config
                    });
                    self.showLoading(-1, config.ErrorMsg);
                }
            },
            fail: function (error) {
                config.bookingSuccess = -1;
                self.showLoading(-1, ERRORMESSAGE.NETWORK);
            },
            complete: function () {
                //关闭loading
            }
        });
    },
    //处理booking数据
    clearData: function (data) {
        var self = this,
            insureInfo = data.insureInfo,
            fill = self.data.fill,
            booking = self.data.booking,
            config = self.data.config,
            seatNum = 9,
            seatPreTips = '(剩',
            seatPosTips = '张成人票)',
            insure = [];
        if (data.priceChangeNotes && data.priceChangeNotes.content) {
            self.singleModal(data.priceChangeNotes.content, data.priceChangeNotes.title);
        }
        if (data.vendorInfo && data.vendorInfo.seatInfo) {
            var seatInfo = data.vendorInfo.seatInfo;
            seatNum = seatInfo.seatNum > seatInfo.maxPassenger? seatInfo.maxPassenger: seatInfo.seatNum;
            if (seatNum <= 9) {
                if (seatInfo.seatNum > seatInfo.maxPassenger) {
                    seatPreTips = '(本航班单次仅支持';
                    seatPosTips = '人购买）';
                }
            }
        }
        if (seatNum < 2) {
            config.showAddPsgBtn = false;
        }
        booking.seatNum = seatNum;
        booking.seatPreTips = seatPreTips;
        booking.seatPosTips = seatPosTips;
        self.setData({
            config: config,
            booking: booking
        });
        //存在退改签信息存入storage
        if (data.tgqInfo) {
            wx.setStorage({
                key: 'tgqInfo',
                data: data.tgqInfo
            });
        }
        //存在活动购票须知存入storage
        if (data.activityInfo) {
            wx.setStorage({
                key: 'activityInfo',
                data: data.activityInfo
            });
        }
        //各种协议存入storage
        if (data.ticketNoticeInfos && data.ticketNoticeInfos.length) {
            for (var i = 0, len = data.ticketNoticeInfos.length; i < len; i++) {
                wx.setStorage({
                    key: 'ticketNoticeInfos' + i,
                    data: data.ticketNoticeInfos[i]
                });
            }
        }
        //初始化保险默认勾选
        if (insureInfo) {
            for (var i = 0,len = insureInfo.length; i < len; i++) {
                insure.push({
                    value: !!insureInfo[i].checked,
                    id: i
                });
                config.insureService += insureInfo[i].name + '/';
            }
            //默认保险协议
            config.insureService = config.insureService.substring(0,config.insureService.length-1);
            fill.insure = insure;
            self.setData({
                fill: fill,
                config: config
            })
            self.setInsureServiceInfos();
        }

        //读取用户暂存的输入内容
        self._readFillInfo();
    },
    //设置协议信息中的保险协议
    setInsureServiceInfos: function () {
        var data = this.data,
            config = data.config,
            fill = data.fill,
            insure = fill.insure,
            booking = data.booking,
            insureInfo = booking.insureInfo,
            hasBuyInsure = false,
            insureService = '',
            insureServiceInfo = {
                title: '保险说明',
                infos:[]
            };
        for (var i = 0,len = insure.length; i < len; i++) {
            if (insure[i].value) {
                hasBuyInsure = true;
                insureServiceInfo.infos.push(insureInfo[i].detailInfo);
                insureService += insureInfo[i].name + '/';
            }
        }
        if (hasBuyInsure) {
            insureService = insureService.substring(0, insureService.length - 1);
            wx.setStorage({
                key: 'insureService',
                data: insureServiceInfo
            });
        }
        config.insureService = insureService;
        this.setData({
            config: config
        });
    },
    /*     事件       */
    //用户输入框输入事件
    bindInput: function (e) {
        var dataset = e.target.dataset,
            fillType = dataset.fillType,
            fillName = dataset.fillName,
            index = dataset.index,
            value = e.detail.value,
            fill = this.data.fill;
        if (index != undefined) {
            fill[fillType][index][fillName] = value;
        }
        else {
            fill[fillType][fillName] = value;
        }
        this.setData({fill: fill});
    },
    //增加乘机人
    addPsgTap: function (e) {
        var data = this.data,
            self = this,
            fill = data.fill,
            config = data.config,
            currentPsgNum = fill.passengerList.length,
            seatNum = data.booking.seatNum,
            passengerList = data.fill.passengerList;
        if (currentPsgNum < seatNum) {
            passengerList.push({
                name: '',
                idCard: '',
                onFocus: false,
                nameErrorMsg:'',
                idCardErrorMsg:'',
                passengerClass: 'opening'
            });
            if (passengerList.length >= seatNum || passengerList.length >= 9) {
                config.showAddPsgBtn = false;
            }

            //WATCHER
            this._qWatcher.addCount(WATCHER.BOOKING.ADD_PSG_CLICK);
        }
        self.setData({
            fill: fill,
            config: config
        });
        setTimeout(function(){
            passengerList[passengerList.length - 1].passengerClass = 'passenger-item';
            self.setData({
                fill: fill
            });
            //重算价格
            self._calcPrice();
        },PASSENGER.ANIMATION_TIME);
    },
      //链接跳转事件
    bindLink: function(e) {
        var self = this,
            data = self.data,
            config = data.config,
            lastNavTime = config.lastNavTime,
            dataset = e.target.dataset,
            type = dataset.type,
            now = new Date().getTime(),
            url = "../viewInfo/viewInfo?from=booking&type=" + type;
            //避免多次点击
        if (now - lastNavTime >= 500) {
            config.lastNavTime = now;
            self.setData({
                config: config
            })
            wx.navigateTo({
                url: url
            });
        }
    },
    //删除乘机人点击事件
    delPsgTap: function(e) {
        var self = this,
            dataset = e.target.dataset,
            index = dataset.index,
            data = self.data,
            fill = data.fill,
            config = data.config,
            seatNum = data.booking.seatNum,
            passengerList = fill.passengerList;
            //删除乘机人
        passengerList[index].passengerClass = 'closing';
        if ((passengerList.length - 1 < seatNum)&&(passengerList.length <= 9)) {
            config.showAddPsgBtn = true;
        }
        config.readyDelIndex = PASSENGER.NO_DEL;
        self.setData({
            fill:fill,
            config: config
        });
        setTimeout(function(){
            passengerList.splice(index,1);
            self.setData({
                fill: fill
            });
            //WATCHER
            self._qWatcher.addCount(WATCHER.BOOKING.DEL_PSG_CLICK);
            //重算价格
            self._calcPrice();
        },PASSENGER.ANIMATION_TIME);
    },
    /**
     * 乘机人进入删除状态按钮
     * @param e
     */
    readyDelPsgTap: function (e) {
        var dataset = e.currentTarget.dataset,
            index = dataset.index,
            data = this.data,
            config = data.config;
            config.readyDelIndex = index;
        this.setData({
            config:config
        });
    },
    /**
     * 显示价格详情
     */
    showDetailTap: function(e) {
        var self = this,
            data = self.data,
            config = data.config;
            self._qWatcher.addCount(WATCHER.BOOKING.PRICE_DETAIL);
        config.showPriceDetail = !config.showPriceDetail;
        self.setData({
            config:config
        });
    },
    //协议状态改变
    agreementsTap: function (e) {
        var data = this.data,
            fill = data.fill;
        fill.agreements = !fill.agreements;
        this.setData({
            fill:fill
        });
    },
    /**
     * 弹层event
     */
    tapPopEvent: function(e){
        this._popModal = new PopModal(this);
        var dataset = e.currentTarget.dataset,
            type = dataset.type,
            index = dataset.index,popData,
            data = this.data;
        if (type === 'nameNotice') {
            //WATCHER
            this._qWatcher.addCount(WATCHER.BOOKING.NAME_NOTICE_CLICK);
            popData = data.booking.nameNotice;
        }
        else if (type === 'insureInfo') {
            this._qWatcher.addCount(WATCHER.BOOKING.INSURE_NOTICE_CLICK);
            popData = data.booking.insureInfo[index].detailInfo;
        }
        else if (type === 'specialTips') {
            popData = data.booking.specialTips;
            if (!popData.contents || !popData.contents.length) {
                return;
            }
            popData.title = '提示信息';
        }
        if (popData && Object.keys(popData).length) {
            this._popModal.showModal(popData);
        }
    },
    /**
     * 输入框获取焦点
     * 去掉错误信息
     * 身份信息放大显示
     */
    bindFocus: function(e) {
        var dataset = e.target.dataset,
            index = dataset.index,
            fillType = dataset.fillType,
            fillName = dataset.fillName,
            data = this.data,
            fill = data.fill;
        if (index != undefined) {
            fill[fillType][index][fillName+'ErrorMsg'] = '';
        }
        else {
            fill.contact[fillName+'ErrorMsg'] = '';
        }
        // 身份信息不放大
        // if (fillName === 'idCard') {
        //     fill.passengerList[index].onFocus = true;
        // }
        this.setData({
            fill:fill
        });
    },
    bindBlur: function(e) {
        var dataset = e.target.dataset,
            index = dataset.index,
            fillType = dataset.fillType,
            fillName = dataset.fillName,
            value = e.detail.value,
            data = this.data,
            params = data.params,
            fill = data.fill;
        if (fillName === 'idCard') {
           value = inputSpace.insertSpace(value,[6,15]);
           fill.passengerList[index].onFocus = false;
        }
        else if (fillName === 'mobile') {
           value = inputSpace.insertSpace(value,[3,8]);
        }
        if (index != undefined) {
            fill[fillType][index][fillName] = value;
        }
        else {
            fill[fillType][fillName] = value;
        }
        var relationData = {
            depDate: params.depDate,
            passengerList: fill.passengerList
        }
        if (index != undefined) {
            fill[fillType][index][fillName] = value;
            fill[fillType][index][fillName+'ErrorMsg'] = validater(fillName,value,relationData);
        }
        else {
            fill[fillType][fillName] = value;
            fill.contact[fillName+'ErrorMsg'] = validater(fillName,value,relationData);
        }
        this.setData({
            fill:fill
        });

    },
    /**
     * 重置删除状态
     */
    restDelTap: function (e) {
        var dataset = e.target.dataset,
            index = dataset.index,
            data = this.data,
            config = data.config;
        if (config.readyDelIndex === index) {
            config.readyDelIndex = PASSENGER.NO_DEL;
            this.setData({
                config:config
            });
        }
    },
    /**
     * 保险switch
     */
    insureChange:function(e) {
        var index = e.currentTarget.dataset.index,
            self = this,
            data = self.data,
            fill = data.fill,
            booking = data.booking,
            priceInfo = booking.priceInfo,
            adultPrice = priceInfo.adultPrice,
            prefer = adultPrice.barePrice - adultPrice.packagePrice,
            insure = fill.insure[index],
            value = insure.value,
            insureInfo = booking.insureInfo[index];
        if (value) {
            self._qWatcher.addCount(WATCHER.BOOKING.INSURE_CLOSE);
        }
        else {
            self._qWatcher.addCount(WATCHER.BOOKING.INSURE_OPEN);
        }
        if (value && insureInfo.hasPrefer && prefer > 0) {
            var content = '购买' + insureInfo.name + '可享受优惠套餐价，优惠' + prefer + '元。取消' + insureInfo.name + '，票价将由' + adultPrice.packagePrice + '元恢复为' + adultPrice.barePrice + '元。'
            wx.showModal({
                title: '小驼提示',
                content: content + '\n',
                confirmColor: COLOR.TEXT,
                success: function(res) {
                    if (res.confirm) {
                        insure.value = !insure.value;
                        self.setData({fill:fill});
                        // //重算价格
                        self._calcPrice();
                        self.setInsureServiceInfos();
                    }
                    else{
                        self.setData({fill:fill});
                    }
                }
            });
        }
        else {
            insure.value = !insure.value;
            self.setData({fill:fill});
            // //重算价格
            self._calcPrice();
            self.setInsureServiceInfos();
        }

    },
    /**
     * 提交生单
     */
    submitTap: function (e) {
        var self = this;
        self.showLoading(1, '正在为您提交订单...');
        var result = self._validate();
        //校验失败
        if (result !== true) {
            self.hideLoading();
            self.singleModal(result);
            return;
        }
        var data = orderPaser(self.data);
        self._createOrderRequest(data);
        self._qWatcher.pageEnd();
    },
    _createOrderRequest: function(data) {
        var self = this;
        var opt = {
            service: API_URLS.CREATE_ORDER,
            method: 'POST',
            watcher: self._qWatcher,
            target: WATCHER.BOOKING.CREATE_ORDER_REQ,
            data: data,
            success: function(res) {
                //页面卸载，终止
                if (self.data.config.unLoad) {
                    return;
                }
                if (res && res.data.status == 0) {
                    self.showLoading(1, '正在发起支付请求...');
                    flightPay({
                        orderData: res.data.data,
                        page: self,
                        name: 'BOOKING'
                    });
                    // self._payMethodRequest(res.data.data);
                }
                else {
                    self.hideLoading();
                    var msg = (res && res.data && res.data.message) || '提交订单失败，请稍后再试.'
                    self.singleModal(msg);
                }
            },
            fail: function(res) {
                //页面卸载，终止
                if (self.data.config.unLoad) {
                    return;
                }
                self.hideLoading();
                self.singleModal('您的网络似乎有点问题。');
            }
        };
        requester.request(opt);
    },
    _payMethodRequest: function(orderData) {
        var orderTokenInfo = orderData.tokenInfo,
            orderNo = (orderData.priceInfo && orderData.priceInfo.orderNo) || '',
            mobile = (orderData.contacter && orderData.contacter.phone) || '';
        var self = this,
            user = getApp().user,
            openId = user.openId,
            sign = orderData.sign,
            s_time = new Date().getTime();
        if (!orderTokenInfo || !orderTokenInfo.cashierUrl || !orderTokenInfo.token) {
            self.hideLoading();
            wx.showModal({
                title: '小驼提示',
                content: '发起支付请求失败，稍后再试。\n',
                showCancel: false,
                confirmColor: COLOR.TEXT,
                success: function(res) {
                    self.showLoading(1,'支付失败，正在跳转订单详情');
                    setTimeout(function(){
                        self._gotoOrderDetail(orderNo, mobile, sign);
                    },2000);
                }
            });
            return;
        }
        var payStatus = -1;
        var opt = {
            cashierUrl: orderTokenInfo.cashierUrl,
            openId: openId,
            bd_source:"wx",
            success: function(res){
                payStatus = 1;
                //页面卸载，终止
                if (self.data.config.unLoad) {
                    return;
                }
            },
            fail: function(error){
                payStatus = 0;
                //页面卸载，终止
                if (self.data.config.unLoad) {
                    return;
                }
            },
            complete: function() {
                //页面卸载，终止
                if (self.data.config.unLoad) {
                    return;
                }
                //支付结果
                var result,text = '';
                if(payStatus == 1) {
                    result = '_success';
                    text = '支付成功，';
                }
                else if(payStatus == 0) {
                    result = '_fail';
                    text = '支付失败，';
                }
                else {
                    result = '_cancel';
                    text = '支付取消，';
                }
                self._qWatcher.addCount(WATCHER.BOOKING.WX_PAY_REQ + result);
                self.showLoading(1,text + '正在跳转订单详情');
                setTimeout(function(){
                    self._gotoOrderDetail(orderNo, mobile, sign);
                },2000);
                self._qWatcher.addTime(WATCHER.BOOKING.WX_PAY_REQ + '_time', new Date().getTime() - s_time);
            },
            beforeOpen: function() {
            },
            afterOpen: function() {
                self.hideLoading();
            }
        };
        Pay.openCashier(opt);

    },
    _gotoOrderDetail: function(orderNo, mobile, sign) {
        orderNo = encodeURIComponent(orderNo);
        mobile = encodeURIComponent(mobile);
        sign = encodeURIComponent(sign);
        var url = '/flight/pages/orderDetail/orderDetail?orderNo=' + orderNo + '&mobile=' + mobile + '&sign=' + sign;
        wx.redirectTo({
            url: url
        });
    },
    // 生单前校验
    _validate: function () {
        var data = this.data,
            fill = data.fill,
            booking = data.booking,
            passengerList = fill.passengerList,
            contact = fill.contact,result,
            params = data.params,
            relationData = {
            depDate: params.depDate,
            passengerList: fill.passengerList
        }
        //乘机人数量校验
        if ((booking.seatNum && passengerList.length > booking.seatNum) || passengerList.length > 9) {
            return '对不起，本航班最多支持' + (booking.seatNum || 9) + '个人购买，请修改后提交。';
        }

        //乘机人合法性校验
        var checkItems = ['name', 'idCard'];
        for (var i = 0, len = passengerList.length; i < len; i++) {
            for (var j = 0; j < checkItems.length; j++) {
                result = validater(checkItems[j], passengerList[i][checkItems[j]], relationData);
                if (result !== '' || result.length) {
                    return result + '，请修改后提交。';
                }
            }
        }
        //联系人校验
        var checkItems = ['contactName', 'mobile'];
        for (var j = 0; j < checkItems.length; j++) {
            result = validater(checkItems[j], contact[checkItems[j]], relationData);
            if (result !== '' || result.length) {
                return result + '，请修改后提交。';
            }
        }
        //阅读协议校验
        if (fill.agreements !== true) {
            return '在提交订单前请确认已阅读并同意商品相关条款和说明。';
        }
        return true;
    },
    /**
     * 计算价格
     */
    _calcPrice: function () {
        var data = this.data,
        booking = data.booking,
        insureInfo = booking.insureInfo,
        fill = data.fill,
        insure = fill.insure,
        passengerList = fill.passengerList,
        passengerNum = passengerList.length,

        priceInfo = booking.priceInfo,
        adultPrice = priceInfo.adultPrice,
        oilPrice = priceInfo.oil || 0,
        airportFee = priceInfo.airportFee || 0,
        ticketPrice = adultPrice.barePrice,

        priceTypeTips = '',
        preferFlag = false,
        totalPrice = 0;
        //计算保险价格
        for (var i = 0,len = insure.length; i < len; i++) {
            if (insure[i].value) {
                totalPrice += insureInfo[i].price * passengerNum;
                //计算让利
                if (insureInfo[i].hasPrefer) {
                    preferFlag = true;
                    priceTypeTips = '（购买' + insureInfo[i].name + '时）'
                }
            }
        }
        // 计算机票价格

        //减让利价
        if (preferFlag === true) {
            ticketPrice = adultPrice.packagePrice;
        }
        //总价=（机票价 + 燃油 + 机建） * 人数
        totalPrice += (ticketPrice + oilPrice + airportFee) * passengerNum;
        fill.totalPrice = totalPrice;
        fill.ticketPrice = ticketPrice;
        fill.priceTypeTips = priceTypeTips;
        this.setData({
            fill: fill
        });
    },
    //设置title
    _setNavigationBarTitle: function(data) {
        wx.setNavigationBarTitle({
            title: data.depCity + ' ⇀ ' + data.arrCity
        });
    },
    //读取存储用户输入信息
    _readFillInfo: function () {
        var flightFillData,passengerList = [],
            self = this,
            data = self.data,
            config = self.data.config,
            booking = self.data.booking,
            fill = data.fill;
        try {
            flightFillData = wx.getStorageSync(STORAGE_KEY.FLIGHT_PASSENGER_FILL);
            if (flightFillData.contact) {
                fill.contact.contactName = flightFillData.contact.contactName || '';
                fill.contact.mobile = flightFillData.contact.mobile || '';
            }
            if (flightFillData.passengerList && flightFillData.passengerList.length) {
                for (var i = 0,len = flightFillData.passengerList.length; i < len; i++) {
                    //暂存信息多于座位数或者大于最大限制数
                    if ((booking.seatNum && i >= booking.seatNum) || i > 9) {
                        break;
                    }
                    passengerList.push({
                        name: flightFillData.passengerList[i].name || '',
                        idCard: flightFillData.passengerList[i].idCard || '',
                        onFocus: false,
                        nameErrorMsg:'',
                        idCardErrorMsg:'',
                        passengerClass: 'passenger-item'
                    });
                }
                fill.passengerList = passengerList;
                if (passengerList.length >= booking.seatNum || passengerList.length >= 9) {
                    config.showAddPsgBtn = false;
                }
            }
            self.setData({
                fill: fill,
                config: config
            });
        } catch (error) {
        }
    },
    //存储用户输入信息
    _saveFillInfo: function () {
        var data = this.data,
            fill = data.fill,
            config = data.config,
            passengerList = fill.passengerList,
            contact = fill.contact,
            flightFillData = {
                passengerList:[],
                contact: {}
            };
        //booking失败不存储
        if (!config.bookingSuccess) {
            return;
        }
        for (var i = 0,len = passengerList.length; i < len; i++) {
            if (passengerList[i].name!='' || passengerList[i].idCard!='') {
                flightFillData.passengerList.push({
                    name: passengerList[i].name,
                    idCard: passengerList[i].idCard
                });
            }
        }
        flightFillData.contact = {
            contactName: contact.contactName,
            mobile: contact.mobile
        };
        wx.setStorage({
            key: STORAGE_KEY.FLIGHT_PASSENGER_FILL,
            data: flightFillData
        });
    },
    init: function(param) {
        var self = this;
        self._qWatcher = new QWatcher(WATCHER.BOOKING.PV);
        self._status = new Status(self);
        self._qWatcher.pageStart();
        self._setNavigationBarTitle(param);
        if(param.fromShare) {
            self.setStorage('DepCity_FLIGHT', param.depCity);
            self.setStorage('ArrCity_FLIGHT', param.arrCity);
            self.setStorage('DepDate_FLIGHT', new Date(param.depDate).getTime());
        }
    },
    /*          生命周期方法        */
    onLoad: function (param) {
        var self = this;
        self.init(param);
        self.loadData(param);
    },
    //分享功能
    onShareAppMessage: function () {
        var self = this;
        var params  = self.data.params;
        var priceInfo = self.data.booking.priceInfo;
        var price = priceInfo.adultPrice.packagePrice || priceInfo.adultPrice.barePrice;
        var query = [];
        self._qWatcher.addCount(WATCHER.BOOKING.SHARE);
        for (var key in params) {
            var value = params[key] || '';
            query.push(key + '=' + value);
        }

        query.push('bd_origin=' + utils.bdOrigin.getV() || '');
        query.push('fromShare=true');
        var jumpUrl = '/pages/business/flight/booking/booking?' + query.join('&');
        var shareUrl = '/home/pages/index?navigateTo=' + encodeURIComponent(jumpUrl);
        var title = '这张灰机票不错哦，和我一起旅行吧';
        var desc = params.depCity + '-' + params.arrCity + ' ' + dateFormat(new Date(params.depDate), 'm月d日');
        if (price) {
            desc += ' ¥' + price;
        }
        return {
            title: title,
            desc: desc,
            path: shareUrl
        }
    },
    onReady: function(param) {
    },
    // 隐藏
    onHide: function () {
        //暂存乘机人信息
        this._saveFillInfo();
    },
    //页面卸载
    onUnload: function () {
        var self = this,
            config = self.data.config;
        config.unLoad = true;
        self.setData({
            config: config
        })
        //暂存乘机人信息
        self._saveFillInfo();
    }
})
