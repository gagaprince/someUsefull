var qWatcher = require('../../utils/qWatcher.js');
Page({
    onLoad: function (params) {
        var that = this,
            source = params.from;
        this._qWatcher = new qWatcher('wechat_view_info');
        if (params.type === 'tgqInfo') {
            this._qWatcher.addCount(source + '_tgqinfo');
        }
        wx.getStorage({
            key: params.type,
            success: function(res) {
              that.setData({
                  viewInfo: res.data
                })
            }
        })
    },
    //页面卸载
    onUnload: function () {
        var self = this;
        self._qWatcher.pageEnd();
    },
    onReady: function() {
        this.setNavigationBarTitle();
    },

    setNavigationBarTitle: function() {
        wx.setNavigationBarTitle({
            title: this.data.viewInfo.title
        });
    }
})
