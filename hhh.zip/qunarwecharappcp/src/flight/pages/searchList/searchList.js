var Status = require('../../../common/templates/status/status.js');
var extend = require('../../../common/utils/object/extend.js');
var dateMath = require('../../../common/utils/date/math.js');
var dateFormat = require('../../../common/utils/date/format.js');
var EventEmitter = require('../../../common/EventEmitter.js');
var requester = require('../../utils/qRequester.js');
var utils = require("../../../common/utils.js");
// var requester = require('../../../common/requester.js');
var qWatcher = require('../../utils/qWatcher.js');
var constant = require('../../constant.js');
var COLOR = constant.COLOR,
    STORAGE_KEY = constant.STORAGE_KEY;
var app = getApp();
/**
 * url参数
 * @param depCity 出发城市
 * @param arrCity 到达城市
 * @param depDate 出发日期
 */
Page({
    data: {
        params: {
            sort: 1, //1 价格从低到高 3 价格从高到底低 2 从早到晚 4 从晚到早
            page: 1
        },
        filters: [
            {
                key: 'price',
                text: '从低到高',
                selected: true,
                defaultText: '价格',
                selectedText: ['从低到高', '从高到低'],
                sort: [1, 3],
                ruleKey: 'sort_by_price'
            },
            {
                key: 'time',
                text: '时间',
                selected: false,
                defaultText: '时间',
                selectedText: ['从早到晚', '从晚到早'],
                sort: [2, 4],
                ruleKey: 'sort_by_time'
            }
        ],
        statusData:{
            status: 4,
            statusDesc:'加载中...'
        },
        previousDisable: false,
        nextDisable: false,
        nextDepDate: '',
        preDepDate: '',
        playNextDateAni: false,
        playPreDateAni: false,
        scrollTop: ''
    },
    onLoad: function(params) {
        this.storeParams(params);
        this._status = new Status(this);
        this.init(params);
        this.dataComplete = false;
        this.isBooking = false;
        this.initEvent();
        this.qWatcher = new qWatcher('wechat_search_list');
        this.loadTime = new Date();
    },
    setStorage: function(key, value) {
        wx.setStorage({
            key: key,
            data: value
        });
    },
    init: function(param) {
        var self = this;
        //搜索信息存入storage
        if(param.fromShare) {
            self.setStorage('DepCity_FLIGHT', param.depCity);
            self.setStorage('ArrCity_FLIGHT', param.arrCity);
            self.setStorage('DepDate_FLIGHT', new Date(param.depDate).getTime());
        }
    },
    //分享功能
    onShareAppMessage: function () {
        var self = this;
        var nickName = app.user.nickName;
        var data  = this.data.params;
        var jumpUrl = '/flight/pages/searchList/searchList?fromShare=true&depCity=' + data.depCity + '&arrCity=' + data.arrCity +'&depDate=' + data.depDate+'&bd_origin=' + utils.bdOrigin.getV() || '';
        var shareUrl = '/home/pages/index?navigateTo=' + encodeURIComponent(jumpUrl);
        var title = (nickName || '我') + '正在预订机票，你也来看看吧';
        var desc = data.depCity + '-' + data.arrCity + ' ' + dateFormat(new Date(data.depDate), 'm月d日');
        self.qWatcher.addCount('share');
        return {
            title: title,
            desc: desc,
            path: shareUrl
        }
    },
    onReady: function(param) {
        this.setNavigationBarTitle();
        this.loadData(4);
    },
    onShow: function() {
        if (this.qWatcher) {
            this.qWatcher.pageStart();
        }
    },
    initEvent: function() {
        var self = this;
        EventEmitter.addListener(constant.event.FLIGHT_CALENDAR_DATE_CHANGE, function(date) {
            self.handleDateChange(date);
        });
    },
    storeParams: function(params) {
        this.setData(extend(this.data.params, params));
    },
    setNavigationBarTitle: function() {
        wx.setNavigationBarTitle({
            title: this.data.params.depCity + ' ⇀ ' + this.data.params.arrCity
        });
    },
    loadData: function(loadType) {
        this.dataComplete = false;
        if (loadType) {
            this._status.show(loadType);
        }
        //console.log('loadData');
        //console.log('当前参数' + JSON.stringify(this.data.params));
        var self = this;
        requester.request({
            service: '/flight/search/flightList',
            data: extend({}, this.data.params),
            success: function(data) {
                data = data.data;
                if (data.status !== 0) {
                    self.showError(constant.ERRORMESSAGE.SERVER);
                } else {
                    self.setData({
                        scrollTop: 'header-holder'
                    });
                    setTimeout(function(){
                        self.setData({
                            scrollTop: ''
                        });
                    },100);
                    data = data.data;
                    self.handleData(data);
                    self._status.hide();
                }
            },
            fail: function(e) {
                self.showError(constant.ERRORMESSAGE.NETWORK);
            },
            complete: function() {
                self.dataComplete = true;
            },
            target: 'flightlist',
            watcher: this.qWatcher
        });
    },
    showError: function(msg) {
        this._status.show(-2, msg);
    },
    handleData: function(data) {
        var depDate = new Date(this.data.params.depDate);
        data.depDate = dateFormat(depDate, 'm月d日 周w');

        var previousDisable = false;
        var nextDsiable = false;
        var today = new Date(dateFormat(new Date(), 'yyyy-mm-dd'));
        var lastDay = dateMath.addDays(today, 365);
        if (depDate.getTime() === today.getTime()) {
            previousDisable = true;
        }
        if (depDate.getTime() === lastDay.getTime()) {
            nextDsiable = true;
        }
        data.previousDisable = previousDisable;
        data.nextDsiable = nextDsiable;

        data.flightList = data.flightList || [];
        //ios上的bug 如果当前有航班  切换下一天没航班时 显示的还是当前的航班
        if (data.flightList.length === 0) {
            data.flightList.push({
                iosBug: true
            });
        }
        this.setData(data);
    },
    filterChange: function(e) {
        if (!this.dataComplete) {
            return;
        }
        //标记当前dom对象 selected为true
        //其余fliter selected为false
        var target = e.currentTarget;
        var key = target.dataset.key;
        var text = target.dataset.text;
        var self = this;
        var filters = this.data.filters;

        filters.forEach(function(val) {
            if (val.key === key) {
                var selectedTextIndex = 0;
                if (val.selected) {
                    //点击之前 该filter就是选中状态
                    selectedTextIndex = val.selectedText.indexOf(text) === 0 ? 1 : 0;
                } else {
                    selectedTextIndex = val.opRecord || 0;
                }
                val.opRecord = selectedTextIndex;
                val.text = val.selectedText[selectedTextIndex];
                val.selected = true;
                self.data.params.sort = val.sort[selectedTextIndex];
            } else {
                val.text = val.defaultText;
                val.selected = false;
            }
        });
        self.setData({
            filters: filters,
            params: self.data.params
        });
        self.loadData(1);
        var ruleKey = target.dataset.ruleKey;
        self.qWatcher.addCount(ruleKey);
    },
    handleDateChange: function(date) {
        if (!this.dataComplete) {
            return;
        }
        // wx.setStorage({
        //     key: "DepDateflight",
        //     data: date.getTime()
        // });
        EventEmitter.dispatch(constant.event.CALENDAR_DATE_CHANGE, date);
        var dateForDisplay = dateFormat(date, 'm月d日 周w');
        this.setData(extend(this.data, {
            depDate: dateForDisplay
        }));
        this.data.params.depDate = dateFormat(date, 'yyyy-mm-dd');
        this.data.params.page = 1;
        this.loadData(1);
    },
    previousOrNextDateChange: function(e) {
        var self = this;
        var target = e.currentTarget;
        if (target.dataset.disable === 'true') {
            return;
        }
        var ruleKey = target.dataset.ruleKey;
        var type = parseInt(target.dataset.type);
        var depDate = dateMath.addDays(new Date(this.data.params.depDate), type);

        var data = this.data;
        if (type === 1) {
            data.playNextDateAni = true;
            data.nextDepDate = dateFormat(depDate, 'm月d日 周w');
        } else {
            data.playPreDateAni = true;
            data.preDepDate = dateFormat(depDate, 'm月d日 周w');
        }

        this.setData(data);

        setTimeout(function() {
            self.setData({
                playNextDateAni: false,
                playPreDateAni: false
            });
        }, 400);

        this.handleDateChange(depDate);
        this.qWatcher.addCount(ruleKey);
    },
    showCalendar: function() {
        var self = this;
        var data = self.data;
        this.qWatcher.addCount('calendar');
        var params = {
            bizType: "flight", 
            date: data.params.depDate, // 默认单选日期；多选的第一个日期 （不传的话展示今天）
            startCity: data.depCity,
            destCity: data.arrCity,
            eventType: constant.event.FLIGHT_CALENDAR_DATE_CHANGE,  // 选择日期成功之后触发的事件，通过监听这个事件来得到响应
            storageType: data.DEP_DATE
        };
        params.url = encodeURIComponent('/flight/pricetrend');  // 请求日历数据的url，一定要encode
        params.reqData = {   // 请求日历数据的 参数
            startCity: data.params.depCity,
            destCity: data.params.arrCity,
            checkType: 'ajax',
            priceType: 2
        };
         wx.navigateTo({
            url: '/common/pages/calendar/calendar?data=' + JSON.stringify(params)
        });
    },
    booking: function(e) {
        var self = this;
         //console.warn('点击booking');
        if (this.isBooking) {
            //console.warn('正在booking中 中止');
            return;
        }
        //console.warn('有效BOOking');
        this.isBooking = true;
        setTimeout(function() {
            self.isBooking = false;
        }, 1000);
        var now = new Date();
        if (now.getTime() - this.loadTime.getTime() >= 1000 * 60 * 10) {
            wx.showModal({
                title: '小驼提示',
                content: '航班信息可能已过期，请重新搜索\n',
                complete: function() {
                    self.loadTime = new Date();
                    self.loadData(1);
                },
                showCancel: false,
                confirmColor: COLOR.TEXT
            });
            return;
        }

        var index = parseInt(e.currentTarget.dataset.index);
        var flightInfo = this.data.flightList[index];
        var params = '';
        var paramsFromParams = [
            'depCity', 'arrCity', 'depDate'
        ];

        paramsFromParams.forEach(function(key) {
            params += key + '=' + self.data.params[key] + '&';
        });

        var paramsFromFightinfo = [
            'hasStop',, 'airCode', 'mainAirCode', 'depAirportCode', 'arrAirportCode',
            'depTime', 'arrTime', 'extparam', 'price'
        ];

        paramsFromFightinfo.forEach(function(key) {
            params += key + '=' + flightInfo[key] + '&';
        });
        //跳转booking页面结束
        this.qWatcher.pageEnd();
        wx.navigateTo({
            url: '/flight/pages/booking/booking?' + params,
            complete: function() {
                //booking时有时会闪一下  延迟下执行历史记录
                setTimeout(function() {
                    //标记点击过
                    self.data.flightList[index].clicked = true;
                    self.setData(self.data);
                }, 200);
            }
        });

        this.qWatcher.addCount('booking');
    },
    networkRetry: function() {
        this.loadData(4);
    },
    longtap: function() {
       // console.log('longtap');
    },
    onUnload: function() {

    }
});
