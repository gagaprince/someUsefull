function PopModal(root) {
	this._root = root;
	root.hidePopModal = this.hideModal.bind(this);
}

PopModal.prototype.showModal = function(data) {
	var that = this;

	that.setData({
		popData: data
	});
}

PopModal.prototype.hideModal = function() {
	var that = this;

	that.setData({
		popData: null
	});
} 

PopModal.prototype.setData = function(data, completion) {
    this._root.setData({
        popData: data
    });
    completion && completion();
}

module.exports = PopModal;