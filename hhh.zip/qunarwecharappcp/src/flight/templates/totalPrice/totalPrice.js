function TotalPrice(root) {
	this._root = root;
	root.hidePopModal = this.hideModal.bind(this);
}

TotalPrice.prototype.showModal = function(data) {
	this.setData({
		totalPrice: data
	});

	this._root.setData({
		'isPop': true
	});
}

TotalPrice.prototype.hideModal = function() {
	this.setData({
		totalPrice: null
	});

	this._root.setData({
		'isPop': false
	});
} 

TotalPrice.prototype.setData = function(data, completion) {
    this._root.setData({
        totalPrice: data
    });
    completion && completion();
}

module.exports = TotalPrice;