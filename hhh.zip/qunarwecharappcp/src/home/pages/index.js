var config = require("../../common/config.js")
var homeConfig = require("../../common/config/homeConfig.js")
var user = require("../../common/user.js")
var pay = require("../../common/pay.js")
var watcher = require("../../common/watcher.js")
var utils = require("../../common/utils.js")

//获取应用实例
var app = getApp()
Page({
    data: {
        nav: homeConfig.nav,
        aniCls:""
    },
    onShareAppMessage: function () {
        this.sendWatcher("share_tab_from_home")
        return utils.share.getParam({
            title: '去哪儿旅行',
            desc: '去哪儿旅行--酒店机票火车票汽车票门票预订服务'
        });
    },
    onLoad: function(params){
        utils.bdOrigin.setV(params.bd_origin);

        user.login(function(res){ });

        params = params || {}
        var app = getApp()
        app.globalData = app.globalData || {}
        app.globalData.bd_origin = params.bd_origin|| ""

        this.pageParams = params
        // this.isBeta = config.isBeta;
        // this.setDebug(config.isDebug, config.isBeta)
    },
    onShow: function(){
        var me = this
        //埋点需要放在之前
        user.getUserInfo(function(res){
            var user = (res.data && res.data.wechat) || {}
            if(user.isQunarUser != null){
                var isQunarUser = user.isQunarUser ?"isQunarUser" :"notQunarUser"
                me.sendWatcher(isQunarUser)
            }
            if(!res.ret){
                me.sendWatcher("user_getUserInfo_fail")
            }
            //微信授权——拒绝
            if(res.data && res.data.wx_getUserInfo_deny){
                me.sendWatcher("wx_getUserInfo_deny")
            }
        });
        this.setData({navFlag: false})
        wx.removeStorageSync('my_page_order_filter')   //订单过滤条件置为空，=默认值
        watcher.pv({ "page": "home" });
    },
    onReady: function () {
        //分享出去的链接，从首页跳转，这样可以回到首页可以进订单列表等
        var pageParams = this.pageParams || {}
        var navigateTo = pageParams.navigateTo || pageParams.navigateto
        var redirectTo = pageParams.redirectTo || pageParams.redirectto
        if(navigateTo){
            wx.navigateTo({ url: decodeURIComponent(navigateTo) })
            this.sendWatcher("home_navigateTo")
            return
        }
        if(redirectTo){
            wx.redirectTo({ url: decodeURIComponent(redirectTo) })
            this.sendWatcher("home_redirectTo")
        }
    },
    toBusiness: function(e) {
        var me = this
        var bizType = e.currentTarget.dataset && e.currentTarget.dataset.biztype;
        if (!bizType || me.data.navFlag) {
            return;
        }
        this.setData({navFlag: true})
        setTimeout(function() {
            me.sendWatcher("to_"+ bizType + "_from_home")
            var bizUrl = me.getBusinessUrl(bizType)
            wx.navigateTo({ url: bizUrl});
        }, 300)

    },
    getBusinessUrl: function(bizType) {
        var businessUrl
        if(bizType == "hotel") {
            businessUrl = '/hotel/pages/hotel/hotel-list/hotel-list'
        } else if(bizType == "ticket") {
            businessUrl = '/ticket/pages/list/list'
        } else {
            businessUrl = '/common/pages/search/index?from=home&bizType=' + bizType
        }
        return businessUrl
    },
    sendWatcher: function(actionType){
        watcher.click({
            "page": "home",
            "action-type": actionType
        })
    }
    // ,debugDomain:function(clearUserInfo){
    //     this.isBeta = !this.isBeta
    //     global.__BETA__ = this.isBeta;
    //     this.setData({ debugText: "请稍后......", debugStatusText:"(切换中)" })
    //     config.debugUpdateDomain(this.isBeta)
    //     if(clearUserInfo != false) {
    //         user.clearUserInfo()
    //     }
    //     var self = this
    //     user.login(function(res){
    //         if(res.ret){
    //             self.setDebug(true, self.isBeta)
    //             self.setData({ debugStatusText:"(切换完成)" })
    //         } else {
    //             self.setData({ debugStatusText:"(切换失败, 请重试): " + res.errMsg})
    //         }
    //     });
    // },
    // setDebug:function(isDebug, isBeta){
    //     var text = isBeta ? "当前是beta: 点击更换为线上": "当前是线上: 点击更换为beta"
    //     this.setData({ isDebug: isDebug, debugText: text, debugStatusText: ""})
    // }
})
