/**
* @Author: 少烈 <shaolie>
* @Date:   2016-11-29T16:07:48+08:00
* @Email:  lshaolie@163.com
* @Last modified by:   shaolie
* @Last modified time: 2016-11-30T22:47:54+08:00
* @Note: Please contact me if you find any bugs 🐜^*^
*/


var SeatUtil = {
    isSameTicketsType: function(srcTicketInfos, dstTicketInfos) {
        if (srcTicketInfos.length == dstTicketInfos.length) {
            for(var idx = 0; idx < srcTicketInfos.length; idx++) {
                for(var dstIdx = 0; dstIdx < dstTicketInfos.length; dstIdx++) {
                    // 相同
                    if(srcTicketInfos[idx].type == dstTicketInfos[dstIdx].type &&
                        srcTicketInfos[idx].price == dstTicketInfos[dstIdx].price) {
                        break;
                    }
                }

                // 如果条件成立，说明没找到相等的项
                if (dstIdx == dstTicketInfos.length) {
                    break;
                }
            }
            // 如果条件成立，说明是同类型的item
            if (idx == srcTicketInfos.length) {
                return true;
            }
        }
        return false;
    },

    /* 是否每个车次的备选坐席都选择了 */
    isEachTrainSeatSelected: function(trains) {
        for (var i = 0; i < trains.length; i++) {
            var ticketInfos = trains[i].ticketInfos;
            for (var j = 0; j < ticketInfos.length; j++) {
                var ticket = trains[i].ticketInfos[j];
                if (ticket.selected == true) {
                    break;
                }
            }
            if (j == ticketInfos.length) {
                return false;
            }
        }
        return true;
    }
};

module.exports = SeatUtil;
