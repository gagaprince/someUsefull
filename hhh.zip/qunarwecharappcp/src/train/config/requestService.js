/**
* @Author: 少烈 <shaolie>
* @Date:   2017-03-18T16:35:32+08:00
* @Email:  lshaolie@163.com
* @Last modified by:   shaolie
* @Last modified time: 2017-03-18T16:35:34+08:00
*/

var env = global.__envType == 'beta' ? (global.__env.train.envType || 'betad') : 'product';
module.exports = {
    // suggest
    SUGGEST: '/api/train/TrainStationSuggest',
    // 站站搜索
    SEARCH: '/api/train/trains2s',
    // faq
    FAQ: '/h5/train/TrainOrderFaqs',
    // 时刻表
    TIME_LABEL: '/h5/train/TrainDetail',
    // booking
    ORDER_FILL_OPT: '/h5/train/trainOrderFillOpt',
    // 提交订单
    ORDER_COMMIT: '/h5/train/trainordercommit',
    SAVE_ROB_ORDER: '/h5/train/flagship/SaveRobOrder',
    // 订单详情
    ORDER_DETAIL: '/h5/train/TrainOrderDetail',
    // 支付
    PAY_METHOD: '/h5/train/TrainPayMethod',
    // 推送乘客信息
    PRE_PUSH_PASSENGERS: '/api/train/TrainPrePushPassengers',
    // 身份核验
    PASSENGER_VERIFY: '/api/train/trainPassengerVerify',
    // 订单动作
    ORDER_ACTION: '/h5/train/TrainOrderOp',
    // 退票信息展示
    ORDER_REFUNDVIEW: '/h5/train/TrainTuiPiaoView',
    // 申请退票
    ORDER_REFUND: '/h5/train/TrainTuiPiao',
    // 日历预售期
    Calendar: '/api/train/TrainCalendar',
    // 监控
    Watcher: '/h5/train/TrainMonitor',
    // 12306登录
    Login12306: '/h5/train/flagship/Login',
    // 12306乘客列表
    PassengerList : '/h5/train/flagship/ContactsGet'
};
