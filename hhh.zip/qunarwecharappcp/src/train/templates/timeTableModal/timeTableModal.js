/*timeTableModal.js*/

/*
 * 使用该代理类时需要实现如下函数：
 * @func getTrain   {function}  用于提供 train 对象
 * train : {
 * 		dStation: string,     用户出发站（不一定是起始站）
 * 		aStation: string,     用户目标站（不一定是终点站）
 * 		stations: [{
 * 			no: string,       车站编号
 * 			name: string,     车站名称
 * 			arrTime: string,  到达时间
 * 			depTime: string,  出发时间
 * 			stayTime: string  停留时间
 * 		}],
 * }
 *
 * 内部会生成 timeTableModalData 对象，并作为 data 的一个字段，使用处无需关心
 * timeTableModalData : {
 * 		stationList: [OneOf[{
 * 			type: "cell",
            noStyle: string,
            noTextStyle: string,
            nameStyle: string,
            arrTimeStyle: string,
            depTimeStyle: string,
            stayTimeStyle: string,

            num: string,
            name: string,
            arrTime: string,
            depTime: string,
            stayTime: string
 * 		}, {
 * 			type: "expandButton",
 * 			tapEvent: OneOf["expandTimeTableStart", "expandTimeTableEnd"]
 * 		}]],
 * 		timeTableModalAnimationData: object    动画对象
 * }
 */

function TimeTableModal(root) {
    this._root = root;
    root.expandTimeTableStart = this._expandTimeTableStart.bind(this);
    root.expandTimeTableEnd = this._expandTimeTableEnd.bind(this);
    root.tapTimeTableModal = this.hideModalWithAnimation.bind(this);
    this.expandedStart = this.expandedEnd = false;
    this._syncRenderData();

    var animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease'
    });

    var that = this;
    wx.getSystemInfo({
        success: function(res) {
            var height = res.windowHeight;
            var offset = getApp().globalData.deviceInfo.isIOS ? 72 : 65;
            that.setData({
                contentScrollViewHeight: height - 168 - offset
            });
        },
        fail: function() {
            var height = getApp().globalData.deviceInfo.windowHeight;
            var offset = getApp().globalData.deviceInfo.isIOS ? 72 : 65;
            that.setData({
                contentScrollViewHeight: height - 168 - offset
            });
        }
    });

    this.animation = animation
}

/*public methor*/
TimeTableModal.prototype.showModalWithAnimation = function() {
    var that = this;
    this.setData({
        timeTableModalAnimationData: this.animation.export()
    }, function() {
        that.animation.opacity(1).step()
        that.setData({
            timeTableModalAnimationData: that.animation.export()
        });
    });
}

TimeTableModal.prototype.hideModalWithAnimation = function() {
    var that = this;
    this.animation.opacity(0).step();
    this.setData({
        timeTableModalAnimationData: that.animation.export()
    }, function() {
        setTimeout(function() {
            that.setData({
                timeTableModalAnimationData: null
            });
        }, 300);
    });
}

/*private methor*/
TimeTableModal.prototype._expandTimeTableStart = function() {
    this.expandedStart = true;
    this._syncRenderData();
}

TimeTableModal.prototype._expandTimeTableEnd = function() {
    this.expandedEnd = true;
    this._syncRenderData();
}

TimeTableModal.prototype._syncRenderData = function() {
    var that = this;
    var stationList = this._stationListPreLoad();
    wx.getSystemInfo({
        success: function(res) {
            var height = res.windowHeight;
            var expandStyle = (44 + 30 + 36 * stationList.length + 34 > height - 2 * 84) ? "flex: 1;" : "";
            that.setData({
                stationList: stationList,
                expandStyle: expandStyle
            });
        },
        fail: function(error) {
            var height = getApp().globalData.deviceInfo.windowHeight;
            var expandStyle = (44 + 30 + 36 * stationList.length + 34 > height - 2 * 84) ? "flex: 1;" : "";
            that.setData({
                stationList: stationList,
                expandStyle: expandStyle
            });
        }
    });
}

TimeTableModal.prototype._getStationIndex = function(stationName) {
    var stations = this._getTrain().stations;
    for (var i = 0; i < stations.length; i++) {
        if(stations[i].name == stationName) {
            return i;
        }
    }
    return -1;
}

TimeTableModal.prototype._getNoText = function(no, name) {
    var noStyle = "background-color': white";
    var noTextStyle = "color: #c7ced4";

    var train = this._getTrain();
    var num = no.length < 2 || no < 10 ? ('0' + no) : no;
    if (name == train.dStation) {
        num = '出';
    } else if (name == train.aStation) {
        num = '到';
    }

    if (name == train.dStation || name == train.aStation) {
        noStyle = "border-width: 0; width:20px; height:20px; background-color: #FF9705;";
        noTextStyle = "color: white";
    }
    return {
        noStyle: noStyle,
        noTextStyle: noTextStyle,
        num: num
    };
}

TimeTableModal.prototype._getContentCell = function(station, idx) {
    var train = this._getTrain();
    var dStationIndex = this._getStationIndex(train.dStation);
    var aStationIndex = this._getStationIndex(train.aStation);

    var noText = this._getNoText(station.no, station.name);
    var nameStyle, depTimeStyle, stayTimeStyle, arrTimeStyle;
    nameStyle = depTimeStyle = stayTimeStyle = arrTimeStyle = "color: #000000";

    if (station.name == train.dStation) {
        nameStyle = depTimeStyle = "color: #FF9705";
        arrTimeStyle = stayTimeStyle = "color: #888888";

    } else if (station.name == train.aStation) {
        nameStyle = arrTimeStyle = "color: #FF9705";
        stayTimeStyle = depTimeStyle = "color: #888888";
    }

    if (idx < dStationIndex || idx > aStationIndex) {
        arrTimeStyle = depTimeStyle = "color: #888888";
        nameStyle = stayTimeStyle = "color: #888888";
    }

    return {
        type: "cell",
        noStyle: noText.noStyle,
        noTextStyle: noText.noTextStyle,
        nameStyle: nameStyle,
        arrTimeStyle: arrTimeStyle,
        depTimeStyle: depTimeStyle,
        stayTimeStyle: stayTimeStyle,
        num: noText.num,
        name: station.name,
        arrTime: station.arrTime,
        depTime: station.depTime,
        stayTime: station.stayTime ? station.stayTime : "-"
    };
}

TimeTableModal.prototype._getExpandButton = function(tapEvent) {
    return {
        type: 'expandButton',
        tapEvent: tapEvent
    };
}

TimeTableModal.prototype._stationListPreLoad = function() {
    var train = this._getTrain();
    var dStationIndex = this._getStationIndex(train.dStation);
    var aStationIndex = this._getStationIndex(train.aStation);
    var isStartExpand = !this.expandedStart && dStationIndex > 3;
    var isEndExpand = aStationIndex != -1 && !this.expandedEnd && train.stations.length - aStationIndex > 3;

    var stationList = [];

    var that = this;
    train.stations.forEach(function(station, idx) {
        var needRender = (isStartExpand && idx == 0) ||
        (isEndExpand && idx == train.stations.length - 1) ||
        (idx >= dStationIndex && idx <= aStationIndex) ||
        (idx < dStationIndex && !isStartExpand) ||
        (idx > aStationIndex && !isEndExpand);

        if(needRender) {
            stationList.push(that._getContentCell(station, idx));
        }

        if (isStartExpand && idx == 0) {
            stationList.push(that._getExpandButton("expandTimeTableStart"));
        } else if (isEndExpand && idx == aStationIndex) {
            stationList.push(that._getExpandButton("expandTimeTableEnd"));
        }
    });
    return stationList;
}

TimeTableModal.prototype.setData = function(data, completion) {
    var timeTableModalData = this._root.data.timeTableModalData || {};
    for (var key in data) {
        timeTableModalData[key] = data[key];
    }

    this._root.setData({
        timeTableModalData: timeTableModalData
    });
    completion && completion();
}

TimeTableModal.prototype.getData = function(key) {
    return key ? this._root.data[key] : this._root.data;
}

TimeTableModal.prototype._getTrain = function() {
    return this._root.getTrain();
}

module.exports = TimeTableModal;
