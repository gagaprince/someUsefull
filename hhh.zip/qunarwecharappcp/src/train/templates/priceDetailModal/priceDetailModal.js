/**
* @Author: 少烈 <shaolie>
* @Date:   2016-10-09T10:05:25+08:00
* @Email:  lshaolie@163.com
* @Last modified by:   shaolie
* @Last modified time: 2016-10-09T10:15:01+08:00
* @Note: Please contact me if you find any bugs 🐜^*^
*/

var util = require('../../utils/util.js');
var isEmptyArray = util.isEmptyArray;
var isEmptyObject = util.isEmptyObject;

function createPriceItem(title, price, count, unit) {
    return {
        title: title,
        price: price,
        count: count,
        unit: unit
    };
}

function createPerferServer(title, price, count, unit) {
    if (price == 0) {
        return {
            title: title
        };
    }

    if (!unit) {
        unit = '人';
    }
    return {
        title: title,
        price: parseInt(price, 10),
        count: count,
        unit: unit
    };
}

function getPassengerCount(data) {
    // var {choosedPassengers} = data;

    if (isEmptyArray(data.choosedPassengers)) {
        return 0;
    }
    return data.choosedPassengers.length;
}

/**
 * 返回火车价格
 */
function getTicketPrice(data) {
    var selectedTicket = getSelectedTicket(data);

    if (!selectedTicket) {
        return 0;
    }
    return selectedTicket.price;
}

function filterSelectedTicket(data) {
    // var {orderResult} = data;
    if (isEmptyObject(data.orderResult)) {
        return null;
    }

    var orderResult = data.orderResult;
    var tickets = orderResult.tickets;
    for (var i = 0; i < tickets.length; i++) {
        if (tickets[i].ticketId == orderResult.checkTicket) {
            return tickets[i];
        }
    }
    return null;
}


function getAlternativeSeatPrice(data) {
    var ticketPrice = getTicketPrice(data);
    var maxPrice = ticketPrice;
    data.optionalItems[2].items.forEach(function(seat) {
        maxPrice = Math.max(seat.price, maxPrice);
    });
    if (maxPrice > ticketPrice) {
        return maxPrice;
    }
    return 0;
}

/**
 * 获取被选中的车票
 * @param  {Object} data data
 * @return {Ticket}       车票信息
 */
function getSelectedTicket(data) {
    var ticket = filterSelectedTicket(data)
    return ticket;
}

function getOtherSelectedPreferServer(data) {
    var selectedPreferServer = [];
    // var {product: {productInfo}} = data.orderResult;
    var productInfo = data.orderResult.product.productInfo;
    if (!isEmptyArray(productInfo)) {
        productInfo.forEach(function(otherProduct) {
            // var {productList, isJustOne} = otherProduct;
            var count = otherProduct.isJustOne ? 1 : getPassengerCount(data);
            otherProduct.productList.forEach(function(product) {
                if (product.pCheck && product.pPrice > 0) {
                    selectedPreferServer.push(
                        createPerferServer(product.pDesc, product.pPrice, count, otherProduct.isJustOne ? '份' : '人')
                    );
                }
            });
        });
    }
    return selectedPreferServer;
}

function getSelectedPreferServers(data) {
        // var {orderResult} = data;
        if (isEmptyObject(data.orderResult)) {
            return [];
        }

        var insurance = data.selectedInsurance;
        var selectedPreferServer = [];
        if (!isEmptyObject(insurance)) {
            var count = data.totalInsuranceCount;
            var selectedPS = createPerferServer(insurance.name, insurance.price, count);
            selectedPreferServer = [selectedPS];
        }

        //其他优选服务
        // selectedPreferServer = selectedPreferServer.concat(getOtherSelectedPreferServer(data));

        //过滤不购买选项
        if (selectedPreferServer.length > 0) {
            selectedPreferServer = selectedPreferServer.filter(function(server) {
                if (server.title.indexOf('不购买') == -1 && server.count > 0) {
                    return true;
                }
                return false;
            });
        }

        return selectedPreferServer;
}

//TODO 根据红包优惠返回价格
function getCouponPrice(data) {
    return 0;
}

// function getPriceDetailViewHeight(dataSource) {
//     var height = 40 + 50;
//     for (var i = 0; i < dataSource.length; i++) {
//         var source = dataSource[i];
//         for (var j = 0; j < source.length; j++) {
//             height += 40;
//         }
//     }
//     return height;
// }

function getNecessaryPriceSource(data){
    var priceSource = [];
    // var {orderResult} = data;
    if (isEmptyArray(data.orderResult)) {
        return priceSource;
    }

    //火车票费用
    var ticketPrice = getTicketPrice(data);
    var pCount = getPassengerCount(data);
    if (pCount > 0) {
        priceSource.push(createPriceItem('火车票', ticketPrice, pCount, '人'));
    }

    //备选坐席费用
    var alternativeSP = getAlternativeSeatPrice(data);
    if (alternativeSP > 0) {
        priceSource.push(createPriceItem(
            '备选坐席预收费用',
            alternativeSP - ticketPrice,
            pCount,
            '人'
        ));
    }
    return priceSource;
}

function getExtraPriceSource(data) {
    var priceSource = [];

    // 优选服务
    var selectedPreferServers = getSelectedPreferServers(data);
    if (isEmptyArray(selectedPreferServers)) {
        return priceSource;
    }

    selectedPreferServers.forEach(function(preferServer) {
        if (preferServer.price > 0) {
            var title = preferServer.title;
            if (title.indexOf('保险') != -1) {
                title = '出行保障';
            }
            priceSource.push(createPriceItem(
                title,
                preferServer.price,
                preferServer.count,
                preferServer.unit
            ));
        }
    });

    // 其他产品（一元免单等）
    // var bundleLabels = data.FillOrderReducer.trainFillOrderInfo.data.bundleLabels;
    // bundleLabels.map(function(bundleLabel, idx) {
    //     if (open) {
    //         // var unit = bundleLabel.countTag ? '人' : '份';
    //         var count =  bundleLabel.countTag ? getPassengerCount(data) : 1;
    //         priceSource.push(createPriceItem(
    //             bundleLabel.title,
    //             bundleLabel.unitPrice,
    //             bundleLabel.count,
    //             '人'
    //         ));
    //     }
    // });

    return priceSource;
}

function getDiscountPriceSource(data) {
    var discountSource = [];

    // var {orderResult} = data;
    if (isEmptyObject(data.orderResult)) {
        return discountSource;
    }

    //送票上门
    // if (data.CommonReducer.isShowHomeDelivery) {
    //     var deliveryDP = getDeliveryDiscountPrice(data);
    //     if (deliveryDP > 0) {
    //         discountSource.push(createPriceItem('送票上门立减', -deliveryDP, -1));
    //     }
    // }

    var couponPrice = getCouponPrice(data);
    if (couponPrice > 0) {
        discountSource.push(createPriceItem('优惠金额', -couponPrice, -1));
    }

    return discountSource;
}

function getPriceDetailSources(data) {
    var necessaryPS = getNecessaryPriceSource(data);
    var extraPS = getExtraPriceSource(data);
    var discountPS = getDiscountPriceSource(data);

    return [necessaryPS, extraPS, discountPS];
}

function PriceDetailModal(root) {
    this._root = root;
    if (!root.showPriceDetail) {
        root.showPriceDetail = this.showPriceDetail.bind(this);
    }

    this.syncRenderData();
}

/*public methor*/
/**
 * 总价格
 */
PriceDetailModal.prototype.getTotalPrice = function() {
    var passengerCount = getPassengerCount(this.getData());
    if (passengerCount < 1) {
        return 0;
    }
    var sources = this._getModalData().priceDataSource;
    return sources.reduce(function(pre, curArray) {
        return pre + curArray.reduce(function(prePrice, curItem) {
            return prePrice + Number(curItem.price) * Math.abs(curItem.count);
        }, 0);
    }, 0);
}

PriceDetailModal.prototype.showModalWithAnimation = function() {
    this.setData({
        showing: true,
        isShow: true
    });
}

PriceDetailModal.prototype.hideModalWithAnimation = function() {
    var that = this;
    this.setData({
        showing: false
    }, function() {
        setTimeout(function() {
            that.setData({
                isShow: false
            });
        }, 300);
    });
}

/*显示价格详情*/
PriceDetailModal.prototype.showPriceDetail = function(event) {
    if (getPassengerCount(this.getData()) > 0) {
        if (typeof event == "function") {
            event();
        }
        if (this._getModalData().isShow) {
            this.hideModalWithAnimation();
        } else {
            this.showModalWithAnimation();
        }
    }
}

/*private methor*/
PriceDetailModal.prototype.syncRenderData = function() {
    var detailSources =  getPriceDetailSources(this.getData());
    this.setData({
        priceDataSource: detailSources
    });
}

PriceDetailModal.prototype.setData = function(data, completion) {
    var priceDetailModalData = this.getData('priceDetailModalData') || {};
    for (var key in data) {
        priceDetailModalData[key] = data[key];
    }
    priceDetailModalData.priceDataSource = priceDetailModalData.priceDataSource.filter(elem => {
        return elem.length > 0;
    });
    this._root.data.priceDetailModalData = priceDetailModalData;
    this._root.setData({
        priceDetailModalData: priceDetailModalData
    });
    completion && completion();
}

PriceDetailModal.prototype._getModalData = function() {
    if (!this._root.data.priceDetailModalData) {
        this.syncRenderData();
    }
    return this._root.data.priceDetailModalData;
}

PriceDetailModal.prototype.getData = function(key) {
    return key ? this._root.data[key] : this._root.data;
}

module.exports = PriceDetailModal;
