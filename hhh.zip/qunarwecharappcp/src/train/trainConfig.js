/**
* @Author: 少烈 <shaolie>
* @Date:   2016-11-17T14:26:48+08:00
* @Email:  lshaolie@163.com
* @Last modified by:   shaolie
* @Last modified time: 2016-11-17T14:28:34+08:00
* @Note: Please contact me if you find any bugs 🐜^*^
*/

var Requester    = require('./utils/requester.js');
var Service      = require('./config/requestService.js');
var Utils = require('./utils/util.js');
var TrainConfig = {};

TrainConfig.onLaunch = function() {
    global.AccountInfoOf12306 = {};
    global.AccountInfoOf12306.isLogined12306 = false;

    setTimeout(function() {
        requestPassenger(2);
    }, 2000);
}

var requestPassenger = function (retryTimes) {
    var app = getApp();
    if (Utils.isEmptyString(app.user.unionId) ||
    Utils.isEmptyString(app.user.openId)) {
        setTimeout(function() {
            requestPassenger(--retryTimes);
        }, 2000);
    } else {
        Requester.request({
            service: Service.PassengerList,
            param: {
                reqType: "0",
                reqStage: "1"
            },
            success: function (response) {
                if (response.data && response.data.getStatus === 0) {
                    var passengers = response.data.passengers;
                    passengers.forEach(function(psg) {
                        psg.source = 2;
                    });

                    global.AccountInfoOf12306.passengers = passengers;
                    global.AccountInfoOf12306.isLogined12306 = true;
                }
            }
        });
    }
};

TrainConfig.onLaunch();


// if (!global.__DEV__) {
//     console.log = function() {}
// }

module.export = TrainConfig;
