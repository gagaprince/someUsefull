/**
 * 订单详情
 *
 * 跳转示例：
 * wx.redirectTo({url: "../orderDetail/orderDetail?orderNo=" + orderNo + "&phone=" + phone + "&token=" + token});
 * wx.navigateTo({url: "../orderDetail/orderDetail?orderNo=" + orderNo + "&phone=" + phone + "&token=" + token});
 *
 */

var TimeTableModal = require('../../templates/timeTableModal/timeTableModal.js');
var Network = require('../../../common/comps/network/network.js');
var Requester = require('../../utils/requester.js');
var Service      = require('../../config/requestService');
var Watcher = require('../../utils/watcher.js');
var Util = require('../../utils/util.js');
var Pay = require("../../../common/pay.js")
var App = getApp();
var TrainDef     = require('../../utils/define.js');
var ModalUtil   = require('../../utils/modalUtil.js');
var EventEmitter = require('../../../common/EventEmitter.js');
var EVENT_NAME      = TrainDef.TRAIN_EVENT_NAME;


var ORDER_STATUS = {
    ORDER_STATE_WAIT_PAY: '10',                 // 待支付
    ORDER_STATE_CANCEL: '140',                  // 订单取消
    ORDER_STATE_WAIT_TICKET : "30",             // 出票尝试中
    ORDER_STATE_EXPRESS : "50",                 // 出票完成
    ORDER_STATE_ROBING : "210",                 // 抢票中
    ORDER_STATE_PAPER_SUCC : "20"               // 订单等待处理
};

var TRAIN_ORDER_ACTION = {
    ACTION_NO : 0,
    ACTION_CANCEL : 1,                          // 取消订单
    ACTION_PAY : 2,                             // 支付
    ACTION_RETURN : 3,                          // 申请退票
    ACTION_12306 : 9,
    ACTION_ORDER_STATUS : 10,                   // 查看支付状态
    ACTION_REBOOK : 11,
    ACTION_12306_CHECKOUT : 12
};

var ORDER_OVER_TIME = 30 * 60 * 1000;         // 倒计时总时间 30分钟

Page({
    pageName: TrainDef.TRAIN_PAGE_NAME.ORDER_DETAIL,
    /**数据**/
    data: {
        networkData:{
            status: 4,                         // 网络状态
            loadingDesc:'加载中...'
        },
        orderDetail:{},                        // 请求结果
        orderStatus:{},                        // 订单状态
        timeLineBrief:{},                      // 车次信息
        passengerInfo:{                        // 乘客信息
            isNeedShowInsurance: false,        // 是否展示保险信息按钮
            passengerList: []
        },
        orderActions:[],                       // 订单操作
        isShowFeeDetail: false,                // 是否正在显示金额详情对话框
        isShowPayBtn: false,                   // 是否显示支付按钮
        isShowCountDown: false,                // 是否显示倒计时
        countDownText:''                       // 倒计时时间文字
    },
    orderDetail:{},                                   // 网络请求返回的订单详情数据
    orderDetailParam:{},
    timeTableTrainsData:{},                           // 车次时刻表数据
    countDownTime:0,                                  // 倒计时时间
    payCountDown:[],                                  // 倒计时定时任务
    actionPayType:TRAIN_ORDER_ACTION.ACTION_NO,       // 支付类型
    /**数据**/


    /*=========================================================*/
    // 点击事件
    /*=========================================================*/

    payClick: function() {
        if(this.actionPayType == TRAIN_ORDER_ACTION.ACTION_PAY){
            Watcher.sendWatcher.call(this, Watcher.keys.ORDER_DETAIL_PAY_ORDER);  //立即支付
            this.requestPay();
        }
    },
    actionItemClick: function (e) {
        var that = this;
        var orderAction = this.orderDetail.orderActions[e.currentTarget.dataset.index];
        if (orderAction.actId === TRAIN_ORDER_ACTION.ACTION_RETURN) {// 申请退票
            Watcher.sendWatcher.call(this, Watcher.keys.ORDER_DETAIL_APPLY_REFUND);  //取消订单
            this.refundListener = EventEmitter.addListener(EVENT_NAME.DID_REFUND_TICKET, function() {
                that.requestOrderDetail(that.orderDetailParam);
            });
            wx.navigateTo({
                url: '../orderRefund/orderRefund?orderNo=' + that.orderDetail.orderNo + '&orderId=' + that.orderDetail.orderId + '&orderToken=' + that.orderDetail.orderToken
            });

        } else {
            if (!Util.isEmptyString(orderAction.msg)) {
                var confirmText = '';
                var cancelText = '';
                if (orderAction.actId === TRAIN_ORDER_ACTION.ACTION_CANCEL) {// 取消订单
                    confirmText = "知道了";
                    cancelText = "不等了";
                } else {
                    confirmText = "是";
                    cancelText = "否";
                }

                ModalUtil.showModal({
                    title: orderAction.menu || '提示',
                    content: orderAction.msg,
                    showCancel: true,
                    confirmText: confirmText,
                    cancelText: cancelText,
                    onCancel: function (res) {
                        Watcher.sendWatcher.call(that, Watcher.keys.ORDER_DETAIL_CANCLE_ORDER);  //取消订单
                        that.requestOrderAction(orderAction);
                    }
                });
            } else {
                Watcher.sendWatcher.call(that, Watcher.keys.ORDER_DETAIL_CANCLE_ORDER);  //取消订单
                this.requestOrderAction(orderAction);
            }
        }
    },
    feeDetailClick: function() {
        this.setData({isShowFeeDetail:true});
        this.feeDetailAnimation= wx.createAnimation({
            duration: 300,
            timingFunction: 'ease'
        });
        this.feeDetailAnimation.opacity(1).step();
        this.setData({feeDetailAnimation: this.feeDetailAnimation.export()});
    },
    agentPhoneClick: function () {
        if(Util.isEmptyString(this.orderDetail.agentPhone)){
            return;
        }
        var that = this;
        wx.showActionSheet({
            itemList: [this.orderDetail.agentPhone],
            success: function (res) {
                if (!res.cancel) {
                    wx.makePhoneCall({
                        phoneNumber: that.orderDetail.agentPhone
                    });
                }
            }
        });
    },
    feeDetailLayerClick: function() {
        this.feeDetailAnimation.opacity(0).step();
        this.setData({feeDetailAnimation: this.feeDetailAnimation.export()});
        setTimeout(function(){
            this.setData({isShowFeeDetail:false});
        }.bind(this),300);
    },
    insuranceFaqClick: function() {
        wx.navigateTo({
            url: '../faq/faq?type=' + this.orderDetail.insuranceType + '&insuranceCode=' + this.orderDetail.insuranceCode
        });
    },
    ticketInfoClick: function() {
        wx.navigateTo({
            url: '../faq/faq?type=3'
        });
    },
    networkRetry: function() {
        Network.showNetwork.call(this, {status: 4});
        this.requestOrderDetail(this.orderDetailParam);
    },

    /*=========================================================*/
    // 网络请求
    /*=========================================================*/
    /**
     * param{orderNo,phone,token}
     * mode 1下拉刷新 2重新加载 0或不传默认加载
     */
    requestOrderDetail: function (param, mode) {
        var that = this;
        Requester.request({
            service: Service.ORDER_DETAIL,
            param: {
                orderNo: param.orderNo,
                detailType: '1',
                mobile: param.phone,
                vtoken: Util.isEmptyString(param.phone) ? param.token : ''
            },
            success: function (response) {
                console.log(response);
                if (!response || response.statusCode != 200 ||  !response.data || response.data.status != 0) {
                    var loadingDesc = (response && response.data) ? response.data.msg : '';
                    !mode && Network.showNetwork.call(that, {status: -2, loadingDesc: loadingDesc});
                    return;
                }
                that.orderDetail = response.data;
                that.data.orderDetail = response.data;
                if(Util.isEmptyString(param.phone)){
                    param.phone = that.orderDetail.contactPhoneObj.value;
                }
                wx.setNavigationBarTitle({
                    title: that.orderDetail.orderStatus
                });
                that.setData({ orderDetail: that.data.orderDetail });
                that.refreshTimeLineBrief();
                that.refreshOrderStatus();
                that.refreshPassengerInfo();
                that.refreshOrderActions();
                that.refreshPayPayButton();
                !mode && Network.hideNetwork.call(that);
            },
            fail: function (error) {
                !mode && Network.showNetwork.call(that, {status: -1, loadingDesc: '网络连接失败'});
            },
            complete: function () {
                mode == 1 && wx.stopPullDownRefresh();// 停止下拉刷新
                // 弹出toast提示
                mode == 2 && Network.hideNetwork.call(that, function() {
                    wx.showToast({ title: '成功', icon: 'success' });
                    setTimeout(function () { wx.hideToast() }, 1500);
                });
            }
        });
    },
    requestPay: function(){
        Network.showNetwork.call(this, {status: 3, loadingDesc: '正在提交订单'});
        var that = this;
        Requester.request({
            service: Service.PAY_METHOD,
            param: {
                orderNo: this.orderDetail.orderNo,
                vtoken: this.orderDetail.orderToken
            },
            success: function(res) {
                console.log('that.orderDetail: ', that.orderDetail);
                that.handleGetPayMethodResult(that.orderDetail.orderNo, that.orderDetail.orderToken, that.orderDetail.contactPhoneObj.value, res)
            },
            fail: function(error) {
                ModalUtil.showModal({content: '支付异常，请稍后重试'});
            },
            complete: function() {
                Network.hideNetwork.call(that);
            }
        });
    },
    handleGetPayMethodResult: function(orderNo, token, phone, res) {
        if (res.data.code == 0) {
            console.log('获取收银台地址成功：', res);
            var that = this;
            var data = {
                cashierUrl: res.data.payUrl,
                bd_source:"wx",
                openId: App.user.openId,
                success: function(res){
                    console.log('跳转支付页面', res);
                    Network.showNetwork.call(that, {status: 2});
                    that.requestOrderDetail(that.orderDetailParam);
                },
                fail:function(error){
                    console.log('跳转支付失败', error);
                }
            };
            Pay.openCashier(data);
        } else {
            ModalUtil.showModal({content: '支付异常，请稍后重试'});
            console.log('获取收银台地址失败：', res);
        }
    },
    requestTimeTable: function(){
        if(this.timeTableTrainsData && !Util.isEmptyArray(this.timeTableTrainsData.stations)){
            this._timeTableModal.showModalWithAnimation();
            return;
        }

        Network.showNetwork.call(this, {status: 3, loadingDesc: '加载中'});
        var that = this;
        Requester.request({
            service: Service.TIME_LABEL,
            param: {
                trainNum: this.orderDetail.trainNo,
                date: this.orderDetail.trainStartDate,
                startStation: this.orderDetail.trainFrom,
                endStation: this.orderDetail.trainTo
            },
            success: function(response) {
                if(response.statusCode == 200 && response.data && response.data.status == 0 && !Util.isEmptyArray(response.data.trains)){
                    that.timeTableTrainsData = response.data.trains[0];
                    that.timeTableTrainsData.dStation = that.orderDetail.trainFrom;
                    that.timeTableTrainsData.aStation = that.orderDetail.trainTo;
                    that._timeTableModal = new TimeTableModal(that);
                    that._timeTableModal.showModalWithAnimation();
                }
            },
            complete: function(){
                Network.hideNetwork.call(that);
            }
        });
    },

    requestOrderAction: function(action) {
        Network.showNetwork.call(this, {status: 3, loadingDesc: '正在取消订单'});
        var that = this;
        Requester.request({
            service: Service.ORDER_ACTION,
            param: {
                orderNo: this.orderDetail.orderNo,
                vtoken: this.orderDetail.orderToken,
                orderId: this.orderDetail.orderId,
                opt: action.actId
            },
            success: function(response) {
                if(response.statusCode == 200 && response.data && response.data.status == 0){
                    that.requestOrderDetail(that.orderDetailParam,2);
                }else {
                    Network.hideNetwork.call(that, function() {
                        let msg = response.data ? response.data.msg : (response.msg ? response.msg : '取消订单失败，请重试');
                        ModalUtil.showModal({content: msg});
                    });
                }
            },
            fail: function(){
                Network.hideNetwork.call(that, function() {
                    ModalUtil.showModal({content: '取消订单出错，请重试'});
                });
            }
        });
    },

    /*=========================================================*/
    // 生命周期
    /*=========================================================*/

    onShareAppMessage: function() {
        return Util.shareToTrainHome();
    },

    onLoad: function (param) {
        this.orderDetailParam = param;
    },
    onReady: function (param) {
        if(!this.orderDetailParam || Util.isEmptyString(this.orderDetailParam.orderNo) || (Util.isEmptyString(this.orderDetailParam.phone) && Util.isEmptyString(this.orderDetailParam.token))){
            ModalUtil.showModal({
                content: '出错',
                onConfirm: function (res) {
                    wx.navigateBack();
                }
            });
            return;
        }
        Watcher.sendPV.call(this, Watcher.keys.ORDER_DETAIL_SUCCESS);// 监控
        Network.showNetwork.call(this, {status: 4});
        this.requestOrderDetail(this.orderDetailParam);
    },
    onShow: function (param) {
        this.startCountDown();
    },
    onHide: function() {
        this.stopCountDown();
        Network.hideNetwork.call(this);
    },
    onUnload: function(){
        this.stopCountDown();
        Network.hideNetwork.call(this);
        this.refundListener && this.refundListener.removeListener();
    },
    onPullDownRefresh: function (param){
        this.stopCountDown();
        this.requestOrderDetail(this.orderDetailParam,1);
    },


    /*=========================================================*/
    // 处理&刷新
    /*=========================================================*/

    // 车次信息
    refreshTimeLineBrief: function () {
        var timeLineBrief = {};
        timeLineBrief.dStation = this.orderDetail.trainFrom;
        timeLineBrief.aStation = this.orderDetail.trainTo;
        timeLineBrief.dTime = this.orderDetail.trainStartTime;
        timeLineBrief.aTime = this.orderDetail.trainEndTime;
        timeLineBrief.timeCost = this.orderDetail.timeCost;
        timeLineBrief.trainNumber = this.orderDetail.trainNo;
        timeLineBrief.trainType = this.orderDetail.trainType;
        if (!Util.isEmptyString(this.orderDetail.trainStartDate)) {
            var depData = new Date(this.orderDetail.trainStartDate);
            var month = depData.getMonth() + 1;
            month = (month < 10) ? "0" + month : month;
            var day = depData.getDate();
            day = (day < 10) ? "0" + day : day;
            timeLineBrief.depDataValue = month + "-" + day;
        }
        if (!Util.isEmptyString(this.orderDetail.arrDate)) {
            var arrData = new Date(this.orderDetail.arrDate);
            var month = arrData.getMonth() + 1;
            month = (month < 10) ? "0" + month : month;
            var day = arrData.getDate();
            day = (day < 10) ? "0" + day : day;
            timeLineBrief.arrDataValue = month + "-" + day;
        }
        timeLineBrief.depWeek = this.orderDetail.depWeek;
        timeLineBrief.arrWeek = this.orderDetail.arrWeek;
        this.setData({ timeLineBrief: timeLineBrief });
    },
    // 订单状态
    refreshOrderStatus: function () {
        var orderStatus = {};
        if (this.orderDetail.processBar && !Util.isEmptyArray(this.orderDetail.processBar.processLogs)) {
            var processLog = this.orderDetail.processBar.processLogs[this.orderDetail.processBar.processLogs.length - 1];
            orderStatus.statusName = processLog.statusName;
            orderStatus.statusDesc = processLog.statusDesc;
            orderStatus.orderSts = this.orderDetail.orderSts;
            if (this.orderDetail.statusRightShowMode === 0) {
                orderStatus.statusRightSideInfo = !Util.isEmptyString(this.orderDetail.statusRightSideInfo) ? this.orderDetail.statusRightSideInfo : this.orderDetail.topTip;

            } else {
                orderStatus.statusRightSideInfo = "第 " + this.orderDetail.statusRightSideInfo + " 次发起抢票";
            }
        }
        this.setData({ orderStatus: orderStatus });
    },
    // 乘客
    refreshPassengerInfo: function () {
        var passengerInfo = { isNeedShowInsurance: false, passengerList: [] };
        if (!Util.isEmptyArray(this.orderDetail.passengerInfos)) {
            for (var i = 0; i < this.orderDetail.passengerInfos.length; i++) {
                var passengerItem = this.orderDetail.passengerInfos[i];
                if (passengerItem.insureCount > 0) {
                    passengerInfo.isNeedShowInsurance = true;
                }
                if ("儿童票" === passengerItem.ticketTypeStr) {
                    if (passengerItem.certNoObj) {
                        passengerItem.certNoObj.value = (passengerItem.birthday + "   " + ((1 === passengerItem.gender) ? "男" : "女"));
                    }
                }
                if(Util.isEmptyString(passengerItem.seat)){
                    passengerItem.seat = this.orderDetail.trainSeat;
                }
                passengerInfo.passengerList.push(passengerItem);
            }
        }
        this.setData({ passengerInfo: passengerInfo });
    },
    // 订单操作
    refreshOrderActions: function () {
        var orderActions = [];
        if (!Util.isEmptyArray(this.orderDetail.orderActions)) {
            for (var i = 0; i < this.orderDetail.orderActions.length; i++) {
                var item = this.orderDetail.orderActions[i];
                if (item.actId == TRAIN_ORDER_ACTION.ACTION_ORDER_STATUS || item.actId == TRAIN_ORDER_ACTION.ACTION_PAY || item.actId == TRAIN_ORDER_ACTION.ACTION_12306_CHECKOUT) {
                    continue;
                }
                orderActions.push(item);
            }
        }
        this.setData({ orderActions: orderActions });
    },
    // 立即支付按钮
    refreshPayPayButton: function () {
        if (!Util.isEmptyArray(this.orderDetail.orderActions)) {
            for (var i = 0; i < this.orderDetail.orderActions.length; i++) {
                var item = this.orderDetail.orderActions[i];
                if (item.actId === TRAIN_ORDER_ACTION.ACTION_PAY) {
                    if (!this.orderDetail.orderCreateTime) {
                        continue;
                    }
                    this.actionPayType = TRAIN_ORDER_ACTION.ACTION_PAY;
                    var date = new Date(this.orderDetail.orderCreateTime.replace(/-/g, "/"));
                    var serverTime = new Date();
                    this.countDownTime = date.getTime() + ORDER_OVER_TIME - serverTime.getTime();
                    this.setData({ isShowPayBtn: true });
                    this.refreshCountDown();
                    this.startCountDown();
                    break;
                }
            }
        } else {
            this.stopCountDown();
            this.setData({ isShowPayBtn: false });
        }
    },
    // 支付倒计时
    refreshCountDown: function () {
        if (this.countDownTime > 0) {
            this.setData({ isShowCountDown: true, countDownText: this.formatTime(this.countDownTime) });
        } else {
            this.setData({ isShowCountDown: false });
        }
    },
    // 开始倒计时
    startCountDown: function () {
        for (var i = 0; i < this.payCountDown.length; i++) {// 避免多次调用重复计时
            clearInterval(this.payCountDown[i]);
        }
        this.payCountDown.push(setInterval(function () {
            this.countDownTime -= 1000;
            if (this.countDownTime <= 0) {
                this.stopCountDown();
            }
            this.refreshCountDown();
        }.bind(this), 1000));
    },
    // 停止倒计时
    stopCountDown: function () {
        for (var i = 0; i < this.payCountDown.length; i++) {
            clearInterval(this.payCountDown[i]);
        }
        this.payCountDown = [];
    },
    // 格式化时间
    formatTime: function (ms) {
        var ss = 1000;
        var mi = ss * 60;
        var hh = mi * 60;
        var dd = hh * 24;

        var day = Math.floor(ms / dd);
        var hour = Math.floor((ms - day * dd) / hh);
        var minute = Math.floor((ms - day * dd - hour * hh) / mi);
        var second = Math.floor((ms - day * dd - hour * hh - minute * mi) / ss);

        var strMinute = minute < 10 ? "0" + minute : "" + minute;//分钟
        var strSecond = second < 10 ? "0" + second : "" + second;//秒

        return strMinute + ":" + strSecond;
    },


    /*=========================================================*/
    // 车次信息，时刻表相关
    /*=========================================================*/

    tapTimeLineBrief: function (event) {
        this.requestTimeTable();
    },
    getTrain: function () {
        return this.timeTableTrainsData;
    }
})
