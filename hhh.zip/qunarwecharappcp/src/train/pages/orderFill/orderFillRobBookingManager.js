/**
* @Author: 少烈 <shaolie>
* @Date:   2016-12-01T10:22:42+08:00
* @Email:  lshaolie@163.com
* @Last modified by:   shaolie
* @Last modified time: 2016-12-01T10:42:59+08:00
* @Note: Please contact me if you find any bugs 🐜^*^
*/


var EventEmitter    = require('../../../common/EventEmitter.js');

var TrainDef        = require('../../utils/define.js');
var EVENT_NAME      = TrainDef.TRAIN_EVENT_NAME;
var TRAIN_STATUS    = TrainDef.TRAIN_STATUS;

var JumpUtil    = require('../../utils/jumpUtil.js');
var goto = JumpUtil.goto;

var SeatUtil            = require('../../businessLogic/seatUtil.js');
var DateTimeUtils       = require('../../utils/dateTime.js');
var formatDateTime      = DateTimeUtils.formatDateTime;

var Utils         = require('../../utils/util.js');
var stringifyURLParam   = Utils.stringifyURLParam;
var isEmptyString       = Utils.isEmptyString;
var isEmptyArray        = Utils.isEmptyArray;

var OPTIONAL_DATE_INDEX = 0;
var OPTIONAL_TRAINS_INDEX = 1;
var OPTIONAL_SEATS_INDEX = 2;

/* 消除字符串最后一个顿号 */
function trimLastSlightPauseMark(str) {
    if (!isEmptyString(str) && str.charAt(str.length - 1) == "、") {
        str = str.substr(0, str.length-1);
    }
    return str;
}

function syncSameTicketSelectedStatus(srcTicketInfos, dstTicketInfos) {
    srcTicketInfos.forEach(function(srcTicket) {
        dstTicketInfos.forEach(function(dstTicket) {
            if (srcTicket.type == dstTicket.type) {
                dstTicket.selected = srcTicket.selected;
            }
        });
    });
};

function RobBookingManager(root) {
    this._root = root;

    this.overrideOnUnload();
    for (var func in RootManager) {
        root[func] = RootManager[func];
    }

    this._optionalSeatsListener = EventEmitter.addListener(EVENT_NAME.DID_SELECT_OPTIONAL_SEATS, root.didSelectOptaionalSeats.bind(root));
    this._optionalTrainsListener = EventEmitter.addListener(EVENT_NAME.DID_SELECT_OPTIONAL_TRAINS, root.didSelectOptaionalTrains.bind(root));
    this._optionalDateListener = EventEmitter.addListener(EVENT_NAME.OPTIONAL_DATE_SELECT, root.didSelectOptaionalDates.bind(root));
};

RobBookingManager.prototype.overrideOnUnload = function() {
    var onUnload = this._root.onUnload;
    var that = this;
    this._root.onUnload = function() {
        that.dealloc();
        onUnload && onUnload();
    }
};

RobBookingManager.prototype.dealloc = function() {
    this._optionalSeatsListener  && this._optionalSeatsListener.removeListener();
    this._optionalTrainsListener && this._optionalTrainsListener.removeListener();
    this._optionalDateListener   && this._optionalDateListener.removeListener();
};

var RootManager = {
    didOptionalCellTap: function(event) {
        var id = event.currentTarget.id;
        if (id == "备选坐席") {
            this.enterOptionalSeatsPage();
        } else if(id == "备选车次") {
            this.enterOptionalTrainsPage();
        } else if(id == "备选日期") {
            this.enterOptionalDatesPage();
        }
    },

    enterOptionalSeatsPage: function() {
        var that = this;
        goto('optionalSeats', "", function() {
            EventEmitter.dispatch(EVENT_NAME.OPTIONAL_SEATS_LOADED, {
                defaultSelectedSeat: that.data.selectedSeat,
                trains: that._selectedTrains,
                seatTips: that.data.orderResult.seatTips
            });
        });
    },

    enterOptionalTrainsPage: function() {
        var that = this;

        goto('optionalTrains', "", function() {
            EventEmitter.dispatch(EVENT_NAME.OPTIONAL_TRAINS_LOADED, {
                currentTrainNumber: that.param.trainNumber,
                startStation: that.param.dCity,
                endStation: that.param.aCity,
                date: that.param.date,
                trains: that._trains,
                filterDeparted: that._isOptionalTrainNeedFilterDeparted()
            });
        });
    },

    enterOptionalDatesPage: function() {
        var optionalDates = [];
        this.data.optionalItems[OPTIONAL_DATE_INDEX].items.forEach(function(date) {
            optionalDates.push(formatDateTime(date, "yyyy-MM-dd"));
        });

        var params = {
            bizType: 'train', // 业务线
            date: this.param.date, // 主选日期
            eventType: EVENT_NAME.OPTIONAL_DATE_SELECT,  // 选择日期成功之后触发的事件，通过监听这个事件来得到响应
            isMultiSelect: true, // 是否多选
            reqData: {bizType: 0},   // 请求日历数据的 参数
            url: encodeURIComponent('/train/product/api/train/TrainCalendar'),  // 请求日历数据的url，一定要encode
            dates: optionalDates, // 已经选择的备选日期s
            maxSelectDays: 6 // 最多备选多少个
        };
        wx.navigateTo({url: '../../../common/pages/calendar/calendar?data=' + JSON.stringify(params)});
    },

    /* 更新抢票截止日期 */
    updateTicketBookingDeadline: function() {
        var optionalDates = this.data.optionalItems[OPTIONAL_DATE_INDEX].items;
        var maxDate = new Date(this.param.date);
        // 获取最晚日期
        if (!isEmptyArray(optionalDates)) {
            var opDate = optionalDates[optionalDates.length - 1]
            if (opDate - maxDate > 0) {
                maxDate = opDate;
            }
        }
        // 获取最晚时间
        var maxDateStr = formatDateTime(maxDate);
        console.log('max', maxDate, '---', this.data.orderResult.train.dTime);
        // var maxTime = new Date(maxDateStr + " " + this.data.orderResult.train.dTime);
        var maxTime = new Date(maxDateStr);
        var dTime = this.data.orderResult.train.dTime;
        if (dTime) {
            maxTime.setHours(parseInt(dTime.split(':')[0], 10), parseInt(dTime.split(':')[1], 10));
        }
        console.log('max', maxTime);
        var optionalTrains = this.getOptionalItem(OPTIONAL_TRAINS_INDEX).items;
        if (!isEmptyArray(optionalTrains)) {
            var opTrain = optionalTrains[optionalTrains.length - 1];
            // var opTime = new Date(maxDateStr + " " + opTrain.dTime);
            var opTime = new Date(maxDateStr);
            var opDTime = opTrain.dTime;
            if (opDTime) {
                opTime.setHours(parseInt(opDTime.split(':')[0], 10), parseInt(opDTime.split(':')[1], 10));
            }
            if (opTime - maxTime > 0) {
                maxTime = opTime;
            }
        }

        console.log(maxTime);
        // 如果最晚时间是主选时间，则抢票停止时间为： 发车时间 - 40min
        var deadline = maxTime.getTime() - 40 * 60 * 1000;
        var todayStr = formatDateTime(new Date());
        if (maxDateStr != todayStr) {
            deadline = maxTime.getTime() - 2 * 3600 * 1000;
        }
        this.setData({
            ticketBookingDealline: formatDateTime(new Date(deadline), "MM月dd日 hh:mm")
        });
        this._robDeadline = formatDateTime(new Date(deadline), "yyyy-MM-dd hh:mm");
    },

    didSelectOptaionalSeats: function(param) {
        var that = this;
        this._selectedTrains = param.selectedTrains;
        var optionalSeats = this.getOptionalItem(OPTIONAL_SEATS_INDEX, true);
        // 拼接备选坐席显示数据
        this._selectedTrains.forEach(function(item, i) {
            var ticketInfos = item.ticketInfos;
            for (var j = 0; j < ticketInfos.length; j++) {
                var seat = item.ticketInfos[j];
                if (seat.selected && optionalSeats.desc.indexOf(seat.type) == -1) {
                    // 如果是当前车次，并且是主抢坐席类型，则不需要显示
                    if (item.trainNumber == that.param.trainNumber && that.data.selectedSeat.type == seat.type) {
                        continue;
                    }
                    optionalSeats.desc += (seat.type + "、")
                    optionalSeats.items.push(seat);
                }
            }
        });
        optionalSeats.desc = trimLastSlightPauseMark(optionalSeats.desc);   // 消除最后一个顿号
        this.syncRenderData({
            optionalItems: this.data.optionalItems
        });
    },

    didSelectOptaionalTrains: function(param) {
        var that = this;
        var trains = param.trains;
        this._trains = param.trains;
        this._selectedTrains = [this.data.orderResult.train];

        var optionalTrain = this.getOptionalItem(OPTIONAL_TRAINS_INDEX, true);
        // 拼接备选车次显示数据
        trains.forEach(function(train) {
            if(train.selected) {
                that._selectedTrains.push(train);
                optionalTrain.desc += (train.trainNumber + "、");
                optionalTrain.items.push(train);

                // 如果和主选车次坐席类型相同，则将其备选坐席的是否选中状态设置相同
                if (SeatUtil.isSameTicketsType(that.data.orderResult.train.ticketInfos, train.ticketInfos)) {
                    syncSameTicketSelectedStatus(that.data.orderResult.train.ticketInfos, train.ticketInfos);
                }

            } else {
                // 如果没有选中该车次，则将所有坐席选择状态置 false
                train.ticketInfos.forEach(function(ticket) {
                    ticket.selected = false;
                });
            }
        });
        optionalTrain.desc = trimLastSlightPauseMark(optionalTrain.desc);   // 消除最后一个顿号

        this.didSelectOptaionalSeats({selectedTrains: this._selectedTrains});
        this.updateTicketBookingDeadline();
    },

    didSelectOptaionalDates: function(param) {
        var optionalDate = this.getOptionalItem(OPTIONAL_DATE_INDEX, true);
        var preDate = null, rst = [], isSequeue = false;
        param.forEach(function(dateStr, idx) {
            var date = new Date(dateStr);
            optionalDate.items.push(date);
            var formatDate = formatDateTime(date, "MM月dd日")
            if (preDate) {
                if ((date - preDate) <= 86400000) {
                    if (idx == param.length - 1) {
                        rst.push('-' + formatDate);
                    }
                    isSequeue = true;
                } else {
                    if (isSequeue) {
                        var formatPreDate = formatDateTime(preDate, "MM月dd日");
                        rst.push('-' + formatPreDate + '、' + formatDate);
                        isSequeue = false;
                    } else {
                        rst.push(formatDate);
                    }
                }
            } else {
                rst.push(formatDate);
            }
            preDate = date;
        });

        rst.forEach(function(ds) {
            if (ds.indexOf('-') == 0) {
                optionalDate.desc = trimLastSlightPauseMark(optionalDate.desc);
            }
            optionalDate.desc += (ds + '、')
        });

        // 消除最后一个顿号
        optionalDate.desc = trimLastSlightPauseMark(optionalDate.desc);

        this.setData({
            optionalItems: this.data.optionalItems
        });

        // 过滤已发车项
        if(this._isOptionalTrainNeedFilterDeparted()) {
            this._trains.forEach(function(train) {
                // 已发车状态 和 已停售的过滤
                if (train.trainStatus == TRAIN_STATUS.DISABLE ||
                    train.trainStatus == TRAIN_STATUS.DEPARTED) {
                    train.selected = false;
                    train.ticketInfos.forEach(function(ticket) {
                        ticket.selected = false;
                    });
                }
            });
            this.didSelectOptaionalTrains({trains: this._trains});
        } else {
            this.updateTicketBookingDeadline();
        }
    },

    _isOptionalTrainNeedFilterDeparted: function() {
        // 没有备选日期 && 主选是今天 的时候过滤，其他不过滤
        return (isEmptyString(this.data.optionalItems[OPTIONAL_DATE_INDEX].desc) &&
            formatDateTime(new Date(), "yyyy-MM-dd") == this.param.date)
    },


    _isSelectedOptionalSeat: function(train) {
        return this._getOptoinalSeatsType(train).length > 0;
    },

    _getSelectedSeats: function(train) {
        var seats = [];
        train.ticketInfos.forEach(function(ticket) {
            if (ticket.selected == true) {
                seats.push(ticket);
            }
        });
        return seats;
    },

    /* 获取主选坐席类型 */
    _getMainSeatType: function(train) {
        if (train.trainNumber == this.param.trainNumber) {
            return this.data.selectedSeat.type;
        }

        for (var i = 0; i < train.ticketInfos.length; i++) {
            var ticket = train.ticketInfos[i];
            // 备选车次的话选择第一个坐席作为主选坐席
            if (ticket.selected == true) {
                return ticket.type;
            }
        }
        return train.ticketInfos[0].type;
    },

    /* 获取备选坐席类型 */
    _getOptoinalSeatsType: function(train) {
        var optionalSeats = [];
        var mainSeatType = this._getMainSeatType(train);

        for (var i = 0; i < train.ticketInfos.length; i++) {
            var ticket = train.ticketInfos[i];
            if (ticket.selected == true && mainSeatType != ticket.type) {
                optionalSeats.push(ticket.type);
            }
        }
        return optionalSeats;
    },

    _spliceOptionalSeatKey: function(trains, paramRef) {
        for (var i = 0; i < trains.length; i++) {
            // trains 转化为提交订单格式的字典
            var train = trains[i];
            console.log('train', train);
            var trainJson = {};
            var idx = i;
            trainJson['trainNum' + idx] = train.trainNumber;
            trainJson['startStation' + idx] = train.dStation;
            trainJson['endStation' + idx] = train.aStation;
            trainJson['depDateTime' + idx] = train.dTimeStr;
            trainJson['arrDateTime' + idx] = train.aTimeStr;
            trainJson['distance' + idx] = train.distance;
            trainJson['duration' + idx] = train.time;
            trainJson['seat' + idx] = this._getMainSeatType(train); //主选坐席
            trainJson['isCandidateSeat' + idx] = (this._isSelectedOptionalSeat(train)) ? 1 : 0;     //是否选择了备选坐席

            // 备选坐席
            var optoinalSeatsType = this._getOptoinalSeatsType(train);
            if (!isEmptyArray(optoinalSeatsType)) {
                trainJson['candidateSeats' + idx] = optoinalSeatsType.join('#');
            }

            for (var key in trainJson) {
                paramRef[key] = trainJson[key];
            }
        }
        paramRef['probableTrainCount'] = trains.length; //备选车次数量
    },

    getOptionalItem: function(key, needClear) {
        var optionalItems = this.data.optionalItems[key];
        if (needClear) {
            optionalItems.desc = "";
            optionalItems.items = [];
        }
        return optionalItems;
    }
};

module.exports = RobBookingManager;
