/**
* @Author: 少烈 <shaolie>
* @Date:   2016-11-30T19:22:41+08:00
* @Email:  lshaolie@163.com
* @Last modified by:   shaolie
* @Last modified time: 2016-11-30T19:22:45+08:00
* @Note: Please contact me if you find any bugs 🐜^*^
*/

var EventEmitter = require('../../../common/EventEmitter.js');
var Requester    = require('../../utils/requester.js');
var Service      = require('../../config/requestService');

var TrainDef     = require('../../utils/define.js');
var EVENT_NAME      = TrainDef.TRAIN_EVENT_NAME;
var CACHE_KEY       = TrainDef.TRAIN_CACHE_KEY;

var JumpUtil    = require('../../utils/jumpUtil.js');
var Utils         = require('../../utils/util.js');
var stringifyURLParam   = Utils.stringifyURLParam;
var isEmptyArray        = Utils.isEmptyArray;
var isEmptyString       = Utils.isEmptyString;
var isEmptyObject       = Utils.isEmptyObject;

function canBuyInsurence(passenger) {
    if (passenger.certs[0].type != "NI" && isEmptyString(passenger.birthday)) {
        return false;
    }
    return true;
}

function isSamePassenger(srcPassenger, dstPassenger) {
    if( srcPassenger.name       != dstPassenger.name ||
        srcPassenger.gender     != dstPassenger.gender ||
        srcPassenger.birthday   != dstPassenger.birthday ||
        srcPassenger.ticketType != dstPassenger.ticketType)
        {
            return false;
        }
    for(var i = 0; i < dstPassenger.certs.length; i++) {
        var dstCert = dstPassenger.certs[i];
        for(var j = 0; j < srcPassenger.certs.length; j++){
            var srcCert = srcPassenger.certs[j];
            if(srcCert.type === dstCert.type && srcCert.numberObj.value === dstCert.numberObj.value){
                return true;
            }
        }
    }
    return false;
}

function PassengerManager(root) {
    this._root = root;

    this.overrideOnUnload();

    for (var func in RootManager) {
        root[func] = RootManager[func];
    }

    //监听乘客选择
    this._passengerListener = EventEmitter.addListener(EVENT_NAME.DID_CHOOSE_PASSENGERS, root.didChoosePassengers.bind(root));
};

PassengerManager.prototype.overrideOnUnload = function() {
    var onUnload = this._root.onUnload;
    var that = this;
    this._root.onUnload = function() {
        that.dealloc();
        onUnload && onUnload();
    }
};

PassengerManager.prototype.dealloc = function() {
    this._passengerListener && this._passengerListener.removeListener();
};

var RootManager = {};
RootManager.didChoosePassengers = function(param) {
    var rewriteCertDisplay = function(passenger) {
        var idNum = passenger.certs[0].numberObj.value;
        passenger.certs[0].numberObj.display = idNum;
        if(passenger.certs[0].type == "NI") {
            passenger.certs[0].numberObj.display = idNum.substr(0, 6) + " " + idNum.substr(6, 8) + " " + idNum.substring(14);
        }
    };
    /*进入添加乘客页*/
    var passengers = [];
    for (let p of param.passengers) {
        if (p.isSelected && passengers.length < 5) {
            passengers.push(p)
        }
    }
    var index = param.editIndex;
    var newPsg = param.newPassenger;
    if (index >= 0) {
        var orgPsg = this.data.choosedPassengers[index];
        if (!isSamePassenger(newPsg, orgPsg)) {
            rewriteCertDisplay(newPsg);
            this.verifyPassengers([newPsg]);    // 乘客核验
        }
    } else {
        if (newPsg) {
            rewriteCertDisplay(newPsg);
            this.verifyPassengers([newPsg]);    // 乘客核验
        } else {
            var dataPsgs = this.data.choosedPassengers;
            var needVerifyPsgs = [];
            //获取需要核验的用户
            for(var i = 0; i < passengers.length; i++) {
                for(var j = 0; j < dataPsgs.length; j++) {
                    if (isSamePassenger(dataPsgs[j], passengers[i])) {
                        break;
                    }
                }

                if (j == dataPsgs.length) {
                    needVerifyPsgs.push(passengers[i]);
                }
            }

            passengers.forEach(function(psg) {
                rewriteCertDisplay(psg);
            });

            if (!isEmptyArray(needVerifyPsgs)) {
                this.verifyPassengers(needVerifyPsgs);
            }
        }
    }

    var totalInsuranceCount = 0;
    passengers.forEach(function(passenger) {
        if(canBuyInsurence(passenger)) {
            totalInsuranceCount++;
        }
    });
    this.syncRenderData({
        choosedPassengers: passengers,
        totalInsuranceCount: totalInsuranceCount
    }, true);
    wx.setStorage({
        key: CACHE_KEY.ORDER_FILL_PASSENGERS_INFO,
        data: passengers
    });
};

RootManager.needEnterLoginPage = function() {
    return (this.data.orderResult.wxIsCanShow12306Login && !this.isNoAccountBooking)
}

RootManager.enterPassengerAddPage = function(){
    var passenger = stringifyURLParam({data:{passengerList:this.data.choosedPassengers,editIndex:-1}});
    if (global.AccountInfoOf12306.isLogined12306) {
        JumpUtil.goto('passengerList', passenger);
    } else {
        if(this.needEnterLoginPage()){
            JumpUtil.goto('login', passenger);
        } else {
            JumpUtil.goto('passenger', passenger);
        }
    }
};

RootManager.editPassenger = function(event) {
    var index = event.currentTarget.dataset.index;
    if (index < this.data.choosedPassengers.length) {
        var passenger = stringifyURLParam({data:{passengerList:this.data.choosedPassengers,editIndex:index}});
        JumpUtil.goto('passenger', passenger);
    }
};

RootManager.psgEditingStatus = function(event) {
    var index = event.currentTarget.dataset.index;
    this.setData({
        psgEditingIdx: index
    });
}

RootManager.canclePsgEdting = function() {
    this.setData({
        psgEditingIdx: -1
    });
}

RootManager.removePassenger = function(event) {
    var index = event.currentTarget.dataset.index;
    if (index < this.data.choosedPassengers.length) {
        this.data.choosedPassengers.splice(index, 1);

        var totalInsuranceCount = 0;
        this.data.choosedPassengers.forEach(function(passenger) {
            if(canBuyInsurence(passenger)) {
                totalInsuranceCount++;
            }
        });
        this.syncRenderData({
            choosedPassengers: this.data.choosedPassengers,
            totalInsuranceCount: totalInsuranceCount,
            psgEditingIdx: -1
        });

        wx.setStorage({
            key: CACHE_KEY.ORDER_FILL_PASSENGERS_INFO,
            data: this.data.choosedPassengers
        });
    }
};

RootManager.verifyPassengers = function(passengers) {
    // 12306乘客不需要核验
    var passengerNeedVerify = [];
    for (let l in passengers) {
        if(passengers[l].source !=2) {
            passengerNeedVerify.push(passengers[l]);
        }}
    if(passengerNeedVerify.length <=0) {
        return
    }
    var prePushParam = {};
    // 提前核验
    var prePsgsParam = PassengerManager.splicePassengersParam(passengerNeedVerify, this.data.selectedInsurance, {
        name: "psgerName", certNo: "psgerCarNo",
        certType: "psgerCardType", gender: "psgerSex",
        birthday: "psgerBirthday", insuranceCount: "psgerInsuranceCount",
        passengerCount: "psgerCount"
    });
    for (var psgKey in prePsgsParam) {
        prePushParam[psgKey] = prePsgsParam[psgKey];
    }
    Requester.request({
        param: prePsgsParam,
        service: Service.PRE_PUSH_PASSENGERS,
        method: 'POST'
    });

    // 核验
    var commitParam = {};
    this._splicePassengersKey(passengerNeedVerify, commitParam);

    var orderResult = this.data.orderResult;
    if (orderResult) {
        commitParam.agentId = orderResult.agentId;
    }
    Requester.request({
        param: commitParam,
        service: Service.PASSENGER_VERIFY,
        method: "POST"
    });
};

PassengerManager.splicePassengersParam = function(passengers, product, keyMap) {
    var param = {};
    var isNoAccount = 'false';
    for (var i = 0; i < passengers.length; i++) {
        // passenger转化为提交订单格式的字典
        var passenger = passengers[i];
        console.log('passenger', passenger);
        var psg = {};
        var idx = i + 1;
        psg[keyMap.name + idx] = passenger.name;
        psg[keyMap.certNo + idx] = passenger.certs[0].numberObj.value;
        psg[keyMap.certType + idx] = passenger.certs[0].type;
        psg[keyMap.gender + idx] = passenger.gender;
        psg[keyMap.birthday + idx] = passenger.birthday;
        psg['pisc' + idx] = 0;     // 是否儿童
        psg['source' + idx] = passenger.source ? passenger.source : 0;          // 乘客来源 0-用户中心，1-无线火车票，2-12306
        // 如果有一个乘客是非12306，则为无账号购票
        if (passenger.source != 2) {
            isNoAccount = 'true';
        }
        // 价格大于0，说明购买了保险，每个乘客的保险份数为1，否则保险份数为0
        // var product = this.data.selectedInsurance;
        if (!isEmptyObject(product)) {
            if (product.price > 0 && canBuyInsurence(passenger)) {
                psg[keyMap.insuranceCount + idx] = 1;
            } else {
                psg[keyMap.insuranceCount + idx] = 0;
            }
        }

        for (var psgKey in psg) {
            param[psgKey] = psg[psgKey];
        }
    }
    param[keyMap.passengerCount] = passengers.length; //乘客个数
    param.isNoAccount = isNoAccount;
    return param;
};

module.exports = PassengerManager;
