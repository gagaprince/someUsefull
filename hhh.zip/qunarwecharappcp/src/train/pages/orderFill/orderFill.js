/**
* @Author: 少烈 <shaolie>
* @Date:   2016-10-24T12:16:54+08:00
* @Email:  lshaolie@163.com
* @Last modified by:   shaolie
* @Last modified time: 2016-10-24T12:21:24+08:00
* @Note: Please contact me if you find any bugs 🐜^*^
*/


var TimeTableModal   = require('../../templates/timeTableModal/timeTableModal.js');
var PriceDetailModal = require('../../templates/priceDetailModal/priceDetailModal.js');
var Network          = require('../../../common/comps/network/network.js');

var EventEmitter = require('../../../common/EventEmitter.js');
var Watcher      = require('../../utils/watcher.js');
var Requester    = require('../../utils/requester.js');
var Service      = require('../../config/requestService');
var TrainDef     = require('../../utils/define.js');

var PassengerManager  = require('./orderFillPassengerManager.js');
var RobBookingManager = require('./orderFillRobBookingManager.js');
var User = require('../../../common/user.js');
var Pay = require("../../../common/pay.js");

var EVENT_NAME      = TrainDef.TRAIN_EVENT_NAME;
var CACHE_KEY       = TrainDef.TRAIN_CACHE_KEY;
var FAQ_TYPE        = TrainDef.TRAIN_FAQ_TYPE;
var PAGE_NAME       = TrainDef.TRAIN_PAGE_NAME;
var TRAIN_STATUS    = TrainDef.TRAIN_STATUS;

var Utils         = require('../../utils/util.js');
var StorageUtil   = require('../../utils/storageUtil.js');
var ModalUtil   = require('../../utils/modalUtil.js');
var DateTimeUtils = require('../../utils/dateTime.js');
var SeatUtil    = require('../../businessLogic/seatUtil.js');
var JumpUtil    = require('../../utils/jumpUtil.js');

var goto = JumpUtil.goto;

var isValidPhone        = Utils.isValidPhone;
var stringifyURLParam   = Utils.stringifyURLParam;
var isEmptyObject       = Utils.isEmptyObject;
var isEmptyString       = Utils.isEmptyString;
var isEmptyArray        = Utils.isEmptyArray;
var formatDateTime      = DateTimeUtils.formatDateTime;

var MAX_PASSENGER = 5;

/*获取被选中的保险*/
function getSelectedInsurance(orderResult) {
    if(orderResult.showInsurance == "true" || orderResult.showInsurance == 1) {
        var insuranceProducts = orderResult.insuranceInfo.insuranceProducts;
        for(var i = 0; i < insuranceProducts.length; i++) {
            var insurance = insuranceProducts[i];
            if (insurance.selected) {
                return insurance;
            }
        }
    } else {
        return {};
    }
}

function canBuyInsurence(passenger) {
    return !(passenger.certs[0].type != "NI" && isEmptyString(passenger.birthday));
}

var OPTIONAL_DATE_INDEX = 0;

Page({
    pageName: PAGE_NAME.ORDER_FILL,
    _selectedTrains: [],
    _trains: [],
    isNoAccountBooking: false,
    data:{
        psgEditingIdx: -1,
        totalPrice: 0,
        choosedPassengers: [],
        totalInsuranceCount: 0,
        phoneNumberCellSource: {
            title: "手机号",
            placeholder: "通知出票状态和出票信息",
            phoneNumber: ""
        },

        tipModal: {
            hidden: true
        },
        readedOrderNotice: true,
        networkData: {
            status: 4
        },

        optionalItems: [
            {
                title: "备选日期",
                desc: "",
                items: []
            },
            {
                title: "备选车次",
                desc: "",
                items: []
            },
            {
                title: "备选坐席",
                desc: "",
                items: []
            }
        ]
    },

    onLoad: function(param) {
        Watcher.sendPV.call(this, Watcher.keys.BOOKING_SUCCESS);

        this.listenEvent();

        this.param = JSON.parse(param.trainInfo);

        this._passengerManager = new PassengerManager(this);
        this._robBookingManager = new RobBookingManager(this);

        this.autoFillOrder();

        var that = this;
        User.getUserInfo(function(res){
            var exParams = res && res.data && res.data.exParams
            that.wechatPlatform = exParams && exParams.platform
        });
    },

    onShareAppMessage: function() {
        return Utils.shareToTrainHome();
    },

    onReady: function() {
        var that = this;
        this.fetchOrderData(this.param, function(orderResult) {
            that._selectedTrains = [orderResult.train];
            that.data.orderResult = orderResult;
            that.setData({
                orderResult: orderResult,
                selectedInsurance: getSelectedInsurance(orderResult)
            });

            // 如果不显示12306登录，并且用户未登陆，则使用无账号购票
            if (!orderResult.wxIsCanShow12306Login && !global.AccountInfoOf12306.isLogined12306) {
                that.isNoAccountBooking = true;
            }
            if(!isEmptyArray(orderResult.train.stations)) {
                that._timeTableModal = new TimeTableModal(that);
            }
            that._priceDetailModal = new PriceDetailModal(that);

            that.selectSeat({currentTarget:
                {
                    dataset: {
                        ticket_id: that.data.orderResult.checkTicket
                    }
                }
            });
        });
    },

    onUnload: function() {
        Network.hideNetwork.call(this);
        this._insuranceListener && this._insuranceListener.removeListener();
    },

    autoFillOrder: function() {
        var that = this;
        // 乘客
        wx.getStorage({
            key: CACHE_KEY.ORDER_FILL_PASSENGERS_INFO,
            success: function(res) {
                if (!isEmptyArray(res.data)) {
                    var totalInsuranceCount = 0;
                    res.data.forEach(function(passenger) {
                        if(canBuyInsurence(passenger)) {
                            totalInsuranceCount++;
                        }
                    });
                    that.setData({
                        choosedPassengers: res.data,
                        totalInsuranceCount: totalInsuranceCount
                    });
                    that.verifyPassengers(res.data);
                }
            }
        });
        //联系人
        wx.getStorage({
            key: CACHE_KEY.ORDER_FILL_CONTACT_PHONE,
            success: function(res) {
                typeof res.data == 'string' && that.setPhoneNumberData({
                    phoneNumber: res.data
                });
            }
        });
        // 阅读须知
        wx.getStorage({
            key: CACHE_KEY.ORDER_FILL_BOOK_NOTICE_READED,
            success: function(res) {
                //标识缓存上是已经读过的，下次不需要进行缓存的存储
                if (res.data == true) {
                    that._readedOrderNotice = true;
                }
                that.setData({
                    readedOrderNotice: res.data
                })
            }
        });
    },

    fetchOrderData: function(param, callback) {
        Network.showNetwork.call(this, {status: 4});
        this.networkRetry = null;

        var that = this;
        var ticketInfos = param.ticketInfos;
        var requestParam = {
            searchType: 'stasta',
            sort: 3,
            seatType: ticketInfos[0].type,
            startStation: param.dep,
            endStation: param.arr,
            trainNum: param.trainNumber,
            date: param.date
        };
        Requester.request({
            service: Service.ORDER_FILL_OPT,
            param: requestParam,
            method: 'POST',
            success: function(res) {
                console.log(res);
                var data = res.data;
                if (!isEmptyObject(data) && data.status == 0 && !isEmptyArray(data.tickets)) {
                    data.train.ticketInfos = data.tickets;
                    callback(data);
                    Network.hideNetwork.call(that);
                } else {
                    var content = data.msg || "请选择其他坐席";
                    var tipModalData = {
                        content: content,
                        confirmText: "好的",
                        onConfirm: wx.navigateBack
                    };
                    ModalUtil.showModal(tipModalData);

                    that.networkRetry = that.fetchOrderData.bind(that, param, callback);
                    Network.showNetwork.call(that, {status: -2, loadingDesc: '网络请求失败'});
                }
            },
            fail: function(error) {
                that.networkRetry = that.fetchOrderData.bind(that, param, callback);
                Network.showNetwork.call(that, {status: -1, loadingDesc: '网络连接失败'});
            }
        });
    },

    listenEvent: function() {
        var that = this;

        //监听保险选择
        this._insuranceListener = EventEmitter.addListener(EVENT_NAME.DID_FINISH_SELECT_INSURANCE, function(insuranceInfo) {
            that.data.orderResult.insuranceInfo = insuranceInfo;
            that.syncRenderData({
                selectedInsurance: getSelectedInsurance(that.data.orderResult)
            });
        });

        this._noAccountBookingListener = EventEmitter.addListener(EVENT_NAME.NO_ACCOUNT_BOOKING, function() {
            that.isNoAccountBooking = true;
            global.AccountInfoOf12306.isLogined12306 = false;
        });
    },

    syncRenderData: function(data) {
        for (var key in data) {
            this.data[key] = data[key];
        }
        this.data.selectedInsurance = getSelectedInsurance(this.data.orderResult);
        this._priceDetailModal.syncRenderData();
        data = data || {};
        data.totalPrice = this._priceDetailModal.getTotalPrice();
        this.setData(data);
    },

    getTrain: function(callback) {
        return this.data.orderResult.train;
    },

    /*=========================================================*/
    // 私有方法
    /*=========================================================*/
    /*检查信息完整*/
    _checkInfo: function() {
        var tipModalData = {
            hidden: false,
            confirmText: "好的"
        };

        var that = this;
        if (this.data.choosedPassengers.length == 0) {
            tipModalData.content = "请至少添加一位乘客";
            tipModalData.title = "未添加乘客";
            tipModalData.onConfirm = this.enterPassengerAddPage.bind(this);
        } else if(this.data.choosedPassengers.length > MAX_PASSENGER) {
            tipModalData.content = "您最多只能添加" + MAX_PASSENGER + "位乘客";
            tipModalData.title = "添加乘客过多";
        } else if (!isValidPhone(this.data.phoneNumberCellSource.phoneNumber)) {
            tipModalData.content = "请输入正确的手机号码";
            tipModalData.title = "手机有误";
        } else if (!this.data.readedOrderNotice) {
            tipModalData.content = "请确认您已以阅读预订须知";
            tipModalData.title = "未阅读预订须知";
        } else if (this.needRobTicket() && !SeatUtil.isEachTrainSeatSelected(this._selectedTrains)) {
            tipModalData.content = "请选择备选坐席";
            tipModalData.onConfirm = function() {
                that.enterOptionalSeatsPage();
            }
        }

        if (tipModalData.content) {
            ModalUtil.showModal(tipModalData);
            return false;
        }

        return true;
    },

    /*=========================================================*/
    // 事件响应函数
    /*=========================================================*/
    tapTimeLineBrief: function(event) {
        var that = this;
        var train = this.data.orderResult.train;

        var showModal = function() {
            that._timeTableModal = that._timeTableModal || new TimeTableModal(that);
            that._timeTableModal.showModalWithAnimation();
        }
        if (train.stations) {
            showModal();
        } else {
            this.fetchTimeTableData(function() {
                showModal();
            });
        }
    },

    fetchTimeTableData: function(successCallback) {
        Network.showNetwork.call(this, {status: 3});
        this.networkRetry = null;

        var that = this;
        var train = this.data.orderResult.train;
        var param = {
            trainNum: train.trainNumber,
            date: train.date,
            startStation: train.dStation,
            endStation: train.aStation
        };
        Requester.request({
            service: Service.TIME_LABEL,
            param: param,
            method: 'POST',
            success: function(res) {
                if (res.data && res.data.status == 0) {
                    if(!isEmptyArray(res.data.trains)) {
                        that.data.orderResult.train.stations = res.data.trains[0].stations;
                    }
                    successCallback && successCallback(res.data.trains[0].stations);
                } else {
                    var tipModalData = {
                        content: "暂无数据",
                        confirmText: "好的"
                    };
                    ModalUtil.showModal(tipModalData);
                }
            },
            fail: function(error) {
                var tipModalData = {
                    content: "网络请求失败",
                    confirmText: "好的"
                };
                ModalUtil.showModal(tipModalData);
            },
            complete: function() {
                Network.hideNetwork.call(that);
            }
        });
    },

    /*选择坐席*/
    selectSeat: function(event) {
        var ticketId = event.currentTarget.dataset.ticket_id;
        var selectedSeat;
        var that = this;
        var ticketInfos = this.data.orderResult.train.ticketInfos;

        if(isEmptyArray(ticketInfos)) {
            return;
        }

        var selectT = function(i) {
            that._preSelectedSeat = that.data.selectedSeat;   //记录上一个被选中的坐席
            selectedSeat = ticketInfos[i];
            ticketId = selectedSeat.ticketId;
            that.frameLeftAnimation = that.frameLeftAnimation || wx.createAnimation({
                duration: 300,
                timingFunction: 'ease'
            })
            that.frameLeftAnimation.left(15 + (i * 12) + (i * 70) + (i * 2)).step();

            if (!that.needRobTicket(selectedSeat)) {
                ticketInfos.forEach(function(ticket, idx) {
                    ticket.selected = false;
                });
            } else {
                ticketInfos.forEach(function(ticket, idx) {
                    if (idx == i && that.needRobTicket(ticket)) {
                        ticket.selected = true;
                    } else if(that.needRobTicket(ticket) && that._preSelectedSeat && that._preSelectedSeat.type == ticket.type) {
                        ticket.selected = false;
                    }
                });
            }
        }

        for (var i = 0; i < ticketInfos.length; i++) {
            var ticket = ticketInfos[i];
            if (ticket.ticketId == ticketId) {
                selectT(i);
                break;
            }
        }
        if (!selectedSeat) {
            selectT(0);
        }
        this.data.orderResult.checkTicket = selectedSeat.ticketId;
        this.syncRenderData({
            frameLeftAnimation: this.frameLeftAnimation.export(),
            orderResult: this.data.orderResult,
            selectedSeat: selectedSeat
        });
        this.didSelectOptaionalTrains({trains:that._trains})
    },

    /* 判断所给坐席是否需要抢票
     * ticket: 可选，如果不传则默认为 当前被选中的坐席
     */
    needRobTicket: function(ticket) {
        if (!ticket) {
            ticket = this.data.selectedSeat;
        }

        if (ticket.wxSaleStatus == 1 || (ticket.wxSaleStatus == 0 && ticket.count < 0)) {
            return true;
        }
        return false;
    },

    /*进入保险选择页*/
    enterInsurancePage: function() {
        var insuranceInfo = stringifyURLParam({insuranceInfo:this.data.orderResult.insuranceInfo});
        goto('insurance', insuranceInfo);
    },

    /*显示价格详情*/
    showPriceDetail: function(event) {
        var that = this;
        this._priceDetailModal && this._priceDetailModal.showPriceDetail(function() {
            var animation = wx.createAnimation({
                duration: 300,
                timingFunction: 'ease'
            });
            var rotateDeg = that.data.rotateArrowAnimation ? -that.data.rotateArrowAnimation.actions[0].animates[0].args[0] : 90;
            animation.rotate(rotateDeg).step();
            that.setData({
                rotateArrowAnimation: animation.export()
            });
        });
    },

    _splicePassengersKey: function(passengers, paramRef) {
        var psgsParam = PassengerManager.splicePassengersParam(passengers, this.data.selectedInsurance, {
            name: "pname", certNo: "pcn",
            certType: "pct", gender: "psex",
            birthday: "pbd", insuranceCount: "pbxn",
            passengerCount: "pCount"
        });
        for (var psgKey in psgsParam) {
            paramRef[psgKey] = psgsParam[psgKey];
        }
    },

    isPaperTicket: function() {
        return false;
    },

    /*提交订单*/
    commitOrder: function() {
        if (this._checkInfo()) {
            Watcher.sendWatcher.call(this, Watcher.keys.COMMIT_ORDER);

            Network.showNetwork.call(this, {status: 3, loadingDesc: '正在提交订单'});
            this.networkRetry = null;

            var that = this;
            var orderResult = this.data.orderResult;

            var train = orderResult.train;
            var selectedInsurance = this.data.selectedInsurance;
            var contactName = this.data.choosedPassengers[0].name;
            var phoneNumber = this.getPhoneNumberData("phoneNumber");

            var commitParam = {
                morereq: "1",
                bizMode: "0",
                isCandidateSeat: "0",        //是否勾选备选坐席
                isNeedPaper: "false",        //是否需要纸质票
                isPs: "0",                    //是否有发票收件人信息
                agentId: orderResult.agentId,
                trainNum: train.trainNumber,
                startStation: train.dStation,
                endStation: train.aStation,
                depDateTime: train.dTimeStr,
                arrDateTime: train.aTimeStr,
                date: train.date,
                distance: train.distance,
                duration: train.time,
                searchType: 'stasta',
                ticketId: this.data.selectedSeat.ticketId,
                seat: this.data.selectedSeat.type,
                supportPaper: "false",
                hasRecommendPaper: "false",
                selfPickUpTicket: "false",
                contactMobile: phoneNumber, //联系手机
                contactName: contactName,   //联系人姓名
                wechatPlatform: this.wechatPlatform
            };

            if (!isEmptyObject(selectedInsurance)) {
                commitParam.insuranceCode = selectedInsurance.insuranceCorpCode;
                commitParam.productCode = selectedInsurance.productCode;
                commitParam.bxPrice = selectedInsurance.price;       //保险价格
            }

            // 是否需要抢票
            if (this.needRobTicket()) {
                this._spliceOptionalSeatKey(this._selectedTrains, commitParam);

                commitParam.touchRobPay = "true";
                commitParam.robEndDate = this._robDeadline; //抢票截止时间
                var dateItems = this.getOptionalItem(OPTIONAL_DATE_INDEX).items;
                if (!isEmptyArray(dateItems)) {
                    var dateStrs = [];
                    dateItems.forEach(function(date) {
                        dateStrs.push(formatDateTime(date, 'yyyy-MM-dd'));
                    });
                    commitParam.probableTrainDate = dateStrs.join(',');
                }
            }

            //乘客信息
            var passengers = this.data.choosedPassengers;
            this._splicePassengersKey(passengers, commitParam);
            if (this.isNoAccountBooking) {
                commitParam.isNoAccount = "true";
            }
            //非抢票 && 非纸质
            if (!this.needRobTicket() && !this.isPaperTicket()) {
                // 有账号的微信小程序生单 && 乘客都是12306乘客
                if (commitParam.isNoAccount == "true") {
                    commitParam.bizMode = "0";
                } else {
                    commitParam.bizMode = "7";
                }
            }
            console.log('请求参数', commitParam);

            var service = this.needRobTicket() ? Service.SAVE_ROB_ORDER : Service.ORDER_COMMIT;
            Requester.request({
             	service: service,
                param: commitParam,
                method: 'POST',
                success: this._handleCommitOrderResult.bind(this),
                fail: function(error) {
                    var tipModalData = {
                        content: "提交订单失败，请重试",
                        confirmText: "好的"
                    }
                    ModalUtil.showModal(tipModalData);
                    Network.hideNetwork.call(that);
                    console.log("生单失败", error);
                }
            });
        }
    },
    _handleCommitOrderResult: function(res) {
        console.log('===========res', res);
        if (res.data && res.data.status == 0) {
            console.log('生单成功：', res);
            var tipModalData = {
                content: "生单成功",
                confirmText: "好的"
            }

            var orderNo = res.data.orderInfo.orderNo;
            var phone = this.getPhoneNumberData("phoneNumber");//res.data.orderInfo.contact.phone;
            var token = res.data.orderToken;
            var user = getApp().user;
            var openId = user.openId;
            var param = {
                orderNo: orderNo,
                vtoken: token,
                openId: openId
            };
            console.log('获取收银台请求参数', param);
            Requester.request({
                service: Service.PAY_METHOD,
                param: param,
                success: this._handleGetPayMethodResult.bind(this, orderNo, token, phone),
                fail: function(error) {
                    wx.redirectTo({
                        url: "../orderDetail/orderDetail?orderNo=" + orderNo + "&phone=" + phone + "&token=" + token
                    });
                    console.log('获取收银地址失败：', error);
                }
            })
        } else {
            console.log('生单失败了', res);
            var tipModalData = {
                content: res.data.msg,
                confirmText: "好的"
            }
            var status = res.data.status;
            // 12306 账号有误
            // 105: 用户审核未通过    460: 登录失效
            if (status == 460 || status == 105) {
                // 如果是 www 登陆模式,则不提示登录
                if (this.data.orderResult.wxIsCanShow12306Login) {
                    tipModalData.confirmText = "去登录";
                    var passenger = stringifyURLParam({data:{passengerList:this.data.choosedPassengers,editIndex:-1}});
                    tipModalData.onConfirm = function() {
                        goto('login', passenger);
                    }
                } else {
                    tipModalData.confirmText = "确定";
                }
                if (status == 460) {
                    // 如果是 www 登陆模式，则直接进行无账号购票尝试
                    if (this.data.orderResult.wxIsCanShow12306Login) {
                        tipModalData.content = "12306登录过期，请重新登录";
                        tipModalData.cancelText = "直接购票";
                        var that = this;
                        tipModalData.onCancel = function() {
                            that.isNoAccountBooking = true;
                            that.commitOrder();
                        };
                    } else {
                        this.isNoAccountBooking = true;
                        Network.hideNetwork.call(this);
                        this.commitOrder();
                        return;
                    }
                }
            }
            ModalUtil.showModal(tipModalData);
            Network.hideNetwork.call(this);
        }
    },
    _handleGetPayMethodResult: function(orderNo, token, phone, res) {
        if (res.data && res.data.code == 0) {
            var that = this;
            var user = getApp().user;
            var openId = user.openId;
            console.log('获取收银台地址成功：', res);
            var data = {
                cashierUrl: res.data.payUrl,
                openId: openId,
                bd_source:"wx",
                success: function(res){
                    // 向首页发送 到订单详情的
                    EventEmitter.dispatch(EVENT_NAME.NAVIGATE_TO_ORDER_DETAIL, {
                        orderNo: orderNo,
                        phone: phone,
                        token: token
                    });
                    // 回到首页
                    JumpUtil.backTo(PAGE_NAME.HOME);

                    console.log('跳转支付页面', res);
                },
                fail: function(error){
                    console.log('跳转支付失败', error);
                },
                complete: function() {
                    Network.hideNetwork.call(that);
                },
                beforeOpen: function() {
                    Network.hideNetwork.call(that);
                }
            };
            Pay.openCashier(data);
        } else {
            console.log('获取收银台地址失败：', res);
            wx.redirectTo({
                url: "../orderDetail/orderDetail?orderNo=" + orderNo + "&phone=" + phone + "&token=" + token
            });
        }
    },

    /* phoneNumberCell */
    textChange: function(event) {
        var phoneNumber = event.detail.value;
        this.setPhoneNumberData({
            phoneNumber: phoneNumber
        });
        // if (phoneNumber.length == 11 && isValidPhone(phoneNumber)) {
        //     wx.hideKeyboard();
        // }
    },

    didChangedPhone: function(event) {
        var phoneNumber = event.detail.value;
        this.setPhoneNumberData({
            phoneNumber: phoneNumber
        });

        // 如果号码有效， 则缓存
        if (isValidPhone(phoneNumber)) {
            wx.setStorage({
                key: CACHE_KEY.ORDER_FILL_CONTACT_PHONE,
                data: phoneNumber
            });
        }
    },

    setPhoneNumberData: function(option) {
        var phoneNumberCellSource = this.data.phoneNumberCellSource || {};
        for (var key in option) {
            phoneNumberCellSource[key] = option[key];
        }
        this.setData({
            phoneNumberCellSource: phoneNumberCellSource
        });
    },

    getPhoneNumberData: function(key) {
        return key ? this.data.phoneNumberCellSource[key] : this.data.phoneNumberCellSource;
    },

    /* 预定须知 */
    changeOrderNoticeCheckedState: function(event) {
        this.setData({
            readedOrderNotice: !this.data.readedOrderNotice
        });
        this.storeReadedOrderNoticeIfNeed();
    },

    /* 显示预定须知 */
    showOrderNoticeFAQ: function(event) {
        goto('faq', 'type=' + FAQ_TYPE.TGQ);
        this.setData({
            readedOrderNotice: true
        });

        // 如果之前没读过，则需要缓存
        this.storeReadedOrderNoticeIfNeed();
    },

    storeReadedOrderNoticeIfNeed: function() {
        if (!this._readedOrderNotice) {
            wx.setStorage({
                key: CACHE_KEY.ORDER_FILL_BOOK_NOTICE_READED,
                data: true
            });
        }
    }
});
