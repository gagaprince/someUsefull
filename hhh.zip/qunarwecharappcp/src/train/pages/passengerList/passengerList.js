var Network = require('../../../common/comps/network/network.js');
var Requester = require('../../utils/requester.js');
var Service = require('../../config/requestService.js');

var Util = require('../../utils/util.js');
var EventEmitter = require('../../../common/EventEmitter.js');
var TrainDef = require('../../utils/define.js');
var Watcher = require('../../utils/watcher.js');
var TRAIN_EVENT_NAME = TrainDef.TRAIN_EVENT_NAME;

var app = getApp();

Page({
    pageName: TrainDef.TRAIN_PAGE_NAME.PASSENGER_LIST,
    data: {
        networkData: {
            status: 0,                         // 网络状态
            loadingDesc: '登录中'
        },
        passengers: [],
        finishButtonEnable: false
    },
    passengersFromOrderFill:[],

    selectedPassengersCount:function(){
        let count = 0;
        for (let k in this.data.passengers) {
            if (this.data.passengers[k].isSelected) {
                count++;
            }
        }
        return count;
    },

    finishClick: function () {
        let count = 0;
        let selectedPassengers = [];
        for (let k in this.data.passengers) {
            if (this.data.passengers[k].isSelected) {
                selectedPassengers.push(this.data.passengers[k]);
                count++;
            }
        }

        if (count > 5) {
            wx.showModal({
                title: '提示',
                content: '最多只能选5个乘客\n',
                confirmText: '知道了\n',
                showCancel: false
            });
            return;
        }
        EventEmitter.dispatch(TRAIN_EVENT_NAME.DID_CHOOSE_PASSENGERS, {
            passengers: selectedPassengers,
            editIndex: -1
        });
        wx.navigateBack();

    },
    addClick: function () {
        if(this.selectedPassengersCount() >= 5){
            this.showMaxPassengerTip();
            return;
        }
        wx.redirectTo({
            url: '../passenger/passenger?' + Util.stringifyURLParam({ data: { passengerList: this.data.passengers, editIndex: -1,isFromList:true } })
        });
    },

    passengerClick: function (e) {
        let index = e.currentTarget.dataset.index;
        if(this.data.passengers[index].isSelected){
            this.data.passengers[index].isSelected = !this.data.passengers[index].isSelected;
        }else{
            if(this.selectedPassengersCount() >= 5){
                this.showMaxPassengerTip();
                return;
            }
            this.data.passengers[index].isSelected = true;
        }
        this.refreshPassengers();
    },

    showMaxPassengerTip: function() {
        wx.showModal({
            title: '提示',
            content: '最多只能选5个乘客',
            confirmText: '知道了',
            showCancel: false
        });
    },

    refreshPassengers: function () {
        let enable = false;
        for (let k in this.data.passengers) {
            if (this.data.passengers[k].isSelected) {
                enable = true;
                break;
            }
        }
        this.setData({ passengers: this.data.passengers, finishButtonEnable: enable });
    },

    onShareAppMessage: function() {
        return Util.shareToTrainHome();
    },

    onLoad: function (params) {
        Watcher.sendPV.call(this, Watcher.keys.PASSENGER_LIST);

        // 参数校验
        if (params && params.data) {
            let data = Util.parseURLParam(params).data;
            this.passengersFromOrderFill = data.passengerList;
        }
        this._loginSuccess = EventEmitter.addListener(TRAIN_EVENT_NAME.LOGIN_12306_SUCCESS, this.onLoginback.bind(this));
        this._addPassenger = EventEmitter.addListener(TRAIN_EVENT_NAME.ADD_PASSENGER_TO_LIST, this.didChoosePassengers.bind(this));
    },
    onLoginback:function(params){
        if(params.loginSuccess) {
            this.requestPassenger();
        }
    },
    didChoosePassengers:function(params){
        if(params && params.newPassenger) {
            this.data.passengers = params.passengers;
            this.refreshPassengers();
        }
    },

    onReady: function () {
        if (global.AccountInfoOf12306.passengers) {
            this.data.passengers = global.AccountInfoOf12306.passengers;
            this.mergePassenger();
            this.refreshPassengers();
        } else {
            this.requestPassenger();
        }

    },

    onUnload: function () {
        this._loginSuccess && this._loginSuccess.removeListener();
        this._addPassenger && this._addPassenger.removeListener();
    },

    requestPassenger: function () {
        Network.showNetwork.call(this, {status: 3})
        var that = this;
        Requester.request({
            service: Service.PassengerList,
            param: {
                reqType: "0",
                reqStage: "1"
            },
            success: function (response) {
                that.didRequestSuccess(response);
                console.log("===getPassenger===",response);
            },
            fail: function (error) {
                Network.showNetwork.call(that, {status: -1, loadingDesc: '网络连接失败'});
            },
            complete: function () {
                Network.hideNetwork.call(that);
            }
        });
    },

    mergePassenger: function () {
        for (let p in this.data.passengers) {
            this.data.passengers[p].isSelected = false;
        }
        for (let k in this.passengersFromOrderFill) {
            var lp = this.passengersFromOrderFill[k];
            var flag = false;
            for (let l in this.data.passengers) {
                var kp = this.data.passengers[l];
                if (lp.name === kp.name && lp.certs[0].type === kp.certs[0].type && lp.certs[0].numberObj.value === kp.certs[0].numberObj.value) {
                    kp.isSelected = true;
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                lp.isSelected = true;
                lp.source = 1;
                this.data.passengers.push(lp);
            }
        }
    },
    didRequestSuccess: function (response) {
        if (response.data && response.data.getStatus === 0) {
            this.data.passengers = response.data.passengers;
            for (let l in this.data.passengers) {
                this.data.passengers[l].source =2;
            }
            this.mergePassenger();
            this.refreshPassengers();
        } else if (response.data && response.data.getStatus == 10200) {
            global.AccountInfoOf12306.isLogined12306 = false;

            var that =this
            wx.showModal({
                title: '提示',
                content: response.data.msg + "\n",
                showCancel: false,
                success: function (res) {
                    wx.redirectTo({url: "../login/login?" + Util.stringifyURLParam({ data: { passengerList: that.passengersFromOrderFill, editIndex: -1 }})});
                }
            });
        } else {
            var errorMsg = "获取乘客失败，请稍后重试";
            if(response.data && response.data.msg) {
                errorMsg = response.data.msg;
            }
            wx.showModal({
                title: '提示',
                content: errorMsg + "\n",
                showCancel: false,
                success: function (res) {
                    if (res.confirm == 1 || res.confirm == "true") {
                        wx.navigateBack();
                    }
                }
            });
        }
    }
});
