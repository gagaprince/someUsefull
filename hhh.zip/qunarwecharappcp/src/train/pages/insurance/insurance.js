
var EventEmitter = require('../../../common/EventEmitter.js');
var UTILS = require('../../utils/util.js');
var Watcher = require('../../utils/watcher.js');
var TrainDef = require('../../utils/define.js');
var TRAIN_EVENT_NAME = TrainDef.TRAIN_EVENT_NAME;

Page({
    pageName: TrainDef.TRAIN_PAGE_NAME.INSURACE,
    data:{
        insuranceInfo: []
    },
    onLoad:function(param){
        Watcher.sendPV.call(this, Watcher.keys.INSURANCE_SUCCESS);

        var result = UTILS.parseURLParam(param);
        this.setData({
            insuranceInfo: result.insuranceInfo
        });
    },

    selectInsurance: function(event) {
        var insuranceId = event.currentTarget.id;
        for (var i = 0; i < this.data.insuranceInfo.insuranceProducts.length; i++) {
            var insurance = this.data.insuranceInfo.insuranceProducts[i];
            if (insurance.productCode == insuranceId) {
                insurance.selected = 1;
            } else {
                insurance.selected = 0;
            }
        }
        this.setData({
            insuranceInfo: this.data.insuranceInfo
        });
    },

    didFinishSelection: function(event) {
        for (var i = 0; i < this.data.insuranceInfo.insuranceProducts.length; i++) {
            var insurance = this.data.insuranceInfo.insuranceProducts[i];
            if (insurance.selected == 1) {
                if (insurance.price == 0) {
                    Watcher.sendWatcher.call(this, Watcher.keys.INSURANCE_NONE + "_0");
                } else {
                    Watcher.sendWatcher.call(this, Watcher.keys.INSURANCE + "_0" + "_" + insurance.price);
                }
            }
        }
        EventEmitter.dispatch(TRAIN_EVENT_NAME.DID_FINISH_SELECT_INSURANCE, this.data.insuranceInfo);
        wx.navigateBack();
    }
})
