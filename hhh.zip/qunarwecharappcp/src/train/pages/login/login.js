var Network = require('../../../common/comps/network/network.js');
var Requester = require('../../utils/requester.js');
var Service      = require('../../config/requestService.js');

var TrainDef = require('../../utils/define.js');
var Watcher = require('../../utils/watcher.js');

var Util = require('../../utils/util.js');
var EventEmitter = require('../../../common/EventEmitter.js');

var app = getApp();
Page({

    data: {
        networkData: {
            status: 0,                         // 网络状态
            loadingDesc: '登录中'
        },
        isSelected: true,
        name: '',
        password: '',
        loginType: 'WIRELESS'
    },

    bindNameInput: function (e) {
        this.data.name = e.detail.value;
        this.setData({name: this.data.name});
    },

    bindPasswordInput: function (e) {
        this.data.password = e.detail.value;
        this.setData({password: this.data.password});
    },

    noLoginClick: function () {
        EventEmitter.dispatch(TrainDef.TRAIN_EVENT_NAME.NO_ACCOUNT_BOOKING);
        wx.redirectTo({
            url:'../passenger/passenger?' + Util.stringifyURLParam(this._param)
        });
    },

    loginClick: function () {
        if (!this.data.name || this.data.name.length <= 0) {
            wx.showModal({
                title: '提示',
                content: '用户名不能为空\n',
                showCancel: false
            });
            return;
        }
        if (!this.data.password || this.data.password.length <= 0) {
            wx.showModal({
                title: '提示',
                content: '密码不能为空\n',
                showCancel: false
            });
            return;
        }
        if (!this.data.isSelected) {
            wx.showModal({
                title: '提示',
                content: '请先勾选使用规则及隐私条款\n',
                showCancel: false
            });
            return;
        }
        this.requestLogin();
    },

    checkboxClick: function () {
        this.data.isSelected = !this.data.isSelected;
        this.setData({isSelected: this.data.isSelected});
    },

    requestLoginType: function () {
        var that = this;
        Requester.request({
            service: Service.Login12306,
            param: {
                reqType: "rob",
                rtype: 1
            },
            success: function (response) {
                console.log(response);
                if(response.data.status == 0) {
                    if (response.data.dataMap.loginType) {
                        that.data.loginType = response.data.dataMap.loginType;
                    }
                }
            },
            fail: function (error) {
                that.data.loginType = "WIRELESS"
            },
            complete: function () {

            }
        });
    },

    requestLogin: function () {
        var that = this;
        Network.showNetwork.call(this, {status: 3, loadingDesc: '正在登录...'});
        Requester.request({
            service: Service.Login12306,
            param: {
                login12306: 1,
                rtype: 1,
                loginType: that.data.loginType,
                tusername: that.data.name,
                tpwd: that.data.password,
                reqType: "rob"
            },
            success: function (response) {
                console.log(response);
                that.didRequestSuccess(response);
            },
            fail: function (error) {
                Network.hideNetwork.call(that, function() {
                    wx.showModal({
                        title: '提示',
                        content:  "网络请求失败，请重试\n",
                        showCancel: false
                    });
                });
            },
            complete: function () {
                Network.hideNetwork.call(that);
            }
        });
    },

    didRequestSuccess: function (response) {
        if (response.data.status == 0) {
            EventEmitter.dispatch(TrainDef.TRAIN_EVENT_NAME.LOGIN_12306_SUCCESS, {
                loginSuccess: true,
                chooseNoAccount : false
            });

            // 将 12306 账号密码缓存到内存上
            global.AccountInfoOf12306 = {};
            global.AccountInfoOf12306.username = this.data.name;
            global.AccountInfoOf12306.password = this.data.password;
            global.AccountInfoOf12306.isLogined12306 = true;
            // wx.navigateBack();
            wx.redirectTo({url: '../passengerList/passengerList?' + Util.stringifyURLParam(this._param)});
        } else {
            var errorMsg = response.data.msg ? response.data.msg : "登录失败，请重试！";
            wx.showModal({
                title: '提示',
                content: errorMsg + "\n",
                showCancel: false
            });
        }
    },

    onLoad: function (param) {
        Watcher.sendWatcher.call(this, Watcher.keys.LOGIN_12306);
        this.requestLoginType();

        if (global.AccountInfoOf12306 && global.AccountInfoOf12306.username
            && global.AccountInfoOf12306.password) {
            this.setData({
                name: global.AccountInfoOf12306.username,
                password: global.AccountInfoOf12306.password
            });
        }

        if (param) {
            this._param = Util.parseURLParam(param);
        }
    },

    onShareAppMessage: function() {
        return Util.shareToTrainHome();
    },

    onUnload: function () {
        Network.hideNetwork.call(this);
    }
})
