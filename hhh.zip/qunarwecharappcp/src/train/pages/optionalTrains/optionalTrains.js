// optionalTrains.js
var EventEmitter = require('../../../common/EventEmitter.js');
var requester = require('../../utils/requester.js');
var Service      = require('../../config/requestService');
var Network = require('../../../common/comps/network/network.js');
var TrainDef = require('../../utils/define.js');
var Watcher = require('../../utils/watcher.js');
var Util = require('../../utils/util.js');

var EVENT_NAME = TrainDef.TRAIN_EVENT_NAME;
var TRAIN_STATUS = TrainDef.TRAIN_STATUS;

/**
 * startStation=北京&endStation=上海&date=2016-12-12&currentTrainNumber=G102&filterDeparted=false
 */
Page ({
    pageName: TrainDef.TRAIN_PAGE_NAME.OPTIONAL_TRAINS,
    data: {
        trains: [],
        filterDeparted: false,
        networkData:{
            status: 4
        },
        // 过滤已发车车次以后的可选车次
        hasSelectableTrains: true
    },

    maxSelectCount: 19,
    selectedCount: 0,
    onShareAppMessage: function() {
        return Util.shareToTrainHome();
    },

    onLoad() {
        Watcher.sendPV.call(this, Watcher.keys.OPTIONAL_TRAINS);
        var that = this;
        this._paramListener = EventEmitter.addListener(EVENT_NAME.OPTIONAL_TRAINS_LOADED, function(param) {
            param.tips = '多选几个车次，抢票成功率更高哦！';
            that.setData({
                param: param
            });
        });
    },

    onUnload() {
        this._paramListener && this._paramListener.removeListener();
        Network.hideNetwork.call(this);
    },

    onReady() {
        var trains = this.data.param.trains;
        if (Util.isEmptyArray(trains)) {
            this.requestTrains();
        }
        else {
            Network.showNetwork.call(this, {status: 4});
            var that = this;
            Network.hideNetwork.call(this, function() {
                that.handleTrains(trains);
            });
        }
    },

    requestTrains() {
        Network.showNetwork.call(this, {status: 4});

        var param = this.data.param;
        // handle network
        var that = this;
        requester.request({
            service: Service.SEARCH,
            param: {
                searchType: 'stasta',
                startStation: param.startStation,
                endStation: param.endStation,
                date: param.date,
                sort: 3
            },
            success: function(response) {
                that.didRequestSuccess(response);
            },
            fail: function(error) {
                Network.showNetwork.call(that, {status: -1, loadingDesc: '网络连接失败'});
            }
        });
    },

    // 网络失败重试
    networkRetry: function() {
        this.requestTrains();
    },

    didRequestSuccess(response) {
        var dataMap = response.data.dataMap;
        if (!dataMap || dataMap.status != 0) {
            Network.showNetwork.call(this, {status: -2, loadingDesc: '网络请求失败'});
        }
        else {
            var trains = dataMap.directTrainInfo.trains;
            this.handleTrains(trains);
            Network.hideNetwork.call(this);
        }
    },

    handleTrains(trains) {
        var currentTrainNumber = this.data.param.currentTrainNumber;

        var filterDeparted = this.data.param.filterDeparted;
        var departedCount = 0;

        var selectedCount = 0;

        var filteredTrains = [];
        for (var index in trains) {
            var obj = trains[index];
            // 当前车次
            if (obj.trainNumber == currentTrainNumber
            || obj.trainStatus == TRAIN_STATUS.MAP_ADJUST) {
                continue;
            }
            // 过滤已发车车次
            else if (filterDeparted
                && (obj.trainStatus == TRAIN_STATUS.DISABLE
                    || obj.trainStatus == TRAIN_STATUS.DEPARTED)) {
                departedCount += 1;
            }
            else if (obj.selected) {
                selectedCount += 1;
            }
            filteredTrains.push(obj);
        }
        trains = filteredTrains;

        this.selectedCount = selectedCount;
        var hasSelectableTrains = filterDeparted ? (trains.length > departedCount) : true;

        this.setData({
            trains: trains,
            filterDeparted: filterDeparted,
            hasSelectableTrains: hasSelectableTrains
        });
    },

    didTrainLineTap(e) {
        var index = e.currentTarget.dataset.index;
        var trains = this.data.trains;

        var selected = !trains[index].selected;
        if (selected && this.selectedCount >= this.maxSelectCount) {
            wx.showModal({
                title: '提示',
                content: '可选车次数量已达到上限\n',
                showCancel: false
            });
            return;
        }
        trains[index].selected = selected;
        this.selectedCount += (selected ? 1 : -1);
        this.setData({
            trains: trains
        });
    },

    didConfirmButtonTap() {
        EventEmitter.dispatch(EVENT_NAME.DID_SELECT_OPTIONAL_TRAINS, {
            trains: this.data.trains
        });
        wx.navigateBack();
    }

})
