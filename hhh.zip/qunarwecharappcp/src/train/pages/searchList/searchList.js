//searchList.js
var Utils = require('../../utils/dateTime.js');
var EventEmitter = require('../../../common/EventEmitter.js');
var Watcher = require('../../utils/watcher.js');
var requester = require('../../utils/requester.js');
var Service = require('../../config/requestService');
var Network = require('../../../common/comps/network/network.js');
var TrainDef = require('../../utils/define.js');
var storageUtils = require('../../utils/storageUtil.js');
var Config = require('../../../common/pages/search/config.js');
var CommonUtils = require('../../../common/utils.js');

var TRAIN_EVENT_NAME = TrainDef.TRAIN_EVENT_NAME;
var TRAIN_CACHE_KEY = TrainDef.TRAIN_CACHE_KEY;
var TRAIN_STATUS = TrainDef.TRAIN_STATUS;
var EVENT_NAME = Config.event;

// @param {startStation:'出发城市', endStation:'到达城市', date:'出发日期', onlyGD: '仅查看高铁动车true/false'}
Page({
    pageName: TrainDef.TRAIN_PAGE_NAME.SEARCH_LIST,
    data: {
        // result
        trains: [],
        // network
        networkData:{
            status: 4
        },
        // dataBar
        prevEnable: true,
        nextEnable: true
    },
    // scroll-view 顶部偏移
    lastScrollTop: 0,
    // 上一次搜索的时间戳
    timestamp: 0,
    // 日期格式
    dateFormat: 'yyyy-MM-dd',
    // 起始和结束日期
    start: '', end: '',
    //            0         1           2         3        4       5       6        7
    actionMap: [undefined, undefined, undefined, undefined, 'grab', undefined, 'grab', undefined],

    // 下拉刷新
    onPullDownRefresh: function(e) {
        // 如果有数据，下拉刷新不显示loading
        this.refresh({
            loading: this.data.networkData.status != 0
        });
    },

    // 搜索超时重试
    bindModelConfirm: function (e) {
        this.refresh();
    },

    // 网络失败重试
    networkRetry: function() {
        this.refresh();
    },

    // 点击具体车次
    bindCellTap: function (e) {
        var ts = new Date().getTime();
        // 超过20min
        if (ts - this.timestamp > 20 * 60 * 1000) {
            var that = this;
            wx.showModal({
                title: '提示',
                content: '搜索结果已过期，点击‘确认’刷新',
                showCancel: false,
                success: function(res) {
                    if (res.confirm == 1 || res.confirm == 'true') {
                        that.refresh()
                    }
                }
            });
        }
        else {
            var index = e.currentTarget.dataset.index;
            var train = this.data.trains[index];
            var trainStatus = train.trainStatus;
            if (trainStatus == TRAIN_STATUS.ENABLE || trainStatus == TRAIN_STATUS.DEFAULT || this.actionMap[trainStatus] == 'grab') {
                var param = JSON.stringify({
                    dCity: train.dCity,
                    aCity: train.aCity,
                    dep:train.dStation,
                    arr:train.aStation,
                    date:train.date,
                    trainNumber:train.trainNumber,
                    ticketInfos:train.ticketInfos
                });
                var that = this;
                wx.navigateTo({
                    url: '../orderFill/orderFill?trainInfo=' + param,
                    success: function() {
                        Watcher.sendWatcher.call(that, Watcher.keys.BOOKING);
                    }
                });
            }
        }
    },

    bindSelectDayTap: function(e) {
        var params = {
            bizType: 'train', // 业务线
            date: this.data.param.date, // 默认单选日期；多选的第一个日期 （不传的话展示今天）
            eventType: EVENT_NAME.SEARCHLIST_DATE_CHANGE,  // 选择日期成功之后触发的事件，通过监听这个事件来得到响应
            reqData: {bizType: 0},   // 请求日历数据的 参数
            url: encodeURIComponent('/train/product/api/train/TrainCalendar')  // 请求日历数据的url，一定要encode
        };
        wx.navigateTo({url: '../../../common/pages/calendar/calendar?data=' + JSON.stringify(params)});
    },

    didSelectDate: function(date) {
        date = Utils.formatDateTime(new Date(date), this.dateFormat);
        var param = this.data.param;
        param.date = date;
        this.setData({
            param: param
        });
        this.refresh();
    },

    bindPrevDayTap: function(e) {
        if (this.data.prevEnable) {
            this.adjustDate(false);
        }
    },

    bindNextDayTap: function(e) {
        if (this.data.nextEnable) {
            this.adjustDate(true);
        }
    },

    // 调整日期 @add 是否是加一天
    adjustDate: function (add) {
        var param = this.data.param;
        var d = Utils.parseDateTime(param.date, this.dateFormat);
        d = Utils.addDate(d, add ? 1 : -1);
        var date = Utils.formatDateTime(d, this.dateFormat);
        param.date = date;

        EventEmitter.dispatch(EVENT_NAME.CALENDAR_DATE_CHANGE, d);
        this.setData({
            param: param
        });
        this.refresh();
    },

    /**
     * options: {
     *      loading: 'nullable bool, default true'
     * }
     */
    refresh: function(options) {
        options = options || {};
        // handle data
        this.timestamp = new Date().getTime();
        var param = this.data.param;
        var d = Utils.parseDateTime(param.date, this.dateFormat);
        var s = Utils.parseDateTime(this.start, this.dateFormat);
        var e = Utils.parseDateTime(this.end, this.dateFormat);
        var prevEnable = d.getTime() - s.getTime() > 0;
        var nextEnable = d.getTime() - e.getTime() < 0;
        if (!prevEnable) {
            param.date = this.start;
            d = s;
        }

        var todayDesc = Utils.getTodayDesc(d);
        var displayDate = Utils.formatDateTime(d, 'MM月dd日') + ' '
                         + ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()] + ' '
                         + todayDesc;

        options.loading !== false && Network.showNetwork.call(this, {status: 3});
        this.setData({
            param: param,
            displayDate: displayDate,
            prevEnable: prevEnable,
            nextEnable: nextEnable
        });

        // handle network
        var that = this;
        requester.request({
            service: Service.SEARCH,
            param: {
                searchType: 'stasta',
                startStation: param.startStation,
                endStation: param.endStation,
                date: param.date
            },
            success: function(response) {
                that.didRequestSuccess(response);
            },
            fail: function(error) {
                Network.showNetwork.call(that, {status: -1, loadingDesc: '网络连接失败'});
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        });
    },

    didRequestSuccess: function(response) {
        var dataMap = response.data.dataMap;
        if (!dataMap || dataMap.status != 0) {
            Network.showNetwork.call(this, {status: -2, loadingDesc: dataMap.msg || '网络请求失败'});
        }
        else {
            var result = this.handleTrains(dataMap.directTrainInfo.trains);
            var trains = result.trains;
            var error = result.error;
            var that = this;
            Network.hideNetwork.call(this, function() {
                that.setData({
                    trains: trains
                });

                if (error == -1) {
                    wx.showModal({
                        title: '提示',
                        content: '暂无高铁动车，已为您展示全部车次',
                        showCancel: false
                    })
                }
            });
        }
    },

    /**
     * return {
     *      trains: []
     *      error: -1 暂无高铁动车
     * }
     */
    handleTrains: function(trains) {
        var onlyGD = this.data.param.onlyGD == "true";
        var result = [];

        var that = this;
        trains.forEach(function(train) {
            // 车次
            train.trainNumber = train.trainNumber.split('/')[0];
            // 价格
            train.priceMsg = train.priceMsg && train.priceMsg.replace('¥', '');
            // 坐席
            train.ticketInfos = train.ticketInfos && train.ticketInfos.slice(0, 4);
            // 动作
            var trainStatus = train.trainStatus;
            train.action = that.actionMap[trainStatus];
            // 状态
            train.statusDesMultiLine = train.trainStatusDes ? !!train.trainStatusDes.match('\n') : '';
            if (onlyGD && train.trainNumber.match('G|D')) {
                result.push(train);
            }
        });

        trains = onlyGD && result.length ? result : trains;

        var error = 0;
        if (onlyGD && !result.length) {
            error = -1;
        }
        return {
            trains: trains,
            error: error
        };
    },

    onLoad: function(param) {
        Watcher.sendPV.call(this, Watcher.keys.SEARCH_SUCCESS);
        this._listener = EventEmitter.addListener(EVENT_NAME.SEARCHLIST_DATE_CHANGE, this.didSelectDate);

        var d = new Date();
        this.start = Utils.formatDateTime(d, this.dateFormat);
        // 预售期
        var preData = storageUtils.getStorageSync(TRAIN_CACHE_KEY.CALENDAR);
        var pre12306 = preData.pre12306;
        if (!pre12306 || pre12306 <= 0) {
            pre12306 = 59;
        }
        else {
            pre12306 -= 1;
        }

        var preQuanr = preData.preQunar;
        if (!preQuanr || preQuanr < 0) {
            preQuanr = 0;
        }
        this.end = Utils.formatDateTime(Utils.addDate(d, pre12306 + preQuanr), this.dateFormat);
        this.setData({
            param: param
        });
    },

    onUnload: function() {
        this._listener && this._listener.removeListener();
        Network.hideNetwork.call(this);
    },

    onReady: function() {
        this.showNavigationBarTitle();
        Network.showNetwork.call(this, {status: 4});
        this.refresh({
            loading: false
        });
    },

    onShow: function() {
        this.showNavigationBarTitle();
    },

    onShareAppMessage: function () {
        var navigateToUrl = '/train/pages/searchList/searchList?startStation=' + this.data.param.startStation + '&endStation=' + this.data.param.endStation + "&date=" + this.data.param.date
        return CommonUtils.share.getParam({
            title: '预订火车票 - 去哪儿旅行',
            desc: this.data.param.startStation + ' 到 ' + this.data.param.endStation + '\n' + this.data.param.date,
            url: navigateToUrl
        });
    },

    showNavigationBarTitle: function() {
        var param = this.data.param;
        param && wx.setNavigationBarTitle({
            title: param.startStation + ' ⇀ ' + param.endStation
        });
    }

})
