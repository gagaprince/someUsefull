
var Requester = require('../../utils/requester.js');
var Service = require('../../config/requestService');
var Network = require('../../../common/comps/network/network.js');
var Util = require('../../utils/util.js');
var ModalUtil   = require('../../utils/modalUtil.js');
var TrainDef = require('../../utils/define.js');
var Watcher = require('../../utils/watcher.js');
var EventEmitter = require('../../../common/EventEmitter.js');
var TRAIN_EVENT_NAME = TrainDef.TRAIN_EVENT_NAME;

Page({
    pageName: TrainDef.TRAIN_PAGE_NAME.ORDER_REFUND,
    data: {
        networkData:{
            status: 4                         // 网络状态
        },
        passengers: [],
        refundReason:'',
        orderRefundViewParam:{},               //网络请求返回的数据
        confirmButtonEnable: false,
        totalRefundFee:0,                      //手续费
        totalRefundAmount:0,                   //实退金额
        isExpand:false,                        //退票说明是否展开
        reducedInstruction:'',                 //退票说明收起后展示的内容
        isShowRefundFeeDetail:false            //是否正在展示手续费说明
    },
    orderDetailParam:{},                       //订单详情页传过来的数据

    requestRefundViewInfo:function(){
        var that = this;
        Requester.request({
            service: Service.ORDER_REFUNDVIEW,
            param: {
                orderNo: that.orderDetailParam.orderNo,
                orderId: that.orderDetailParam.orderId,
                vtoken: that.orderDetailParam.orderToken
            },
            success: function(response) {
                Network.hideNetwork.call(that, function() {
                    if(response.data && response.data.status == 0){
                        if(!Util.isEmptyString(response.data.refundFeeInstruction)) {
                            response.data.refundFeeInstruction = response.data.refundFeeInstruction.replace(/；/g, '；\n\n');
                        }
                        that.setData({orderRefundViewParam: response.data,passengers:response.data.passengerInfos});
                        that.handleRefundInstruction();
                        that.dealWithPassengers();
                    }
                    else {
                        let msg = response.data ? response.data.msg : (response.msg ? response.msg : '加载失败，请重试');
                        ModalUtil.showModal({
                            content: msg,
                            onConfirm: wx.navigateBack
                        });
                    }
                });
            },
            fail : function(){
                Network.hideNetwork.call(that, function() {
                    ModalUtil.showModal({
                        content: '网络请求失败，请重试',
                        onConfirm: wx.navigateBack
                    });
                });
            }
        });
    },

    requestRefund:function(){
        Network.showNetwork.call(this, {status: 3, loadingDesc: '正在退票'});
        var that = this;
        var refundFee = 0;
        var refundPassengersCount = 0;
        var param = {
                orderNo: this.orderDetailParam.orderNo,
                orderId: this.orderDetailParam.orderId,
                vtoken: this.orderDetailParam.orderToken,
                comment: this.data.refundReason
            };

        for(let i = 0; i < this.data.passengers.length; i++){
            var passengerItem = this.data.passengers[i];
            if(passengerItem.isSelected){
                refundFee += parseFloat(passengerItem.refundFee);
                refundPassengersCount++;
                param['name' + refundPassengersCount] = passengerItem.name;
            }
        }
        param['passengerCount'] = refundPassengersCount;
        param['refundFee'] = refundFee || '0';
        Requester.request({
            service: Service.ORDER_REFUND,
            param: param,
            success: function(response) {
                Network.hideNetwork.call(that, function() {
                    if(response.statusCode == 200 && response.data && response.data.status == 0){
                        wx.navigateBack();
                        EventEmitter.dispatch(TRAIN_EVENT_NAME.DID_REFUND_TICKET);
                    }
                    else {
                        let msg = response.data ? response.data.msg : (response.msg ? response.msg : '退款失败，请重试');
                        ModalUtil.showModal({
                            content: msg
                        });
                    }
                });
            },
            fail : function() {
                Network.hideNetwork.call(that, function() {
                    ModalUtil.showModal({
                        content: '退款出错，请重试'
                    });
                });
            }
        });
    },

    handleRefundInstruction:function(){
        var refundInstruction = this.data.orderRefundViewParam.refundInstruction;
        if(!Util.isEmptyString(refundInstruction)){
            var index = refundInstruction.indexOf("2.");
            if(index !== -1){
                this.setData({reducedInstruction:refundInstruction.substring(0,index), isExpand:false});
            }else{
                this.setData({isExpand:true});
            }
        }
    },

    dealWithPassengers:function(){
        for (let p in this.data.passengers) {
            this.data.passengers[p].isSelected = false;
        }
        if(this.data.passengers.length == 1){
            //如果只有一个乘客人默认选中
            this.data.passengers[0].isSelected = true;
        }
        this.setData({passengers:this.data.passengers});
        this.confirmButtonClickEnable();
        this.calculateRefundAmountAndFee();
    },

    // 计算实退金额和手续费
    calculateRefundAmountAndFee:function(){
        var refundAmount = 0;
        var refundFee = 0;
        for (let p in this.data.passengers) {
            var passenger = this.data.passengers[p];
            if(passenger.isSelected){
                if(!Util.isEmptyString(passenger.refundAmount)){
                    refundAmount += parseFloat(passenger.refundAmount);
                }
                if(!Util.isEmptyString(passenger.refundFee)){
                    refundFee += parseFloat(passenger.refundFee);
                }
            }
        }
        this.setData({totalRefundAmount:refundAmount, totalRefundFee:refundFee});
    },

    /*=========================================================*/
    // 点击&绑定事件
    /*=========================================================*/

    confirmClick: function() {
        wx.hideKeyboard();
        if(this.data.confirmButtonEnable){
            this.confirmGoApplyRefund();
        }
    },
    confirmGoApplyRefund:function(){
        var selectedCount = 0;
        var selectedChildrenCount = 0;
        for (let p in this.data.passengers) {
            if(this.data.passengers[p].isSelected){
                selectedCount ++;
                if(this.data.passengers[p].ticketType === 0){
                    selectedChildrenCount ++;
                }
            }
        }
        if(selectedChildrenCount == selectedCount){
            ModalUtil.showModal({
                content: '因儿童不可单独购票，不可只退成人票！',
                confirmText: "确定"
            });
            return;
        }
        var that = this;
        ModalUtil.showModal({
            content: '确认申请退票?',
            confirmText: "确定",
            cancelText:"取消",
            onConfirm: function(res) {
                that.requestRefund();
            }
        });
    },
    confirmButtonClickEnable:function(){
        var selectedCount = 0;
        for (let p in this.data.passengers) {
            if(this.data.passengers[p].isSelected){
                selectedCount ++;
            }
        }
        if(selectedCount > 0){
             this.setData({confirmButtonEnable:true});
        }else{
            this.setData({confirmButtonEnable:false});
        }
    },
    refundFeeClick: function() {
        wx.hideKeyboard();
        this.setData({isShowRefundFeeDetail:true});
        this.feeDetailAnimation= wx.createAnimation({
            duration: 300,
            timingFunction: 'ease'
        });
        this.feeDetailAnimation.opacity(1).step();
        this.setData({feeDetailAnimation: this.feeDetailAnimation.export()});
    },
    redundFeeDetailLayerClick: function() {
        this.feeDetailAnimation.opacity(0).step();
        this.setData({feeDetailAnimation: this.feeDetailAnimation.export()});
        setTimeout(function(){
            this.setData({isShowRefundFeeDetail:false});
        }.bind(this),300);
    },
    passengerClick: function (e) {
        wx.hideKeyboard();
        let index = e.currentTarget.dataset.index;
        this.data.passengers[index].isSelected = this.data.passengers[index].isSelected ? !this.data.passengers[index].isSelected : true;
        let enable = false;
        for (let k in this.data.passengers) {
            if (this.data.passengers[k].isSelected) {
                enable = true;
                break;
            }
        }
        this.setData({passengers:this.data.passengers});
        this.confirmButtonClickEnable();
        this.calculateRefundAmountAndFee();
    },

    expandClick:function(e){
        this.setData({ isExpand: !this.data.isExpand });
    },

    /*=========================================================*/
    // 生命周期
    /*=========================================================*/

    // 页面初始化 params为页面跳转所带来的参数
    onLoad: function (params) {
        Watcher.sendPV.call(this, Watcher.keys.ORDER_REFUND);

        this.orderDetailParam = params;
    },

    // 页面渲染完成
    onReady:function(){
        if(!this.orderDetailParam || Util.isEmptyString(this.orderDetailParam.orderNo) || Util.isEmptyString(this.orderDetailParam.orderId) || Util.isEmptyString(this.orderDetailParam.orderToken)){
            ModalUtil.showModal({
                content: '出错',
                onConfirm: wx.navigateBack
            });
            return;
        }
        Network.showNetwork.call(this, {status: 4});
        this.requestRefundViewInfo();
    },
    // 页面显示
    onShow:function(){
    },
    // 页面隐藏
    onHide:function(){
    },
     // 页面关闭
    onUnload:function(){
        Network.hideNetwork.call(this);
    },
    onShareAppMessage: function() {
        return Util.shareToTrainHome();
    }
})
