/**
 * 添加编辑乘客
 *
 * 使用:
 * wx.navigateTo({
 *     url: '../passenger/passenger?xxx',
 * });
 *
 *
 * 参数:
 * data:{
 *     editIndex: -1,                         // 编辑模式 新增加-1 编辑>=0
 *     passengerList:[
 *         {
 *             name: "username",              // 用户名称
 *             gender: 0,                     // 性别 0男 1女
 *             birthday: "2013-01-01",        // 出生日期
 *             certs:[
 *
 *             ],
 *         },
 *     ]
 * }
 */

var EventEmitter = require('../../../common/EventEmitter.js');
var CheckUtil = require('../../utils/checkUtil.js');
var Util = require('../../utils/util.js');
var DateFormat = require('../../utils/dateTime.js');

var TrainDef = require('../../utils/define.js');
var Watcher = require('../../utils/watcher.js');
var TRAIN_EVENT_NAME = TrainDef.TRAIN_EVENT_NAME;

var CERT_TYPES = ["身份证", "护照", "台胞证", "港澳通行证"];
var CERT_KEY = ["NI","PP","TB","GA"];
var GENDER_KEYS = ['1','2'];
var GENDER_VALUES = ["男","女"];


Page({


    /*=========================================================*/
    // 数据
    /*=========================================================*/
    pageName: TrainDef.TRAIN_PAGE_NAME.PASSENGER_EDIT,
    data: {
        certTypes: CERT_TYPES,               // 证件类型
        genders: GENDER_VALUES,              // 性别
        isFinished: false,                   // 乘客信息是否填写完整
        curCertIndex: 0,                     // 当前选中的证件类型索引
        genderIndex: 0,                      // 性别索引
        curDate: DateFormat.formatDateTime(new Date(), 'yyyy-MM-dd'),
        passengerInfo: {
            name: '',
            gender: '1',                     // 字符串 1男 2女 默认1
            birthday: '',
            certType: CERT_KEY[0],
            certNo: '',
            ticketType: 0
        }
    },
    editIndex: -1,                           // 编辑模式 新增加-1 编辑>=0
    passenger: {                             // 当前正在编辑的乘客信息
    },
    passengerList: [                         // 上一个页面传过来的乘客列表
    ],
    isFromList:false,               //是否来自list页


    /*=========================================================*/
    // 点击&绑定事件
    /*=========================================================*/
    finishClick: function() {

        var name = this.data.passengerInfo.name;
        var certNo = this.data.passengerInfo.certNo;
        var birthday = this.data.passengerInfo.birthday;
        var certType = this.data.passengerInfo.certType;

        var error = '';
        // 用户名称
        error = CheckUtil.checkName(name);

        // 证件号
        if(!error || error.length <=0){
            if(certType === 'NI'){
                error = CheckUtil.checkNI(certNo);
            }else if(certType === 'PP'){
                error = CheckUtil.checkPP(certNo);
            }else if(certType === 'TB'){
                error = CheckUtil.checkTB(certNo);
            }else if(certType === 'GA'){
                error = CheckUtil.checkGA(certNo);
            }
        }

        // 出生日期
        if(certType != 'NI' && (!error || error.length <=0) && (!birthday || birthday <= 0)){
            error = '请选择出生日期';
        }

        // 判断是否重复
        if(!error || error.length <=0){
            for(var i = 0 ; i < this.passengerList.length; i++){
                if(i == this.editIndex){
                    continue;
                }
                var passengerItem = this.passengerList[i];
                for(var j = 0 ;j < passengerItem.certs.length; j++){
                    var certItem = passengerItem.certs[j];
                    if(certItem.type === certType && certItem.numberObj.value === certNo){
                        error = '您输入的乘客信息重复';
                    }
                }
            }
        }

        // 弹框提示
        if(error && error.length > 0){
            wx.showModal({
                title: '提示',
                content: error + '\n',
                confirmText:'知道了\n',
                showCancel:false
            });
            return;
        }

        this.passenger.name = name;
        this.passenger.gender = this.data.passengerInfo.gender;
        this.passenger.birthday = birthday;
        this.passenger.ticketType = this.data.passengerInfo.ticketType;
        if(this.passenger.certs && this.passenger.certs.length > 0){
            var isModify = false;
            var modifyIndex = 0;
            for(var i = 0; i < this.passenger.certs.length; i++){
                var cert = this.passenger.certs[i];
                if(cert.type === certType){
                    cert.numberObj.value = certNo;
                    cert.numberObj.display = certNo;
                    modifyIndex = i;
                    isModify = true;
                    break;
                }
            }
            if(!isModify){
                var cert = {};
                cert.type = certType;
                cert.certId = '';
                cert.name = CERT_TYPES[this.data.curCertIndex];
                cert.numberObj = {display:certNo,value:certNo};
                this.passenger.certs.unshift(cert);
            }else{
                var cert = this.passenger.certs[modifyIndex];
                this.passenger.certs.splice(modifyIndex,1);
                this.passenger.certs.unshift(cert);
            }
        }else{
            var cert = {};
            cert.type = certType;
            cert.certId = '';
            cert.name = CERT_TYPES[this.data.curCertIndex];
            cert.numberObj = {display:certNo,value:certNo};
            this.passenger.certs = [];
            this.passenger.certs.push(cert);
        }

        this.passenger.source = 1;
        if(this.editIndex < 0){
            this.passenger.isSelected = true;
            this.passengerList.push(this.passenger);
        }

        // if (this.data.isFromList) {
        //     EventEmitter.dispatch(TRAIN_EVENT_NAME.ADD_PASSENGER_TO_LIST, {
        //         passengers: this.passengerList,
        //         editIndex: this.editIndex,
        //         newPassenger: this.passenger
        //     });
        // } else {
            EventEmitter.dispatch(TRAIN_EVENT_NAME.DID_CHOOSE_PASSENGERS, {
                passengers: this.passengerList,
                editIndex: this.editIndex,
                newPassenger: this.passenger
            });
        // }
        wx.navigateBack();
    },
    dialogLayerClick : function() {
        // this.dialogAnimation.opacity(0).step();
        // this.setData({dialogAnimation: this.dialogAnimation.export()});
        // setTimeout(function(){
        this.setData({isShowFaqDialog:false});
        // }.bind(this),300);
    },
    faqClick: function() {
        wx.hideKeyboard();
        this.setData({isShowFaqDialog:true});
        // this.dialogAnimation= wx.createAnimation({
        //     duration: 0,
        //     timingFunction: 'ease'
        // });
        // this.dialogAnimation.opacity(1).step();
        // this.setData({dialogAnimation: this.dialogAnimation.export()});

        // 因为文字太长显示的bug
        // wx.showModal({
        //     title: '姓名填写说明',
        //     content: '1. 请优先使用中文姓名。        \n' +
        //              '2. 如果姓名中有“·”（中点）或“.”（下点）时，请仔细辨析身份证件原件上的字符，准确输入。\n' +
        //              '3. 如姓名中有生僻字，无法输入或者输入保存后系统无法正确显示时，可用小写的汉语拼音或同音字代替。例如“张垚”可输入为“张yao”。\n' +
        //              '4. 如姓名中有繁体字无法输入时，可用简体代替。\n' +
        //              '5. 如姓名较长，汉字或英文字符合计超过30个（1个汉字算2个英文字符）时，请按姓名中第一个汉字或英文字符开始按顺序连续输入30个字符，空格字符不输入，英文字符不需区别大小写。\n' +
        //              '6. 台籍乘客请使用台胞证（台湾居民来往大陆通行证）',
        //     showCancel:false
        // });
    },
    certChangeClick: function(e) {
        var that = this;
        wx.showActionSheet({
            itemList: CERT_TYPES,
            success: function (res) {
                if (!res.cancel) {
                    that.data.passengerInfo.certType = CERT_KEY[res.tapIndex];
                    that.data.passengerInfo.certNo = '';
                    if(that.editIndex >=0 && !Util.isEmptyArray(that.passenger.certs)){
                        for(let j = 0; j < that.passenger.certs.length; j++){
                            let item = that.passenger.certs[j];
                            if(that.data.passengerInfo.certType === item.type){
                                that.data.passengerInfo.certNo = item.numberObj.value;
                            }
                        }
                    }
                    that.setData({curCertIndex:res.tapIndex});
                    that.refreshView(that.data.passengerInfo);
                }
            }
        });
    },
    genderChangeClick: function (e) {
        var that = this;
        wx.showActionSheet({
            itemList: GENDER_VALUES,
            success: function (res) {
                if (!res.cancel) {
                    that.data.genderIndex = res.tapIndex;
                    that.data.passengerInfo.gender = GENDER_KEYS[res.tapIndex];
                    that.setData({ genderIndex: res.tapIndex });
                }
            }
        });
    },
    bindDateChange: function(e) {
        this.data.passengerInfo.birthday = e.detail.value;
        this.refreshView(this.data.passengerInfo);
    },
    bindNameInput: function(e){
        this.data.passengerInfo.name = e.detail.value;
        this.refreshView(this.data.passengerInfo);
    },
    bindNameDidChange: function(e) {
        this.data.passengerInfo.name = e.detail.value.trim();
        this.refreshView(this.data.passengerInfo);
    },
    bindCertNoInput: function(e) {
        this.data.passengerInfo.certNo = e.detail.value;
        if(this.data.curCertIndex == 0 && !Util.isEmptyString(e.detail.value)){
            this.data.passengerInfo.certNo = e.detail.value.toUpperCase();
        }
        this.refreshView(this.data.passengerInfo);
    },
    bindCertNoChange: function(e) {
        this.data.passengerInfo.certNo = e.detail.value.trim();
        if(this.data.curCertIndex == 0 && !Util.isEmptyString(e.detail.value)){
            this.data.passengerInfo.certNo = e.detail.value.toUpperCase();
        }
        this.refreshView(this.data.passengerInfo);
    },

    /*=========================================================*/
    // 生命周期
    /*=========================================================*/
    onShareAppMessage: function() {
        return Util.shareToTrainHome();
    },

    // 页面初始化 params为页面跳转所带来的参数
    onLoad:function(params){
        Watcher.sendPV.call(this, Watcher.keys.PASSENGER_EDIT);
        // 参数校验
        if(!params || !params.data){
            return;
        }
        var data = Util.parseURLParam(params).data;
        if(data.isFromList) {
            this.data.isFromList = true;
        }
        var editIndex = data.editIndex;
        var passengerList = data.passengerList;
        if(editIndex <= -2 || !passengerList || passengerList.length <=0){
            return;
        }

        this.editIndex = editIndex;
        this.passengerList = passengerList;

        if(this.editIndex <= -1){// 添加乘客
            return;
        }

        this.passenger = this.passengerList[this.editIndex];
        this.data.passengerInfo.name = this.passenger.name;
        if(!Util.isEmptyString(this.passenger.gender)){
            this.data.passengerInfo.gender = this.passenger.gender;
        }
        if(!Util.isEmptyString(this.passenger.birthday)){
            this.data.passengerInfo.birthday = this.passenger.birthday;
        }
        if(this.passenger.certs && this.passenger.certs.length > 0) {
            this.data.passengerInfo.certType = this.passenger.certs[0].type;
            this.data.passengerInfo.certNo = this.passenger.certs[0].numberObj.value;
        }
        var index = CERT_KEY.indexOf(this.data.passengerInfo.certType);
        if(index < 0){
            index = 0;
            this.data.passengerInfo.certType = CERT_KEY[index];
            for(var i = 0; i < this.passenger.certs.length; i++){
                var item = certs[i];
                if(this.data.passengerInfo.certType === item.type){
                    this.data.passengerInfo.certNo = item.numberObj.value;
                }
            }
        }
        this.data.curCertIndex = index;
        this.setData({curCertIndex:index});
        this.refreshView(this.data.passengerInfo);
    },
    // 页面渲染完成
    onReady:function(){
        wx.setNavigationBarTitle({
            title: this.editIndex < 0 ? "添加新乘客" : "编辑乘客"
        });
    },
    // 页面显示
    onShow:function(){
    },
    // 页面隐藏
    onHide:function(){
    },
     // 页面关闭
    onUnload:function(){
    },


    /*=========================================================*/
    // 刷新&处理
    /*=========================================================*/
    refreshView: function(passengerInfo) {
        var isFinished = true;
        if(!passengerInfo.name || passengerInfo.name.length <= 0){
            isFinished = false;
        }
        if(!passengerInfo.certNo || passengerInfo.certNo.length <= 0){
            isFinished = false;
        }
        if(passengerInfo.certType !='NI' && (!passengerInfo.birthday || passengerInfo.birthday.length <= 0)){
            isFinished = false;
        }
        this.setData({isFinished:isFinished,passengerInfo:passengerInfo});
    }
})
