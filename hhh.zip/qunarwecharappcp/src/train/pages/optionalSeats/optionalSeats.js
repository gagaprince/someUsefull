/**
* @Author: 少烈 <shaolie>
* @Date:   2016-11-20T12:20:19+08:00
* @Email:  lshaolie@163.com
* @Last modified by:   shaolie
* @Last modified time: 2016-11-20T15:51:46+08:00
* @Note: Please contact me if you find any bugs 🐜^*^
*/


var Utils = require('../../utils/util.js');
var ModalUtil     = require('../../utils/modalUtil.js');
var SeatUtil    = require('../../businessLogic/seatUtil.js');
var parseURLParam = Utils.parseURLParam;
var EventEmitter = require('../../../common/EventEmitter.js');
var TrainDef     = require('../../utils/define.js');
var Watcher = require('../../utils/watcher.js');
var EVENT_NAME = TrainDef.TRAIN_EVENT_NAME;

Page({
    pageName: TrainDef.TRAIN_PAGE_NAME.OPTIONAL_SEATS,
    data:{
        flag: false,
        trainSeats: []
    },

    onShareAppMessage: function() {
        return Utils.shareToTrainHome();
    },

    onLoad:function(){
        Watcher.sendPV.call(this, Watcher.keys.OPTIONAL_SEATS);
        var that = this;
        EventEmitter.addListener(EVENT_NAME.OPTIONAL_SEATS_LOADED, function(param) {
            var defaultSelectedSeat = param.defaultSelectedSeat;
            var trains = param.trains;
            that._trains = trains;  // 备份
            var trainRst = [];

            // 将坐席类型相同的车次进行分组
            for(var i = 0; i < trains.length; i++) {
                if (Utils.isEmptyArray(trainRst)) {
                    trainRst.push([trains[i]]);
                    continue;
                }

                for(var j = 0; j < trainRst.length; j++) {

                    var srcTicketInfos = trainRst[j][0].ticketInfos;
                    var newTicketInfos = trains[i].ticketInfos;

                    if (SeatUtil.isSameTicketsType(srcTicketInfos, newTicketInfos)) {
                        trainRst[j].push(trains[i]);
                        break;
                    } else if (j == trainRst.length - 1) {
                        trainRst.push([trains[i]]);
                        break;
                    }
                }
            }

            // 构造 trainSeats 用于渲染
            var trainSeats = [];
            for (var i = 0; i < trainRst.length; i++) {
                var groupTrains = trainRst[i];
                var title = "";
                for (var j = 0; j < groupTrains.length; j++) {
                    title += (trainRst[i][j].trainNumber + "、");
                }
                if (title.length > 0) {
                    title = title.substr(0, title.length - 1);
                }
                trainSeats.push({title:title, seats: trainRst[i][0].ticketInfos, items:groupTrains});
            }

            // 勾选默认选中项
            for(var i = 0; i < trainSeats[0].seats.length; i++) {
                if(defaultSelectedSeat.type == trainSeats[0].seats[i].type) {
                    trainSeats[0].seats[i].selected = true;
                    break;
                }
            }

            that.setData({
                trainSeats: trainSeats,
                defaultSelectedSeat: defaultSelectedSeat,
                seatTips: param.seatTips,
                trains: trains
            });

        });
    },

    onUnload:function(){
        // 页面关闭
        EventEmitter.removeListener(EVENT_NAME.OPTIONAL_SEATS_LOADED);
    },
    clickRadioBtn: function(event) {
        var sectionId = parseInt(event.currentTarget.dataset.sectionId, 10);
        var rowId = parseInt(event.currentTarget.dataset.rowId, 10);

        var trainSeats = this.data.trainSeats;

        var that = this;

        var clickType =trainSeats[sectionId].seats[rowId].type;
        trainSeats[sectionId].seats[rowId].selected = !trainSeats[sectionId].seats[rowId].selected;
        var selected = trainSeats[sectionId].seats[rowId].selected;
        for (var i = sectionId; i < trainSeats.length; i++) {
            var items = trainSeats[i].items;
            items.forEach(function (item){
                that.data.trains.forEach(function(train) {
                    if (train.trainNumber == item.trainNumber) {
                        for(var j = 0; j < train.ticketInfos.length; j++) {
                            var ticket = train.ticketInfos[j];
                            if (ticket.type == clickType) {
                                ticket.selected = selected;
                                break;
                            }
                        }
                    }
                });

                // 向下联动
                for(var j = 0; j < item.ticketInfos.length; j++) {
                    var ticket = item.ticketInfos[j];
                    if (ticket.type == clickType) {
                        ticket.selected = selected;
                        break;
                    }
                }
            });
        }
        this.setData({
            trainSeats: trainSeats
        });
    },

    didFinishSelection: function(event) {
        var that = this;

        if (SeatUtil.isEachTrainSeatSelected(this.data.trains)) {
            this._trains.forEach(function(train, i) {
                train.ticketInfos.forEach(function(ticket, j) {
                    ticket.selected = that.data.trains[i].ticketInfos[j].selected;
                });
            });
            EventEmitter.dispatch(EVENT_NAME.DID_SELECT_OPTIONAL_SEATS, {selectedTrains: this._trains});
            wx.navigateBack();
        } else {
            ModalUtil.showModal({
                content: "请选择备选坐席"
            });
        }
    }
});
