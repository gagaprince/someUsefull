// faq.js
var requester = require('../../utils/requester.js');
var Service      = require('../../config/requestService.js');
var Network = require('../../../common/comps/network/network.js');
var Util = require('../../utils/util.js');

/**
 * @url faq?type=xx&insuranceCode=xx&productCode=xx
 */
Page({
    data:{
        // network
        networkData:{
            status: 4
        },
        // faq result
        faqContents: {}
    },

    network_retry: function() {
        this.request();
    },

    onShareAppMessage: function() {
        return Util.shareToTrainHome();
    },

    onLoad: function(param) {
        this.setData({param:param});
    },

    onReady: function() {
        Network.showNetwork.call(this, {status: 4});
        this.request();
    },

    onUnload: function() {
        Network.hideNetwork.call(this);
    },

    request: function() {
        var param = this.data.param;
        var that = this;
        requester.request({
            service: Service.FAQ,
            param: {
                type: param.type,
                insuranceCode: param.insuranceCode,
                productCode: param.productCode
            },
            success: function(response) {
                response = response.data;
                if (!response || response.status != 0) {
                    Network.showNetwork.call(that, {status: -2, loadingDesc: '网络请求失败'});
                }
                else {
                    Network.hideNetwork.call(that, function() {
                        that.setData({
                            faqContents: response.contents
                        });
                    });
                }
            },
            fail: function(error) {
                Network.showNetwork.call(that, {status: -1, loadingDesc: '网络连接失败'});
            }
        });
    }

})
