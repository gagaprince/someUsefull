// define.js

var TRAIN_PAGE_NAME = {
    HOME:           "TrainHomePage",
    SEARCH_LIST:    "TrainSearchListPage",
    ORDER_FILL:     "TrainOrderFillPage",
    ORDER_DETAIL:   "TrainOrderDetailPage",
    PASSENGER_LIST: "TrainPassengerList",
    PASSENGER_EDIT: "TrainPassengerEditPage",
    INSURACE:       "TrainInsurancePage",
    OPTIONAL_SEATS: "TrainOptionalSeats",
    OPTIONAL_TRAINS: "TrainOptionalTrains",
    ORDER_REFUND:  "TrainOrderRefund"
}

// 消息名
var TRAIN_EVENT_NAME = {
    DATE_SELECT: "TrainDateSelected",
    OPTIONAL_DATE_SELECT: "TrainOptionalDateSelected",
    CITY_SELECT: "TrainCitySelected",
    DID_FINISH_SELECT_INSURANCE: "TrainDidFinishSelectInsurance",
    DID_CHOOSE_PASSENGERS: "TrainDidChoosePassengers",
    ADD_PASSENGER_TO_LIST:"AddPassengerToList",
    NAVIGATE_TO_ORDER_DETAIL: "TrainNavigateToOrderDetail",

    DID_SELECT_OPTIONAL_SEATS: "TrainDidSelectOptionalSeats",
    DID_SELECT_OPTIONAL_TRAINS: "TrainDidSelectOptionalTrains",
    DID_REFUND_TICKET: "TrainRefundTicket",

    LOGIN_12306_SUCCESS:"LoginSuccess",
    OPTIONAL_TRAINS_LOADED: "TrainOptionalTrainsLoaded",
    OPTIONAL_SEATS_LOADED: "TrainOptionalSeatsLoaded",

    NO_ACCOUNT_BOOKING: "TrainNoAccountBooking"
}

// 本地存储key
var TRAIN_CACHE_KEY = {
    // 出发城市
    DEP_CITY: "TrainDepCity",
    // 到达城市
    ARR_CITY: "TrainArrCity",
    // 出发日期
    DEP_DATE: "TrainDepDate",
    // 日历预售期
    CALENDAR:"TrainCalendar",
    // 历史城市
    HISTORY_CITY:"TrainHistoryCity",

    ORDER_FILL_PASSENGERS_INFO: "TrainOrderFillPassengersInfo",
    ORDER_FILL_CONTACT_PHONE: "TrainOrderFillContactPhone",
    ORDER_FILL_BOOK_NOTICE_READED: "TrainOrderFillBookNoticeReaded"
}

var TRAIN_FAQ_TYPE = {
    // 无线
    WIRELESS: 1,
    // www
    _3W: 2,
    // 取票、退票、改签
    TGQ: 3,
    // 站站搜索首页提示
    STATION_TO_STATION_HOME_TIPS: 4,
    // www5元保险
    WWW_5YUAN_INSURANCE: 7,
    // 儿童票须知
    CHILD_TICKET: 8,
    // 学生票须知
    STUDENT_TICKET: 13,
    /// 身份待核验处理办法faq
    ID_VERIFICATION: 14,
    // 改签说明faq
    REBOOK_NOTICE: 16,
    // 送票到站取票地址详情
    TAKE_TICKET_ADDRESS_DETAIL: 17,
    // 姓名规则
    NAME_RULE: 20,
    // 保险须知
    INSURANCE_NOTICE: 101,
    /// 经济委托协议
    ECONOMIC_COMMISSION_AGREEMENT: 102,
    /// 12306使用规则和隐私协议
    _12306_USAGE_RULES_AND_PRIVACY_CLAUSES: 103,
    // 纸质票在线选座，协议须知
    PAPER_TICKET_ONLINE_SEAT: 104
}

var TRAIN_STATUS = {
    /// 0、默认或未知
    DEFAULT: 0,
    /// 1、可预订
    ENABLE: 1,
    /// 2、已停售
    DISABLE: 2,
    /// 3、已发车
    DEPARTED: 3,
    /// 4、已售空
    SOLD_OUT: 4,
    /// 5、临时停售
    SALE_STOP: 5,
    /// 6、未起售
    NOT_ON_SALE: 6,
    /// 7、运行图调整
    MAP_ADJUST: 7
}

module.exports = {
    TRAIN_PAGE_NAME: TRAIN_PAGE_NAME,
    TRAIN_EVENT_NAME: TRAIN_EVENT_NAME,
    TRAIN_CACHE_KEY: TRAIN_CACHE_KEY,
    TRAIN_FAQ_TYPE: TRAIN_FAQ_TYPE,
    TRAIN_STATUS: TRAIN_STATUS
}
