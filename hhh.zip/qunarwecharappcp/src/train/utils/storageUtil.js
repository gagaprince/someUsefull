
var StorageUtil = {
    setStorageSync: function(key, value){
        try {
            wx.setStorageSync(key, value)
            return true;
        } catch (e) {
            return false;
        }
    },

    getStorageSync: function(key) {
        try {
            return wx.getStorageSync(key)
        } catch(e) {
            return null;
        }
    },

    removeStorageSync: function(key) {
        try {
            wx.removeStorageSync(key)
            return true;
        } catch (e) {
            return false;
        }
    },

    getStorageInfoSync: function() {
        try {
            return wx.getStorageInfoSync()
        } catch (e) {
            return null;
        }
    },

    clearStorageSync: function() {
        try {
            wx.clearStorageSync()
            return true;
        } catch(e) {
            return false;
        }
    },

    getSystemInfoSync: function() {
        try {
            return wx.getSystemInfoSync()
        } catch (e) {
            return null;
        }
    },

    setStorage: wx.setStorage,
    getStorage: wx.getStorage,
    getStorageInfo: wx.getStorageInfo,
    removeStorage: wx.removeStorage,
    clearStorage: wx.clearStorage,
    getSystemInfo: wx.getSystemInfo
};

module.exports = StorageUtil;
