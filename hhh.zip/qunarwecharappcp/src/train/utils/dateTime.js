// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") --> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      --> 2006-7-2 8:9:4.18
function formatDateTime(date, fmt) { //author: meizz
    if (!fmt) {
        fmt = "yyyy-MM-dd";
    }
    var o = {
        "M+": date.getMonth() + 1, //月份
        "d+": date.getDate(), //日
        "h+": date.getHours(), //小时
        "m+": date.getMinutes(), //分
        "s+": date.getSeconds(), //秒
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度
        "S": date.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return fmt;
}

function parseDateTime(str, fmt) {
    return new Date(str);
}

function addDate(date, days) {
    return new Date(date.getTime() + days * 24 * 3600 * 1000);
}

function formatNumber(n) {
    n = n.toString()
    return n[1] ? n : '0' + n
}

// 判断周几
function getWeek(date) {
    var day = date.getDay();
    return ["周日", "周一", "周二", "周三", "周四", "周五", "周六"][day];
}

// 是否是闰年
function is_leap(year) {
   return (year%100==0?(year%400==0?1:0):(year%4==0?1:0));
}

// 计算一个月有多少天
// month为具体月份 0-11
function daysCountOfMonth(year,month) {
    var m_days = [31, 28 + is_leap(year), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    return m_days[month];
}

// 计算日历中一个月的行数
function weeksCountOfMonth(year,month) {
    // 计算月第一天是周几
    var date = new Date(year,month,1);
    var first = date.getDay();
    var weeks = Math.ceil((daysCountOfMonth(year,month) + first) / 7);
    return weeks;
}

function getTodayDesc(d) {
    var desc = '';
    var today = new Date();
    if (today.getFullYear() == d.getFullYear() && today.getMonth() == d.getMonth()) {
        var dateOfToday = today.getDate();
        var date = d.getDate();

        var difference = date - dateOfToday;
        if (difference >= 0 && difference < 3) {
            desc = ['今天', '明天', '后天'][difference];
        }
    }
    return desc;
}

module.exports = {
    formatDateTime: formatDateTime,
    parseDateTime: parseDateTime,
    addDate: addDate,
    getWeek:getWeek,
    daysCountOfMonth:daysCountOfMonth,
    weeksCountOfMonth:weeksCountOfMonth,
    getTodayDesc:getTodayDesc
}
