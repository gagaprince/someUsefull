// Requester.js
var Requester = require('../../common/requester.js');
var Config    = require('../../common/config.js');
function request(obj) {
    obj.host = obj.host || Config.train.HOST;
    Requester.request(obj);
}

module.exports = {
    request: request
};
