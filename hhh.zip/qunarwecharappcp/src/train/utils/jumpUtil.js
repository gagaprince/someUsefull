var TRAIN_PAGE_NAME = require('./define.js').TRAIN_PAGE_NAME;

var JumpUtil = {
    goto: function(key, param, success) {
        if (key.indexOf("pub:") == 0) {
            key = key.substring(4);
            wx.navigateTo({
                url: '/common/pages/' + key + '/' + key + '?' + param,
                success: success
            });
        } else {
            wx.navigateTo({
                url: '../' + key + '/' + key + '?' + param,
                success: success
            });
        }
    },

    /**
     * pageName:  要跳转的页面名称。在跳转回页面时确保页面下有 pageName 属性
     */
    backTo: function(pageName) {
        var pages = getCurrentPages();
        var homePageCount = 0;
        if (pageName == TRAIN_PAGE_NAME.HOME) {
            homePageCount = 10;
        } else {
            for(var i = 0; i < pages.length; i++) {
                if (pages[i].pageName == pageName) {
                    homePageCount = pages.length - i - 1;
                    break;
                }
            }
        }

        wx.navigateBack({
            delta: homePageCount
        });
    }
};

module.exports = JumpUtil;
