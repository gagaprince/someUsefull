
var Watcher = require('../../common/watcher.js');
var Config = require('../../common/config.js');

/**
 *
 * key: 'string 监控的名字，会默认在最后添加 '_wx_iOS' or '_wx_android' ',
 * success: 'nullable bool 是否是成功的监控，默认 true',
 * duration: 'nullable string 持续的时间'
 *
 */
function click(query) {
    if (!query) {
        return;
    } else {
        query["action-type"] = 'train_' + query["action-type"];
    }
    console.log('TrainWatcher', query);
    Watcher.click(query);
}

function pv(query, delay) {
    if (!query) {
        return;
    } else {
        query["action-type"] = 'train_' + query["action-type"];
    }
    console.log('TrainPV', query);
    Watcher.pv(query, delay);
}

function sendWatcher(actionType) {
    if (!this) {
        return console.error('use Watcher.sendWatcher.call(this, actionType) to call');
    } else if(!this.pageName) {
        return console.error('this.pageName is undefined');
    } else if(!actionType) {
        return console.error('actionType is undefined');
    }
    click({
        page: this.pageName,
        "action-type": actionType
    });
}

function sendPV(actionType, delay) {
    if (!this) {
        return console.error('use Watcher.sendPV.call(this, actionType) to call');
    } else if(!this.pageName) {
        return console.error('this.pageName is undefined');
    } else if(!actionType) {
        return console.error('actionType is undefined');
    }
    pv({
        page: this.pageName,
        "action-type": actionType
    }, delay);
};

module.exports = {
    send: click,
    sendWatcher: sendWatcher,
    sendPV: sendPV,
    // train_search_wx_iOS
    keys: {
        /**
         * 首页
         */
        // 小程序进火车票首页版本号监控
        VERSION: Config.version,
        // 进入火车票首页量
        INDEX: 'index',
        // 点击搜索量
        SEARCH: 'search',
        /**
         * 车次列表页
         */
        // 进入车次列表页量
        SEARCH_SUCCESS: 'search_success',
        // 显示车次列表页量
        SEARCH_SHOW: 'search_show',
        // 点击具体车次量
        BOOKING: 'booking',
        /**
         * 填单页
         */
        // 进入填单页量
        BOOKING_SUCCESS: 'booking_success',
        COMMIT_ORDER: 'commit_order',
        // 进入保险页面量
        INSURANCE_SUCCESS: 'insurance_success',
        // 出行保障点击量
        INSURANCE: 'insurance',
        // 选择不购买点击量
        INSURANCE_NONE: 'insurance_none',

        /**
         * 订单详情
         */
        ORDER_DETAIL_SUCCESS: 'order_detail_success',
        ORDER_DETAIL_CANCLE_ORDER: 'order_detail_cancle_order', //取消订单
        ORDER_DETAIL_APPLY_REFUND: 'order_detail_apply_refund', //申请退票
        ORDER_DETAIL_PAY_ORDER: 'order_detail_pay_order',        //立即支付

        PASSENGER_LIST: 'passenger_list',       //进入乘客列表
        PASSENGER_EDIT: 'passenger_edit',        //进入乘客编辑页面（添加乘客）

        OPTIONAL_SEATS: "optional_seats",
        OPTIONAL_TRAINS: "optional_trains",
        ORDER_REFUND:  "order_refund",

        LOGIN_12306: "login_12306"
    }
}

/*
var watcher = require('../../../../train/utils/watcher.js');
watcher.send(watcher.keys.xxx);
*/
