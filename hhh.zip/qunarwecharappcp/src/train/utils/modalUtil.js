
/**
 * 显示 alert 提示
 * @type {Object}
 */
var ModalUtil = {
    /**
     * 显示 alert 提示
     * @param {Object} option {onConfirm: func, onCancel: func, title: string, content: string， cancleText: string, confirmText: string}
     * title 默认为 “提示”，
     * confirmText 默认为 "好的"，
     * 如果不实现 onCancel函数 并且 cancelText 为空，则不显示取消按钮
     */
    showModal: function(option) {
        if (option.onConfirm || option.onCancel) {
            option.success = function(res){
                if (res.confirm == 1 || res.confirm == "true") {
                    option.onConfirm && option.onConfirm();
                } else {
                    option.onCancel && option.onCancel();
                }
            }
        }
        option.confirmText = option.confirmText || '好的';
        option.confirmColor = option.cancelColor = "#1fbcd2";
        option.title = option.title ? option.title : "提示";
        option.showCancel = option.onCancel || option.cancelText ? true : false;
        wx.showModal && wx.showModal(option);
    }
};

module.exports = ModalUtil;
