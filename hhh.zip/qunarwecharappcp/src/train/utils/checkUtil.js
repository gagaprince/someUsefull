

function checkName(name) {
    if(!name || name.length <=0){
        return "请输入姓名";
    }

    //name = name.replace(/ /g,"");// 空格
    name = name.replace(/／/g,"/");

    var hz = name.match(/[\u4e00-\u9fa5]/g);
    
    // 汉字的个数
    var i = hz ? hz.length : 0;

    // 计算字符长度
    var j = name.length - i + i * 2;
    if (j < 3) {
        return "姓名过短，请输入正确姓名 ";
    } else if (j > 30) {
        return "姓名长度超过限制 ";
    }

    // 姓名中不能含有除汉子，字母，“空格”，“.”,”·”以外的其他字符
    if (!name.match(/^[\u4e00-\u9fa5A-Za-z\\s\\.·]+$/)) {
        return "姓名中不能含有除汉字，字母，“空格”，“.”，”·”以外的其他字符";
    }

    // 如果包含中文
    if (name.match(/[\u4e00-\u9fa5]/g)) {
        // 如果包含英文
        if (name.match(/[A-Za-z]/g)) { // 只要中文和英文同时存在  就不能有符号
            if (name.match(/\\s/g) || name.match(/\\./g) || name.match(/·/g) || !name.substring(0, 1).match(/[\u4e00-\u9fa5]/)) { // 含有符号 或者不是中文开头
                return "姓名中不能同时包含汉字、字母和符号，姓必须是中文";
            }
        } else if (name.match(/\\s/g)) { // 不包含英文, 纯中文姓名不能包含空格, 可以含有“.”,”·”
            return "中文姓名不能含有除汉字，“.”，”·”以外的其他字符";
        }
    }

    // 如果包含中文, 就只能以中文开头
    if (name.match(/[\u4e00-\u9fa5]/g) && !name.substring(0, 1).match(/[\u4e00-\u9fa5]/)) {
        return "中文姓名的姓必须是中文";
    }

    return "";
}

function checkNI(ni) {
    if (!ni || ni.length <= 0) {
        return "请输入身份证号";
    }
    if (ni.length != 18 && ni.length != 15) {
        return "身份证号长度有误，请重新输入后提交";
    }
    if (!ni.match(/^[0-9]{17}[0-9xX]$/) && !ni.match(/^[0-9]{14}[0-9xX]$/)) {
        return "身份证号码中有不能识别的字符";
    }
    if (!identityCodeValid(ni)) {
        return "身份证信息错误";
    }
    return "";
}

function checkPP(pp) {
    if ( !pp || pp.length <= 0) {
        return "请输入证件号码";
    }
    if (pp.length < 5 || pp.length > 17) {
        return "证件号码填写有误，请重新填写";
    }
    return "";
}

function checkTB(tb) {
    if (!tb || tb.length <= 0) {
        return "请输入证件号码";
    }
    if (tb.length != 8 && tb.length != 10) {
        return "台胞证只能为8位或10位数字";
    }
    return "";
}

function checkGA(ga) {
    if (!ga || ga.length <= 0) {
        return "请输入证件号码";
    }
    if (ga.charAt(0) != 'H' && ga.charAt(0) != 'M') {
        return "港澳通行证以大写字母“H”或“M”开头";
    }
    if ((ga.length != 11 && ga.length != 9) || (!ga.match(/[HM][0-9]{10}/) && !ga.match(/[HM][0-9]{8}/))) {
        return "港澳通行证为1位英文字母+8位或10位数字";
    }
    return "";
}

var city = {
    11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",
    23:"黑龙江 ",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",
    41:"河南",42:"湖北 ",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",
    53:"云南",54:"西藏 ",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外 "};

function identityCodeValid(code) { 

    var tip = "";
    var pass= true;
            
    if(!code || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(code)){
        tip = "身份证号格式错误";
        pass = false;
    } else if(!city[code.substr(0,2)]){
        tip = "地址编码错误";
        pass = false;
    } else{
        //18位身份证需要验证最后一位校验位
        if(code.length == 18){
            code = code.split('');
            //∑(ai×Wi)(mod 11)
            //加权因子
            var factor = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 ];
            //校验位
            var parity = [ 1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2 ];
            var sum = 0;
            var ai = 0;
            var wi = 0;
            for (var i = 0; i < 17; i++){
                ai = code[i];
                wi = factor[i];
                sum += ai * wi;
            }
            if(parity[sum % 11] != code[17]){
                tip = "校验位错误";
                pass =false;
            }
        }
    }
    return pass;
}

module.exports = {
    checkName: checkName,
    checkNI:checkNI,
    checkPP:checkPP,
    checkTB:checkTB,
    checkGA:checkGA
}