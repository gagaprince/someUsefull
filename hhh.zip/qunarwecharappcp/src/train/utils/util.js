var CommonUtils = require('../../common/utils.js');

function isEmptyString(property) {
    return !property || property.length === 0;
}

function isEmptyArray(array) {
    return !array || array.length === 0;
}

function isEmptyObject(obj) {
    for (var key in obj) {
        return !key;
    }
    return true;
}

function isValidPhone(phoneNumber) {
    return phoneNumber.length == 11 && phoneNumber.charAt(0) == "1";
}

function stringifyURLParam(param) {
    var rstString = "";
    for(var key in param) {
        rstString += (key + '=' + JSON.stringify(param[key]) + '&')
    }
    rstString = rstString.substr(0, rstString.length - 1);
    return rstString;
}

function parseURLParam(param) {
    console.log('param', param);
    var rst = {};
    for(var key in param) {
        rst[key] = JSON.parse(param[key]);
    }
    return rst;
}

function shareToTrainHome() {
    var navigateToUrl = '/common/pages/search/index?from=home&bizType=train';
    return CommonUtils.share.getParam({
        title: '预订火车票 - 去哪儿旅行',
        url: navigateToUrl
    });
}

module.exports = {
    isEmptyObject: isEmptyObject,
    isEmptyArray: isEmptyArray,
    isEmptyString: isEmptyString,
    isValidPhone:isValidPhone,
    stringifyURLParam: stringifyURLParam,
    parseURLParam: parseURLParam,
    shareToTrainHome: shareToTrainHome
}
