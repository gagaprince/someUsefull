const requester = require('./requester.js');

const doCacheImages = global.doCacheImages = () => {
    let cacheImageList = global.__cacheImageList || [];

    setTimeout(() => {
        cacheImageList.forEach((img) => {
            requester.request({
                host: global.server,
                service: '/source' + img + '.cur',
                header: {
                    'content-type': 'text/plain'
                },
                dataType: 'text',
                success: (res) => {
                    if (res.statusCode == 200 && res.data.indexOf('data:img') === 0) {
                        try {
                            wx.setStorageSync(`cache-${img}`, res.data);
                        } catch (e) {}
                    }
                }
            })
        });
        try {
            var res = wx.getStorageInfoSync()
            res.keys.forEach((key) => {
                if (key.indexOf('cache-') === 0 && cacheImageList.indexOf(key.substring(6)) === -1) {
                    wx.removeStorageSync(key);
                }
            })
        } catch (e) {}
    }, 1000);
};
