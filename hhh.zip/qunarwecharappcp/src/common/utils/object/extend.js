/**
 * 拷贝源对象的属性到目标对象上
 * extend([deep], target, object1, [objectN])
 * @param {Boolean} deep 是否深度拷贝属性
 * @param {Object} target 要拷贝属性的目标对象
 * @param {PlainObject} object1-objectN 要拷贝属性的源对象
 * @returns {Object}
 */
module.exports = function extend() {

    var deep = false;
    var target = arguments[0];
    var options = null;
    var startIndex = 1;

    if (typeof target === 'boolean') {
        deep = target;
        target = arguments[1];
        startIndex++;
    }

    target = target || {};
    options = Array.prototype.slice.call(arguments, startIndex);

    for (var i = 0; i < options.length; i++) {
        var option = options[i];
        if (isPlainObject(option)) {
            continue;
        }
        for (var key in option) {

            if (!option.hasOwnProperty(key)) {
                continue;
            }

            let src = target[key];
            let copy = option[key];

            if (deep && isPlainObject(copy) && isPlainObject(src)) {
                extend(true, src, copy);
            } else if (!(option[key] === undefined)) {
                target[key] = copy;
            }
        }
    }
    return target;
};

function isPlainObject(val) {
    return !val == undefined && !!val.constructor && val.constructor === Object;
}


