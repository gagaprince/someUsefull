var watcher = require("../../watcher.js")
var user = require("../../user.js")
var config = require("../../config.js")
var toast = require("../../comps/toast/toast.js")

Page({
    data:{
        noPayOrders: 0,
        islogin: false,
        userdata: {},
        userInfo: {
            userimg: '',
            username: ''
        },
        toast: {
            extendClass: "hide",
            content: ""
        }
    },
    ignores: /(^iPhone 6s Plus(<iPhone8,2>)$)|(^iPhone 7 Plus(<iPhone9,2>)$)|(^iPhone 7(<iPhone9,1>)$)/gi,
    ignore: false,
    onLoad:function(options){
        // 页面初始化 options为页面跳转所带来的参数
        var self = this;
        wx.getSystemInfo({
            success: function(res) {
                console.log(res.model)
                if (res && res.model) {
                    self.ignores.test(res.model) 
                    ? (self.ignore = true)
                    : false;
                }
            }
        })
    },
    onShow: function () {
        this.loadData()
        wx.removeStorageSync('my_page_order_filter')   //订单过滤条件置为空，=默认值
        watcher.pv({ "page": "my"});
    },
    onReady:function(){
        //this.loadData()
        //watcher.pv({ "page": "my"});  放在onShow
    },
    sendWatcher: function(actionType){
        watcher.click({
            "page": "my",
            "action-type": actionType
        })
    },
    // 点击登陆
    tologin: function() {
        var self = this
        if(self._submitLoginFlag){
            return
        }
        self._submitLoginFlag = true
        user.showQunarUserLogin({
            success:function(res){
                self.loadData();//登录失败或登录成功都需要获取数据
            },
            fail: function(res){
                if(!res.ret && res.data && res.data.wx_getUserInfo_deny) {
                    //微信授权——拒绝
                    wx.showModal({
                        title: '温馨提示',
                        content:"授权失败，请十分钟后允许授权再登录",
                        showCancel:false,
                        confirmText:"知道了"
                    })
                    self.sendWatcher("wx_getUserInfo_auth_deny")
                }
                if(res.data && res.data.wx_getUserInfo_deny){
                    self.sendWatcher("wx_getUserInfo_deny")
                }
            },
            complete:function(){
                self._submitLoginFlag = false
            }
        });
        this.sendWatcher("myLogin");
    },
    // 退出登录
    logout:function(){
        var self = this;
        wx.showModal({
            title: '确认退出登录？',
            //content: '确认退出登录？',
            success: function(res) {
                if(res.confirm){
                    user.logout(function(res){
                        if(res.ret){
                            self.loadData();
                            self.sendWatcher("logout_success");
                        } else {
                            self.sendWatcher("logout_fail");
                        }
                    })
                    self.sendWatcher("logout_click_confirm");
                } else {
                    self.sendWatcher("logout_click_cancel");
                }
            }
        })
        self.sendWatcher("logout_click");
    },
    loadData:function(){
        var self = this
        user.getUserInfo(function(res){
            var qunar = res.data && res.data.qunar;
            var wechat = res.data && res.data.wechat;
            var exParams = res.data && res.data.exParams;
            if(res.ret && wechat.isQunarUser){
                self.setData({ islogin: true, userData: qunar });
            } else {
                 self.setData({ islogin: false });
            }
            self.setData({ qunar: qunar, exParams: exParams });
            self.getUserInfo(qunar);   //未登录也需要调用
        });
    },
    // 获取用户信息
    getUserInfo: function(data) {
        var self = this;
        wx.request({
            url: config.settings.requestDomain + config.service.getUserInfo,
            method:"POST",
            data: data,
            header: {
                'content-type': 'application/x-www-form-urlencoded'
            },
            success: function(res){
                var data = (res && res.data && res.data.data) || {};
                self.updateUser(data);
            },
            fail: function() {
            },
            complete: function() {
            }
        });
    },
    updateUser: function(data) {
        var nickName = (data.user && data.user.nickname) || ""
        var headUrl = (data.user && data.user.headUrl) || ""
        if (!nickName || !headUrl) {
            this.setData({
                islogin: false,
                noPayOrders: data.unpayCount
            });
            return;
        }
        this.setData({userInfo: {
            userimg: headUrl,
            username: nickName
        },noPayOrders: data.unpayCount});
    },
    tolinkman: function() {
        var self = this;
        if (self.ignore) {
            wx.makePhoneCall({
                phoneNumber: '10101234'
            });
            return;
        }
        wx.showModal({
            title: '请拨打客服电话',
            content: '10101234',
            confirmText: '呼叫',
            confirmColor: '#11b4ca',
            cancelColor: '#11b4ca',
            success: function(res) {
                if (res.confirm) {
                    wx.makePhoneCall({
                        phoneNumber: '10101234'
                    });
                }
            }
        });
        this.sendWatcher("myLinkman");
    },
    // 订单，过滤
    toOrder: function(e) {
        var filter = e.currentTarget.dataset && e.currentTarget.dataset.filter;
        var all = e.currentTarget.dataset && e.currentTarget.dataset.all;
        var actionType = all && (all === 'all') ? 'all' : filter;
        if (!filter) {
            return;
        }
        wx.setStorageSync('my_page_order_filter', filter)
        wx.switchTab({
           url: '../../pages/order/order'   //switchTab传不了url参数
        });
        this.sendWatcher("myOrders_"+actionType);
    }
})