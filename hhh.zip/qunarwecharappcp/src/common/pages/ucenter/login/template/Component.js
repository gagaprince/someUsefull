//Component
function Component(options){
    options = options || {}
    var obj = {}
    for(var attr in options){
        obj[attr] = options[attr]
    }
    obj.data = options.data || {}
    obj.setData = setData
    obj.on = on
    return obj
}
function setData(updateData){
     var updateDataWithPath = {}
     for(var attr in updateData){
         //增加路径，只更新部分数据；不用全更新
         updateDataWithPath[this.dataContainer + "." + attr ] = updateData[attr]
         this.data[attr] =  updateData[attr]
     }
     this.page.setData(updateDataWithPath)
}

function on (eventName, func){
    if(!this.page || !func){
        return
    }
    eventName = (this.dataContainer + "_" + eventName)
    if(this.page[eventName]){
        console.warn("出现事件覆盖: " + eventName)
        return
    }
    var me = this
    this.page[eventName] = function(){
        return func.apply(me, arguments)
    }
}
module.exports = Component
