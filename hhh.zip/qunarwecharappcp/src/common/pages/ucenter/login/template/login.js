var config = require('../../../../config.js');
var user = require('../../../../user.js');
var watcher = require("../../../../watcher.js")
var toast = require('../../../../comps/toast/toast.js');
var Component = require('./Component.js');

var app = getApp()
var login = Component({
    name:"login",
    dataContainer:"user_login",
    data: {
        title: "短信验证码登录",
        subTitle: "如手机号未注册，验证后将自动注册",
        clearUrl: "../../../images/common/clear.png",
        //toast自定义
        toast: {
            extendClass: "hide",
            content: ""
        },
        mobilePlaceholder: "请输入手机号",
        clearIconClass: "",
        smsBtnText: "免费获取",
        canSendSmsFlag: true,
        wait: 60,
        smsBtnClass: "",
        loginBtnClass: "",
        mobile: "",
        loginCode: "",
        showWay: "" // popup 或者 page
    },
    onShow:function(){
        this.on("sendSMSCode",this.sendSMSCode)
        this.on("bindMobileInput",this.bindMobileInput)
        this.on("clearInput",this.clearInput)
        this.on("saveSmsCode",this.saveSmsCode)
        this.on("checkLogin",this.checkLogin)
        this.on("closeLogin",this.closeLogin)
        this.on("hideClear",this.hideClear)
        this.on("controlClear",this.controlClear)
    },
    onReady: function(page, options) {
        this.page = page
        if(options.showWay == "popup"){
            this.page.login = this
        } else {
            this.show(page, options)
        }
    },
    show: function(page, options) {
        options = options || {}
        this.page = page
        this.data.showWay = options.showWay || "popup"
        this.onShow(page)
        this.setData( { mobile:"", loginCode:"" } )    //初始化手机、验证码为空

        this.loginId = options.loginId || page.loginId //登录ID
        var that = this
        user.getUserInfo(function(res) {
            var userInfo = res && res.data
            var exParams =  userInfo && userInfo.exParams
            that.exParams = exParams || {}   //后续需要使用

            that.setData(that.data)
            if(options.showWay == "popup"){
                setTimeout(function(){
                    that.setData({animate: "on" })
                },0)
            }
        })
        watcher.pv({ "page": "login"});
    },
    sendWatcher: function(actionType){
        watcher.click({
            "page": "login",
            "action-type": actionType
        })
    },
    closeLogin: function() {
        this.setData({animate: "off" })
        this.loginCallback("cancel", {ret: false, errMsg: "您手动关闭了登录页面"})
    },
    bindMobileInput: function(e) {
        this.controlClear(e)
        return this.bindReplaceInput(e)
    },
    hideClear: function(e) {
        this.setData({clearIconClass: ""})
    },
    //控制后面叉图标的显示和隐藏
    controlClear: function(e) {
        var value = e.detail.value
        if(value !== "") {
            this.setData({clearIconClass: "show"})
        } else {
            this.setData({clearIconClass: ""})
        }
    },
    //输入够11位，开启分割
    bindReplaceInput: function(e) {
        var value = e.detail.value
        var noFormatVal = value && value.replace(/\s*/g,'')
        var res = noFormatVal
        if(/^\d{11}$/.test(noFormatVal)) {
            res = noFormatVal.replace(/^(\d{3})(\d{4})(\d{4})$/,'$1 $2 $3')
        }else if(/^\d{12,13}$/.test(noFormatVal)) {
            // 位数输入多 修复bug
            res = noFormatVal.replace(/^(\d{3})(\d{4})(\d{4})(\d{1,2})$/,'$1 $2 $3')
        }
        this.setMobile(res)
        this.setSubmitBtn()
    },
    setMobile: function(val) {
        if(/^(\d{3})\s(\d{4})\s(\d{4})$/.test(val)) {
            this.setData({mobile: val})
        } else {
            this.data.mobile = val
        }
    },
    getMobile: function() {
        return this.data.mobile.replace(/\s*/g, "")
    },
    //存储手机验证码
    saveSmsCode: function(e) {
        var self = this
        setTimeout(function(){
            self.setData({ loginCode:e.detail.value })
        }, 0)
        this.setSubmitBtn()
    },
    setSubmitBtn: function() {
        if(this.getMobile() != "" && this.data.loginCode != "") {
            this.data.loginBtnClass = "lighter"
            this.setData({
                loginBtnClass: "lighter"
            })
        } else {
            this.setData({
                loginBtnClass: ""
            })
        }
    },
    //点击清除手机号码行为，激活placeholder,mobile置为空（有bug）
    clearInput: function(e) {
        this.setData({
            mobile: ""
        })
        var temp = {detail: {value: this.getMobile()}}
        this.controlClear(temp)
        this.sendWatcher("clearMobileBtn")
    },
    sendSMSCode: function(e) {
        var that = this
        if(!that.data.canSendSmsFlag) {
            that.showToast("正在获取，请稍候")
        } else {
            this.sendSMSCodeValidate(function(res) {
                if(res.valid) {
                    //获取短信验证码
                    user.sendSMSCode({
                        mobile: that.getMobile()
                    }, function(res) {
                        //发送验证码回调,成功
                        if(!res.ret) {
                            that.data.canSendSmsFlag = true;
                            that.showToast(res.errmsg || "发送失败，请稍后重试")
                            return;
                        }
                        that.data.isSmsSended = true
                        that.changeBtn()
                    }, function(msg) {
                        //失败的处理
                        that.showToast(msg)
                        that.setData({
                            canSendSmsFlag: true,
                            loginCode: ""
                        })
                    })
                    that.data.canSendSmsFlag = false;
                } else {
                    that.showToast(res.errMsg)
                    that.data.canSendSmsFlag = true;
                }
            })
        }
        that.sendWatcher("sendSMS_btn")
    },
    //倒计时60秒，控制按钮样式
    changeBtn: function() {
        var that = this
        //this.timer = setTimeout(function () {
            if (that.data.wait == 1) {
                that.enableBtn()
                console.log("倒计时结束")
            } else {
                that.data.wait--
                that.setData({
                    smsBtnText: that.data.wait + "s后重发",
                    smsBtnClass: "gray"
                })
                that.countdownTimer = setTimeout(function () {
                    that.changeBtn();
                }, 1000);
            }
        //}, 1000);
    },
    enableBtn: function() {
        //clearTimeout(this.timer);
        clearTimeout(this.countdownTimer);
        this.setData({
            wait: 60,
            smsBtnText: "免费获取",
            smsBtnClass: "",
            canSendSmsFlag: true
        })
    },
    checkLogin: function(e) {
        var that = this
        this.loginValidate(function(validateRes) {
            if(validateRes.valid) {
                that.login()
            } else {
                that.showToast(validateRes.errMsg)
                that.setData({ loginCode: "" })
            }
        })
        that.sendWatcher("login_btn")
    },
    loginCallback: function(action, res) {
        var that = this
        //回调
        if(action == "success") {
            res = res || {ret: true, errMsg: action}
            setTimeout(function() {
                if(that.data.showWay == "page") {
                    wx.navigateBack()
                } else {
                    //popup??
                    that.setData({animate: "off" })
                }
                app._qunarUserLoginComplete && app._qunarUserLoginComplete(that.loginId, res)
            }, 1000)
        } else if(action == "cancel") {
            res = res || { ret: false, errMsg: action }
            app._qunarUserLoginComplete && app._qunarUserLoginComplete(that.loginId, res)
        }
    },
    //qunar登录
    login: function() {
        var that = this
        var loginData = {
            mobile: that.getMobile(),
            logincode: that.data.loginCode
        }
        // that.wechatSingle = qunar.wechatSingle     //wechatSingle:true 表示没有跟大公众号做过关联绑定
        user.qunarLoginAndReigster(loginData, function(res) {
            //登录回调处理
            //21027
            if(!res.ret){
                that.showToast(res.errmsg || "登录失败，请重试")
                //验证码错误，清空验证码
                if(res.errcode == 21023 || res.errcode == 21027 || res.errcode == 11005){
                    that.setData({ loginCode: "" })
                    that.enableBtn()
                }
            }else {
                if(res && res.data && res.data.isReg) {
                    that.showToast("注册成功，您可以使用该手机号在去哪儿网登录")
                } else {
                    that.showToast("登录成功")
                }
                that.enableBtn()
                that.loginCallback("success", res)
            }

        }, function(msg) {
            that.showToast(msg)
        })
    },
    sendSMSCodeValidate: function(callback) {
        var res = {}
        if(this.validateMobile(this.getMobile())) {
            res.valid = true
        } else {
            res.valid = false
            res.errMsg = "请输入正确的手机号码"
        }
        callback && callback(res)
        return res.valid
    },
    loginValidate: function(callback) {
        var res = {}
        if(!this.data.isSmsSended) {
            res.valid = false
            res.errMsg = "请先获取短信验证码"
        } else if(!this.validateMobile(this.getMobile())) {
            res.valid = false
            res.errMsg = "请输入正确的手机号码"
        } else if(!this.validateSmsCode(this.data.loginCode)){
            res.valid = false
            res.errMsg = "请输入正确的验证码"
        } else {
            res.valid = true
        }
        callback && callback(res)
        return res.valid
    },
    validateMobile: function(mobile) {
        return /^1[0-9]{10}$/.test(mobile)
    },
    validateSmsCode: function(smsCode) {
        return /^\d{6}$/.test(smsCode)
    },
    showToast: function(msg) {
        toast.show(this, "toast", msg)
    },
    getUrl: function(apiName) {
        return config.settings.requestDomain + config.service[apiName]
    }
})

module.exports = login
