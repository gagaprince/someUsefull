
var login = require('./template/login.js');
Page({
    data: {
        templateName: "login" //login_activity
    },
    onLoad: function(params) {
        this.loginId = params.loginId
        this.rules = JSON.parse(decodeURIComponent(params.rules))

        var templateName = params.templateName || "login"
        this.setData({templateName: templateName })
    },
    onReady: function() {
        login.onReady(this, { showWay:"page" })
        login.setData({rules: this.rules})
    },
    onShow: function() {

    },
    onUnload: function() {
        //在login组件里重写了onUnload
        login.loginCallback("cancel", {ret: false, errMsg: "您已退出登录页面"})
    }
})
