//calendar.js '../calendar/calendar?date='
var dateFormat = require('../../utils/date/format.js');
var dateMath = require('../../utils/date/math.js');
var EventEmitter = require('../../EventEmitter.js');
var requester = require('../../requester.js');
var extend = require('../../utils/object/extend.js');
var Toast = require('../../comps/network/network.js');
var holidays = require('./calendarData.js');

const ONE_DAY = 86400000;
const FORMAT_TYPE = 'yyyy-mm-dd';
const CNY_SYMBOL = '￥';
const TRAIN_BOOKING_TEXT = '预约';
const TRAIN_MULTI_SELECT_MAIN_TEXT = '主选';
const TRAIN_MULTI_SELECT_SUB_TEXT = '备选';

Page({
    today: null,
    finalDay: null,
    isFirst: false, // 是否是重新渲染的第一天，只有门票需要重新渲染
    data: {
        calendarArray: null,
        toViewId: '',
        firstSelected: '',
        secondSelected: '',
        isActiveDoubleSelected: true
    },
    monthDateFormat: 'yyyy年mm月',
    monthIdFormat: 'yyyy-mm',
    onLoad: function (params) {
        var self = this;
        var data = JSON.parse(params.data) || {};
        params = Object.assign(params, data);
        Reflect.deleteProperty(params, 'data');

        if (params.sText && params.eText) {
            self.setData({
                sText: params.sText,
                eText: params.eText
            });
        }
        if (params.isMultiSelect) {
            var data = {
                isMultiSelect: params.isMultiSelect
            };
            if (params.maxSelectDays && params.maxSelectDays > 0) {
                data.maxSelectDays = params.maxSelectDays;
            }
            self.setData(data);
        }
        self.setData({
            params: params
        });
        self._initCalendar(params.calendarDays);
        self.getHolidayData();
        self.updateMultiInfo();
    },

    onReady: function () {
        this.toViewId();
    },

    toViewId: function () {
        var self = this;
        var params = self.data.params;
        if (params && params.date) {
            var date = new Date(params.date);
            self.setData({
                toViewId: 'cal_' + dateFormat(date, self.monthIdFormat)
            });
        }
    },

    getHolidayData: function (notFirst) {
        var self = this;
        var holidayData = wx.getStorageSync('CALENDAR_HOLIDAY_DATA');
        if (!holidayData) {
            self.holidayData = holidays;
            try {
                wx.setStorageSync('CALENDAR_HOLIDAY_DATA', JSON.stringify(res.data));
            } catch (e) {}
            // 后续有节假日接口再开放
            // self.requestHolidayData(function () {
            //     self.requestData();
            // });
        } else {
            self.holidayData = JSON.parse(holidayData);
        }
        self.updateInfo(function (item, i) {
            self.updateHolidays(item, i);
        });
        if (!notFirst) {
            self.requestData();
        }
    },

    requestHolidayData: function (callback) {
        var self = this;
        requester.request({
            service: '/flight/queryHolidayData',
            success: function (res) {
                res = res.data;
                if (res.code !== 0) {
                    return;
                }
                self.holidayData = res.data;
                callback && callback();
                try {
                    wx.setStorageSync('CALENDAR_HOLIDAY_DATA', JSON.stringify(res.data));
                } catch (e) {}
            }
        });
    },

    updateHolidays: function (item, i) {
        var self = this;
        var holidayData = self.holidayData;
        var holiday = holidayData.holiday;
        var tiaoxiu = holidayData.work;
        var vacation = holidayData.vacation;
        if (holiday[i]) {
            item.holiday = holiday[i];
        }
        if (tiaoxiu[i]) {
            item.work = true;
        }
        if (vacation[i]) {
            item.vacation = true;
        }
    },

    updateMultiInfo: function () {
        var self = this;
        var dataParams = self.data.params;
        if (dataParams.isMultiSelect) {
            self.setData({
                multiSelectDateArr: dataParams.dates.map((item) => new Date(item))
            });
            var dates = dataParams.dates;
            var mainDate = dataParams.date;
            self.updateInfo(function (item, i) {
                if (mainDate == i) {
                    item.text = TRAIN_MULTI_SELECT_MAIN_TEXT;
                    item.isHighLight = true;
                }
                dates.forEach((date) => {
                    if (date == i) {
                        item.isMultiSelect = true;
                        item.text = TRAIN_MULTI_SELECT_SUB_TEXT;
                        item.isHighLight = true;
                    }
                });
            });
        }
    },

    updateInfo: function (callback) {
        var self = this;
        var calendarData = self.data.calendarArray;
        calendarData.forEach(function (monthData) {
            var rows = monthData.daysArray;
            rows.forEach(function (columns) {
                for (var i = 0, len = columns.length; i < len; i++) {
                    if (columns[i].isBlank) {
                        continue;
                    }
                    var d = dateFormat(columns[i].date, FORMAT_TYPE);
                    callback && callback(columns[i], d);
                }
            });
        });

        self.setData({
            calendarArray: calendarData
        });
    },

    requestData: function () {
        var self = this;
        var dataParams = self.data.params;
        if (!dataParams.url || !dataParams.reqData) {
            return;
        }
        requester.request({
            service: decodeURIComponent(dataParams.url),
            param: dataParams.reqData,
            success: self.handleRequestDataSuccess.bind(self),
            fail: self.handleRequestDataFail.bind(self)
        });
    },
    handleRequestDataSuccess: function (res) {
        var self = this;
        var dataParams = self.data.params;
        var bizType = dataParams.bizType;
        var data = {};
        if (res.statusCode === 200 && bizType === 'train') {
            data = self.dealTrain(res);
        } else if (res.data.code == 0 && bizType === 'flight') {
            data = self.dealFlight(res);
        } else if (res.statusCode == 200 && bizType === 'ticket') {
            // 其他按规定字段来的业务线，比如门票
            data = self.dealDefault(res);
        } else {
            self.handleRequestDataFail();
            return;
        }

        self.updateInfo(function (item, i) {
            if (data[i]) {
                if (self.isFirst) {
                    self.setData({
                        firstSelected: i
                    });
                    self.isFirst = false;
                }
                var text = data[i].text || '';
                var isHighLight = data[i].isHighLight || false;
                item.text = text;
                item.tempText = text;
                item.isHighLight = isHighLight;
                item.tempIsHighLight = isHighLight;
                item.resdata = JSON.stringify(data[i]);
                item.isPreThanToday = false;
                item.isLastThanFinal = false;
            }
        });
        self.updateMultiInfo();
        self.toViewId();
    },
    dealDefault: function (res) {
        var self = this;
        var data = res.data.data;
        var date = this.data.params.date;
        if (!data[date]) {
            self.isFirst = true;
        }
        self.updateInfo(function (item, i) {
            if (!data[i]) {
                item.isDisabled = true;
            }
        });
        return data;
    },
    dealFlight: function (res) {
        var res = res.data;
        var data = res.priceTrendDataMap.goFTrend;
        for (var prop in data) {
            var item = data[prop];
            item['text'] = CNY_SYMBOL + item.price;
            item['isHighLight'] = item.isLowPrice === 1 ? true : false;
        }
        return data;
    },
    dealTrain: function (res) {
        var self = this;
        var data = {};
        if (res.data.pre12306 && res.data.pre12306 > 0) {
            var pre12306 = res.data.pre12306;
            var preQunar = res.data.preQunar;
            var totalDays = pre12306 + preQunar;
            var day = new Date();
            for (var i = 1; i <= totalDays; i++) {
                var key = dateFormat(day, FORMAT_TYPE);
                data[key] = data[key] || {};
                if (i > preQunar && i <= totalDays) {
                    // data[key] = {
                    //     text: TRAIN_BOOKING_TEXT,
                    //     isHighLight: true
                    // };
                    data[key].text = TRAIN_BOOKING_TEXT;
                    data[key].isHighLight = true;
                } else {
                    data[key].isDisabled = false;
                }
                day = new Date(day.getTime() + ONE_DAY);
            }
            self._initCalendar(totalDays - 1);
            self.getHolidayData(true);
        }
        return data;
    },
    handleRequestDataFail: function () {
        var self = this;
        var dataParams = self.data.params;
        var bizType = dataParams.bizType;
        if (bizType === 'ticket') {
            Toast.showNetwork.call(this, {
                status: -3,
                loadingDesc: `获取数据失败`
            });
            setTimeout(function () {
                wx.navigateBack();
            }, 2000);
        }
    },
    _initCalendar: function (calendarDays) {
        var dataParams = this.data.params;
        var isDoubleSelect = dataParams.isDoubleSelect;
        // 选中的日期
        var firstSelected = dataParams.date || dateFormat(new Date(), FORMAT_TYPE);
        if (isDoubleSelect) {
            var secondSelected = dataParams.eDate || dateFormat(new Date(new Date(dataParams.date).getTime() + ONE_DAY), FORMAT_TYPE);
        }

        // 如果开始日期大于结束日期，调换。
        if (new Date(firstSelected).getTime() > new Date(secondSelected).getTime()) {
            var temp = firstSelected;
            firstSelected = secondSelected;
            secondSelected = temp;
        }
        this.today = new Date();
        // 预售期
        calendarDays = calendarDays || 365;
        // 计算预售期最后一天
        this.finalDay = dateMath.addDays(this.today, calendarDays);
        // 计算现在的月份
        var thisMonth = this.today.getMonth();
        var thisYear = this.today.getYear();
        // 计算最后的月份
        var finalMonth = this.finalDay.getMonth();
        var finalYear = this.finalDay.getYear();
        if (finalMonth <= thisMonth && finalYear > thisYear) {
            finalMonth += (finalYear - thisYear) * 12;
        }
        // 计算总共的月份
        var months = finalMonth - thisMonth + 1;
        // 每个月的索引日期
        var monthDate = this.today;
        var monthArray = [];

        for (var i = 0; i < months; i++) {
            var idMonth = dateFormat(monthDate, this.monthIdFormat);
            var tDate = dateFormat(monthDate, this.monthDateFormat);
            // 获取本月第一天
            var firstDay = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
            // 计算本月有多少天
            var days = dateMath.daysCountOfMonth(monthDate.getFullYear(), monthDate.getMonth());
            // 计算第一天是周几
            var firstWeek = firstDay.getDay();
            // 计算本页在日历中有多少行
            var rows = dateMath.weeksCountOfMonth(monthDate.getFullYear(), monthDate.getMonth());
            // 获取本月最后一天
            var lastDay = new Date(monthDate.getFullYear(), monthDate.getMonth(), days);
            // 计算最后一天是周几
            var lastWeek = lastDay.getDay();

            // 计算第一行增加几个空白天数
            var firstNum = firstWeek;
            // 计算最后一行增加几个空白天数
            var lastNum = 7 - lastWeek - 1;

            // 列数组
            var rowArray = [];
            for (var row = 0; row < rows; row++) {
                // 行数组
                var columnArray = [];
                var markDate;
                for (var column = 0; column < 7; column++) {
                    var item;
                    if (row == 0) {
                        if (column < firstNum) {
                            // 第一行的空元素
                            item = {
                                isBlank: true
                            };
                            columnArray.push(item);
                            continue;
                        } else {
                            // 第一天
                            if (column == firstNum) {
                                markDate = firstDay;
                            } else {
                                markDate = dateMath.addDays(markDate, 1);
                            }
                        }
                    } else if (row == rows - 1) {
                        if (column >= 7 - lastNum) {
                            // 最后一行的空元素
                            item = {
                                isBlank: true
                            };
                            columnArray.push(item);
                            continue;
                        } else {
                            markDate = dateMath.addDays(markDate, 1);
                        }
                    } else {
                        markDate = dateMath.addDays(markDate, 1);
                    }
                    item = {
                        isCheck: new Date(markDate.toDateString()).getTime() == new Date(new Date(firstSelected).toDateString()).getTime(),
                        isBlank: false,
                        date: markDate,
                        formatDate: dateFormat(markDate, FORMAT_TYPE),
                        showDate: markDate.getFullYear() == this.today.getFullYear() && markDate.getMonth() == this.today.getMonth() && markDate.getDate() == this.today.getDate() ? "今天" : markDate.getDate(),
                        isWeekend: column == 0 || column == 6,
                        isPreThanToday: new Date(markDate.toDateString()).getTime() < new Date(this.today.toDateString()).getTime(),
                        isLastThanFinal: new Date(markDate.toDateString()).getTime() > new Date(this.finalDay.toDateString()).getTime()
                    };

                    item.firstSelected = new Date(markDate.toDateString()).getTime() == new Date(new Date(firstSelected).toDateString()).getTime();
                    if (item.firstSelected) {
                        this.updateSelectDate(firstSelected);
                    }

                    if (isDoubleSelect) {
                        item.secondSelected = new Date(markDate.toDateString()).getTime() == new Date(new Date(secondSelected).toDateString()).getTime();
                        if (item.secondSelected) {
                            this.updateSelectDate(secondSelected, true);
                        }
                    }
                    columnArray.push(item);
                }
                monthDate = dateMath.addDays(markDate, 1);
                rowArray.push(columnArray);
            }

            var aMonth = {
                date: tDate,
                idMonth: idMonth,
                daysArray: rowArray
            };
            monthArray.push(aMonth);
        }
        this.setData({
            calendarArray: monthArray
        });
    },
    updateSelectDate: function (date, isSecond = false) {
        let data = {};
        let field = 'firstSelected';
        if (isSecond) {
            field = 'secondSelected';
        }
        data[field] = date;
        this.setData(data);
    },
    dateSelected: function (e) {
        var dataParams = this.data.params;
        var dataset = e.currentTarget.dataset;
        var isDoubleSelect = dataParams.isDoubleSelect;
        var isMultiSelect = dataParams.isMultiSelect;
        var isDisabled = dataset.disabled;

        if (isDisabled) {
            return;
        }
        if (isDoubleSelect) {
            // 双选的情况
            this.dateSelectDouble(dataset);
        } else if (isMultiSelect) {
            this.dateSelectMulti(dataset);
        } else {
            // 单选的情况
            this.dateSelectDefault(dataset);
        }
    },
    dateSelectDefault: function (dataset) {
        var dataParams = this.data.params;
        var eventType = dataParams.eventType;
        var storageType = dataParams.storageType;

        var date = new Date(dataset.date);
        var resdata = dataset.resdata;

        this.updateSelectDate(dateFormat(date, FORMAT_TYPE));
        this.dateSelectedFinish({ eventType, storageType, resdata, showToast: false});
    },
    dateSelectDouble: function (dataset) {
        var dataParams = this.data.params;
        var eventType = dataParams.eventType;
        var storageType = dataParams.storageType;
        var firstSelected = this.data.firstSelected;
        var secondSelected = this.data.secondSelected;
        var date = new Date(dataset.date);

        var isActived = this.data.isActiveDoubleSelected;
        // 当前入店日期
        var curFirst = this.getDateFormString(firstSelected).getTime();
        // 当前离店日期
        var curSecond = this.getDateFormString(secondSelected).getTime();
        // 选中日期
        var selectedDate = date.getTime();
        // 如果选中日期大于当前选中endDate，那么就应该 选中的日期为新的startDate，选中的日期的后一天为新的endDate，此时不满足条件，不能active
        if (selectedDate > curSecond) {
            if (isActived) {
                var newDate = new Date(selectedDate + ONE_DAY);
                this.dateSelectedNotFinish();
                this.updateSelectDate(dateFormat(date, FORMAT_TYPE));
                this.updateSelectDate(dateFormat(newDate, FORMAT_TYPE), true);
            } else {
                this.updateSelectDate(dateFormat(date, FORMAT_TYPE), true);
                this.dateSelectedFinish({ eventType, storageType });
            }
        } else if (selectedDate === curSecond || selectedDate === curFirst) {
            if (isActived) {
                var newDate = new Date(selectedDate + ONE_DAY);
                this.dateSelectedNotFinish();
                this.updateSelectDate(dateFormat(date, FORMAT_TYPE));
                this.updateSelectDate(dateFormat(newDate, FORMAT_TYPE), true);
            } else {
                this.dateSelectedFinish({ eventType, storageType });
            }
        } else if (selectedDate > curFirst) {
            // 如果选中的日期大于当前选中的startDate，那么更新第二个日期，这个时候符合条件，应该active
            this.updateSelectDate(dateFormat(date, FORMAT_TYPE), true);
            this.dateSelectedFinish({ eventType, storageType });
        } else if (selectedDate < curFirst) {
            // 如果选中的日期小于当前选中的startDate，那么更新第二个日期，这个时候符合条件，应该active
            this.dateSelectedNotFinish();
            this.updateSelectDate(dateFormat(date, FORMAT_TYPE));
        }
    },
    dateSelectMulti: function (dataset) {
        var dataParams = this.data.params;
        var maxSelectDays = dataParams.maxSelectDays;
        var date = new Date(dataset.date);

        var isRepeat = false;

        var isMainSelect = dataParams.date === dateFormat(date, FORMAT_TYPE); // 如果是主选择，不能改变状态。
        if (isMainSelect) {
            return;
        }

        var multiSelectDateArr = this.data.multiSelectDateArr;

        // 如果选中的为已选中的，则在已选中列表内删除该元素
        for (var i = 0, len = multiSelectDateArr.length; i < len; i ++) {
            var item = dateFormat(multiSelectDateArr[i], FORMAT_TYPE);
            var tempDate = dateFormat(date, FORMAT_TYPE);
            if (item == tempDate) {
                multiSelectDateArr.splice(i, 1);
                isRepeat = true;
                break;
            }
        }

        // 如果选中的元素超过maxSelectDays，则给出提示。
        if (multiSelectDateArr.length >= maxSelectDays) {
            Toast.showNetwork.call(this, {
                status: -3,
                loadingDesc: `最多可选择${maxSelectDays}个日期`
            });
            return;
        }

        // 如果选中的没有重复，更新数组
        if (!isRepeat) {
            multiSelectDateArr.push(date);
        }

        // 更新对应的UI
        var selectedDate = date;
        this.updateInfo(function (item, i) {
            var date = dateFormat(selectedDate, FORMAT_TYPE);

            if (date == i) {
                if (item.isMultiSelect) {
                    item.isMultiSelect = false;
                    item.text = item.tempText || '';
                    item.isHighLight = item.tempIsHighLight || false;
                } else {
                    item.isMultiSelect = true;
                    item.text = TRAIN_MULTI_SELECT_SUB_TEXT;
                    item.isHighLight = true;
                }
            }
        });
        // 做下排序
        this.multiSelectSort(multiSelectDateArr);
        
        // 更新
        this.setData({
            multiSelectDateArr: multiSelectDateArr
        });
    },
    multiSelectSort: function (arr) {
        arr.sort((a, b) => {
            a = a.getTime();
            b = b.getTime();
            return a - b > 0;
        });
        return arr;
    },

    dateSelectedFinish: function ({
        eventType, storageType = '', callbackData = '', resdata = '', showToast = true
    } = {}) {
        let bizType = this.data.params.bizType;
        this.setData({
            isActiveDoubleSelected: true
        });
        if (eventType) {
            let data = this.data;
            let params = data.params;
            let date;
            let storageDate;
            if (callbackData) {
                date = callbackData;
            } else if (params.isDoubleSelect) {
                date = {
                    startDate: new Date(data.firstSelected),
                    endDate: new Date(data.secondSelected)
                };
                storageDate = JSON.stringify(date);
            } else {
                storageDate = date = new Date(data.firstSelected);
                if (bizType === 'ticket' && resdata !== '') {
                    date = JSON.parse(resdata);
                    storageDate = resdata;
                }
            }
            EventEmitter.dispatch(eventType, date);
            if (storageType && storageType !== '') {
                try {
                    wx.setStorageSync(storageType, storageDate);
                } catch (e) {}
            }
        }
        if (showToast) {
            wx.showToast({
                title: '日期选择成功',
                icon: 'success',
                duration: 500,
                success: function () {
                    setTimeout(function () {
                        wx.navigateBack();
                    }, 100);
                }
            });
        } else {
            setTimeout(() => {
                wx.navigateBack();
            }, 100)
        }
    },
    dateSelectedNotFinish: function () {
        this.setData({
            isActiveDoubleSelected: false
        });
    },
    multiSelectFinish: function () {
        var callbackData = this.data.multiSelectDateArr;
        var eventType = this.data.params.eventType;
        this.dateSelectedFinish({ eventType, callbackData });
    },
    getDateFormString: function (date) {
        // date 须为 '2017-03-20' 这种格式
        date = date.split('-').map(Number);
        return date.length >= 3 ? new Date(date[0], date[1] - 1, date[2]) : new Date();
    }
});
