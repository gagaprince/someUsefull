//index.js
var config = require("../../config.js")
var EventEmitter = require("../../EventEmitter.js")
var watcher = require("../../watcher.js")
var QWatcher = require('../../../flight/utils/qWatcher');
var dateFormat = require('../../utils/date/format.js');
var utils = require('../../utils.js');
var constant = require('./config.js');
var WATCHER = require('../../../flight/constant').WATCHER;
var TrainWatcher = require('../../../train/utils/watcher.js');
 //获取应用实例
var app = getApp()
Page({
    data: {
        isOnlyGaotie:false,
        bizType: 'flight',//默认值取机票，给机票导流
        depCity: '北京', //首次进入小程序，出发和到达城市均为上海、北京；如果有更新，会将新的值存在localstorage中；取值时，先拿localstorage，再取此默认值；
        arrCity: '上海',
        DEP_DATE_KEY: '',
        DEP_CITY_KEY: '',
        ARR_CITY_KEY: '',
        SLOGAN: {
            flight: '全程预订保障，去哪儿都放心',
            train: '全程预订保障，去哪儿都放心',
            bus: '官方授权，覆盖全国'
        }
    },
    //TODO: 给所有点击及PV添加监控
    onShareAppMessage: function () {
        var me = this;
        var bizTypeCfg = me.bizTypeCfg;
        var bd_origin = utils.bdOrigin.getV() || '';
        bizTypeCfg.share.path += '&bd_origin=' + bd_origin;

        me.clk('SHARE');

        return utils.share.getParam({
            url: bizTypeCfg.share.path,
            title: bizTypeCfg.share.title,
            desc: bizTypeCfg.share.desc
        });

    },
    onLoad: function(params){
        var me = this,
            bizTypeCfg;
        me._qWatcher = new QWatcher(WATCHER.HOME.PV);
        var app = getApp()
        app.globalData = app.globalData || {}

        //TODO:这里是否会影响全局数据呢？
        app.globalData.bd_origin = params.bd_origin|| ""
        params.bizType = params.bizType || me.data.bizType;
        me.pageParams = params

        me.bizTypeCfg = bizTypeCfg = constant[params['bizType']];
        me.setData({
            showSwitch: bizTypeCfg.showSwitch,
            bizType: params.bizType
        });
        wx.setNavigationBarTitle({
            title: me.bizTypeCfg.displayName
        });

        var upperCaseBizType = params.bizType.toUpperCase();
        me.data.DEP_DATE_KEY = constant.STORAGE_KEY.DEP_DATE + '_' + upperCaseBizType;
        me.data.DEP_CITY_KEY = constant.STORAGE_KEY.DEP_CITY + '_' + upperCaseBizType;
        me.data.ARR_CITY_KEY = constant.STORAGE_KEY.ARR_CITY + '_' + upperCaseBizType;

        me._init();
        me._registerListeners();

        me.pv();
    },
    onShow: function(){
        // watcher.pv({ "page": "home" });
    },

    //TODO:这段代码不知道干嘛的
    /*onReady: function () {
        //分享出去的链接，从首页跳转，这样可以回到首页可以进订单列表等
        var pageParams = this.pageParams || {}
        var navigateTo = pageParams.navigateTo || pageParams.navigateto
        var redirectTo = pageParams.redirectTo || pageParams.redirectto
        if(navigateTo){
            wx.navigateTo({ url: decodeURIComponent(navigateTo) })
            watcher.click({ "page": "home", "action-type": "home_navigateTo" })
            return
        }
        if(redirectTo){
            wx.redirectTo({ url: decodeURIComponent(redirectTo) })
            watcher.click({ "page": "home", "action-type": "home_redirectTo" })
        }
    },*/
    onUnload: function(){
        this._removeListeners();
    },
    _init: function(){
        var me = this,
            pageDefaultData = me.data,
            depCity,
            arrCity,
            depDate,
            oneDay = 86400000;
        //初始化日期和城市
        try {
            depDate = wx.getStorageSync(pageDefaultData.DEP_DATE_KEY);
            depCity = wx.getStorageSync(pageDefaultData.DEP_CITY_KEY);
            arrCity = wx.getStorageSync(pageDefaultData.ARR_CITY_KEY);
        } catch (error) {
        }
        depDate = (depDate >= Date.now() && depDate) || (Date.now() + oneDay);
        me.setData({
            arrCity: arrCity || pageDefaultData.arrCity,
            depCity: depCity || pageDefaultData.depCity,
            depDate: depDate || pageDefaultData.depDate
        });
        me._setDate(new Date(depDate));
    },
    //设置日期
    _setDate: function(date) {
        var me = this,
            displayDate = dateFormat(date, 'm月d日'),
            searchDate = dateFormat(date, 'yyyy-mm-dd'),
            dateWeek = dateFormat(date, '周w'),
            now = new Date(),
            oneDay = 86400000,
            today = new Date(now.getFullYear() + '/' + (now.getMonth() + 1) + '/' + now.getDate()).getTime(),
            days = parseInt((date - today) / oneDay);
        var dayStr = ['今天', '明天', '后天'];
        if (days < 3) {
            dateWeek += '(' + dayStr[days] + ')';
        }
        wx.setStorage({
            key: me.data.DEP_DATE_KEY,
            data: date.getTime()
        });
        this.setData({
            displayDate: displayDate,
            searchDate: searchDate,
            dateWeek: dateWeek
        });
    },
    _setCity: function(cityObj){
        var me = this,
            obj = {},
            key = cityObj.isDep ? me.data.DEP_CITY_KEY : me.data.ARR_CITY_KEY,
            viewDataKey = cityObj.isDep ? 'depCity' : 'arrCity';
        obj[viewDataKey] = cityObj.city;
        me.setData(obj);

        wx.setStorage({
            key: key,
            data: cityObj.city
        });
    },
    //注册事件监听
    _registerListeners: function() {
        var me = this;
        me._dateListener = EventEmitter.addListener(constant.event.CALENDAR_DATE_CHANGE, function(date) {
            me._setDate(date);
        });
        /*TODO:
        有个case后续需要兼容：如果直接将搜索列表页面分享，在微信中打开后，会先打开大首页，再打开搜索列表页面；
        此时修改时间，并不能将新的时间同步到搜索页
        修改方案：
        搜索列表页直接将新的时间存储在localstorage中，搜索页面从localstorage里面取，不使用事件的方式回传参数；
        */
        me._dateChangeListener = EventEmitter.addListener(constant.event.SEARCHLIST_DATE_CHANGE, function(date) {
            me._setDate(date);
        });
        me._cityListener = EventEmitter.addListener(constant.event.CITY_CHANGE, function(cityObj) {
            me._setCity(cityObj);
        });
    },
    // 移除事件监听
    _removeListeners: function() {
        var me = this;
        me._dateListener && me._dateListener.removeListener();
        me._dateChangeListener && me._dateChangeListener.removeListener();
        me._cityListener && me._cityListener.removeListener();
    },//事件
    onChooseDate: function(e) {
        var me = this,
            now = new Date().getTime(),
            data = me.data,
            bizType = data.bizType;
            //防止多次点击，锁定500ms

        if (now - data.lastTap < 500) {
            return;
        }
        me.clk('CHOOSE_DATE_CLICK');
        me.setData({
            lastTap: now
        });
        var params = {
            bizType: bizType, // 业务线
            date: data.searchDate, // 默认单选日期；多选的第一个日期 （不传的话展示今天）
            eventType: constant.event.CALENDAR_DATE_CHANGE,  // 选择日期成功之后触发的事件，通过监听这个事件来得到响应
            storageType: data.DEP_DATE_KEY
        };
        if (bizType === 'flight') {
            params.url = encodeURIComponent('/flight/pricetrend');  // 请求日历数据的url，一定要encode
            params.reqData = {   // 请求日历数据的 参数
                startCity: data.depCity,
                destCity: data.arrCity,
                checkType: 'ajax',
                priceType: 2
            };
        } else if (bizType === 'train') {
            params.url = encodeURIComponent('/train/product/api/train/TrainCalendar');  // 请求日历数据的url，一定要encode
            params.reqData = {   // 请求日历数据的 参数
                bizType: 0
            };
        }
        wx.navigateTo({
            url: '/common/pages/calendar/calendar?data=' + JSON.stringify(params)
        });
    },
    onChooseCity: function(e) {
        var me = this,
            now = Date.now(),
            data = me.data;
            //防止多次点击，锁定500ms  切换中无视点击
        if (data.exchangeStatus || (now - data.lastTap < 500)) {
            return;
        }
        me.setData({
            lastTap: now
        });
        var dateSet = e.currentTarget.dataset,
            type = dateSet.type,
            isDep = type === 'depCity' ? true : false;
        if (isDep) {
            me.clk('DEPCITY_CLICK');
        }
        else {
            me.clk('ARRCITY_CLICK');
        }

        var cityList =  me.bizTypeCfg.cityList;
        cityList.isDep = isDep;
        wx.navigateTo({
            url: '/common/pages/citySelector/citySelector?data=' + JSON.stringify(cityList)
        });
    },
    onCityExchange: function() {
        var me = this,
            data = me.data;
        if (data.exchangeStatus) {
            return;
        }
        me.setData({
            exchangeStatus: true
        });

        setTimeout(function() {
            me.setData({
                exchangeStatus: false,
                arrCity: data.depCity,
                depCity: data.arrCity
            });
        },300);

        me.clk('CITY_EXCHANGE_CLICK');
    },
    didSwitchChangeValue:function(e) {
        var me = this;
        var check = e.detail.value;
        this.setData({
            isOnlyGaotie:check
        });
        me.clk('SEARCH_SWITCH_CLICK');
    },
    onSearch:function(){
        var me = this,
            now = new Date().getTime(),
            data = me.data;
        if (data.bizType !== 'bus' && data.arrCity === data.depCity) {
            wx.showModal({
                title: '小驼提示',
                content: '出发城市和到达城市不能相同哦\n',
                showCancel: false,
                confirmColor: '#00bcd4'
            });
            return;
        }
        if (data.exchangeStatus) {
            return;
        }
        //防止多次点击，锁定500ms
        if (now - data.lastTap < 500) {
            return;
        }
        me.setData({
            lastTap: now
        });

        me.clk('SEARCH_CLICK');
        wx.navigateTo({
            url: me.bizTypeCfg.navUrl.replace(/{depCity}/, data.depCity).replace(/{arrCity}/, data.arrCity).replace(/{searchDate}/, data.searchDate).replace(/{onlyGD}/, data.isOnlyGaotie)
        })
    },
    pv: function(){
        var me = this;
        watcher.pv({page: me.pageParams.bizType + '_' + constant.WATCHER.PV});
        if('flight' === me.pageParams.bizType) {
            me._qWatcher.pageStart();
        } else if('train' == me.pageParams.bizType && WATCHER.HOME[name]) {
            watcher.send({
                page: this.pageParams.bizType + '_' + constant.WATCHER.PV,
                "action-type": TrainWatcher.keys.VERSION
            });
        }
    },
    clk: function(name){
        var me = this;
        if('flight' === me.pageParams.bizType && WATCHER.HOME[name]) {
            me._qWatcher.addCount(WATCHER.HOME[name]);
        }
        watcher.click({
            page: this.pageParams.bizType + '_' + constant.WATCHER.PV,
            "action-type": this.pageParams.bizType + '_' + constant.WATCHER[name]
        });
    }
})
