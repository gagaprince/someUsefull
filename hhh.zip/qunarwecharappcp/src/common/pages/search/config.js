var HOSTS = {
    beta: 'https://wxapp.beta.qunar.com',
    production:'https://wxapp.qunar.com'
};
var ENV = 'production';
module.exports = {
    event: {
        'CALENDAR_DATE_CHANGE': 'CALENDAR_DATE_CHANGE',
        'CITY_CHANGE': 'CITY_CHANGE',
        'SEARCHLIST_DATE_CHANGE': 'SEARCHLIST_DATE_CHANGE'
    },
    STORAGE_KEY: {
        'DEP_DATE': 'DepDate',
        'DEP_CITY': 'DepCity',
        'ARR_CITY': 'ArrCity',
        'HISTORY_CITY': 'HistoryCity',
        'HOT_CITY': 'HotCity',
        'PASSENGER_FILL': 'FillData'
    },
    WATCHER: {
        PV : 'search',
        SHARE: 'search_share',
        CHOOSE_DATE_CLICK: 'search_choose_date_clk',
        CITY_EXCHANGE_CLICK: 'search_city_exchange_clk',
        SEARCH_CLICK: 'search_button_clk',
        DEPCITY_CLICK: 'search_depcity_clk',
        ARRCITY_CLICK: 'search_arrcity_clk',
        SEARCH_SWITCH_CLICK: 'search_switch_clk'
    },
    flight: {
        name: 'flight',
        displayName: '国内机票',
        stDate: 0,
        navUrl: '/flight/pages/searchList/searchList?depCity={depCity}&arrCity={arrCity}&depDate={searchDate}',
        showNotice: true,
        share: {
            title: '机票预订 - 去哪儿旅行',
            desc: '总有你要的低价',
            path: '/common/pages/search/index?from=home&bizType=flight'
        },
        cityList: {
            type: 0, // 0:机票 1:火车票 2:汽车票 3:酒店
            cityListService: "/flight/citylist", // 热门城市和所有城市接口的URL
            cityListParam: {type: 10}, // 拼接在热门城市和所有城市接口URL后的参数
            citySuggestService: "/flight/suggest/livesearch2.jsp", // 搜索 suggest 接口的URL
            citySuggestParam: {ver: 1, site: 'domestic'}, // 拼接在搜索 suggest 接口URL的参数
            eventType: "CITY_CHANGE", // 选择城市成功之后触发的事件，通过监听这个事件来得到响应，返回的数据格式
            placeholder: "搜索国内城市：北京/bj/beijing/pek" // 搜索框的文案
            // title: "去哪儿网", // 城市选择组件的 title，优先级最高
            // isDep: true // 是否是出发城市，true 表示是出发城市，false 表示到达城市,不需要区分时可不传
        }
    },
    train: {
        name: 'train',
        displayName: '火车票',
        stDate: 0,
        navUrl: '/train/pages/searchList/searchList?startStation={depCity}&endStation={arrCity}&date={searchDate}&onlyGD={onlyGD}',
        showSwitch: true,
        share: {
            title: '火车票预订 - 去哪儿旅行',
            desc: '免验证码无忧购买火车票，极速购票，支持抢票等多种购票方式。',
            path: '/common/pages/search/index?from=home&bizType=train'
        },
        cityList: {
            type: 1, // 0:机票 1:火车票 2:汽车票 3:酒店
            // cityListService: "/flight/citylist", // 热门城市和所有城市接口的URL
            // cityListParam: {type: 10}, // 拼接在热门城市和所有城市接口URL后的参数
            citySuggestService: "/train/product/api/train/TrainStationSuggest", // 搜索 suggest 接口的URL
            // citySuggestParam: {ver: 1, site: 'domestic',}, // 拼接在搜索 suggest 接口URL的参数
            eventType: "CITY_CHANGE", // 选择城市成功之后触发的事件，通过监听这个事件来得到响应，返回的数据格式
            placeholder: "城市、车站的中文或拼音" // 搜索框的文案
            // isDep: true // 是否是出发城市，true 表示是出发城市，false 表示到达城市,不需要区分时可不传
        }
    },
    bus: {
        name: 'bus',
        displayName: '汽车票',
        stDate: 1,
        navUrl: '/bus/pages/searchlist/searchlist?dep={depCity}&arr={arrCity}&date={searchDate}',
        share: {
            title: '汽车票预订 - 去哪儿旅行',
            desc: '可预订全国20万+车站线路、直达景区旅游专线，线上购票无需排队，极速出票，支持预约抢票',
            path: '/common/pages/search/index?from=home&bizType=bus'
        },
        cityList: {
            type: 2, // 0:机票 1:火车票 2:汽车票 3:酒店
            cityListService: "/weChat/coach/cityList/do.json", // 热门城市和所有城市接口的URL
            // cityListParam: {type: 10}, // 拼接在热门城市和所有城市接口URL后的参数
            citySuggestService: "/weChat/coach/suggest/do.json", // 搜索 suggest 接口的URL
            // citySuggestParam: {ver: 1, site: 'domestic',}, // 拼接在搜索 suggest 接口URL的参数
            eventType: "CITY_CHANGE", // 选择城市成功之后触发的事件，通过监听这个事件来得到响应，返回的数据格式
            placeholder: "城市、车站的中文或拼音" // 搜索框的文案
            // title: "去哪儿网", // 城市选择组件的 title，优先级最高
            // isDep: true // 是否是出发城市，true 表示是出发城市，false 表示到达城市,不需要区分时可不传
        }
    }
};
