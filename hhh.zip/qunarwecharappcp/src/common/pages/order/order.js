let app = getApp();
let config = require('../../config.js');
var watcher = require("../../watcher.js")
let user = require('../../user.js');
var Network = require('../../comps/network/network.js');
var requester = require('../../requester.js');

Page({
    data: {
        activeall: {
            all: "active",
            valid: '',
            pend: '',
            refund: ''
        },
        orders: "",
        hasMore: true,
        orderType: {
            all: 'all',
            valid: '',
            pend: '10,11',
            refund: '1010,1020,1030,1040,1050,200010,200020,100100,700030,600010'
        },
        'isHasOrders': 'hide',
        animationData: {},
        isShowDown: 'hide',
        wHeight: 0,
        networkData: {
            status: 3,
            loadingDesc: ''
        }
    },
    alldata: [],
    limit: 20, //每次请求20，固定
    filter: '',
    nextIndex: 0,
    hasMore: true,
    isTabChange: true,  //是否tab切换
    lastScrollTop: 0,
    rotate: 0,
    loading: null,
    currentType: 'all', //用于刷新type标识
    allBusinessTypes: "train,bus,flight,hotel,tese,new_apartment,ticket,hotel_sight",
    sendWatcher: function(actionType){
        watcher.click({
            "page": "order",
            "action-type": actionType
        })
    },
    onLoad: function(params) {
        this.params = params
        // this.loading = new Network(this);
        this.isFromOnLoad = true
    },
    onShow: function () {
        //从我的业务传过来的filter： switchTab传不了url参数
        //如果是从我的业务线点击“xxx订单”过来的，则需要重新刷新数据
        var my_page_order_filter = wx.getStorageSync('my_page_order_filter') || ""
        //在“我的”“首页”移除 wx.removeStorageSync('my_page_order_filter')

        var filter = my_page_order_filter || this.params.filter || this.allBusinessTypes;
        this.filter = filter;
        var me = this
        user.getUserInfo(function(res){
            var exParams = res && res.data && res.data.exParams
            me.data.weChatPlatform = exParams && exParams.platform
            me.loadData(res)
        })

        watcher.pv({ "page": "order"});
    },
    onReady: function () {

    },
    //如果是由于getUserInfo 返回结果false导致，则重新登录加载
    networkRetry: function(res){
        var me = this
        user.login(function(res){
            me.loadData(res)
        })
    },
    loadData: function(res) {
        var me = this;
        if(res.ret){
            if(this.isFromOnLoad){
                this.init();
                this.isFromOnLoad = false
            } else {
                this.refreshData()
            }
        } else {
            Network.hideNetwork.call(me, function() {
                Network.showNetwork.call(me, {
                    status: -2,
                    loadingDesc: "订单加载失败",
                    networkRetry: 'networkRetry',
                    showButton: true
                });
            });
            this.isTabChange = false
        }
    },
    refreshData: function(isNeedLoading) {
        this.resetStatus();
        this.request({
            orderCenterStatus: this.currentType,
            queryScene: this.currentType == '' ? 2 : ''
        }, isNeedLoading || false);
    },
    resetStatus: function() {
        this.alldata = [];
        this.nextIndex = 0;
        this.hasMore = true;
    },
    onPullDownRefresh: function(e) {
        this.refreshData(true)
    },
    onReachBottom: function(e) {  //重绘页面会执行
        console.log("reach bottom");
        if (this.isTabChange || this.hasMore == false) {
            return;
        }
        this.downRefresh();
        this.request({
            orderCenterStatus: this.currentType,
            queryScene: this.currentType == '' ? 2 : ''
        }, true);
    },
    // 切换头部tab
    changeOrderType: function(e) {
        this.resetStatus();
        this.setData({hasMore: true});
        if (this.isTabChange) {
            return;
        }
        this.isTabChange = true;
        let targetid = e.currentTarget.id || "";
        this.setData({ activeall: {
                    all: targetid == 'all' ? 'active' : '',
                    valid: targetid == 'valid' ? 'active' : '',
                    pend: targetid == 'pend' ? 'active' : '',
                    refund: targetid == 'refund' ? 'active' : ''
                }
            });
        this.currentType = e.currentTarget.dataset.type || "";
        this.changeTypeData(e);
    },
    changeTypeData: function(e) {
        let qtype = e.currentTarget.dataset.type || '';
        this.request({
            orderCenterStatus: qtype,
            queryScene: qtype == '' ? 2 : ''
        });

        var actionType = e.currentTarget.id;
        this.sendWatcher(actionType);
    },
    request: function(o, isrefresh) {
        var that = this;
        this.isTabChange = true;
        let cjs = {'type':'weChat','uid':app.user.unionId || ""};
        that.setData({'isHasOrders': 'hide'});
        let rdata = {
            businessTypes: o.businessTypes || this.allBusinessTypes,  //可配置
            ordertoken: "",
            limit: that.limit,
            start: that.nextIndex,
            needCount: true,
            orderCenterStatus: o.orderCenterStatus || '',
            isUserNameQuery: false,
            isUserPhoneQuery: false,
            clientJson: JSON && JSON.stringify(cjs),
            unbindQuery: false,
            queryScene: o.queryScene || '',
            openId: app.user.openId || "",
            unionId: app.user.unionId || "",
            qunarUsername: app.user.qunarUser && app.user.qunarUser.username || "",
            token: app.cookies && app.cookies.token,
            weChatPlatform: that.data.weChatPlatform,
            version: config.version
        };
        if (that.filter) {
            rdata.businessTypes = that.filter;
        }
        if (!isrefresh) {
            Network.showNetwork.call(that, { status: 3 });
        }
        requester.request({
            service: config.service.getOrders,
            data: rdata,
            success: function(res) {
                let data = res && res.data && res.data.data;
                if (data && !data.hasMore) {
                    that.hasMore = false;
                } else if (data && data.nextStart) {
                    that.nextIndex = data.nextStart;
                    that.hasMore = true;
                }

                let orderList = that.formatdata(data && data.orderList || []);
                that.alldata = Array.prototype.concat.call(that.alldata, orderList);
                that.setData({orders: that.alldata, hasMore: that.hasMore});
                if (that.alldata.length == 0) {
                    that.setData({'isHasOrders': 'show', 'hasMore': true});
                    return;
                }
                that.setData({'isHasOrders': 'hide',orders: that.alldata});
            },
            fail: function(res) {
                that.setData({orders: [], 'isHasOrders': 'show'});
            },
            complete: function(e) {
                if (e.statusCode == 502 || e.statusCode == 404) {
                    that.setData({'isHasOrders': 'show', orders: []});
                }
                that.setData({isShowDown: 'hide'});
                try {
                    Network.hideNetwork.call(that);
                } catch (e) {
                    console.log("loading hide excption");
                }
                if (isrefresh) {
                    wx.stopPullDownRefresh();
                }
                that.isTabChange = false;
            }
        });
        //this.sendWatcher(rdata.orderCenterStatus);
    },
    toDetail: function(e) {
        let url = e.currentTarget.dataset && e.currentTarget.dataset.schema;
        console.log(url)
        if (!url) {
            wx.showToast({
                title: "详情页丢失"
            });
            return;
        }
        wx.navigateTo({
            url: url || ''
        });
        this.sendWatcher("go_orderDetail");
    },
    toPay: function(e) {
        let url = e.currentTarget.dataset && e.currentTarget.dataset.schema;
        if (!url) {
            wx.showToast({
                title: "详情页丢失"
            });
            return;
        }
        wx.navigateTo({
            url: url || ''
        });
        this.sendWatcher("go_orderPay");
    },
    formatdata: function(data) {
        if (!data) {
            return;
        }
        let rg = /\d[!\w]*/g;
        data.forEach(function(k,v){
            k.price = k.price && (k.price / 10000);
            if (k.price && k.price > 99999) {
                k.price = Number.toFixed(k.price / 10000, 2) + '万+';
            }
            let orders = k.trainList || k.busList || k.flightList || [];
            let l = orders.length;
            for (let i = 0;i < l;i++) {
                let orderi = orders[i];
                let keyfr = '';
                let keyto = '';
                if (orderi.departure && orderi.arrival) {
                    keyfr = 'departure';
                    keyto = 'arrival';
                } else if (orderi.fromDate && orderi.toDate) {
                    keyfr = 'fromDate';
                    keyto = 'toDate';
                }
                let depm = orderi[keyfr] && orderi[keyfr].match(rg) || '';
                let arrm = orderi[keyto] && orderi[keyto].match(rg) || '';
                if (!depm.length || !arrm.length) {
                    return;
                }
                // 组装时间段
                orderi.timerange = depm[0]+"-"+depm[1]+"-"+depm[2]+"   "+depm[3]+":"+depm[4]+"~"+arrm[3]+":"+arrm[4];
                // 计算跨天
                let depmi = parseInt(depm[1])-1;
                let arrmi =parseInt(arrm[1])-1;
                depm[1] = (depmi < 10) ? ('0'+depmi) : depmi;
                arrm[1] = (arrmi < 10) ? ('0'+arrmi) : arrmi;
                let secs = new Date(arrm[0], arrm[1], arrm[2], arrm[3], arrm[4]).getTime() - new Date(depm[0], depm[1], depm[2], depm[3], depm[4]).getTime();
                if (Math.floor(secs/86400000) > 0) {
                    let tip = "+"+Math.floor(secs/86400000)+"天";
                    orderi.tip = tip;
                }
            }
        });
        return data;
    },
    init: function() {
        this.request({
            orderCenterStatus: 'all',
            queryScene: '',
            businessTypes: this.allBusinessTypes
        });
        this.sendWatcher("all");
    },
    // 上拉刷新动画
    downRefresh: function(){
        var that = this;
        var animation = wx.createAnimation({
            duration: 8000,
            timingFunction: 'linear'
        })
        this.rotate += 720;
        this.animation = animation
        animation.rotate(this.rotate).step()
        this.setData({
            animationData: that.animation.export(),
            isShowDown: 'show-dr'
        })
        setTimeout(function() {
            that.setData({
                animationData: that.animation.export(),
                isShowDown: 'hide'
            })
        }.bind(this), 8000);
    }
});
