var EventEmitter = require('../../EventEmitter.js');
var requester = require('../../requester.js');
var Network = require('../../comps/network/network.js');
var CURRENT_CITY = '_CURRENT_CITY';
var HOT_CITY = '_HOT_CITY';
var HISTORY_CITY = '_HISTORY_CITY';
var ALL_CITIES = '_ALL_CITIES';
var QWatcher = require('../../../flight/utils/qWatcher');
var WATCHER = require('../../../flight/constant').WATCHER;
var utils = require('../../utils.js');
//获取应用实例
Page({
    // @param {isDep:是否是出发城市}
    data: {
        // 区分业务命名前缀
        prefix: '',
        // 当前城市
        currentCity: '',
        cities:[],
        // 是否处于搜索状态
        isSearch:false,
        // 输入框内容
        inputValue:'',
        // 热门城市
        hotCities: [],
        // 有历史城市
        historyCities:[],
        // 所有城市
        allCities: [],
        isFocus:false,
        isShow: false,
        isFail: false,
        failMessage: ''
    },
    getCurrentCity: function() {
        var self = this;
        var defaultUrl = '/api/hotel/location';
        wx.getLocation({
            success: function(res) {
                var latitude = res.latitude;
                var longitude = res.longitude;
                var _cityParam = self.data.param.currentCityParam || {};
                var _param = {
                    location: latitude + ',' + longitude,
                    bd_source: 'smart_app'
                };
                Object.keys(_cityParam).forEach(function(key) {
                    _param[k] = _cityParam[key];
                });
                requester.request({
                    host: self.data.param.currentCityHost || 'https://wxapp.qunar.com',
                    service: self.data.param.currentCityService || defaultUrl,
                    param: _param,
                    success: function(data) {
                        var cityName = data && data.data && data.data.data && data.data.data.city || '';
                        self.setData({
                            currentCity: cityName.replace(/市$/, '')
                        });
                        wx.setStorage({
                            key: self.data.prefix + CURRENT_CITY,
                            data: cityName.replace(/市$/, '')
                        });
                    }
                });
            },
            fail: function (err) {
                self.setData({
                    currentCity: ''
                });
				wx.showModal({
					title: '提示',
					content: '请确认您的手机是否打开定位服务且允许微信访问。如您确认已启动服务，请稍后重试',
					showCancel: false
				});
			},
            complete: function () {
                Network.hideNetwork.call(self, function() {
                    self.setData({
                        isShow: true
                    });
                });
            }
        });
    },
    readCurrentCity: function () {
        var self = this;
        try {
            // var currentCity = wx.getStorageSync(self.data.prefix + CURRENT_CITY);
            // var currentTime = (new Date).getTime();
            // var time = wx.getStorageSync(self.data.prefix + CURRENT_CITY + '_TIME');
            // if (currentCity && time && currentTime - time <= 86400000) { // 当前城市缓存过期时间 1天 = 86400000 ms
            //     self.setData({
            //         currentCity: currentCity
            //     });
            // } else {
                self.getCurrentCity();
            // }
        } catch (error) {
            self.getCurrentCity();
        }
    },
    requestCities: function () {
        var self = this;
        if (self.data.prefix === 'TRAIN') {
            var trainCity = [['北京','上海','广州'],['深圳','南京','武汉'],['杭州','西安','郑州'],['成都','长沙','天津']];
            self.setHotCity(trainCity);
            self.setAllCities([]);
            return;
        }
        var _cityParam = self.data.param.citySuggestParam || {};
        var _cityData = self.data.param.citySuggestData || {};

        if (self.data.prefix === 'BUS') {
            _cityData.b = {
                bizType: self.data.param.isDep ? 1 : 5,
                localVer: 0
            };
            _cityData.c = requester.getParamC()
        }
        var reqData = {
            host: self.data.param.cityListHost || 'https://wxapp.qunar.com',
            service: self.data.param.cityListService,
            param: _cityParam,
            data: _cityData,
            success: function (res) {
                switch (self.data.prefix) {
                    case 'FLIGHT': {
                        if (res && res.data && res.data.length) {
                            var cityObj = res.data[0];
                            if (cityObj && cityObj.n && cityObj.n.length) {
                                self.setHotCity(cityObj.n);
                            }
                            self.setAllCities([]);
                            wx.setStorage({
                                key: self.data.prefix + HOT_CITY + '_TIME',
                                data: (new Date).getTime()
                            });
                            // if (res.data.length > 1) {
                                // self.setAllCities([]);
                                // self.setAllCities(res.data.slice(1));
                            // }
                        }
                        break;
                    }
                    case 'TRAIN' : {
                        // var trainCity = [['北京','上海','广州'],['深圳','南京','武汉'],['杭州','西安','郑州'],['成都','长沙','天津']];
                        // self.setHotCity(trainCity);
                        // self.setAllCities([]);
                        break;
                    }
                    case 'BUS' : {
                        var busCity = res && res.data && res.data.coachCitys && res.data.coachCitys || [];
                        self.setHotCity(busCity);
                        self.setAllCities([]);
                        wx.setStorage({
                            key: self.data.prefix + HOT_CITY + '_TIME',
                            data: (new Date).getTime()
                        });
                        break;
                    }
                    case 'HOTEL' : {
                        if (res && res.data && res.data.data && res.data.data.length) {
                            self.setHotCity(res.data.data[0]);
                            if (res.data.data.length > 1) {
                                self.setAllCities(res.data.data.slice(1));
                            }
                            wx.setStorage({
                                key: self.data.prefix + HOT_CITY + '_TIME',
                                data: (new Date).getTime()
                            });
                        }
                        break;
                    }
                }
            },
            fail: function(err) {
                self.setData({
                    isFail: true,
                    failMessage: '小驼出错啦，请稍后重试'
                });
            },
            complete: function () {
                //关闭loading
                Network.hideNetwork.call(self, function() {
                    self.setData({
                        isShow: true
                    });
                });
            }
        };
        requester.request(reqData);
    },
    readHistory: function () {
        try {
            var self = this;
            var vHistoryCities = wx.getStorageSync(self.data.prefix + HISTORY_CITY);
            if (vHistoryCities && vHistoryCities.length) {
                this.setData({
                    historyCities: vHistoryCities
                });
            }
        } catch (error) {
        }
    },
    readHotAndAllCity: function () {
        //首先在storage里获取，失败则通过网络获取,最后静态数据兜底
        try {
            var self = this;
            var vHotCities = wx.getStorageSync(self.data.prefix + HOT_CITY);
            var allCities = wx.getStorageSync(self.data.prefix + ALL_CITIES);
            var isReqHot = vHotCities && (vHotCities.length || vHotCities['热门城市']);
            var isReqAll = allCities;

            var currentTime = (new Date).getTime();
            var time = wx.getStorageSync(self.data.prefix + HOT_CITY + '_TIME');
            // 汽车票的热门城市经常更新，且出发城市和到达城市的数据不同，故本期汽车票的热门城市数据不读localstorage
            if (isReqHot && isReqAll && self.data.prefix !== 'BUS' && time && currentTime - time <= 3 * 86400000) { // 热门（所有）城市缓存过期时间 3天 = 3*86400000 ms
                this.setHotCity(vHotCities);
                this.setAllCities(allCities);
            } else {
                this.requestCities();
            }
        } catch (error) {
            this.requestCities();
        }
    },
    setHotCity: function (data) {
        this.setData({
            hotCities: data
        });
        var self = this;
        wx.setStorage({
            key: self.data.prefix + HOT_CITY,
            data: data
        });
    },
    setAllCities: function (data) {
        var self = this;
        this.setData({
            allCities: data
        });
        wx.setStorage({
            key: self.data.prefix + ALL_CITIES,
            data: data
        });
    },
    onLoad: function (param) {
        var self = this;
        self._qWatcher = new QWatcher(WATCHER.SUGGEST.PV);
        Network.showNetwork.call(this, { status: 4, loadingDesc: '加载中' });
        var data = JSON.parse(param.data);
        var type = '';
        switch (data.type) {
            case 0:
                type = 'flight';
                self._qWatcher.pageStart();
                break;
            case 1:
                type = 'train';
                break;
            case 2:
                type = 'bus';
                break;
            case 3:
                type = 'hotel';
                break;
        }
        self.setData({
            isShow: false,
            isFail: false,
            failMessage: '',
            param: data,
            prefix: type.toUpperCase()
        });
        // self._qWatcher = new QWatcher(WATCHER.SUGGEST.PV);
        self.readCurrentCity();
        self.readHistory();
        self.readHotAndAllCity();
    },

    onReady: function (param) {
        this._showTitle();
    },

    onShow: function (param) {
        this._showTitle();
    },

    _showTitle: function(title) {
        var data = this.data.param || {};
        var barTitle = '';
        if(data.isDep === true) {
            barTitle = '出发城市';
        }
        else if(data.isDep === false) {
            barTitle = '到达城市';
        }
        barTitle = data.title || barTitle;
        barTitle && wx.setNavigationBarTitle({
            title: barTitle
        });
    },

    cancelTap: function() {
        this.setData({
            isSearch: false,
            isFocus: false,
            noResult: false,
            word: '',
            inputValue:'',
            cities:[]
        });
    },
    bindFocus: function(e) {
        // var word = e.detail.value;
        // if (word.length > 0) {
            this.setData({
                isFocus:true
            });
        // }
    },
    bindKeyInput: utils.debounce(function(e) {
        var word = e.detail.value.replace(/\s/g, '');
        if (word.length > 0) {
            this.setData({
                isFocus:true,
                isSearch: true,
                inputValue: word,
                noResult: false
            });
        } else {
            this.setData({
                isSearch: false,
                inputValue: word,
                noResult: false,
                cities:[]
            });
            return;
        }
        var self = this;
        var updateCities = function(flag, data) {
            if (flag && data && data.length) {
                self.setData({
                    cities: data
                });
            } else {
                self.setData({
                    cities: [],
                    noResult: true
                });
            }
        };
        var _cityParam = self.data.param.citySuggestParam || {};
        var _cityData = self.data.param.citySuggestData || {};
        var _param = { q: word, keyword: word, queryValue: word, city: word };
        var _data = { q: word, keyword: word, b: { queryValue: word }, city: word };
        Object.keys(_cityParam).forEach(function(k) {
            _param[k] = self.data.param.citySuggestParam[k];
        });
        Object.keys(_cityData).forEach(function(k) {
            _data[k] = self.data.param.citySuggestData[k];
        });
        var reqData = {
            host: self.data.param.citySuggestHost || 'https://wxapp.qunar.com',
            service: self.data.param.citySuggestService,
            param: _param,
            data: _data,
            success: function (res) {
                switch (self.data.prefix) {
                    case 'FLIGHT': {
                        updateCities(res.data.result && res.data.result.length, res.data.result);
                        break;
                    }
                    case 'TRAIN' : {
                        updateCities(res.data.dataMap.result && res.data.dataMap.result.length, res.data.dataMap.result);
                        break;
                    }
                    case 'BUS' : {
                        updateCities(res.data.suggestList && res.data.suggestList.length, res.data.suggestList);
                        break;
                    }
                    case 'HOTEL' : {
                        var hotelData = res.data.data && res.data.data.result || [];
                        var newData = [];

                        if (res.data.data && hotelData.length > 0) {
                            var key = res.data.data.userInput,
                                keyLen = key.length;
                            hotelData.forEach(function(item, index) {
                                var text = item.display,
                                    pos = text.toLowerCase().indexOf(key.toLowerCase());
                                if (pos > -1) {
                                    //截取高亮展示文本，重组数据结构
                                    newData.push({
                                        key: item.key,
                                        text: [{
                                            text: text.substr(0, pos),
                                            isHL: false
                                        }, {
                                            text: text.substr(pos, keyLen),
                                            isHL: true
                                        }, {
                                            text: text.substr(pos + keyLen),
                                            isHL: false
                                        }]
                                    });
                                }
                            });
                        }
                        updateCities(res.data.data, newData);
                        break;
                    }
                }
            }
        };
        if (self.data.prefix === 'BUS') {
            reqData.data.c = requester.getParamC();
        }
        requester.request(reqData);
    }, 300),

    blur:function(e) {
        var word = e.detail.value.replace(/\s/g, '');
        if (word.length > 0) {
            this.setData({
                isFocus:false
            });
        }
        else {
            this.setData({
                isFocus:false,
                isSearch: false,
                noResult: false
            });
        }

    },

    cityTap: function(e) {
        var self = this;
        var dataset = e.currentTarget.dataset,
            selectedCity = dataset.city;
        var source = dataset.source;
        var cityObj = {
            city: selectedCity,
            isDep: self.data.param.isDep
        };
        if('FLIGHT' === self.data.prefix) {
            self._qWatcher.addCount('tap_' + source + '_city');
        }
        var historyCities = self.data.historyCities;
        var needSave = true;
        for(var i = 0; i < historyCities.length; i++) {
            if (historyCities[i] == selectedCity) {
                needSave = false;
                break;
            }
        }
        if (needSave) {
            if (historyCities.length >= 3) {
                historyCities.pop();
            }
            historyCities.unshift(selectedCity);
            wx.setStorage({
                key: self.data.prefix + HISTORY_CITY,
                data: historyCities
            });
        }
        var event = self.data.param && self.data.param.eventType;
        EventEmitter.dispatch(event, cityObj);
        wx.navigateBack();
    }
})
