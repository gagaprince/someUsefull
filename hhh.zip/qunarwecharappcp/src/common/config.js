//配置
var version = "1.1.7"
global.__DEV__ = global.__envType === 'beta';

// 老的切换环境
var isDebug = false
var isBeta = global.__envType === 'beta';
global.__DEV__ = isDebug
global.__BETA__ = isBeta

var settings = {
    requestDomain: global.__env.server,
    socketDomain:"wss://wxapp.qunar.com",
    uploadFileDomain:"http://wxapp.qunar.com",
    downloadFileDomain:"http://wxapp.qunar.com"
}

var service = {
    //获取openid 和 获取qunar用户信息
    s2s: "/weChat/coach/search/s2s.json",
    // 填单数据获取
    FILL_ORDER: "/weChat/coach/booking/readyTicket.json",
    // 生成订单
    BUILD_ORDER: "/weChat/coach/saveOrder/do.json",
    // FAQ地址
    FAQ: '/weChat/coach/faq/do.json',
    ORDER_DETAIL: '/weChat/coach/orderDetail/do.json',
    //SUGGEST
    SUGGEST:'/weChat/coach/suggest/do.json',
    CITY_LIST: '/weChat/coach/cityList/do.json',
    //cancel
    CANCEL_ORDER: '/weChat/coach/orderDeal/do.json',
    // 请求收银台
    PAY_METHOD: 'h5/train/TrainPayMethod',

    //自动登录
    autoLogin: "/oauth-client/wechatSmall/smallLogin",
    //校验
    checkLogin: "/oauth-client/wechatSmall/validate",
    //获取订单列表
    getOrders: "/api/wechat/order/query.do",
    // 我的
    getUserInfo: "/ucenter/index/wechatIndex",
    getWechatTab: "/ucenter/index/getWechatTab",
    //监控地址
    watcherUrl: "https://wxapp.qunar.com/pt/pageTrace.do",
    sendSMSCode: '/ucenter/webApi/logincode.jsp',  //发送验证码
    login: '/ucenter/webApi/logincodeverify.jsp',  //登录
    bindThirdPlatform: '/oauth-client/platform/bindThirdUser.jsp',  //绑定去哪儿和微信账号
    unBindThirdPlatform: '/oauth-client/platform/unBindThirdPlatform',
    robAndBind: "/oauth-client/platform/robAndBind"//抢占
}

// RELEASE: "https://wxapp.qunar.com/train/product/",
// DEV_W: "https://wxapp.beta.qunar.com/train/devw/",
// BETA_D: "https://wxapp.beta.qunar.com/train/betad/"
var train = { HOST: global.__env.server + "/train/" + (global.__envType == 'beta' ? (global.__env.train.envType || 'betad') : 'product') };

function debugUpdateDomain(isBeta){
    if(isBeta){
        settings.requestDomain =  "https://wxapp.beta.qunar.com"
        var env = global.__env.train.envType || 'betad';
        train.HOST =  "https://wxapp.beta.qunar.com/train/" + env;
    } else {
        settings.requestDomain =  "https://wxapp.qunar.com"
        train.HOST =  "https://wxapp.qunar.com/train/product"
    }
}

module.exports = {
    version: version,
    settings: settings,
    service: service,
    train: train,
    debugUpdateDomain: debugUpdateDomain,
    isDebug: isDebug,
    isBeta: isBeta
}
