//user.js
/*
    1、先从本地缓存获取用户数据，如果用户数据完备（包含openIdopenId、unionId\ _q），则使用本地数据
    2、如果本地缓存数据不完备，则
       2.1、调用微信登录接口获取Code
       2.2、调用微信获取微信用户信息接口获取用户加密信息
       2.3、调用qunar服务端接口返回openId、unionId及qunar用户信息（将code、微信用户加密信息作为参数发送）
       2.4、将返回数据缓存到本地缓存、及app中
       2.5、服务端接口需要记录登录态、管理登录态
*/
var config = require("./config.js")
var watcher = require("./watcher.js") //埋点
var loginOpts = {
    //有默认值，根据第一次调用登录login时传的为准login(callback, exParams)
    //不同小程序exParams 是不一样的
    exParams:{
        platform: "wechat$$$small",
        app: "ucenter"
    },
    autoLoginTip:"您最近授权过去哪儿网，已为您自动登录",
    //登录失败的重试次数（如果获取不到数据、需要重试的次数）
    retryCount: {
        //wxLogin: 1,             //微信登录重试次数
        //getWxUserInfo: 1,       //获取微信信息重试次数
        getQunarUserInfo: 1     //获取去哪儿用户信息重试次数
    }
}
//登录结果信息
var loginResult = {
    wx_getUserInfo_deny: false,  //是否微信拒绝授权
    status: null,
    errorStack: {}
    //,data:{}
}

//动态获取，betabeta 线上切换时会变
function getLoginUrl(){
    return  config.settings.requestDomain + config.service.getOpenIdAndQunarUser
}
//微信登录
function wxLogin(successCallback){
    wx.login({
        success: successCallback,
        fail: function(res){
            setUserStatus(11, res)
        }
    })
}
//微信获取微信用户信息
function getWxUserInfo(callback, denyIsContinue){
    callback = callback || empty
    var old_wx_getUserInfo_deny = loginResult.wx_getUserInfo_deny
    wx.getUserInfo({
        //成功、失败、取消需要回调获取openId
        success: function(res){
            res.ret = true
            loginResult.wx_getUserInfo_deny = false
            callback(res)
            if(old_wx_getUserInfo_deny){
                sendWatcher("wx_getUserInfo_old_deny_new_allow")
            }
        },
        fail:function(res){
            //拒绝授权: "getUserInfo:cancel", "getUserInfo:fail auth deny"
            res.ret = false
            //"getUserInfo:fail"\"getUserInfo:cancel"\"getUserInfo:fail auth deny"
            loginResult.wx_getUserInfo_deny = true
            callback(res)
        }
    })
}
//请求
function request(options){
    options.header = options.header
    wx.request(options)
}

//调用后端接口、获取qunar用户信息及openId、unionId
function getQunarUserInfo(params ,app, getQunarUserCallback){
    request({
        data: params,
        method: "POST",
        url: getUrl("autoLogin"),
        header: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        success:function(res){
            var result = res.data || {}
            if(result.ret){
                var data = result.data
                updateUserInfo(data)
                getQunarUserCallback && getQunarUserCallback({ ret:true, data:getReturnUserInfoDto() })
            } else {
                res.message = "后端接口获取openid及账号关联失败"
                getQunarUserInfoRetryed(params ,app, getQunarUserCallback, res)
            }
        },
        fail:function(res){
            getQunarUserInfoRetryed(params ,app, getQunarUserCallback,res)
        }
    })
}
//（如果获取不到数据、需要重试）
function getQunarUserInfoRetryed(data ,app, getQunarUserCallback, res){
    var retryCount = loginOpts.retryCount
    retryCount.getQunarUserInfoRetryed = retryCount.getQunarUserInfoRetryed || 0
    if(retryCount.getQunarUserInfoRetryed < retryCount.getQunarUserInfo){
        retryCount.getQunarUserInfoRetryed = retryCount.getQunarUserInfoRetryed + 1
        console.log("getQunarUserInfo:" + retryCount.getQunarUserInfoRetryed, res)
        getQunarUserInfo(data ,app, getQunarUserCallback)   //如果是域名不符合要求则会是同步返回的错误
    } else {
        setUserStatus(31,res)
        var errMsg = (res.message && (res.message + ":" + (res.data && res.data.errMsg))) || res.errMsg
        console.log("getQunarUserInfo:" + (retryCount.getQunarUserInfoRetryed + 1) , res)
        retryCount.getQunarUserInfoRetryed = 0 //重置为初始太
        getQunarUserCallback( { ret:false, errMsg: errMsg } )
    }
}
//获取用户信息、包含去哪儿用户信息
function loginAndGetUserInfos(app, getWxUserCallback, getQunarUserCallback, denyIsContinue){
    var exParams = loginOpts.exParams
    app = app || getApp()
    var oldStatus = loginResult.status
    getWxUserCallback = getWxUserCallback || empty
    getQunarUserCallback = getQunarUserCallback || empty
    setUserStatus(0)
    wxLogin(function(loginRes){
        setUserStatus(1)
        getWxUserInfo(function(res){
            if(res.ret === false && !res.encryptedData && denyIsContinue === false){
                setUserStatus(oldStatus)
                var result = { ret:false, data: getReturnUserInfoDto(), errMsg: res.errMsg }
                getWxUserCallback(result)
                getQunarUserCallback(result)
                return
            }
            app.user = res.userInfo || { nickName:"", avatarUrl:"" }
            //app.user._code = loginRes.code
            setUserStatus(2)
            getWxUserCallback && getWxUserCallback({ ret:true, data: getReturnUserInfoDto() })
            var qunar = app.cookies || {}
            var params = {
                code: loginRes.code,
                encryptedData: res.encryptedData || "",
                iv: res.iv || "",
                platform: exParams.platform,
                autoLogin: true,
                //token: qunar.token || "",    //传token时从后端缓存取数据，code和token不能同时有
                _q : qunar._q || "",
                _v : qunar._v || "",
                _t : qunar._t || "",
                _s : qunar._s || "",
                _i : qunar._i || "",
                QunarGlobal: qunar.QunarGlobal || ""
            }
            getQunarUserInfo(params, app, getQunarUserCallback)
        })
    })
}

//从本地缓存获取用户信息，如果没有则从服务端获取
function loginAndGetUserInfosFromCacheOrServer(app, getWxUserCallback, getQunarUserCallback, exParams){
    loginOpts.exParams = exParams || loginOpts.exParams
    app.user = app.user || {}
    app.cookies = app.cookies || {}
    var status = loginResult.status
    if(status != null){
        //0，1，2在请求处理中，其余情况可以重新登录
        if(!(status == 0 || status == 1 || status == 2 || status == -1)){
            setUserStatus(-1)
            checkLoginAndLogin(app, getQunarUserCallback, getWxUserCallback)
        } else {
            getUserInfo(getQunarUserCallback)             //由于登录接口正在请求中，等待调用成功后回调(getUserInfo)
            console.log("登录接口正在调用中，本次调用cancel(使用正在调用的请求并使用正在调用的返回结果)")   //已经调用过登录接口,不需要重复调用
        }
    } else {
        //未开始请求status=null 或者上一次请求已经结束status=3
        //todo: 需要处理一下一下10s钟内不要重复请求 loginResult.lastRequestTime
        setUserStatus(-1)
        getUserDataCache(app, function(app){
            //checkSession(function(){
                checkLoginAndLogin(app, getQunarUserCallback, getWxUserCallback)
            //})
        })
    }
}
function checkLoginAndLogin(app, getQunarUserCallback, getWxUserCallback){
    //如果是已经登录过并且有openIdopenId、unionId\ _q，则不再登录
    var user = app.user
    var qunar = app.cookies
    //if(!(user.openId && user.unionId && qunar.token)){
    if(!(user.openId && qunar.token)){
        return loginAndGetUserInfos(app, getWxUserCallback, getQunarUserCallback)
    }
    //校验openidopenid、unionid、tokentoken、qvt有效性
    checkLogin(function(res){
        if(res.ret){
            //校验成功
            setUserStatus(3)
            getWxUserCallback && getWxUserCallback(res)
            getQunarUserCallback && getQunarUserCallback(res)
            console.log("user.loginInit:--用户登录相关数据从缓存获取到并校验成功，不向后端发送请求重新获取openId--")
        } else {
            //失败则重新获取数据
            loginAndGetUserInfos(app, getWxUserCallback, getQunarUserCallback)
        }
    })
}
function getUserDataCache(app, callback){
    wx.getStorage({
        key:'InitUserData',
        success:function(res){
            var data = res.data || {}
            app.cookies = data.cookies || {}
            app.user = data.user || {}
            callback && callback(app)
        },
        fail:function(){
            callback && callback(app)
        }
    });
}

function checkSession(callback){
    wx.checkSession({
        success: callback,
        fail: function(){
            //登录态过期, 需要重新请求登陆逻辑 wx.login()
            clearUserInfo()
            callback && callback()
        }
    })
}

function setUserStatus(value, res){
    loginResult.status = value
    loginResult.errorStack = res
}

//主要是openId、unionId 解密完成并关联上qunar用户
function loginAndGetUserInfosReady(func, exParams){
    if(!func){
        return
    }
    var status = loginResult.status
    if (status == 3){
        func( { ret:true, data: getReturnUserInfoDto() } );
    } else if(status == 0 || status == 1 || status == 2 || status == -1){
        waitSyncOpenIdReady(3, func, 5000)
    } else if(status == null){
        //null 表示还没有登录过
        loginAndGetUserInfosFromCacheOrServer(getApp(),null, func, exParams)
    } else {
        var err = loginResult.errorStack || {}
        func( { ret:false, errMsg: (err.message || err.errMsg), stack: err } );
    }
}

//openId\unionId异步获取，timeout:等待最大时间(默认值5000毫秒)
function waitSyncOpenIdReady(readyStatus, callback, timeOut) {
    var startTime = new Date().getTime()
    timeOut = timeOut || 5000;
    var intervalId = setInterval(function() {
        var isTimeout = (new Date().getTime() - startTime >= timeOut)
        if (loginResult.status === readyStatus) {
            clearInterval(intervalId);
            callback && callback({ ret: true , data: getReturnUserInfoDto() });
        } else if(isTimeout){
            clearInterval(intervalId);
            callback && callback( { ret:false, errMsg:"timeout: 请求后端获取openId、unionId 超时" } );
        }
    }, 50);
}
function waitUserReady(func){
    setTimeout(function(){
        loginAndGetUserInfosReady(func)
    },50)
}

function clearUserInfo(){
    var app = getApp()
    if(app){
        //清空app上存储的user cookie
        app.user = {}
        app.cookies = {}
    }
    //清空用户信息缓存
    wx.removeStorageSync("InitUserData")
}

function logout(callback){
    callback = callback || empty
    getUserInfo(function(res){
        var data = res.data || {}
        var qunar = data.qunar || {}
        var exParams = data.exParams || {}
        var params = {
            _q : qunar._q,
            _v : qunar._v,
            _t : qunar._t,
            _s : qunar._s,
            platform : exParams.platform || {},
            exitNow: true
        }
        logoutRequest(params, callback)
    })
}

function logoutRequest(params, callback){
    wx.request({
        url: config.settings.requestDomain + config.service.unBindThirdPlatform,
        method:"POST",
        data: params,
        header: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        success: function(res){
            var result = res.data || {}
            if(result.ret == true){
                unbindQunarUser()
                callback(result)
            } else {
                callback(result)
            }
        },
        fail: function(res) {
            res.ret = false
            callback(res)
        }
    });
}

function unbindQunarUser(){
    updateUserInfo({},true)  //status == 1非qunar用户；status==0 qunar用户
}

//同步登录态数据
function updateUserInfo(data, syncCache){
    if(!data){
        return
    }
    var app = getApp()
    var qunar = app.cookies
    var wechat = app.user
    var newQunar = data.cookies || {}

    qunar._q = newQunar._q || ""
    qunar._v = newQunar._v || ""
    qunar._t = newQunar._t || ""
    qunar._s = newQunar._s || ""

    if(qunar._q){
        qunar.csrfToken = newQunar.csrfToken || ""  //常用联系人使用，放置csrf攻击
        wechat.isQunarUser = true
    } else {
        qunar.csrfToken = ""
        wechat.isQunarUser = false
    }
    qunar._i = qunar._i || newQunar._i || ""                              //设备标量i,不需要每次都变
    qunar.QunarGlobal = qunar.QunarGlobal || newQunar.QunarGlobal || ""   //客户端唯一标识QunarGlobal,不需要每次都变
    qunar.nowTime = data.nowTime || qunar.nowTime
    qunar.token =  data.token || qunar.token                               //???token存在 user?  cookies里？
    qunar.wechatSingle = data.wechatSingle || qunar.wechatSingle           //wechatSingle=true：未在微信公众平台关联(没有跟大公众号做过关联绑定)
    wechat.openId = data.openId || wechat.openId
    wechat.unionId = data.unionId || wechat.unionId || ""
    //只有返回token或者cookies时才设置状态为3：获取成功
    if(data.token || data.cookies){
        setUserStatus(3)
    }

    if(syncCache != false){
        var initUserData = { cookies: qunar, user: wechat }
        wx.setStorage({ key: "InitUserData", data: initUserData})
    }
}
//对外的，数据格式
function getReturnUserInfoDto(){
    var app = getApp()
    return { wechat: app.user, qunar: app.cookies, exParams: loginOpts.exParams ,wx_getUserInfo_deny:loginResult.wx_getUserInfo_deny }
}
function getUserInfo(callback){
    loginAndGetUserInfosReady(callback)
}


//校验登录态：前端校验token q v t是否有效
//1、校验token是否有效
//2、如果有token，校验q v t 是否有效, 如果有效？ 如果无效？
//如果token无线，从新获取code...
//如果token有效，qvt无效，下发qvt
//如果token有效，qvt有效，返回状态码有效
function checkLogin(callback){
    var app = getApp()
    var exParams = loginOpts.exParams
    var qunar = app.cookies || {}
    var params = {}

    params.platform = exParams.platform
    params.token = qunar.token || ""
    params._q = qunar._q || ""
    params._v = qunar._v || ""
    params._t = qunar._t || ""
    params._s = qunar._s || ""
    params._i = qunar._i || ""
    params.autoLogin = true

    callback = callback || empty
    var isQunarUser = app.user.isQunarUser
    request({
        data: params,
        method: "POST",
        header: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        url: getUrl("checkLogin"),
        success:function(res){
            var result = res.data || {}
            var data = result.data || {}
            //token有效
            if(result.ret && data.tokenValid) {
                data.cookies = data.cookies || {}
                updateUserInfo(data)       //token有效，qvts有效或者重新下方qvts、qvts无效时清空qvts
                //如果原来没有qunar关联，checkLogin后关联上了，则表示进行了自动关联
                if(!isQunarUser && app.user.isQunarUser){
                    result.autoQunarLogin = true
                    result.errMsg = loginOpts.autoLoginTip
                }
                var result = { ret: true, data: getReturnUserInfoDto() }
                callback(result)
            } else { //token无效
                callback({ ret:false, errMsg: "::openId、unionid、token失效，校验未通过" })
            }
        },
        fail:function(res){
            callback({ret:false, errMsg: res.errMsg })
        }
    })
}

//1、获取userInfo：getUserInfo（loginAndGetUserInfosReady）
//2、如果userInfo信息token、openid不全？是否要重新登录（loginAndGetUserInfos）？如果登录失败
//3、获取checkLogin（checkLogin）
//4、如果check未通过：自动关联登录（）
//5、如果check未通过：check通过？
//6、判断是否qunar用户，如果不是则引导弹窗
function showQunarUserLogin(options){
    options = options || { isCheckLogin: true , autoLogin: true}
    var app = getApp()
    getUserInfo(function(res){
        var wechat = (res.data && res.data.wechat) || {}
        var unionId = wechat.unionId || ""
        var needLoginAgain = (!res.ret || !unionId)  //unionId为空代码拒绝授权或其他，需要重新获取unionid的场景
        //todo: 需要排除（没有跟大公众号做过关联绑定：微信账号与qunar账号的关联）的情况
        if(needLoginAgain){
            showQunarUserLogin_needLoginAgain(app, options)
            return
        }

        checkLogin(function(res){
            if(!res.ret){
                showQunarUserLogin_needLoginAgain(app, options)
            } else {
                var wechat = (res.data && res.data.wechat) || {}
                if(false === wechat.isQunarUser){
                    showQunarUserLoginPrivate(options)
                    return
                }
                if(res.autoQunarLogin){
                     options.success && options.success(res)
                     options.complete && options.complete(res)
                } else {
                    res.errMsg = "当前已经是登录态"
                    options.success && options.success(res)
                    options.complete && options.complete(res)
                }
            }
        })
    })
}

function showQunarUserLogin_needLoginAgain(app, options){
    //unionId为空则重新登录获取数据，可以优化只获取unionId（需要后端提供根据token、openId、encryptedData、iv解密的接口）
    //var functionDo = unionId ? loginAndGetUserInfos : getWechatUserInfo
    //functionDo(app, null, function(res){
    loginAndGetUserInfos(app, null, function(res){
        var wechat = (res.data && res.data.wechat) || {}
        if(res.ret && wechat.isQunarUser){
            var result = { ret: true, data: res.data, errMsg: loginOpts.autoLoginTip, autoQunarLogin: true }
            options.success && options.success(result)
            options.complete && options.complete(result)
            console.log(result)
        } else if(res.ret){
            showQunarUserLoginPrivate(options)
            return
        }
        if(!res.ret){
            options.fail && options.fail(res)
            options.complete && options.complete(res)
            console.log(res)
        }
    }, false)
}

//qunar用户引导登录
var qunarLoginOptions = {}
function showQunarUserLoginPrivate(options){
    //options.success
    //options.fail
    //options.complete
    var loginId = new Date().getTime()
    qunarLoginOptions[loginId] = options
    if(options.showWay === "popup"){
        options.loginId = loginId
        var page = options.page
        if(page && page.login){
            page.login.show(options)       //login.show(options.page, options)
        } else {
            console("请传递page参数：并且在page里增加变量 page.login = login")
        }
    } else {
        var templateName = options.templateName || ""
        var rules = encodeURIComponent(JSON.stringify(options.rules || []))
        wx.navigateTo({ url: '/common/pages/ucenter/login/login?loginId=' + loginId + '&templateName=' + templateName + '&rules=' + rules})
    }

    var app = getApp()
    app._qunarUserLoginComplete = app._qunarUserLoginComplete || qunarUserLoginComplete
}

function qunarUserLoginComplete(loginId, res){
    var opts = qunarLoginOptions[loginId] || {}
    opts.success = opts.success || empty
    opts.fail = opts.fail || empty
    opts.complete = opts.complete || empty
    res = res || {}
    if(res.ret ){
        //登录成功
        opts.success(res);
    } else {
        opts.fail(res);
    }
    opts.complete(res);
    qunarLoginOptions[loginId] = null
    console.log("qunarUserLoginComplete:ok")
}

function empty(){}

/**
 * 登录模块
 */
function _sendSMSCode(opts, success, fail) {
    var url = getUrl("sendSMSCode")
    opts.action = opts.action || "register"
    opts. type = opts. type || "implicit"
    opts.origin = opts.origin || ( loginOpts.exParams && loginOpts.exParams.platform )
    privateRequest(url, opts, function(res) {
        success && success(res)
        sendWatcher("sendSMS_success")
    }, function(res) {
        console.log("验证码发送失败!")
        fail && fail("网络不稳定，发送验证码失败，请稍候重试")
        sendWatcher("sendSMS_fail")
    })
}
// 登录且登录成功后将qunar账号与微信账号绑定
function qunarLoginAndReigster(opts, success, fail)  {
    var url = getUrl("login")
    //参数处理
    loginAndGetUserInfosReady(function(res) {
        var userInfo = res && res.data
        var qunar = userInfo && userInfo.qunar
        opts.action = opts.action || "register"
        opts.type = opts.type || "implicit"
        opts.origin = opts.origin || ( loginOpts.exParams && loginOpts.exParams.platform )
        opts.token = opts.token || qunar.token
        opts._i = opts._i || qunar._i || ""
        opts.noticeReg = true
        // loginOpts.wechatSingle = qunar.wechatSingle     //wechatSingle:true 表示没有跟大公众号做过关联绑定
        opts.wechatSingle = qunar.wechatSingle     //wechatSingle:true 表示没有跟大公众号做过关联绑定
    })

    privateRequest(url, opts, function(res) {
        //21027
        if(!res.ret){
            success && success(res)
            //验证码错误，清空验证码
            if(res.errcode == 21023 || res.errcode == 21027 || res.errcode == 11005){
                sendWatcher("login_smscode_fail")
                sendWatcher("login_fail")
            }
            return
        }
        //wechatSingle:true 表示没有跟大公众号做过关联绑定, 则不需要做微信账号与qunar账号的关联绑定
        if(opts.wechatSingle){
            updateUserInfoAfterLogin(res)
            success && success(res)
            sendWatcher("login_no_bindthird_wechatSingle")
            return
        }

        var newCookies = (res && res.data) || {}
        var bindParam = {
            platform: opts.origin,
            token: opts.token,
            rob_type: true,
            _i: opts._i || newCookies.icookie || "",
            _q: newCookies.qcookie || "" ,
            _v: newCookies.vcookie || "",
            _t: newCookies.tcookie || "",
            _s: newCookies.scookie || ""
        }
        bindThirdPlatform(bindParam, function(data){
            updateUserInfoAfterLogin(res)
            success && success(res)
            sendWatcher("login_success")
        }, fail)
    }, function(res) {
        console.log("登录失败!")
        fail && fail("网络不稳定，登录失败，请稍候重试")
        sendWatcher("login_fail")
    })
    sendWatcher("login_start")
}
//qunar登录后 更新qvts
function updateUserInfoAfterLogin(res) {
    if(res.ret && res.data){
        var localInfo = {cookies:{}}
        localInfo.cookies._q = res.data.qcookie
        localInfo.cookies._v = res.data.vcookie
        localInfo.cookies._t = res.data.tcookie
        localInfo.cookies._s = res.data.scookie
        localInfo.cookies._i = res.data.icookie
        updateUserInfo(localInfo)
    }
}
// 绑定qunar账号与微信账号
function bindThirdPlatform(opts, success, fail) {
    var url = getUrl("bindThirdPlatform")
    privateRequest(url, opts, function(bindRes) {
        if (bindRes && bindRes.errCode == 12016) {
            opts.robToken = (bindRes.data && bindRes.data.robToken)
            delete opts.token
            delete opts.rob_type
            robAndBind(opts, success, fail)
            return
        }
        if(bindRes.ret){
            success && success(bindRes)
            sendWatcher("bindThird_success")
        } else {
            fail && fail(bindRes.errMsg)
            sendWatcher("bindThird_fail")
        }
    }, function(res) {
        console.log("绑定失败")
        fail && fail("登录失败，攻城狮正在紧急修复，请稍后重试")
        sendWatcher("bindThird_fail")
    })
    sendWatcher("bindThird_start")
}
//抢占
function robAndBind(param, success, fail) {
    var robUrl = getUrl("robAndBind")
    privateRequest(robUrl, param, function(robRes) {
        if(robRes.ret){
            success && success(robRes)
            sendWatcher("robAndBind_success")
        } else {
            fail && fail(robRes.errMsg)
            sendWatcher("robAndBind_fail")
        }
    }, function(res) {
        console.log("抢占失败")
        fail && fail("登录失败，攻城狮正在紧急修复，请稍后重试")
        sendWatcher("robAndBind_fail")
    })
    sendWatcher("robAndBind_start")
}
function privateRequest(url, opts, success , fail ){
    request({
        url: url,
        method: 'POST',
        data: opts || {},
        header: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        success: function(res){
            success && success(res.data)
        },
        fail: function(res){
            fail && fail(res)
        }
    })
}
function getUrl(apiName) {
    return config.settings.requestDomain + config.service[apiName]
}

function sendWatcher(actionType) {
    watcher.click({
        "page": "login",
        "action-type": actionType
    })
}

module.exports = {
    loginInit: loginAndGetUserInfosFromCacheOrServer,
    login: function(callback, exParams){
        loginAndGetUserInfosFromCacheOrServer(getApp(),null, callback, exParams)
    },
    //openIdReady: loginAndGetUserInfosReady,
    logout: logout,
    clearUserInfo: clearUserInfo,
    updateUserInfo: updateUserInfo,
    getUserInfo: loginAndGetUserInfosReady,
    checkLogin: checkLogin,
    showQunarUserLogin: showQunarUserLogin,
    sendSMSCode: _sendSMSCode,
    qunarLoginAndReigster: qunarLoginAndReigster
}
