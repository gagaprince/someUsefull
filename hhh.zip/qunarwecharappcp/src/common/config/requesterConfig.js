module.exports = {
    "default": {
        "params": {
            "bd_origin": "bd_origin",  //渠道
            "bd_source": "bd_source",
            "version": "version",
            "device": "device",
            "platform": "platform",
            "wx_q": "wx_q",
            "wx_v": "wx_v",
            "wx_s": "wx_s",
            "wx_t": "wx_t",
            "wx_i": "wx_i",
            "wx_version": "wx_version",
            "openId": 'openId',
            "unionId": 'unionId'
        }
    },
    "hotel": {
        "constant": {
            "bd_source": "smart_app"
        },
        "params": {
            "bd_source": "bd_source",
            "bd_origin": "bd_origin"
        },
        "header": {
            "openId": "openId",
            "unionId": "unionId",
            "wx-q": "wx_q",
            "wx-v": "wx_v",
            "wx-t": "wx_t"
        }
    }
}