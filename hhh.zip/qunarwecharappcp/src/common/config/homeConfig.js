module.exports = {
    nav: {
        hotel: {
            bizType: "hotel",
            bizTitle: "酒店",
            logoSrc: "/common/images/home/hotel.png",
            illustration: "全网低价/预订保障"
        },
        flight: {
            bizType: "flight",
            bizTitle: "机票",
            logoSrc: "/common/images/home/flight.png",
            illustration: "国内低价机票预订"
        },
        train: {
            bizType: "train",
            bizTitle: "火车票",
            logoSrc: "/common/images/home/train.png",
            illustration: "24h预订/极速抢票"
        },
        bus: {
            bizType: "bus",
            bizTitle: "汽车票",
            logoSrc: "/common/images/home/bus.png",
            illustration: "覆盖全国/官方授权"
        },
        ticket: {
            bizType: "ticket",
            bizTitle: "门票",
            logoSrc: "/common/images/home/ticket.png",
            illustration: "景区/门票/周边游"
        }
    }
}