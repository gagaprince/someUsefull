function Status(root) {
	this._root = root;
    this._root.networkBack = function() {
        wx.navigateBack({
          delta: 1
        })
    };
}

Status.prototype.setData = function(data) {
	this._root.setData(data);
}

Status.prototype.show = function(type, desc) {
    this._isShow = true;
    if (type > 0) {
        var desc = desc || '加载中...';
    }
    this.setData({statusData:{status:type,statusDesc:desc}});
}

Status.prototype.hide = function(){
    this._isShow = false;
   this.setData({statusData:{status:0}});
}

Status.prototype.isShow = function() {
    return this._isShow;
}

module.exports = Status;