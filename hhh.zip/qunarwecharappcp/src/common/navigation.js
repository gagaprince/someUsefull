// 微信 navigation

var noop = function() {};

var isString = function(str) {
    return typeof str === 'string' || str instanceof String;
};

var param2query = function(param) {
    if (typeof param !== 'object') {
        return '';
    }
    var queries = [];
    Object.keys(param).forEach(function(key) {
        queries.push(key + '=' + param[key])
    });
    return queries.join('&');
};


module.exports = {
    // 新开或跳转到已有的页面
    // @param {String} name: 页面唯一标识的名字
    // @param {Object} param:
    //     data: {String | Object} 页面跳转时传递的参数
    //     isDestroy: {Bool} 跳转到已存在的指定 name 的页面，是否销毁中间页
    //     isRedirect: {Bool} 跳转到到下一页，是否redirect
    //     url: {String} 跳转的 URL
    //     success: {Function} 跳转成功回调
    //     fail: {Function} 跳转失败回调
    //     complete: {Function} 跳转结束的回调
    goTo: function(name, param) {
        if (!name) {
			return;
		}
        var param = param || {};
        var data = isString(param.data) ? param.data : param2query(param.data);
		data = data ? '?' + data : '';

        var allPages = getCurrentPages();
        var length = allPages.length;
        var isDestroy = param.isDestroy || false;
        var isRedirect = param.isRedirect || false;

        var exist = allPages.some(function(page) {
            return page.data.pageName === name;
        });
        var lastPage = length > 1 ? allPages[length - 1] : allPages[0];
        var lastPageData = lastPage.data;

        if (exist && isDestroy) {
            this.backTo(name);
        } else if (length < 5 && lastPageData.pageName !== name && !isRedirect) {
            wx.navigateTo({
                url: param.url + data,
                success: param.success || noop,
                fail: param.fail || noop,
                complete: param.complete || noop
            });
        } else {
            wx.redirectTo({
                url: param.url + data,
                success: param.success || noop,
                fail: param.fail || noop,
                complete: param.complete || noop
            });
        }
    },
    navigate: function(param) {
        var allPages = getCurrentPages();
        var length = allPages.length;
        var param = param || {};
        var isRedirect = param.isRedirect || false;
        var data = isString(param.data) ? param.data : param2query(param.data);
		data = data ? '?' + data : '';

        if (length < 5 && !isRedirect) {
            wx.navigateTo({
                url: param.url + data,
                success: param.success || noop,
                fail: param.fail || noop,
                complete: param.complete || noop
            });
        } else {
            wx.redirectTo({
                url: param.url + data,
                success: param.success || noop,
                fail: param.fail || noop,
                complete: param.complete || noop
            });
        }
    },
    redirect: function(param) {
        var param = param || {};
        var data = isString(param.data) ? param.data : param2query(param.data);
		data = data ? '?' + data : '';
        wx.redirectTo({
            url: param.url + data,
            success: param.success || noop,
            fail: param.fail || noop,
            complete: param.complete || noop
        });
    },
    // 回退到指定页面，强制销毁跳转的中间页
    // @param {String} name: 页面唯一标识的名字
    backTo: function(name) {
        if (!name) {
			return;
		}
        var targetCount = 0;
        var allPages = getCurrentPages();
        allPages.forEach(function(page, index) {
            if (page.data.pageName === name) {
                targetCount = targetCount || allPages.length - index - 1;
            }
        });
        wx.navigateBack({
			delta: targetCount
		});
    },
    // 回退
    // @param {Number} delta: 回退层数，默认一层
    back: function(delta) {
        wx.navigateBack({
			delta: delta || 1
		});
    },
    // 回到 home 页
    home: function() {
        wx.navigateBack({
            delta: 5
        });
    }
};
