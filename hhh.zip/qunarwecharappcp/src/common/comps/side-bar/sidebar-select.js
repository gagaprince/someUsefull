/**
 * 介绍: 底部弹出单选框,多用于填单及表单选择较多地方
 *使用方法:
 *     1. 分别在wxml,wxss,js中引入sidebar相应文件,
 *     2. 处理好数据,调用sidebar.showSideBar,传入参数(defaultOptions中非空字符串均为必传项)
 *     3. selectEvent,layerEvent 分别为选中sidebar选项时的事件 及 点击遮罩层事件,确保页面中有对应方法
 *     4. 关闭弹层可使用sidebar.hideSideBar方法
  * @type {*|exports|module.exports}
 */
var extend = require('../../utils/object/extend.js');

module.exports = (() => {
    var defaultOptions = {
        data: {
            title: '', // sidebar title
            tips: '',    // title下方的提示,可见线上填单页房间等选择
            curValue: 'test key 2', // 当前选中值
            curIndex: 1, // 当前选中index
            data: [{ // 渲染数据
                key: 'test key 1',
                value: 'test value 1'
            }, {
                key: 'test key 2',
                value: 'test value 2'
            }, {
                key: 'test key 3',
                value: 'test value 3'
            }]
        },
        showSideBar: true,
        selectEvent: 'select', // 选中事件名称
        layerEvent: 'hideSideBar'  // 点击遮罩层的事件名称
    };

    function showSideBar(options) {

        defaultOptions = extend(defaultOptions, options);

        this.setData({
            sidebar: defaultOptions
        });
    }

    function hideSideBar() {
        setTimeout(function() {
            this.setData({
                "sidebar.showSideBar": false
            });
        }.bind(this), 300);
    }
    return {
        // 展示
        showSideBar: showSideBar,

        // 隐藏
        hideSideBar: hideSideBar
    }

})();
