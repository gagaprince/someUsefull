/**
 * 使用 wiki: http://wiki.corp.qunar.com/pages/viewpage.action?pageId=153148041
 * 网络状态:  加载中，网络错误，没有数据
 *
 * 使用方法
 * var Network = require('../../../common/comps/network/network.js');
 * Network.showNetwork.call(this, { status: 4, loadingDesc: '加载中' }); // 显示
 * Network.hideNetwork.call(this, callback);                                 // 隐藏
 *
 * 在wxss中:
 * @import "../../../common/comps/network/network.wxss";

 * 设置默认状态(可选)
 * data:{
 *     networkData:{
 *         status: 4,                    // { -2:'没有符合条件的搜索结果', -1:'网络连接失败', 0:success,
 *                                       //   1:'toast white', 2:'toast transparent', 3:''qunar加载中mini', 4:'qunar加载中' }
 *         loadingDesc:'加载中...',       // loading描述(可选)
 *         showButton:true               // 显示重新加载 button
 *     }
 * }
 *
 * xml
 * <import src="../../../common/comps/network/network.wxml" />
 * <template is="network" data="{{...networkData}}"/>
 */
var util = require('../../utils/object/object.js');

//  使用 wiki: http://wiki.corp.qunar.com/pages/viewpage.action?pageId=153148041
//  1 toast系统默认加载中 背景白色
//  2 toast系统默认加载中 背景透明
//  3 dots加载中mini 背景透明
//  4 qunar大图骆驼加载中 背景白色
//  0 成功
// -1 网络连接失败
// -2 没有数据
// -3 提示信息

module.exports = (function() {
    var showTime = 0;
    var defaultOptions = {
            width: '100%',
            height: 'auto',
            top: 0,
            bottom: 0,
            status: 4,
            loadingDesc: '努力加载中',
            showButton: true,
            networkRetry: 'networkRetry',
            // showNetwork: true,
            zIndex: '',
            loadingDescColor: '#00BCD4'
        },
        newOptions = {};

    function showNetwork(options) {
        newOptions = JSON.parse(JSON.stringify(defaultOptions));
        util.safeAssign(newOptions, options);
        if (newOptions.status == 1 || newOptions.status == 2) {
            wx.showToast({
                title: newOptions.loadingDesc || '加载中...',
                icon: 'loading',
                duration: 500
            });
            this.setData({
                networkData: newOptions
            });
        } else if (newOptions.status == -3) {
            setTimeout(function () {
                this.setData({
                    networkData: newOptions
                });
                setTimeout(function () {
                    this.setData({ "networkData.status": 0 }); //自动隐藏
                }.bind(this), 2000);
            }.bind(this), 500);
        } else {
            this.setData({
                networkData: newOptions
            });
        }
        showTime = new Date().getTime();
    }

    function hideNetwork(callback) {
        var hideTime = new Date().getTime();
        var me = this,
            status = newOptions.status,
            duration = 800 - (hideTime - showTime);
        var hide = { "networkData.status": 0 };
        if (status == 3 || status == 4) {
            if (duration < 0) {
                me.setData(hide);
                callback && callback();
            } else {
                setTimeout(function() {
                    me.setData(hide);
                    callback && callback();
                }, duration);
            }
        } else if(status > 0 && status < 3){
            wx.hideToast();
            me.setData(hide);
            callback && callback();
        } else {
            me.setData(hide);
            callback && callback();
        }
    }
    return {
        showNetwork,
        hideNetwork
    }
})();
