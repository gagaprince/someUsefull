var NumberInput = function(context, dataKey, max, min, value) {
    var data = context.data[dataKey];
    this._context = context;
    this.dataKey = data.dataKey = dataKey;
    this.max = data.max = max || 10;
    this.min = data.min = min || 0;
    this.value = data.value = value || 0;
    this[dataKey] = data;
}

NumberInput.prototype._changeValue = function(type) {
    var _number = this._context.data && this._context.data[this.dataKey] || {};
    var data = 0;
    if (type === 'plus') {
        data = _number.value < _number.max
            ? ++(_number.value)
            : _number.max;
    } else if (type === 'minus') {
        data = _number.value > _number.min
            ? --(_number.value)
            : _number.min;
    }
    return this._setValue(data);
};

NumberInput.prototype._setValue = function(value) {
    var _value = parseInt(value, 10);
    var _number = this._context.data && this._context.data[this.dataKey] || {};
    if (isNaN(_value)) {
        _value = 0;
    }
    _value = _value < _number.max
        ? _value
        : _number.max;
    _value = _value > _number.min
        ? _value
        : _number.min;

    _number.value = _value;

    var data = {};
    data[this.dataKey] = _number;
    this._context.setData(data);
    return _value;
}

NumberInput.prototype.updateValue = function(e) {
    var target = e.target || {};
    var value = parseInt(e.detail && e.detail.value, 10);
    var type = target.dataset && target.dataset.type;
    if (type) {
        return this._changeValue(type);
    } else if (!isNaN(value)) {
        return this._setValue(value);
    }
}

NumberInput.prototype.getValue = function() {
    var _number = this._context.data && this._context.data[this.dataKey] || {};
	return _number.value || 0;
}

NumberInput.prototype.getMax = function() {
	return this.max;
};

NumberInput.prototype.getMin = function() {
	return this.min;
};

module.exports = NumberInput;
