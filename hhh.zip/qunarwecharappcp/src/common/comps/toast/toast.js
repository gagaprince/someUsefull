/**
 * 1.wxml,wxss,js文件 按照路径规则引入toasttoast （wxml <template is="toast" data="{{...toastData}}" />）
 * 2.js page -> data 定义对象如（extendClass必须为hide）：
 *      toastData: {
 *          extendClass: "hide",
 *          content: "我是toast"
 *      }
 * 3.调用js 调用toast.show(page, "toast", toastObj)  若不传toastObj,给默认提示“异常” 
 */
module.exports = {
    _init: function() {
        this.defaultToastObj = {
            extendClass: "",
            content: "异常"
        }
    },
    /**
     * page 页面对象， toastName 绑定在页面的toast对象的名字， msg 为需要提示的消息
     */
    show: function(page, toastName, msg) {
        var that = this
        var renderToast = {}
        renderToast[toastName] = {}
        renderToast[toastName].extendClass = "" 
        renderToast[toastName].content = msg
        page.setData(renderToast)
        setTimeout(function() {
            that._hide(page, toastName, renderToast)
        }, 2000);
    },
    _hide: function(page, toastName, renderToast) {
        renderToast[toastName].extendClass = "hide"
        renderToast[toastName].content = ""
        page.setData(renderToast)
    }
}

