
var config = require("./config.js")
var requestManager = require("./requester/requestManager.js");
var utils = require("./utils.js");

var name = 'wechatqunarapp';
var nameBeta = name + '_beta';

var globalParam = {
    aid: 3,
    an: name,
    curl: name,
    pid: 233333
}

function getParams(query, wType){
    var app = getApp()
    var deviceInfo = app.globalData.deviceInfo.isIOS ? '_wx_iOS' : '_wx_android';
    var model = app.globalData.deviceInfo.model || "";
    var platform = app.globalData.deviceInfo.platform || "";
    var wx_version = app.globalData.deviceInfo.version || "";

    var _from = utils.bdOrigin.getV() || "common" //渠道
    var q = globalParam;
    if (global.__BETA__) {
        q.an = nameBeta;
        q.curl = nameBeta;
    } else {
        q.an = name;
        q.curl = name;
    }
    q.aid = (wType == null? 3 : wType);     //0:pv, 3:click
    q.sc = 200;
    q._t = new Date().getTime();
    query = query||{};
    query.from = query.from || _from;
    query.device =  query.device || deviceInfo;
    query.version = config.version || '0';
    query.model = model;
    query.platform = platform;
    query.wx_version = wx_version;

    if(app.user){
        query.openId = app.user.openId;
        query.unionId = app.user.unionId;
    }

    q.ctx = JSON.stringify(query);
    return q
}
function getCookies(){
    var app = getApp()
    var cookies = [
        "QunarGlobal=" + app.cookies.QunarGlobal,
        "_q="+ (app.cookies._q || ("U." + app.user.openId))
    ]
    return cookies.join(";")
}
function send(query, wType) {
    try{
        var q = getParams(query, wType)
        requestManager.sendRequest({
            header: { Cookie: getCookies()},
            method: "GET",
            url: config.service.watcherUrl,
            data: q,
            priority: 1001,
            isLimitRequest: true
        })
    } catch(ex){
        console.error(ex);
    }
}
function click(query) {
    //send(query, 3)
    setTimeout(function(){
        send(query, 3)
    }, 0)
}
//delay: 延迟发送，默认1s
function pv(query, delay){
    setTimeout(function(){
        send(query, 0)
    }, (delay || 1000))
}
module.exports = {
    click: click,
    pv: pv
}
