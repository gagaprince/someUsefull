//1、调用后端接口获取支付方式信息
//2、如果是多种展示支付方式、如果只有一种微信则直接支付
//3、
var watcher = require("./watcher.js") //埋点
var payOptions
var submitting = false
var isDevtools = undefined

function init(options){
    if(submitting){
        return;
    }
    submitting = true                               //防止重复提交

    payOptions = options || {}
    payOptions.success = payOptions.success || empty
    payOptions.fail = payOptions.fail || empty
    payOptions.cancel = payOptions.cancel || empty
    payOptions.complete = payOptions.complete || empty
    payOptions.beforeOpen = payOptions.beforeOpen || empty
    payOptions.afterOpen = payOptions.afterOpen || empty

    getPayInfos(options.cashierUrl, { p: "pad" })   //以Json方式返回
    sendWatcher("pay_start")
}
//进入收银台处理--获取多种支付方式配置
function getPayInfos(url, data){
    request(url, data, getPayInfosCallback, function() { sendWatcher("getPayInfos_fail") })
}

function empty(){ }
function payFail(res){
    console.log(res)
    submitting = false
    payOptions.fail(res);
    payOptions.complete(res);
}

function request(url, param, successCallback, failCallBack){
    wx.request({
        data: param,
        url: url,
        method: "GET",
        header: { Cookie: getCookies()},
        success: function(res){
            var data = res.data || {}
            if(data.status == 0){
                successCallback && successCallback(data);
            } else {
                if(data.alertInfo && data.alertInfo.showMsg) {
                    showModal(data.alertInfo.showMsg, data)
                    sendWatcher("pay_intercepter")
                } else {
                    showModal(data.message, data)
                }
            }
        },
        fail: function(res) {
            payFail && payFail(res)
            failCallBack && failCallBack(res)
        }
    })
}
function getCookies(){
    var app = getApp()
    var cookies = app.cookies || {}
    var cookies = [
        "_q=" + cookies._q,
        "_v=" + cookies._v,
        "_t=" + cookies._t,
        "_s=" + cookies._s
    ]
    return cookies.join(";")
}
//多种支付方式处理
function getPayInfosCallback(data){
    //如果只有一种微信支付方式则自动提交、如果有多种则跳转到支付方式页面
    var payInfo = data.dataObj || {}
    var payTypeNames = payInfo.index || []

    var hasWeixinPay = (payTypeNames.indexOf("weixinJSPay") >= 0) //包含微信支付方式
    if(hasWeixinPay){
        weixinJSPaySubmitPay(payInfo, "weixinJSPay")
        sendWatcher("weixinJSPay")
        return
    } else {
        showModal("支付方式配置不正确", data)  // "只支持微信支付，赞不支持其它支付方式"
        sendWatcher("not_weixinJSPay")
    }
}
function getSubmitPayData(payInfo, payTypeName){
    var payTypeData = payInfo.bankList[payTypeName] || {}
    var data = {
        orderNo: payInfo.orderNo,
        token: payInfo.token,
        avers: payInfo.avers,
        vid: payInfo.vid,
        sign: payTypeData.sign,
        venderId: payTypeData.venderId,
        touchPayUrl: payTypeData.touchPayUrl,
        openId: payOptions.openId,
        p:"pad"
    }
    return data
}

//微信支付后端请求处理--下单
function weixinJSPaySubmitPay(payInfo, payTypeName){
    var data = getSubmitPayData(payInfo, payTypeName)
    var url = data.touchPayUrl
    request(url, data, weixinJSPaySubmitCallback, function() { sendWatcher("weixinJSPaySubmitPay_fail") })
}

//呼起微信支付
function weixinJSPaySubmitCallback(data){
    submitting = false
    var options
    try{
        options= (data.payURL && JSON.parse(data.payURL)) || {}
    } catch(ex){
        showModal("JSON.parse(" + data.payURL + ")解析出错", ex)
        sendWatcher("weixinJSPay_json_parse_error")
        return
    }

    options.success = function(res){
        payOptions.success(res);
        sendWatcher("weixinJSPay_success")
        console.log("success-----wx.requestPayment")
    }
    options.fail = function(res){
        if(res.errMsg === "requestPayment:fail cancel"){
            payOptions.cancel(res)
            sendWatcher("weixinJSPay_cancel")
            console.log("cancel-----wx.requestPayment")
        } else {
            payOptions.fail(res)
            sendWatcher("weixinJSPay_fail")
            console.log("fail-----wx.requestPayment")       
        }
    }
    options.complete = function(res){
        payOptions.complete(res)  //res.errMsg == "requestPayment:cancel"
        sendWatcher("pay_complete")
        console.log("complete-----wx.requestPayment:" + JSON.stringify(res))
    }
    if(payOptions.beforeOpen() === false)
        return
    wx.requestPayment(options)
    if(payOptions.afterOpen() === false)
        return
}

function sendWatcher(actionType) {
    watcher.click({
     "page": "pay",
     "action-type": actionType
    })
}

function showModal(content, result){
    submitting = false
    wx.showModal({
        title: '支付提示',
        content: content + "\n" || "",
        showCancel:false,
        confirmColor:"#00bcd4",
        success: function() {
            result.errMsg = (result.errMsg || result.message)
            payFail(result)
        }
    })
}

module.exports = {
    openCashier: init
}
