const ONE_DAY = 86400000; // 一天的毫秒数
const BD_ORIGIN_OUT_DAY = 7; // bd_origin 过期天数
const BD_ORIGIN_MAX_DATE = ONE_DAY * BD_ORIGIN_OUT_DAY; // bd_origin 过期毫秒数
const BD_ORIGIN_DEFAULT = 'common'; // bd_origin 默认值，该值永不过期
const BD_ORIGIN_STORAGE = 'bd_origin';

const SHARE_TITLE_DEFAULT = '去哪儿旅行';
const SHARE_DESC_DEFAULT = '总有你要的低价';
const SHARE_URL_DEFAULT = '/home/pages/index';
const SHARE_JUMP_NAVIGATE = 'navigateTo';

let bdOrigin = {
    /**
     * 设置bd_origin
     * @param  {String} bdOrigin 将要设置的bd_origin
     * 如果没传bdOrigin，则存为默认值，该值永不过期
     * 如果传过来bdOrigin，不管已有的bd_origin 和传过来的是不是一样，都会更新生命周期
     * 理论上下单之前的页面都应该在onLoad的时候调用该函数
     * utils.bdOrigin.setV(params.bd_origin);
     */
    setV: (bdOrigin) => {
        // 如果没有传过来bdOrigin，则为默认值，默认值永不过期。
        let originObj = {};
        if (!bdOrigin) {
            bdOrigin = BD_ORIGIN_DEFAULT;
        } else {
            var currentTime = new Date().getTime();
            originObj.outDateTime = currentTime + BD_ORIGIN_MAX_DATE;
        }
        originObj.bdOrigin = bdOrigin;
        let bdOriginContent = JSON.stringify(originObj);
        try {
            wx.setStorageSync(BD_ORIGIN_STORAGE, bdOriginContent);
        } catch (e) {
            throw e;
        }
    },
    /**
     * 获取bd_origin
     * @return {String} bd_origin
     * 1. 默认值 -> 返回默认值
     * 2. 非默认值
     *     1. 未过期 -> 返回
     *     2. 过期 -> 返回默认值
     * 需要获取的时候调用。
     */
    getV: () => {
        let bdOriginContent, originObj, bdOrigin;
        let currentTime = new Date().getTime();
        try {
            bdOriginContent = wx.getStorageSync(BD_ORIGIN_STORAGE);
        } catch (e) {
            throw e;
        }
        try {
            originObj = JSON.parse(bdOriginContent);
        } catch (e) {
            originObj = {
                bdOrigin: BD_ORIGIN_DEFAULT
            };
        }

        let isDefault = originObj.bdOrigin && originObj.bdOrigin === 'common';

        if (isDefault) {
            bdOrigin = originObj.bdOrigin;
        } else if (originObj.outDateTime && originObj.outDateTime > 0) {
            let isOutDate = currentTime > originObj.outDateTime;
            if (isOutDate) {
                bdOrigin = BD_ORIGIN_DEFAULT;
            } else {
                bdOrigin = originObj.bdOrigin;
            }
        } else {
            bdOrigin = BD_ORIGIN_DEFAULT;
        }
        return bdOrigin;
    }
};

let share = {
    /**
     * 获取分享参数
     * @param  {String} options.title    分享的title 默认为去哪儿旅行
     * @param  {String} options.url      将当前页面，以及参数拼好
     * @param  {String} options.jumpType 跳转方式，有navigateTo和redirectTo两种
     * @return {Object}                  返回title，以及shareUrl
     *
     * 这样做是为了分享出去的页面，能够从首页跳转，然后可以返回首页用到其他的入口。不至于返回的时候直接关闭小程序。
     * url比如：'/common/pages/search/index?from=home&bizType=train'
     */
    getParam: ({url, jumpType, title = SHARE_TITLE_DEFAULT, desc = SHARE_DESC_DEFAULT}) => {
        let path,
            homeUrl = SHARE_URL_DEFAULT + '?bd_origin=' + bdOrigin.getV();

        if (jumpType) {
            '&' + jumpType + '=';
        }

        if (!url) {
            path = SHARE_URL_DEFAULT;
        } else {
            jumpType = jumpType || SHARE_JUMP_NAVIGATE;
            homeUrl += '&' + jumpType + '=';
            path = homeUrl + encodeURIComponent(url);
        }
        return { title, path, desc }
    }
};

var debounce = function(func, wait, immediate) {
    var timeout, args, context, timestamp, result;

    var later = function() {
        // 据上一次触发时间间隔
        var last = new Date() - timestamp;

        // 上次被包装函数被调用时间间隔last小于设定时间间隔wait
        if (last < wait && last > 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
            if (!immediate) {
                result = func.apply(context, args);
                if (!timeout) {
                    context = args = null;
                }
            }
        }
    };

    return function() {
        context = this;
        args = arguments;
        timestamp = new Date();
        var callNow = immediate && !timeout;
        // 如果延时不存在，重新设定延时
        if (!timeout) {
            timeout = setTimeout(later, wait);
        }
        if (callNow) {
            result = func.apply(context, args);
            context = args = null;
        }

        return result;
    };
};

module.exports = { bdOrigin, share, debounce };
