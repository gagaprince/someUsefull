var RequestManager = {
    paddingCount: 0,
    waiting: [],
    priorities: {
        HIGH: 500,
        NORMAL: 750,
        LOW: 1000
    },
    limitRequesting: false,
    limitRequests: [],
    sendRequest: function(reqObj) {
        var me = this;
        // reqObj.property
        // 标记是否为 watcher 请求 或者 img 请求，如果是这种请求，那么同时最多请求一次。

        reqObj.isLimitRequest = reqObj.isLimitRequest || false;

        if (reqObj.isLimitRequest) {
            if (!me.limitRequesting) {
                me.limitRequesting = true;
                me.limitRequests.shift();
                me.request(reqObj);
            } else {
                me.limitRequests.push(reqObj);
            }
        } else {
            me.request(reqObj);
        }
    },
    request: function (reqObj) {
        var me = this;
        reqObj.priority || (reqObj.priority = me.priorities.NORMAL);
        if (me.paddingCount < 5) {
            var complete = reqObj.complete;
            reqObj.complete = function(args) {
                if (reqObj.isLimitRequest) {
                    me.limitRequesting = false;
                }
                me.paddingCount -= 1;
                me.handleWaitings();
                complete && complete(args);
            };
            wx.request(reqObj);
            me.paddingCount += 1;
        }
        else {
            me.waiting.push(reqObj);
        }
    },
    handleWaitings: function() {
        var me = this;
        me.waiting = me.waiting.concat(me.limitRequests);
        me.waiting = me.waiting.sort(function(a, b) {
            return (a.priority - b.priority);
        });
        me.limitRequests = [];
        var reqObj = me.waiting.shift();
        reqObj && me.request(reqObj);
    }
};

module.exports = RequestManager;
