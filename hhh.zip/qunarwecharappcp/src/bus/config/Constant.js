var CommonSearchConfig = require('../../common/pages/search/config.js');

/** 事件处理事件名 */
var BUS_EVENT_NAME = {
    // 搜索列表页点击进入日历,日历发生更改
    SEARCHLIST_DATE_CHANGE: CommonSearchConfig.event.SEARCHLIST_DATE_CHANGE,

    /** 完成保险选择 */
    DID_FINISH_SELECT_INSURANCE: "BusDidFinishSelectInsurance",

    /** 选择乘客 */
    DID_CHOOSE_PASSENGERS: "BusDidChoosePassengers",

    /** 修改搜索参数 */
    DID_CHANGE_SEARCH_PARAM: "BusDidChangeSearchParam",

    /** DID */
    DID_BOOKING_PAGE_BACK_PARAM: "BusDisBookingPageBackParam",

    /** 首页面切换Tab */
    DID_SWITCH_TAB: "Home_ActivateTab"
};

/** 数据存储Key */
var BUS_CACHE_KEY = {
    /** 出发日期 */
    DEP_DATE: "BusDepDate",

    // 搜索列表页日期改变后存储的缓存key,
    // 该Key公共首页也需要,因此不可随意更改。
    SEARCH_LIST_DEP_DATE: "SEARCHLIST_DATE_CHANGE_BUS",

    /** 填单页数据，即 Booking data */
    DATA_BOOKING: "BusDataBooking",

    /** 保险数据 */
    DATA_INSURANCE: "BusDataInsurance"
};

var BUS_FAQ_TYPE = {
    /** 取票、退票须知  */
    TGQ: 1,

    /** 站站搜索首页提示,黄条提示 */
    STATION_TO_STATION_HOME_TIPS: 2,

    /** 保险说明 */
    INSURANCE_NOTICE: 3,

    /** 赠险说明 */
    PRESENT_INSURANCE_NOTICE: 4,

    /** hxa_fpta */
    HXAA_FPTA: 5,

    /** 预售期与预约期《预售期与预约》 */
    PRE_SALE_APPOINT: 6,

    /** 保险委托协议 */
    INSURANCE_AGREEMENT: 7,

    /** 关于我们  */
    ABOUT_US: 9,

    /** 旅游险说明 */
    TRAVEL_INSURANCE_NOTICE: 11,

    /** 校园巴士协议 */
    COMPUS_BUS_AGREEMENT: 18
};

var BUS_CONSTANT_VALUE = {
    TICKET_GET_REBACK: '取票/退票须知'
};

var BUS_PARAM_KEYS = {
    BOOKING_PARAMS: {
        coach: ['checi', 'chexing', 'depCity', 'depStation', 'depDate',
            'depTime', 'arrCity', 'arrStation', 'arrTime', 'ticketPrice',
            'coachFrom', 'servicePrice', 'md5str', 'shiftType', 'price'],
        agent: ['domain'],
        client: ['index', 'section'],
        extParam: null
    }
};

var WatcherValue = {
    Booking: {
        page: 'bus_booking',
        action: {
            saveOrder: 'save_order',
            saveOrderSuccess: 'save_order_success',
            paySuccess: 'pay_success',
            pay: 'pay',
            enterInsurance: 'go_insurance',
            getTicketClicked: 'get_ticket_clicked',
            showPriceDetail: 'show_price_detail',
            optionCoachClicked: 'option_coach_clicked'
        }
    },
    Faq: {
        page: 'bus_faq',
        action: {
            close: 'close_clicked'
        }
    },
    Insurance: {
        page: 'bus_insurance',
        action: {
            selectedNothing: 'selected_no',
            accidentInsuranceClicked: 'accident_insurance_clicked',
            faqLayerClicked: 'faq_layer_clicked',
            protocolClicked: 'protocol_clicked'
        }
    },
    OrderDetail: {
        page: 'bus_order_detail',
        action: {
            pay: 'pay',
            paySuccess: 'pay_success',
            payRightTopClicked: 'pay_right_top_clicked',
            returnCoachClick: 'return_coach_clicked',
            cancelOrderClicked: 'cancel_order_clicked',
            payBottomClicked: 'pay_bottom_clicked',
            showDetail: 'show_detail'
        }
    },
    SearchList: {
        page: 'bus_search_list',
        action: {
            enterBooking: 'go_booking',
            noData: 'no_data',
            bookingDiscount: 'booking_discount'
        }
    }
};

module.exports = {
    BUS_EVENT_NAME: BUS_EVENT_NAME,
    BUS_CACHE_KEY: BUS_CACHE_KEY,
    BUS_FAQ_TYPE: BUS_FAQ_TYPE,
    BUS_CONSTANT_VALUE: BUS_CONSTANT_VALUE,
    BUS_PARAM_KEYS: BUS_PARAM_KEYS,
    WatcherValue: WatcherValue
};
