var service = {
    // 获取openid 和 获取qunar用户信息
    S2S: "/weChat/coach/search/s2s.json",

    // Bus get order fill data
    FILL_ORDER: "/weChat/coach/booking/readyTicket.json",

    // Bus build a order
    BUILD_ORDER: "/weChat/coach/saveOrder/do.json",

    // Bus FAQ
    FAQ: '/weChat/coach/faq/do.json',

    // Bus order detail
    ORDER_DETAIL: '/weChat/coach/orderDetail/do.json',

    // Bus suggest
    SUGGEST: '/weChat/coach/suggest/do.json',

    // Bus city list
    CITY_LIST: '/weChat/coach/cityList/do.json',

    // Bus cancel order
    CANCEL_ORDER: '/weChat/coach/orderDeal/do.json',

    // 请求收银台
    PAY_METHOD: 'h5/train/TrainPayMethod'
};

module.exports = service;
