// contact.js
var contactList = [];

Contact.prototype.initContact = function () {
    contactList = [];

    var autoContact = this.getAutoFillContactData();
    var passengerList = this.getPassengerList();

    // 如果自动填单数据不为空，且乘客列表不包含该联系人，则将其加入到列表首部。
    // 自动填单的联系人需要通过验证。
    var index = isCombineContactInPassengers(autoContact, passengerList);
    if (index == -1) {
        autoContact && verifyContact(autoContact) && contactList.push(autoContact);
    }

    // 将乘客列表加入到联系人列表；
    // 如果乘客列表从取票人列表第一个位置开始，则第一个设置为选中。
    if (passengerList) {
        for (var i = 0; i < passengerList.length; i++) {
            var c = passenger2Contact(passengerList[i]);
            markSelected(c, (index != -1 && i == index));
            c && contactList.push(c);
        }
    }

    // Finally, add other type contact
    var oc = createDefaultContact();
    markOther(oc, true);
    markSelected(oc, contactList.length == 0);
    contactList.push(oc);

    this.syncRenderData();
};

Contact.prototype.syncRenderData = function () {
    this._selectedContact = this.getSelectedContact();
    var contactData = {
        contactList: contactList,
        selectedContact: this._selectedContact
    };
    this._root_.setData({
        contactData: contactData
    });
};

Contact.prototype.getSelectedContact = function () {
    var selectedContact = null;
    var isPassengerIndex = getIndexOfFirstPassenger(contactList);

    for (var i = 0; i < contactList.length; i++) {
        var contact = contactList[i];
        if (contact.selected) {
            selectedContact = contact;
        }

        // mark showName for every item
        initShowName(contact, "乘客" + (i - isPassengerIndex + 1));
    }
    !selectedContact && (selectedContact = markSelected(contactList[0], true));
    return selectedContact;
};

Contact.prototype.selectedContact = function (selectedIndex) {
    contactList[selectedIndex].selected = true;
    for (var i = 0; i < contactList.length; i++) {
        (selectedIndex != i) && (contactList[i].selected = false);
    }
    this.syncRenderData();
};

Contact.prototype.syncAddPassenger = function () {
    var indexOfFirstPassenger = getIndexOfFirstPassenger(contactList);
    var passengerList = this.getPassengerList();
    var contact = passenger2Contact(passengerList[passengerList.length - 1]);
    contactList.splice(indexOfFirstPassenger + passengerList.length - 1, 0, contact);
    this.syncRenderData();
};

Contact.prototype.syncRemovePassenger = function (passengerIndex) {
    var indexOfFirstPassenger = getIndexOfFirstPassenger(contactList);

    // 删除contactList的passengerIndex+indexOfFirstPassenger位置的元素
    contactList.splice(Number(passengerIndex) + indexOfFirstPassenger, 1);
    this.syncRenderData();
};

Contact.prototype.syncUpdatePassenger = function (passengerIndex) {
    var indexOfFirstPassenger = getIndexOfFirstPassenger(contactList);
    var passengerList = this.getPassengerList();
    var p = passengerList[passengerIndex];

    // 更新contactList的passengerIndex+indexOfFirstPassenger位置的元素
    // 此时执行passenger到contact的数据拷贝时，需要覆盖掉phone的数据，
    // 由于contact的输入比passenger的输入只多手机号，因此先把手机号存在passenger中。
    var contact = contactList[Number(passengerIndex) + indexOfFirstPassenger];
    p.phone = contact.phone;
    passenger2Contact(p, contact);

    this.syncRenderData();
};

Contact.prototype.syncContactInput = function (type, content) {
    if (type == "name") {
        this._selectedContact.name = content;
    } else if (type == "tel") {
        this._selectedContact.phone = content;
    } else if (type == "idcard") {
        content = content.toLocaleUpperCase();
        this._selectedContact.certNo = content;
    }
    this.syncRenderData();
};

Contact.prototype.getPassengerList = function () {
    var _passenger = this._passenger;
    if (_passenger) {
        return _passenger.getPassengerList();
    }
    return null;
};

Contact.prototype.getAutoFillContactData = function () {
    var autoContact, autoFillData;
    var orderResult = this.getData().orderResult;
    orderResult && (autoFillData = orderResult.autoFillData);

    autoFillData && (autoContact = autoFillData.ticketPerson);
    autoContact && (autoContact.passengers = null);

    markPassenger(autoContact, false);
    markSelected(autoContact, true);
    markOther(autoContact, false);
    return autoContact;
};

Contact.prototype.getData = function () {
    return this._root_.data;
};

//--Bellow are others methods beyond Contact object.--//
function createDefaultContact() {
    var c = {
        name: '',
        certType: 0,
        certNo: '',
        passengerType: 1, // 乘客类型(1:成人 2:儿童)	 	
        phone: '',
        insurance: null, // 用户选择的保险(没买保险传null)
        travelInsurance: null, // 用户选择的旅游险(没买保险传null) 
        surname: '',
        givenName: '',
        gender: 3, // 1:男 2:女 3:未知
        birthday: '',
        validDay: '',
        nationality: ''
    };
    markPassenger(c, false);
    markSelected(c, false);
    markOther(c, false);
    return c
}

/**
 * 乘客列表内部是否包含自动填单的联系人。
 * 判断规则：
 * 1.身份证号码一样，则认为是一样的；
 * 2.身份证号码为空，名字一样，也认为是一样的。
 * 如果乘客列表包含取票人，则返回包含的index，否则返回-1。
 * @return index-包含；-1-不包含。
 */
function isCombineContactInPassengers(contact, passengerList) {
    var index;
    if (!passengerList || !contact) {
        index = -1;
        return index;
    }
    for (var i = 0; i < passengerList.length; i++) {
        var ps = passengerList[i];
        if (ps.certNo && ps.certNo != '' && ps.certNo == contact.certNo) {
            !ps.phone && (ps.phone = (contact.phone ? contact.phone : ''));
            index = i;
        }
        if (ps.name && ps.name != '' && ps.name == contact.name) {
            !ps.phone && (ps.phone = (contact.phone ? contact.phone : ''));
            index = i;
        }
    }
    return index;
}

function passenger2Contact(passenger, contact) {
    // passenger与contact数据结构一样，因此，直接拷贝。
    contact = contact || {};
    for (var key in passenger) {
        contact[key] = passenger[key];
    }
    !contact.phone && (contact.phone = '');
    markPassenger(contact, true);
    markOther(contact, false)
    return contact;
}

function markPassenger(contact, isPassenger) {
    contact && (contact.isPassenger = isPassenger);
    return contact;
}

function markSelected(contact, isSelected) {
    contact && (contact.selected = isSelected);
    return contact;
}

function markOther(contact, isOther) {
    if (contact) {
        contact.isOther = isOther;
        contact.showName = isOther ? "其它" : "";
    }
    return contact;
}

function initShowName(contact, showName) {
    if (!contact) {
        return;
    }
    if (contact.isOther) {
        // DO NOTHING
        // 因为初始化时已经设置过了
    } else if (contact.isPassenger) {
        contact.showName = contact.name ? contact.name : showName;
    } else {
        contact.showName = contact.name;
    }
}

function getIndexOfFirstPassenger(contactList) {
    if (contactList && (contactList instanceof Array)) {
        for (var i = 0; i < contactList.length; i++) {
            if (contactList[i].isPassenger) {
                return i;
            }
        }
    }
    return 0;
}

/**
 * 验证联系人是否有效。
 * 验证规则：
 * 1.name为空，无效；
 * 2.phone为空，无效。
 */
function verifyContact(contact) {
    return (contact && contact.name && contact.name.length > 0)
        && (contact.phone && contact.phone.length > 0);
}

/**
 * @param root The fillorder.js module
 * @param passenger The Passenger.js module
 * @constructor
 */
function Contact(root, passenger) {
    this._root_ = root;
    if (passenger) {
        this._passenger = passenger;
    } else {
        this._passenger = this._root_._passenger;
    }
}

module.exports = Contact;