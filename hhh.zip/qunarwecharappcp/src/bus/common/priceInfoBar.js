// priceInfoBar.js
var Constant = require('../config/Constant.js');
var ParamUtil = require('../utils/ParamUtil.js');
var Watcher = require('../../common/watcher.js');

var BusFAQType = Constant.BUS_FAQ_TYPE;
var ConstantValue = Constant.BUS_CONSTANT_VALUE;
var Booking = Constant.WatcherValue.Booking;

function PriceInfoBar(root) {
    this._root_ = root;
}

PriceInfoBar.prototype.processItemTap = function (index) {
    var priceInfoList = this.getPriceInfoBarData();
    var coach = this.getCoachData();
    if (!priceInfoList || !coach) {
        return;
    }

    for (var i = 0; i < priceInfoList.length; i++) {
        if (index == i && priceInfoList[i].itemType == "notice") {
            // 进入取票/退款 FAQ PAGE
            wx.navigateTo({
                url: '../faq/faq?' + ParamUtil.stringifyURLParam({
                    depDate: coach.depDate || '',
                    md5str: coach.md5str || '',
                    type: BusFAQType.TGQ,
                    title: ConstantValue.TICKET_GET_REBACK
                })
            });
            Watcher.click({
                "page": Booking.page,
                "action-type": Booking.action.getTicketClicked
            });
            break;
        }
    }
};

PriceInfoBar.prototype.syncRenderData = function () {
    var priceInfoList = getPriceInfoList(this.getData());
    this.setData(priceInfoList);
};

PriceInfoBar.prototype.setData = function (data, complete) {
    var priceInfoList = this.getData("priceInfoList") || [];

    for (var key in data) {
        priceInfoList[key] = data[key];
    }

    this._root_.data.priceInfoList = priceInfoList;
    this._root_.setData({
        priceInfoList: priceInfoList
    });

    complete && complete();
};

PriceInfoBar.prototype.getPriceInfoBarData = function () {
    if (!this._root_.data.priceInfoList) {
        this.syncRenderData();
    }
    return this._root_.data.priceInfoList;
};

PriceInfoBar.prototype.getCoachData = function () {
    var data = this.getData(),
        orderResult,
        coach;
    data && (orderResult = data.orderResult);
    orderResult && (coach = orderResult.coach);
    return coach;
};

PriceInfoBar.prototype.getData = function (key) {
    return key ? this._root_.data[key] : this._root_.data;
};

/**
 * 获取PriceInfoList列表。
 * @param data FillOrder页面的根data。使用this.getData()获取。
 */
function getPriceInfoList(data) {
    var orderResult = data.orderResult;
    if (orderResult && orderResult.coach) {
        return createInfoList(orderResult.coach.ticketPrice, orderResult.coach.servicePrice);
    }
    return null;
}

/**
 * itemType一共有3个值：
 * 1.'price'
 * 2.'service'
 * 3.'notice'
 */
function createInfoItem(name, price, priceSuff, desc, itemType) {
    return {
        name: name,
        price: (price && (price > 0)) ? "￥" + price : "",
        priceSuff: priceSuff,
        desc: desc,
        itemType: itemType
    };
}

function createInfoList(ticketPrice, servicePrice) {
    var infoList = [];
    if (ticketPrice && ticketPrice > 0) {
        infoList.push(createInfoItem("票价", ticketPrice, "", "", "price"));
    }
    if (servicePrice && servicePrice > 0) {
        infoList.push(createInfoItem("服务费", servicePrice, "/人", "", "service"));
    }
    // "取票/退票须知"
    infoList.push(createInfoItem("", "", "", ConstantValue.TICKET_GET_REBACK, "notice"));
    return infoList;
}

module.exports = PriceInfoBar;