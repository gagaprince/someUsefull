// Requester.js
var Requester = require('../../common/requester.js');
var Config = require('../config/config.js');

function request(obj) {
    // Bus needs to assemble the b&c param.
    obj.data = {
        b: obj.data,
        c: Requester.getParamC()
    };
    Requester.request(obj);
}

module.exports = {
    request: request,
    service: Config
};
