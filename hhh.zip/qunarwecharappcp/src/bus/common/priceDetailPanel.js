/**
 * Created by ZQ on 2017/3/19.
 */
var Watcher = require('../../common/watcher.js');
var Constant = require('../config/Constant.js');
var Booking = Constant.WatcherValue.Booking;

function PriceDetailPanel(root) {
    this._root_ = root;
    if (!root.showPriceDetail) {
        root.showPriceDetail = this.showPriceDetail.bind(this);
    }

    var animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease'
    });
    this.animation = animation;
    this._showStatus = true;
}

PriceDetailPanel.prototype.getShowStatus = function () {
    return this._showStatus;
};

PriceDetailPanel.prototype.getTotalPrice = function () {
    var passengerCount = this.getPassengerCount();
    if (passengerCount < 1) {
        return 0;
    }

    // 计算总价格。
    var detailList = getPriceDetailList(this, this.getData(), this.getPassengerCount());
    var totalPrice = 0;
    for (var i = 0; i < detailList.length; i++) {
        for (var j = 0; j < detailList[i].priceList.length; j++) {
            totalPrice += detailList[i].priceList[j].price * detailList[i].priceList[j].count;
        }
    }
    return totalPrice;
};

PriceDetailPanel.prototype.hidePanelWithAnimation = function () {
    var that = this;
    this.animation.bottom(-that._getPriceDetailPanelData().priceDetailViewHeight).step();
    this.setData({
        priceDetailAnimation: that.animation.export()
    }, function () {
        setTimeout(function () {
            that.setData({
                priceDetailAnimation: null
            });
        }, 300);
    });
};

PriceDetailPanel.prototype.showPanelWithAnimation = function () {
    var that = this;
    this.animation.bottom(-that._getPriceDetailPanelData().priceDetailViewHeight).step();
    this.setData({
        priceDetailAnimation: that.animation.export()
    }, function () {
        setTimeout(function () {
            that.animation.bottom(50).step();
            that.setData({
                priceDetailAnimation: that.animation.export()
            });
        }, 50);
    });
};

PriceDetailPanel.prototype.showPriceDetail = function (event) {
    if (this.getPassengerCount() > 0) {
        if (typeof event == "function") {
            event();
        }
        // 动画显示
        if (this._getPriceDetailPanelData().priceDetailAnimation) {
            this.hidePanelWithAnimation();
            this._showStatus = true;
        } else {
            this.showPanelWithAnimation();
            this._showStatus = false;

            Watcher.click({
                "page": Booking.page,
                "action-type": Booking.action.showPriceDetail
            });
        }
        this._root_.setData({
            showLine: this._showStatus
        });
    }
};

/** 刷新渲染数据 */
PriceDetailPanel.prototype.syncRenderData = function () {
    var detailList = getPriceDetailList(this, this.getData(), this.getPassengerCount());
    var priceDetailViewHeight = getPriceDetailViewHeight(detailList);
    this.setData({
        priceDetailList: detailList,
        priceDetailViewHeight: priceDetailViewHeight
    });
};

PriceDetailPanel.prototype.setData = function (data, completion) {
    var priceDetailPanelData = this.getData('priceDetailPanelData') || {};

    for (var key in data) {
        priceDetailPanelData[key] = data[key];
    }

    this._root_.data.priceDetailPanelData = priceDetailPanelData;
    this._root_.setData({
        priceDetailPanelData: priceDetailPanelData
    });
    completion && completion();
};

PriceDetailPanel.prototype._getPriceDetailPanelData = function () {
    if (!this._root_.data.priceDetailPanelData) {
        // 同步数据
        this.syncRenderData();
    }
    return this._root_.data.priceDetailPanelData;
};

PriceDetailPanel.prototype.getData = function (key) {
    return key ? this._root_.data[key] : this._root_.data;
};

PriceDetailPanel.prototype.getPassengerCount = function () {
    return this._root_._passenger.getPassengerList().length;
};


/** 创建单行的价格描述 */
function createPriceItem(price, count) {
    if (price && price != 0) {
        return {
            price: price,
            count: count
        };
    }
    return null;
}

/** 获取出行意外险 */
function getTravelInsurancePrice(root) {
    if (root && root._root_._insurance && root._root_._insurance.getSelectedTravelInsurance()) {
        return root._root_._insurance.getSelectedTravelInsurance().price;
    }
    return 0;
}

/** 创建包含价格和标题的Item项 */
function createPriceDetailItem(title, price, count) {
    var priceList = [];
    var priceItem = createPriceItem(price, count);
    if (priceItem) {
        priceList.push(priceItem);
        return {
            title: title,
            priceList: priceList
        };
    }
    return null;
}

/**
 * 创建保险详情
 * @param data OrderFill页面对应的data。
 */
function crateInsuranceDetailItem(root, title, count, data) {
    var priceList = [];

    var insurance;
    root._root_._insurance && (insurance = root._root_._insurance.getSelectedNormalInsurance())

    // 乘车意外险
    var priceItem = createPriceItem(insurance ? insurance.price : 0, count);

    // 出行意外险
    var traveleItem = createPriceItem(getTravelInsurancePrice(root), count);

    priceItem && priceList.push(priceItem);
    traveleItem && priceList.push(traveleItem);

    if (priceList && priceList.length > 0) {
        return {
            title: title,
            priceList: priceList
        };
    }
    return null;
}

function createServicePriceItem(root, title, count, data) {
    if (!data || !data.orderResult || !data.orderResult.coach) {
        return null;
    }
    var priceList = [];
    var coach = data.orderResult.coach;
    var servicePrice = Number(coach.servicePrice);
    var priceItem = createPriceItem(servicePrice, count);
    priceItem && priceList.push(priceItem);
    if (priceList.length > 0) {
        return {
            title: title,
            priceList: priceList
        }
    }
    return null;
}

function getPriceDetailList(root, data, count) {
    var li = [];
    var result = data.orderResult;
    if (!result || !result.coach) {
        return li;
    }

    var ticketPrice = result.coach.ticketPrice;

    // Seat price item
    var item = createPriceDetailItem("票价", ticketPrice, count);
    item && li.push(item);

    // Insurance item
    var itemInsurance = crateInsuranceDetailItem(root, "保险", count, data);
    itemInsurance && li.push(itemInsurance);

    // Service price
    var itemServicePrice = createServicePriceItem(root, "服务费", count, data);
    itemServicePrice && li.push(itemServicePrice);
    return li;
}

function getPriceDetailViewHeight(detailList) {
    // 35-Title的Height, 30-底部区域的上下PaddingPadding。
    // 24-价格详情列表，每一项的高度。单位都是px。
    var height = 35 + 30;
    for (var i = 0; i < detailList.length; i++) {
        height += 24;
    }
    return height;
}

module.exports = PriceDetailPanel;