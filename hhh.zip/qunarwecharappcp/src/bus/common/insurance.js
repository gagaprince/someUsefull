// insurance.js

function Insurance (root) {
    this._root = root;
}

Insurance.prototype.syncInsuranceData = function (insuranceData) {
    insuranceData = insuranceData ? insuranceData : this.getInsuranceData();
    this._root.setData({
        insuranceData: insuranceData
    });
}

Insurance.prototype.getInsuranceData = function() {
    var insuranceData = this._root.data.insuranceData;
    if(!insuranceData) {
        return initInsuranceData(this._root.data);
    }
    return insuranceData;
}

/** 获取推荐保险的价格 */
Insurance.prototype.getSuggestInsurancePrice = function () {
    if(!this._root.data.insuranceData){
        return 0;
    }
    var insuranceList = this._root.data.insuranceData.insuranceList;
    if(!(insuranceList instanceof Array)){
        return 0;
    }
    return (insuranceList && insuranceList.length > 1) ? insuranceList[0].price : 0;
}

Insurance.prototype.getSelectedTravelInsurance = function () {
    var insuranceData = this.getInsuranceData();
    if(insuranceData && insuranceData.travelInsurance
        && insuranceData.travelInsurance.selected){
            return insuranceData.travelInsurance;
    }
    return null;
}

Insurance.prototype.getSelectedNormalInsurance = function () {
    var insuranceData = this.getInsuranceData();
    return getSelectedNormalInsurance(insuranceData);
}

function initInsuranceData(data) {
    var orderResult = data.orderResult;
    if(!orderResult){
        return null;
    }
    var insuranceData = {};
    insuranceData.insuranceList = orderResult.insurances;
    insuranceData.travelInsurance = orderResult.travelInsurance;

    // normalInsurance
    var insuranceList = insuranceData.insuranceList;
    if((insuranceList instanceof Array)){
        for(var i = 0; i < insuranceList.length; i ++){
            insuranceList[i].selected = (i == 0 ? true : false); 
        }
    }
    insuranceData.selectedInsurance = getSelectedNormalInsurance(insuranceData);

    // travelInsurance
    if(insuranceData.travelInsurance) {
        insuranceData.travelInsurance.selected = true;
        insuranceData.travelInsurance.title = "出行意外险";
    }
    insuranceData.insuranceTitle = "乘车意外险";

    // tips
    var insureRecommendTip = "推荐选择 安全无价",
        travelInsureRecommendTip = "推荐选择 全天保障";
    if(orderResult.promoteRecommendTip) {
        insureRecommendTip = orderResult.promoteRecommendTip.insureRecommendTip || insureRecommendTip;
        travelInsureRecommendTip = orderResult.promoteRecommendTip.travelInsureRecommendTip || travelInsureRecommendTip;
    }
    insuranceData.insureRecommendTip = insureRecommendTip;
    insuranceData.travelInsureRecommendTip = travelInsureRecommendTip;
    
    return (!insuranceData.insuranceList && !insuranceData.travelInsurance) ? null : insuranceData;  
} 

function getSelectedNormalInsurance (insuranceData) {
    var insuranceList = insuranceData ? insuranceData.insuranceList : null;
    if(!(insuranceList instanceof Array)){
        return null;
    }
    for(var i = 0; i < insuranceList.length; i ++){
        if(insuranceList[i].selected){
            return insuranceList[i];
        }
    }
    return null;
}

module.exports = Insurance;