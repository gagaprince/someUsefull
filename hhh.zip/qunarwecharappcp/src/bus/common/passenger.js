// passenger.js
var passengerList = [];

Passenger.prototype.initPassenger = function () {
    passengerList = [];

    // Add auto fill data
    var autoList = this.getAutoFillPassenger();
    if (autoList && autoList.length > 0) {
        for (var i = 0; i < autoList.length; i++) {
            autoList[i] && passengerList.push(autoList[i]);
        }
    }

    // 如果自动填单为空，则添加一个空白的默认Passenger
    if (passengerList.length < 1) {
        var passenger = createDefaultPassenger();
        passenger && passengerList.push(passenger);
    }
    this.syncRenderData();
};

Passenger.prototype.syncAddPassenger = function () {
    passengerList.push(createDefaultPassenger());
    this.syncRenderData();
};

Passenger.prototype.syncRemovePassenger = function (index) {
    passengerList.splice(index, 1);
    this.syncRenderData();
};

Passenger.prototype.syncInputData = function (index, type, content) {
    var passenger = passengerList[index];
    if (type == "name") {
        passenger.name = content;
    } else if (type == "idcard") {
        content = content.toLocaleUpperCase();
        passenger.certNo = content;
    }
    this.syncRenderData();
};

Passenger.prototype.syncRenderData = function () {
    this._root_.setData({
        passengerList: passengerList
    });
};

Passenger.prototype.getPassengerList = function () {
    return passengerList;
};

Passenger.prototype.getAutoFillPassenger = function () {
    var orderResult = this.getData().orderResult;
    var autoFillData;
    orderResult && (autoFillData = orderResult.autoFillData);
    if (autoFillData) {
        return autoFillData.passengers;
    }
    return null;
};

/**
 * 获取root页面的数据。
 * @return Object this._root_.data
 */
Passenger.prototype.getData = function () {
    return this._root_.data;
};

function createDefaultPassenger() {
    return {
        name: '',
        certType: 0,
        certNo: '',
        passengerType: 1, // 乘客类型(1:成人 2:儿童)	 	
        phone: '',
        insurance: null, // 用户选择的保险(没买保险传null)
        travelInsurance: null, // 用户选择的旅游险(没买保险传null) 
        surname: '',
        givenName: '',
        gender: 3, // 1:男 2:女 3:未知
        birthday: '',
        validDay: '',
        nationality: ''
    }
}

function Passenger(root) {
    this._root_ = root;
}

module.exports = Passenger;

