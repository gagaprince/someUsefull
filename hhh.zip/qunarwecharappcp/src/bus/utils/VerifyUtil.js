// VerifyUtil.js

/**
 * 姓名校验
 * @param 姓名字符串
 * @return 校验结果字符串
 */
/**姓名错误信息 */
var NAME_ERROR_TYPE = {
    NO_INPUT: "请输入姓名",
    TOO_SHORT: "姓名过短，请输入正确姓名",
    TOO_LONG: "姓名长度超过限制",
    INCLUDE_SPECIAL_CHAR: "姓名中不能含有除汉字，字母，“空格”，“.”，”·”以外的其他字符",
    MULTI_CHAR: "姓名中不能同时包含汉字、字母和符号，姓必须是中文",
    CHINA_INCLUDE_SPECIAL_CHAR: "中文姓名不能含有除汉字，“.”，”·”以外的其他字符",
    CHINA_FIRST_NAME_ERROR: "中文姓名的姓必须是中文"
};

/**电话错误信息 */
var PHONE_ERROR_TYPE = {
    PHONE_ERROR: "请输入正确的手机号码"
};

/**身份证错误信息 */
var IDCARD_ERROR_TYPE = {
    NO_INPUT: "请输入身份证号",
    LENGTH_ERROR: "身份证号长度有误，请输入15位或18位身份证号",
    CHAR_ERROR: "身份证号码中有不能识别的字符",
    BIRTH_DATE_ERROR: "身份证出生日期填写错误",
    INFO_ERROR: "身份证信息错误",
    FORMAT_ERROR: "身份证号格式错误",
    //专业术语:地址编码错误
    ADD_CODE_ERROR: "身份证号码错误",
    //专业术语:校验位错误 
    LAST_BIT_ERROR: "身份证号码错误" 
};

function verifyName(name) {
    if(!name || name.length <= 0){
        return NAME_ERROR_TYPE.NO_INPUT;
    }

    name = name.replace(/／/g,"/");

    var hz = name.match(/[\u4e00-\u9fa5]/g);
    
    // 汉字的个数
    var i = hz ? hz.length : 0;

    // 计算字符长度
    var j = name.length - i + i * 2;
    if (j < 3) {
        return NAME_ERROR_TYPE.TOO_SHORT;
    } else if (j > 30) {
        return NAME_ERROR_TYPE.TOO_LONG;
    }

    // 姓名中不能含有除汉子，字母，“空格”，“.”,”·”以外的其他字符
    if (!name.match(/^[\u4e00-\u9fa5A-Za-z\\s\\.·]+$/)) {
        return NAME_ERROR_TYPE.INCLUDE_SPECIAL_CHAR;
    }

    // 如果包含中文
    if (name.match(/[\u4e00-\u9fa5]/g)) {
        // 如果包含英文
        // 只要中文和英文同时存在  就不能有符号
        if (name.match(/[A-Za-z]/g)) { 
            if (name.match(/\\s/g) || name.match(/\\./g) || name.match(/·/g) || !name.substring(0, 1).match(/[\u4e00-\u9fa5]/)) { // 含有符号 或者不是中文开头
                return NAME_ERROR_TYPE.MULTI_CHAR;
            }
        } else if (name.match(/\\s/g)) { 
             // 不包含英文, 纯中文姓名不能包含空格, 可以含有“.”,”·”
            return NAME_ERROR_TYPE.CHINA_INCLUDE_SPECIAL_CHAR;
        }
    }

    // 如果包含中文, 就只能以中文开头
    if (name.match(/[\u4e00-\u9fa5]/g) && !name.substring(0, 1).match(/[\u4e00-\u9fa5]/)) {
        return NAME_ERROR_TYPE.CHINA_FIRST_NAME_ERROR;
    }

    return false;
};

/**
 * 电话号码校验
 * @param phoneNumber Number 电话号码
 * @return boolean 是否合法
 */
function verifyPhone(phoneNumber) {
    if(phoneNumber.length !== 11 || phoneNumber.charAt(0) !== "1") {
        return PHONE_ERROR_TYPE.PHONE_ERROR;
    }
    return false;
};

/**
 * 身份证号码校验
 * @param idcard 身份证号码
 * @return String 校验提示信息
 */
function verifyIdCard (idcard){
    if (!idcard || idcard.length <= 0) {
        return IDCARD_ERROR_TYPE.NO_INPUT;
    }
    if (idcard.length !== 18 && idcard.length !== 15) {
        return IDCARD_ERROR_TYPE.LENGTH_ERROR;
    }
    if (!idcard.match(/^[0-9]{17}[0-9xX]$/) && !idcard.match(/^[0-9]{14}[0-9xX]$/)) {
        return IDCARD_ERROR_TYPE.CHAR_ERROR;
    }

    if(idcard.length === 18 && !(1 <= idcard.substr(10, 12) <= 12) && !(1 <= idcard.substr(12, 14) <= 31)){
        return IDCARD_ERROR_TYPE.BIRTH_DATE_ERROR;;
    }

    if(idcard.length === 15 && !(1 <= idcard.substr(8, 10) <= 12) && !(1 <= idcard.substr(10, 12) <= 31)){
        return IDCARD_ERROR_TYPE.BIRTH_DATE_ERROR;
    }
    return identityCodeValid(idcard).tip;
};

var city = {
    11:"北京", 12:"天津", 13:"河北", 14:"山西", 15:"内蒙古",
    21:"辽宁", 22:"吉林", 23:"黑龙江",
    31:"上海", 32:"江苏", 33:"浙江", 34:"安徽", 35:"福建", 36:"江西", 37:"山东",
    41:"河南", 42:"湖北", 43:"湖南", 44:"广东", 45:"广西", 46:"海南",
    50:"重庆", 51:"四川", 52:"贵州", 53:"云南", 54:"西藏",
    61:"陕西", 62:"甘肃", 63:"青海", 64:"宁夏", 65:"新疆",
    71:"台湾", 
    81:"香港", 82:"澳门",
    91:"国外"
};

function identityCodeValid(code) { 
    var tip = null;
    var pass= true;
            
    if(!code || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(code)){
        tip = IDCARD_ERROR_TYPE.FORMAT_ERROR;
        pass = false;
    } else if(!city[code.substr(0,2)]){
        tip = IDCARD_ERROR_TYPE.ADD_CODE_ERROR;
        pass = false;
    } else{
        //18位身份证需要验证最后一位校验位
        if(code.length === 18){
            code = code.split('');
            //∑(ai×Wi)(mod 11)
            //加权因子
            var factor = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 ];
            //校验位
            var parity = [ 1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2 ];
            var sum = 0;
            var ai = 0;
            var wi = 0;
            for (var i = 0; i < 17; i++){
                ai = code[i];
                wi = factor[i];
                sum += ai * wi;
            }
            if(parity[sum % 11] != code[17]){
                tip = IDCARD_ERROR_TYPE.LAST_BIT_ERROR;
                pass =false;
            }
        }
    }
    return {pass: pass, tip: tip};
};

function keyInObject(key, object) {
    if(!key || !object){
        return false;
    }
    for(var k in object){
        if(key === object[k]){
            return true;
        }
    }
    return false;
};

module.exports = {
    verifyName: verifyName,
    verifyIdCard: verifyIdCard,
    verifyPhone: verifyPhone,
    keyInObject: keyInObject,
    NAME_ERROR_TYPE: NAME_ERROR_TYPE,
    PHONE_ERROR_TYPE: PHONE_ERROR_TYPE,
    IDCARD_ERROR_TYPE: IDCARD_ERROR_TYPE
};