

/**
 * 将param解析成一个对象。
 */
function parseURLParam(param) {
	if (!param) {
		return null;
	}
	var result = {};
	for (var key in param) {
		var value = param[key];

		// 微信版本的问题，微信版本6.3.32不能自动decoding。
		var isIOS = getApp().globalData.deviceInfo.isIOS;
		if (!isIOS) {
			value = decodeURIComponent(value);
		}

		var str = '';
		var exception = false;

		// 尝试JSON解析，失败则使用value原值。
		try {
			str = JSON.parse(value)
		} catch (e) {
			exception = true;
		} finally {
			if (!exception) {
				value = str;
			}
		}

		if (value === "undefined") {
			value = undefined;
		} else if (value === "null") {
			value = null;
		} else if (value === "NaN") {
			value = NaN;
		}

		result[key] = value;
	}
	return result;
}

/**
 * 将对象解析成字符串，并放到URL参数里。
 * @param 对象
 */
function stringifyURLParam(param) {
	if (!param) {
		return null;
	}
	var isIOS = getApp().globalData.deviceInfo.isIOS;
	var resultString = '';
	var paramArray = [];
	for (var key in param) {
		var value = param[key];
		var paramStr = '';
		var valueString = '';
		if (value instanceof Object) {
			valueString = JSON.stringify(param[key])
		} else {
			valueString = value;
		}
		if (!isIOS) {
			valueString = encodeURIComponent(valueString);
		}
		paramStr = key + '=' + valueString;
		paramArray.push(paramStr)
	}
	resultString = paramArray.join("&");
	return resultString;
}

function unfoldParams(param) {

}

function assemblyParams(param, paramArray) {
	var resultParam = null;
	if (!param || !paramArray) {
		return resultParam;
	}

	resultParam = {};
	for (var key in paramArray) {
		var value = paramArray[key];
		resultParam[key] = {};

		if (value instanceof Array) {
			for (var innerKey in value) {
				var s = value[innerKey];

				var paramValue = param[s];
				if (paramValue === null || paramValue === undefined) {
				    resultParam[key][s] = "";
				} else {
					
					resultParam[key][s] = param[s];
				}
			}
		} else {
			if (paramValue === null || paramValue === undefined) {
				resultParam[key] = "";
			} else {
				resultParam[key] = param[key];
			}
		}
	}
	return resultParam;
}

module.exports = {
	parseURLParam: parseURLParam,
	stringifyURLParam: stringifyURLParam,
	assemblyParams: assemblyParams
}