// DateUtil.js
/**
 * 日期处理工具
 */

/**
 * 在指定的date中添加days指定的天数
 */
function addDate(date, days) {
    return new Date(date.getTime() + days * 24 * 60 * 60 * 1000);
}

/**
 * 校验日期是否合法
 */
function check(date) {
    if (date && date != undefined) {
        return (new Date(date).getDate() == date.substring(date.length - 2));
    }
    return false
}
/**
 * 获取指定日期是周几
 */
function getWeekInDate(date) {
    // 0-6
    var dayOfWeek = new Date(date).getDay();
    return ["周日", "周一", "周二", "周三", "周四", "周五", "周六"][dayOfWeek]
}

/**
 * 计算指定年月的月份有多少天.
 * month为指定月份:0-11
 */
function calculateDaysCountOfMonth(year, month) {
    var daysOfMonth = [31, 28 + is_leap(year), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    return daysOfMonth[month];

}

/** Private函数，计算指定年份是否为闰年 */
function is_leap(year) {
    return (year % 100 == 0 ? (year % 400 == 0 ? 1 : 0) : (year % 4 == 0 ? 1 : 0));
}

/**
 * 计算指定年月的的月，在该日历中一共有多少行。
 * 一行7天，从周日开始。
 */
function calculateLineCountOfMonth(year, month) {
    var date = new Date(year, month, 1);
    var first = date.getDay();
    var lineCount = Math.ceil((calculateDaysCountOfMonth(year, month) + first) / 7);
    return lineCount;
}

/**
 * 格式化n对象。
 */
function formatNumber(n) {
    n = n.toString;
    return n[1] ? n : '0' + n;
}

/**
 * 将String字符串解析为Date对象。
 */
function parseDate(str) {
    var date = new Date(str);
    return date;
}

/**
 * 获取天的描述信息。
 * 今天、明天、后天，表示包含今天在内的三天。
 */
function getTodayDesc(d) {
    var desc = '';
    var today = new Date();
    if (today.getFullYear() == d.getFullYear() && today.getMonth() == d.getMonth()) {
        var dateOfToday = today.getDate();
        var date = d.getDate();

        var difference = date - dateOfToday;
        if (difference >= 0 && difference < 3) {
            desc = ['今天', '明天', '后天'][difference];
        }
    }
    return desc;
}

/**
 * 对Date的扩展，将 Date 转化为指定格式的String
 * 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
 * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
 * 例子：
 * (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") --> 2006-07-02 08:09:04.423
 * (new Date()).Format("yyyy-M-d h:m:s.S")      --> 2006-7-2 8:9:4.18
 */
function formatDate(date, format) {
    var o = {
        // 月
        "M+": date.getMonth() + 1,
        // 日
        "d+": date.getDate(),
        // 小时
        "h+": date.getHours(),
        // 分
        "m+": date.getMinutes(),
        // 秒
        "s+": date.getSeconds(),
        // 毫秒
        "S+": date.getMilliseconds(),
        // 季度
        "q+": Math.floor((date.getMonth() + 3) / 3)
    };
    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, (RegExp.$1.length == 1) ?
                (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return format;
}

module.exports = {
    addDate: addDate,
    getWeekInDate: getWeekInDate,
    calculateDaysCountOfMonth: calculateDaysCountOfMonth,
    calculateLineCountOfMonth: calculateLineCountOfMonth,
    formatNumber: formatNumber,
    parseDate: parseDate,
    formatDate: formatDate,
    getTodayDesc: getTodayDesc,
    check: check
}