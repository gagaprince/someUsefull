/**
 * 车次列表页，搜索结果列表
 * @param {dep:'出发城市',arr:'到达城市',date:'出发日期'}
 */
var Network = require('../../../common/comps/network/network.js');
var EventEmitter = require('../../../common/EventEmitter.js');
var Watcher = require('../../../common/watcher.js');
var extend = require('../../../common/utils/object/extend.js');
var utils = require("../../../common/utils.js");

var Requester = require('../../common/requester.js');
var Constant = require('../../config/Constant.js');
var DateUtil = require('../../utils/DateUtil.js');
var ParamUtil = require('../../utils/ParamUtil.js');

var CACHE_KEY = Constant.BUS_CACHE_KEY;
var EVENT = Constant.BUS_EVENT_NAME;
var BOOKING_PARAMS = Constant.BUS_PARAM_KEYS.BOOKING_PARAMS;
var SearchList = Constant.WatcherValue.SearchList;

var inLoading = false;
var animationTimer = null;

Page({
    data: {
        // DataBar
        prevEnable: true,
        nextEnable: true,

        searchData: '',
        loadingMore: false,
        inLoading: false,
        animationData: {},
        pageIndex: 1,
        isTop: true
    },

    // scroll-view 顶部偏移
    lastScrollTop: 0,

    // 上一次搜索的时间戳
    timestamp: 0,

    // 预售期60天(加上‘今天’)
    presalePeriod: 59,

    // 日期格式
    dateFormat: 'yyyy-MM-dd',

    // 起始和结束日期
    barTitle: "",

    onLoad: function (param) {
        this.initEventListener(true);
        this.dealParam(param);
        this._initDateBarAndGetListData();
    },

    onShow: function (param) {
        Watcher.pv({"page": SearchList.page});
        this.showNaviTitle();
    },

    onUnload: function (param) {
        this.initEventListener(false);
        this._loading && this._loading.hide();
        inLoading = false;
        wx.hideNavigationBarLoading();
        clearInterval(animationTimer);
    },

    // register=true注册事件,移除注册
    initEventListener: function (register) {
        if (register) {
            this._dateListener = EventEmitter
                .addListener(EVENT.SEARCHLIST_DATE_CHANGE, this.handleDateChanged);
            this._fillorderListener = EventEmitter
                .addListener(EVENT.DID_BOOKING_PAGE_BACK_PARAM, this.didDisable.bind(this));
        }
        else {
            this._dateListener && this._dateListener.removeListener();
            this._paramListener && this._paramListener.removeListener();
        }
    },

    // 参数预处理
    dealParam: function (param) {
        // param={dep:"北京",arr:"上海",date:"2017-03-21"}
        // param = ParamUtil.parseURLParam(param);
        var copyParam = {};
        extend(copyParam, param);

        // 参数预处理，日期格式不对自动变为明天
        var dateStr = copyParam.date;
        if (!DateUtil.check(dateStr)) {
            dateStr = DateUtil.formatDate(DateUtil.addDate(new Date(), 1), this.dateFormat);
        } else {
            var date = DateUtil.parseDate(dateStr, this.dateFormat);
            dateStr = DateUtil.formatDate(date, this.dateFormat);
        }
        copyParam.date = dateStr;
        this.data.param = copyParam;
    },

    _initDateBarAndGetListData: function () {
        // Update search data
        this.handleDateChanged(this.data.param.date, {
            type: 4,
            msg: '努力加载中...'
        });
    },

    // 刷新Date bar
    refreshDateBar: function () {
        var param = this.data.param;
        if (!param) {
            return;
        }

        // 一下日期处理都以Format:2017-03-03处理
        // 今天String
        var today = new Date();
        var today = new Date(DateUtil.formatDate(today, this.dateFormat));

        // 最多可以卖到票的截至时间。
        var endDay = new Date(DateUtil.formatDate(DateUtil.addDate(
            today, this.presalePeriod), this.dateFormat));

        // 需要搜索的日期,已经是format之后的。
        var searchDate = new Date(param.date);

        // 如果需要索索的天是今天,则“前一天”不可点击。
        var prevEnable = searchDate.getTime() - today.getTime() > 0;
        var nextEnable = endDay.getTime() - searchDate.getTime() > 0;

        if (!prevEnable) {
            searchDate = today;
            param.date = DateUtil.formatDate(searchDate, this.dateFormat);
        }

        // Assemble string: 03月20日 周一 今天
        var displayDate = DateUtil.formatDate(searchDate, 'MM月dd日')
            + ' ' + DateUtil.getWeekInDate(searchDate)
            + ' ' + DateUtil.getTodayDesc(searchDate);
        this.setData({
            param: param,
            displayDate: displayDate,
            prevEnable: prevEnable,
            nextEnable: nextEnable
        });
    },

    // 缓存选中的出发时间。
    cacheSelectedDepDate: function (date) {
        date && wx.setStorage({
            key: Constant.BUS_CACHE_KEY.SEARCH_LIST_DEP_DATE,
            data: new Date(date)
        });
    },

    onReady: function (param) {
    },

    onShareAppMessage: function () {
        var userInfo = (getApp() && getApp().user.nickName);
        !userInfo && (userInfo = '宝宝');

        var navigateToUrl = '/bus/pages/searchlist/searchlist?dep='
            + this.data.param.dep + '&arr=' + this.data.param.arr + "&date=" + this.data.param.date;
        return utils.share.getParam({
            url: navigateToUrl,
            title: userInfo + ' 正在预订汽车票 - 去哪儿旅行',
            desc: this.barTitle + ' ' + this.data.param.date,
            jumpType: 'navigateTo'  // 默认navigateTo, 可选 'redirectTo'
        });
    },

    showNaviTitle: function () {
        var param = this.data.param;
        if (param.dep && param.arr) {
            this.barTitle = param.dep + " → " + param.arr;
            wx.setNavigationBarTitle({
                title: this.barTitle
            });
        }
    },

    bindSelectDayTap: function (e) {
        var params = {
            // 业务线
            bizType: "bus",
            // 默认单选日期；多选的第一个日期 （不传的话展示今天）
            date: this.data.param.date,
            // 选择日期成功之后触发的事件，通过监听这个事件来得到响应
            eventType: EVENT.SEARCHLIST_DATE_CHANGE,
            storageType: ""
        };
        wx.navigateTo({
            url: '/common/pages/calendar/calendar?data=' + JSON.stringify(params)
        });
    },

    bindPrevDayTap: function (e) {
        if (this.data.prevEnable) {
            this.adjustDate(false);
        }
    },

    bindNextDayTap: function (e) {
        if (this.data.nextEnable) {
            this.adjustDate(true);
        }
    },

    // 处理时间更改,触发时机:
    // 1.刚进入该页面时,初始触发;
    // 2.进入日历,选择日历后触发;
    // 3.选择加减一天后触发。
    // NOTE:触发的条件都是EventEmitter.dispatch事件SEARCHLIST_DATE_CHANGE。
    // Date一旦更改,则刷新DateBar、缓存最新时间、刷新列表。
    // loading参数不传时,默认loading使用true。
    handleDateChanged: function (date, loading) {
        // Date String.
        date = DateUtil.formatDate(new Date(date), this.dateFormat);
        this.data.param.date = date;
        this.cacheSelectedDepDate(date);
        this.refreshDateBar();
        this.requestData(loading, 1);
    },

    requestData: function (loading, pageIndex) {
        // loading为undefined只有一种情况,那就是选择日期触发。这种情况,
        // 显示dialog样式的提示框。
        //
        if (!loading) {
            loading = {
                type: 3,
                msg: "加载中"
            };
        }
        this.refresh(loading, pageIndex);
    },

    retryRequestData: function () {
        this.requestData(null, 1);
    },

    // 调整日期 @add 是否是加一天
    adjustDate: function (add) {
        var param = this.data.param;
        var d = DateUtil.parseDate(param.date, this.dateFormat);
        d = DateUtil.addDate(d, add ? 1 : -1);
        var date = DateUtil.formatDate(d, this.dateFormat);
        param.date = date;
        EventEmitter.dispatch(Constant.BUS_EVENT_NAME.SEARCHLIST_DATE_CHANGE, new Date(date));
    },

    // 处理不可预订的情况
    didDisable: function (data) {
        if (!data) {
            return;
        }
        if (data.index && data.section) {
            var line = this.data.searchData.coachLines[section][index];
            line.status = 0;
            line.statusDes = "不可预订";
            var searchData = that.data.searchData;
            searchData.coachLines[section][index] = line;
            that.setData({
                searchData: searchData
            });
        }
    },

    // 下拉刷新
    onPullDownRefresh: function (e) {
        // 如果有数据，下拉刷新不显示loading
        if (!inLoading) {
            this.refresh({
                type: -10
            }, 1);
        }
    },

    onReachBottom: function (e) {
        var pageIndex = this.data.pageIndex;
        var searchData = this.data.searchData;
        // 上拉加载更多
        // 加锁
        if (!inLoading) {
            if (searchData.coachLines) {
                if (searchData.count > pageIndex * 100) {
                    this.setData({
                        loadingMore: true
                    });
                    this.animation(true);
                    this.refresh({
                        loading: searchData.status != 0
                    }, pageIndex + 1);
                }
            }
        }
    },

    animation: function (start) {
        if (start) {
            var rotate = 180;
            var animation = wx.createAnimation({
                duration: 500,
                timingFunction: 'linear'
            });
            animation.rotate(rotate).step();
            this.setData({
                animationData: animation.export()
            });

            animationTimer = setInterval(function () {
                rotate += 180;
                animation.rotate(rotate).step();
                this.setData({
                    animationData: animation.export()
                });
            }.bind(this), 500);
        } else {
            clearInterval(animationTimer);
            this.setData({
                animationData: {}
            });
        }

    },

    refresh: function (loading, pageIndex) {
        (loading && loading.type >= -3) && Network.showNetwork.call(this, {
            status: loading.type ? loading.type : 4,
            loadingDesc: loading.msg ? loading.msg : '加载中...'
        });

        // Ensure page index...
        pageIndex = pageIndex || 1;
        if (pageIndex < 1) {
            pageIndex == 1;
            this.data.lastIsTop = true;
        }

        this.timestamp = new Date().getTime();
        var param = this.data.param;

        var me = this;
        inLoading = true;
        Requester.request({
                service: Requester.service.S2S,
                data: {
                    dep: param.dep,
                    arr: param.arr,
                    depDate: param.date,
                    pageSize: 100,
                    pageIndex: pageIndex
                },
                success: function (res) {
                    me.onCompleteRequest(res, pageIndex);
                },
                fail: function () {
                    // Net error, 加载首页时,网络失败需要显示重试。
                    if (pageIndex == 1) {
                        Network.showNetwork.call(me, {
                            status: -1,
                            showButton: true,
                            loadingDesc: '网络失败，请重试',
                            networkRetry: 'retryRequestData'
                        });
                    } else {
                        Network.hideNetwork.call(me, function () {
                            Network.showNetwork.call(me, {
                                status: 2,
                                loadingDesc: '网络请求失败',
                                loadingDescColor: '#00BCD4'
                            });
                        });
                    }
                },
                complete: function () {
                    wx.hideNavigationBarLoading();
                    wx.stopPullDownRefresh();
                    me.setData({
                        loadingMore: false
                    });
                    inLoading = false;
                    me.animation(false);
                }
            }
        );
    },

    onCompleteRequest: function (res, pageIndex) {
        // success
        var me = this;
        if (pageIndex == 1) {
            this.data.pageIndex = 1;
            if (!res.data || res.data.status != 0) {
                me.showNoDataStatus(-1, (res && res.errorMsg) || "暂无搜索结果");
                return;
            }
            if (res.data.coachLines.length) {
                var searchData = res.data;
                var coachLines = res.data.coachLines;
                searchData.coachLines = [coachLines];
                this.setData({
                    searchData: searchData
                });
                Network.hideNetwork.call(this);
            } else {
                me.showNoDataStatus(-1, "暂无搜索结果");
                Watcher.pv({"page": SearchList.action.noData});
            }
            return;
        }

        // 以下为加载跟多时的数据。
        if (!res.data || res.data.status != 0) {
            me.showNoDataStatus(2, (res && res.errorMsg) || "暂无搜索结果");
            return;
        }

        // 翻页请求
        if (res.data && res.data.status == 0) {
            if (res.data.coachLines.length) {
                var searchData = this.data.searchData;
                var coachLines = searchData.coachLines;

                if (coachLines.length > 1) {
                    coachLines.shift();
                }
                this.setData({
                    searchData: searchData
                });
                setTimeout(function () {
                    coachLines.push(res.data.coachLines);
                    this.setData({
                        searchData: searchData
                    });
                }.bind(this), 500)
                Network.hideNetwork.call(me);
                this.data.pageIndex = pageIndex;
            } else {
                me.showNoDataStatus(2, "暂无搜索结果");
            }
        }
    },

    showNoDataStatus: function (type, msg) {
        var me = this;
        Network.hideNetwork.call(me, function () {
            Network.showNetwork.call(me, {
                status: type,
                loadingDesc: msg,
                showButton: type != 2,
                networkRetry: 'retryRequestData',
                loadingDescColor: '#00BCD4'
            });
        });
    },

    networkRetry: function () {
        this.onPullDownRefresh();
    },

    // 点击具体车次
    bindCellTap: function (e) {
        Watcher.click({
            "page": SearchList.page,
            "action-type": SearchList.action.enterBooking
        });

        var ts = new Date().getTime();
        // 超过20min
        if (ts - this.timestamp > 20 * 60 * 1000) {
            wx.showModal({
                title: '提示',
                content: '搜索结果已过期，点击‘确定’刷新',
                success: function (res) {
                    (res.confirm) && this.refresh({loading: true}, 1);
                }.bind(this),
                successText: '确定',
                cancelText: '取消'
            });
        }
        else {
            var index = e.currentTarget.dataset.index;
            var section = e.currentTarget.dataset.section;
            var line = this.data.searchData.coachLines[section][index];
            var that = this;
            if (line.coach.promotePrice && line.coach.promotePrice.length) {
                Watcher.click({
                    "page": SearchList.page,
                    "action-type": SearchList.action.bookingDiscount
                });
            }

            var status = parseInt(line.status);
            if (status == 1 || status == 4) {
                if (status == 4) {
                    var content = line.coach.preSellTip;
                    wx.showModal({
                        title: '提示',
                        content: (content || '所选车次还未开售,确认预定吗?'),
                        success: function (res) {
                            (res.confirm) && that.booking(line, section, index);
                        }.bind(this),
                        confirmText: '确认',
                        cancelText: '取消'
                    });
                } else {
                    that.booking(line, section, index);
                    that.setData({
                        searchData: that.data.searchData
                    });
                }
            }
        }
    },

    // 跳转到填单页
    booking: function (line, section, index) {
        var param = this.dealBookingParam(line, section, index);
        var query = ParamUtil.stringifyURLParam(param);
        wx.navigateTo({
            url: '../fillorder/fillorder?' + query
        });
    },

    // Build booking param
    dealBookingParam: function (param, section, index) {
        var client = {};
        client.section = section;
        client.index = index;
        param.client = client;
        var dealedParam = {};
        for (var key in BOOKING_PARAMS) {
            var value = BOOKING_PARAMS[key];
            if (value instanceof Array) {
                for (var idx in value) {
                    var paramValue = param[key][value[idx]];
                    (paramValue !== null && paramValue !== undefined) && (dealedParam[value[idx]] = paramValue);
                }
            } else {
                var paramValue = param[key];
                (paramValue !== null && paramValue !== undefined) && (dealedParam[key] = paramValue);
            }
        }
        return dealedParam;
    },

    touchMove: function (e) {
        console.log(e);
        e.target.offsetTop = 0;
    }
});
