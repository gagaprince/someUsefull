// insurances.js
// 保险选择页
var ParamUtil = require('../../utils/ParamUtil.js');
var EventEmitter = require('../../../common/EventEmitter.js');
var Constant = require('../../config/Constant.js');
var Watcher = require('../../../common/watcher.js');
var Requester = require('../../common/requester.js');

var EventName = Constant.BUS_EVENT_NAME;
var BusFAQType = Constant.BUS_FAQ_TYPE;
var BusCache = Constant.BUS_CACHE_KEY;
var Insurance = Constant.WatcherValue.Insurance;

Page({
    data: {
        faqData: "",
        isReadedProtocol: true,
        isReadedProtocolShow: true
    },

    onLoad: function (param) {
        var self = this;
        wx.getStorage({
            key: BusCache.DATA_INSURANCE,
            success: function (res) {
                var insuranceData = res.data;
                ensureInsuranceData(insuranceData);
                self.setData({
                    insuranceData: insuranceData
                });
                self._updateProtocolShownStatus();
            }
        })
    },

    onShow: function (param) {
        Watcher.pv({"page": Insurance.page});
    },

    onUnload: function () {
        wx.clearStorage({key: BusCache.DATA_INSURANCE})
    },

    _backToOrderFillPage: function () {
        EventEmitter.dispatch(EventName.DID_FINISH_SELECT_INSURANCE,
            this.data.insuranceData);
        wx.navigateBack();
    },

    /** Private method */
    _updateProtocolShownStatus: function () {
        var si = this.data.insuranceData.selectedInsurance;
        if (si) {
            this.setData({
                isReadedProtocolShow: !(si.selected && (si.price == 0))
            });
        }
    },

    //----Below is Tap event listener---------------//
    /** 进入乘车意外险 FAQ PAGE */
    titleFaqTap: function (e) {
        var param = {
            type: BusFAQType.INSURANCE_NOTICE,
            insurance: this.data.insuranceData.selectedInsurance,
            title: '乘车意外险'
        };
        this.onOpenFaqModal(param);

        // var that = this;
        // wx.navigateTo({
        //     url: '../faq/faq?' + ParamUtil.stringifyURLParam({
        //         type: BusFAQType.INSURANCE_NOTICE,
        //         insurance: that.data.insuranceData.selectedInsurance,
        //         title: '乘车意外险'
        //     })
        // });
    },

    /** 保险列表每一项点击 */
    insuranceItemClicked: function (e) {
        var index = e.currentTarget.dataset.index;
        var insuranceData = this.data.insuranceData;
        var insuranceList = this.data.insuranceData.insuranceList;

        for (var i = 0; i < insuranceList.length; i++) {
            if (index == i) {
                insuranceList[i].selected = true;
                insuranceData.selectedInsurance = insuranceList[i];
            } else {
                insuranceList[i].selected = false;
            }

            if (index == i && insuranceList[i].price == 0) {
                Watcher.click({
                    "page": Insurance.page,
                    "action-type": Insurance.action.selectedNothing
                });
            }
        }
        this.setData({
            'insuranceData.insuranceList': insuranceList
        });
        this._updateProtocolShownStatus();
    },

    /** 意外险是否选择 */
    accidentSwitchChanged: function (e) {
        // var checked = e.detail.value;
        var travelInsurance = this.data.insuranceData.travelInsurance;
        if (travelInsurance) {
            travelInsurance.selected = !travelInsurance.selected
            this.setData({
                'insuranceData.travelInsurance': travelInsurance
            });
        }
        Watcher.click({
            "page": Insurance.page,
            "action-type": Insurance.action.accidentInsuranceClicked
        });
    },

    didSwitchChangeValue: function (e) {
        this.accidentSwitchChanged(e);
    },

    /** 进入出行意外险FAQ PAGE */
    travelFaqTap: function (e) {
        var param = {
            type: BusFAQType.INSURANCE_NOTICE,
            insurance: this.data.insuranceData.travelInsurance,
            title: '出行意外险'
        };
        this.onOpenFaqModal(param);
        // wx.navigateTo({
        //     url: '../faq/faq?' + ParamUtil.stringifyURLParam({
        //         type: BusFAQType.INSURANCE_NOTICE,
        //         insurance: this.data.insuranceData.travelInsurance,
        //         title: '出行意外险'
        //     })
        // });
    },

    /** 阅读按钮点击 */
    onReadedTap: function (e) {
        this.setData({
            isReadedProtocol: !this.data.isReadedProtocol
        });
    },

    /** 进入保险协议FAQ PAGE */
    onProtocolDetailTap: function (e) {
        this.onOpenFaqModal({
            type: BusFAQType.INSURANCE_AGREEMENT,
            title: '保险委托协议'
        });
        // wx.navigateTo({
        //     url: '../faq/faq?' + ParamUtil.stringifyURLParam({
        //         type: BusFAQType.INSURANCE_AGREEMENT,
        //         title: '保险委托协议'
        //     })
        // });

        Watcher.click({
            "page": Insurance.page,
            "action-type": Insurance.action.protocolClicked
        });
    },

    onOpenFaqModal: function (data) {
        var me = this;
        Requester.request({
            service: Requester.service.FAQ,
            data: data,
            success: function (res) {
                res = res.data;
                if (res && res.status == 0) {
                    var faqData = {
                        faqList: res.contents
                    };
                    me.setData({
                        faqData: faqData
                    });
                }
            }
        });
    },

    faqLayerTap: function () {
        this.setData({
            faqData: ''
        });

        Watcher.click({
            "page": Insurance.page,
            "action-type": Insurance.action.faqLayerClicked
        });
    },

    /** 完成按钮点击 */
    onConpleatedCliked: function () {
        if (this.data.isReadedProtocol || !this.data.isReadedProtocolShow) {
            this._backToOrderFillPage();
        } else {
            var that = this;

            try {
                wx.showModal({
                    title: '保险选择提示',
                    content: '请确认已经阅读并同意保险相关说明',
                    cancelText: '取消',
                    confirmText: '同意',
                    confirmColor: '#1ba9ba',
                    success: function (res) {
                        if (res.confirm) {
                            that.setData({
                                isReadedProtocol: true
                            });
                            that._backToOrderFillPage();
                        }
                    }
                });
            } catch (e) {
                console.log("弹窗错误", e);
            }
        }
    }
});

function ensureInsuranceData(insuranceData) {
    if (insuranceData) {
        insuranceData.titleData = {
            title: "乘车意外险",
            desc: "守护你的所有，只为旅途的心安",
            moreInfo: true
        };
    }
}
