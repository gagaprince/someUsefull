// fillorder.js
var ParamUtil = require('../../utils/ParamUtil.js');
var VerifyUtil = require('../../utils/VerifyUtil.js');
var DateUtil = require('../../utils/DateUtil.js');

var Network = require('../../../common/comps/network/network.js');
var EventEmitter = require('../../../common/EventEmitter.js');
var Requester = require('../../common/requester.js');
var Pay = require("../../../common/pay.js");
var Watcher = require('../../../common/watcher.js');
var User = require('../../../common/user.js');

var Constant = require('../../config/Constant.js');

var PriceDetailPanel = require('../../common/priceDetailPanel.js');
var PriceInfoBar = require('../../common/priceInfoBar.js');
var Passenger = require('../../common/passenger.js');
var Contact = require('../../common/contact.js');
var Insurance = require('../../common/insurance.js');

var Booking = Constant.WatcherValue.Booking;
var EventName = Constant.BUS_EVENT_NAME;
var BusCache = Constant.BUS_CACHE_KEY;
var BusParams = Constant.BUS_PARAM_KEYS;
var NameErrorType = VerifyUtil.NAME_ERROR_TYPE;
var PhoneErrorType = VerifyUtil.PHONE_ERROR_TYPE;
var CardErrorType = VerifyUtil.IDCARD_ERROR_TYPE;

Page({
    data: {
        maxPassengerCount: 3,
        showLine: true,
        orderActionData: {
            totalPrice: 0
        }
    },

    onLoad: function (param) {
        this.initGlobalParam();
        this._priceInfoBar = new PriceInfoBar(this);
        this._priceDetailPanel = new PriceDetailPanel(this);
        this._passenger = new Passenger(this);
        this._contact = new Contact(this);
        this._insurance = new Insurance(this);

        this.param = param;

        var that = this;
        this._insuranceListener = EventEmitter.addListener(EventName.DID_FINISH_SELECT_INSURANCE,
            function (insuranceData) {
                that._insurance && that._insurance.syncInsuranceData(insuranceData);
                that._syncDetailActionBarData();
            }
        );

        // READY PAGE DATA
        // INITIAL this.data.orderResult
        that.requestOrderFillData(this.param);
    },

    initGlobalParam: function () {
        var me = this;
        User.getUserInfo(function (res) {
            console.log("UserInfo:", res);
            var exParams = res && res.data && res.data.exParams;
            me.data.weChatPlatform = exParams && exParams.platform;
        });
    },

    onUnload: function () {
        Network.hideNetwork.call(this);
        this._insuranceListener && this._insuranceListener.removeListener();
        // 清除本页面的数据缓存
        wx.clearStorage({key: BusCache.DATA_BOOKING});
    },

    onShow: function (param) {
        Watcher.pv({"page": Booking.page});
    },

    /** Sync coach detail, insurance base data. */
    _initRenderData: function () {
        // 初始化顺序不能随意改变
        this._syncCoachShiftData();
        this._priceInfoBar && this._priceInfoBar.syncRenderData();
        this._initMaxPassengerCount();
        this._passenger && this._passenger.initPassenger();
        this._contact && this._contact.initContact();
        this._syncPassengerCount();
        this._insurance && this._insurance.syncInsuranceData();
        this._syncOptionalCoach(1);
        this._syncDetailActionBarData();
    },

    /** 请求填单数据 */
    requestOrderFillData: function (param) {
        var that = this;

        var parsed = ParamUtil.parseURLParam(param);
        // Assembly params
        var bookingParam = ParamUtil.assemblyParams(parsed, BusParams.BOOKING_PARAMS);
        if (!bookingParam) {
            that.backToSearchListPage();
        }
        delete (bookingParam.client);
        // console.log("请求参数", bookingParam);

        // Start requesting
        Network.showNetwork.call(that, {
            status: 4
        });
        Requester.request({
            service: Requester.service.FILL_ORDER,
            data: bookingParam,
            success: function (success) {
                // console.log("请求成功", success);
                if (!success || !success.data) {
                    that.netErrorStatus("网络请求错误, 请重试");
                    return;
                }

                var status = parseInt(success.data.status);
                var errMsg = success.data.errorMsg;
                if (status == 0) {
                    // Success
                    Network.hideNetwork.call(that);
                    that.data.orderResult = success.data;
                    that._initRenderData();
                } else if (status == 12002 || status == 12003
                    || status == 12004 || status == 12005
                    || status == 12006 || status == 12008 || status == 12011) {
                    // Toast show error and back
                    Network.hideNetwork.call(that, function () {
                        Network.showNetwork.call(that, {
                            status: 2,
                            loadingDesc: errMsg || "网络请求错误, 请重试"
                        });
                    });
                    setTimeout(function () {
                        that.backToSearchListPage(bookingParam.client);
                    }, 2000);
                } else {
                    that.netErrorStatus(errMsg || "网络请求错误, 请重试");
                }
            },
            fail: function (error) {
                // console.log("请求失败", error);
                that.netErrorStatus("网络请求错误, 请重试");
            }
        });
    },

    retryRequestNetwork: function () {
        this.requestOrderFillData(this.param);
    },

    netErrorStatus: function (msg) {
        var me = this;
        Network.hideNetwork.call(me, function () {
            Network.showNetwork.call(me, {
                status: -1,
                showButton: true,
                loadingDesc: msg,
                networkRetry: 'retryRequestNetwork'
            });
        });
    },

    backToSearchListPage: function (data) {
        EventEmitter.dispatch(EventName.DID_BOOKING_PAGE_BACK_PARAM, data || null);
        wx.navigateBack();
    },

    commitOrder: function (e) {
        var that = this;

        var data = that.data;
        var orderResult = that.data.orderResult;

        var insuranceSuggestPrice = 0;
        that._insurance && (insuranceSuggestPrice = that._insurance.getSuggestInsurancePrice());

        var commitParam = {
            coach: orderResult.coach,
            agent: orderResult.agent,
            agreeOptionalCoach: data.optionalCoach && (data.optionalCoach.agreeOptionalCoach ? 1 : 0),
            extParam: "",
            acceptInsuranceGift: 0,
            discountPackageCode: "",
            discountPackageAmount: "",
            insuranceSuggestPrice: insuranceSuggestPrice,
            wechatPlatform: that.data.weChatPlatform
        };

        commitParam.passengers = this._buildPassengersParam();
        commitParam.ticketPerson = this._contact.getSelectedContact();

        // console.log('生单请求参数', JSON.stringify(commitParam));
        Watcher.click({
            "page": Booking.page,
            "action-type": Booking.action.saveOrder
        });

        Network.showNetwork.call(that, {
            status: 3,
            loadingDesc: '正在提交订单...'
        });
        Requester.request({
            service: Requester.service.BUILD_ORDER,
            data: commitParam,
            success: this._handleCommitOrderResult.bind(this),
            fail: function (error) {
                // console.log("生单失败", error);
                Network.hideNetwork.call(that, function () {
                    Network.showNetwork.call(that, {
                        status: -3,
                        loadingDesc: '网络请求失败'
                    });
                });
            }
        });
    },

    _buildPassengersParam: function () {
        var passengerList = this._passenger.getPassengerList();
        for (var i = 0; i < passengerList.length; i++) {
            passengerList[i].insurance = this._insurance ? this._insurance.getSelectedNormalInsurance() : null;
            passengerList[i].travelInsurance = this._insurance ? this._insurance.getSelectedTravelInsurance() : null;
        }
        return passengerList;
    },

    /** 处理生成订单成功 */
    _handleCommitOrderResult: function (res) {
        var that = this;
        if (!res.data || res.data.status != 0) {
            // console.log('生单失败了', res);
            Network.hideNetwork.call(that);
            that.showModal({
                title: "提交订单失败",
                content: (res.data && res.data.errorMsg) || "订单提交失败, 请重试。",
                showCancel: false
            });
            return;
        }

        // console.log('生单成功：', res);
        Watcher.click({
            "page": Booking.page,
            "action-type": Booking.action.saveOrderSuccess
        });

        // 只需要cashierUrl即可，进入收银台环境
        var cashierUrl = res.data.cashierUrl;
        var user = getApp().user;
        var openId = user.openId;

        var orderNo = res.data.orderNo;
        var token = res.data.token
        // console.log('支付链接：', cashierUrl);

        var data = {
            cashierUrl: cashierUrl || '',
            openId: openId,
            bd_source: "wx",
            success: function (res) {
                console.log('支付成功,跳转订单详情页!', res);
                Watcher.click({
                    "page": Booking.page,
                    "action-type": Booking.action.paySuccess
                });
                that.enterOrderDetailPage({
                    orderNo: orderNo,
                    token: token
                });
            },
            fail: function (error) {
                // console.log('支付失败', error);
                // 由于Pay模块已经弹窗提示了支付失败原因,因此这里不需要再次弹窗。
                that.enterOrderDetailPage({
                    orderNo: orderNo,
                    token: token
                });
            },
            complete: function (error) {
                Network.hideNetwork.call(that);
                // Bug: 微信版本6.5.2 及之前版本中，用户取消支付不会触发 fail 回调，
                // 只会触发 complete 回调，回调 errMsg 为 'requestPayment:cancel'。
                // 业务逻辑是:用户取消支付,很大的可能性是可能发现填写有误,想重新填写,
                // 因此,只有放弃已经生成的单,重新填写,重新生单,不必跳转到OrderDetailPage。
            },
            beforeOpen: function () {
                Network.hideNetwork.call(that);
            }
        };

        // console.log("支付参数：", JSON.stringify(data));
        Watcher.click({
            "page": Booking.page,
            "action-type": Booking.action.pay
        });

        // 调起微信支付
        Pay.openCashier(data);
    },

    // 进入订单详情页
    enterOrderDetailPage: function (reqParm) {
        reqParm && wx.navigateTo({
            url: '../orderDetail/orderDetail?' + ParamUtil.stringifyURLParam(reqParm)
        });
    },

    _checkPassengerList: function (e) {
        var passengerList = this._passenger.getPassengerList();

        var title;
        var verifyTip;

        if (!passengerList || passengerList.length < 1) {
            title = "未添加乘客";
            verifyTip = "请添加乘客";
        }

        if (verifyTip) {
            this.showModal({title: title, content: verifyTip, showCancel: false});
            return false;
        }

        for (var index = 0; index < passengerList.length; index++) {
            var p = passengerList[index];
            verifyTip = VerifyUtil.verifyName(p.name);
            verifyTip = verifyTip ? verifyTip : VerifyUtil.verifyIdCard(p.certNo);
            if (VerifyUtil.keyInObject(verifyTip, NameErrorType)) {
                title = "乘客" + (!p.name ? (index + 1) : '"' + p.name + '"') + "姓名有误";
            } else if (VerifyUtil.keyInObject(verifyTip, CardErrorType)) {
                title = "乘客" + (!p.name ? (index + 1) : '"' + p.name + '"') + "身份证有误";
            }

            if (verifyTip) {
                break;
            }
        }

        if (verifyTip) {
            this.showModal({title: title, content: verifyTip, showCancel: false});
            return false;
        }

        if (!verifyTip) {
            var pl = passengerList;
            for (var i = 1; i < pl.length; i++) {
                for (var j = i - 1; j >= 0; j--) {
                    if (pl[j].certNo === pl[i].certNo) {
                        title = "乘客身份证重复";
                        verifyTip = "乘客" + (!pl[j].name ? (j + 1) : '"' + pl[j].name + '"') +
                            "与乘客" + (!pl[i].name ? (i + 1) : '"' + pl[i].name + '"') + "身份证号重复"
                        if (verifyTip) {
                            this.showModal({title: title, content: verifyTip, showCancel: false});
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    },

    _checkContactInfo: function (e) {
        var contact = this._contact.getSelectedContact();
        var verifyTip = VerifyUtil.verifyName(contact.name);
        if (contact.isOther) {
            verifyTip = verifyTip ? verifyTip : VerifyUtil.verifyIdCard(contact.certNo);
        }
        verifyTip = verifyTip ? verifyTip : VerifyUtil.verifyPhone(contact.phone);

        var title;
        // CONTACTS PHONE VERIFY
        if (verifyTip == PhoneErrorType.PHONE_ERROR) {
            title = "取票人手机号有误";
        } else if (VerifyUtil.keyInObject(verifyTip, CardErrorType)) {
            title = "取票人身份证号有误";
        } else {
            title = "取票人姓名有误";
        }
        // CONTACTS NAME VERIFY USE DEFAULT TIP
        verifyTip && this.showModal({
            title: title,
            content: verifyTip,
            showCancel: false
        });
        return !verifyTip;
    },

    /**Sync coach detail data */
    _syncCoachShiftData: function () {
        if (!this.data.orderResult) {
            return;
        }
        var coach = this.data.orderResult.coach;
        if (coach) {
            // coachShifData为固定属性名，UI层需要识别该属性，不可更改。
            var coachShifData = {};
            for (var key in coach) {
                coachShifData[key] = coach[key];
            }
            var depDate = new Date(coachShifData.depDate);
            var week = DateUtil.getWeekInDate(depDate);
            coachShifData.depDate = coachShifData.depDate + ' ' + (week ? week : '');

            this.setData({
                coachShifData: coachShifData
            });
        }
    },

    _syncDetailActionBarData: function () {
        this._priceDetailPanel.syncRenderData();
        var orderActionData = this.data.orderActionData;
        orderActionData.totalPrice = this._priceDetailPanel.getTotalPrice();
        this.setData({
            orderActionData: orderActionData
        });
    },

    /**checked, 0, 1 */
    _syncOptionalCoach: function (checked) {
        if (this.data.orderResult && this.data.orderResult.optionalCoach) {
            var msg = this.data.orderResult.optionalCoach.msg;
            this.setData({
                optionalCoach: {
                    title: "备选车次",
                    msg: msg ? msg : '备选车次描述',
                    agreeOptionalCoach: checked == 1 ? true : false
                }
            });
        }
    },

    _syncPassengerCount: function () {
        if (this._passenger && this._passenger.getPassengerList()) {
            this.setData({
                passengersCount: this._passenger.getPassengerList().length
            });
        }
    },

    _initMaxPassengerCount: function () {
        var orderResult = this.data.orderResult;
        if (orderResult && orderResult.passengerCount && orderResult.passengerCount > 0) {
            this.setData({
                maxPassengerCount: orderResult.passengerCount
            });
        }
    },

    //-------Below are tap envents ---------//
    /** 价格信息展示栏每一项点击 */
    priceInfoBarItemTap: function (e) {
        var id = e.currentTarget.id;
        this._priceInfoBar && this._priceInfoBar.processItemTap(id);
    },

    /** 保险Item点击。*/
    insuranceItemClicked: function (e) {
        var self = this;
        wx.setStorage({
            key: BusCache.DATA_INSURANCE,
            data: self._insurance ? self._insurance.getInsuranceData() : null,
            success: function (res) {
                wx.navigateTo({url: '../insurances/insurances'})
            }
        });
        Watcher.click({
            "page": Booking.page,
            "action-type": Booking.action.enterInsurance
        });
    },

    /** 备选车次开关按钮 */
    optionCoachChanged: function (e) {
        if (this.data.optionalCoach) {
            this._syncOptionalCoach(this.data.optionalCoach.agreeOptionalCoach ? 0 : 1);
        }

        Watcher.click({
            "page": Booking.page,
            "action-type": Booking.action.optionCoachClicked
        });
    },

    didSwitchChangeValue: function (e) {
        this.coachShiftswitchChanged(e);
    },

    /** 底部ActionBar左侧点击 */
    bottomActionLeftClicked: function (e) {
        var that = this;
        this._priceDetailPanel && this._priceDetailPanel.showPriceDetail(function () {
            // 执行底部的箭头旋转的动画
            var animation = wx.createAnimation({
                duration: 300,
                timingFunction: 'ease'
            });
            var rotateDeg = 180;
            if (that.data.rotateArrowAnimation) {
                rotateDeg = 180 - that.data.rotateArrowAnimation.actions[0].animates[0].args[0]
            }
            animation.rotate(rotateDeg).step();
            that.setData({
                rotateArrowAnimation: animation.export()
            });
        });
    },

    /** 底部ActionBar右侧点击 */
    bottomActionRightClicked: function (e) {
        // 检测乘客列表是否为空
        if (!this._checkPassengerList() || !this._checkContactInfo()) {
            return;
        }
        // 提交订单
        this.commitOrder();
    },

    /** 添加乘客 */
    addPassenger: function (e) {
        this._passenger && this._passenger.syncAddPassenger();
        this._contact && this._contact.syncAddPassenger();
        this._syncDetailActionBarData();
        this._syncPassengerCount();
    },

    /** 删除乘客 */
    deletePassenger: function (e) {
        var index = Number(e.currentTarget.dataset.idx);
        this._passenger && this._passenger.syncRemovePassenger(index);
        this._contact && this._contact.syncRemovePassenger(index);
        this._syncDetailActionBarData();
        this._syncPassengerCount();
    },

    /** 输入乘客姓名 */
    passengerNameInput: function (e) {
        var index = Number(e.currentTarget.dataset.idx);
        this._passenger && this._passenger.syncInputData(index, "name", e.detail.value);
        this._contact && this._contact.syncUpdatePassenger(index);
        this.hideKeyboard(e.detail.value, 30);
    },

    /** 输入乘客身份证号码 */
    passengerIdCardInput: function (e) {
        var index = Number(e.currentTarget.dataset.idx);
        this._passenger && this._passenger.syncInputData(index, "idcard", e.detail.value);
        this._contact && this._contact.syncUpdatePassenger(index);
        this.hideKeyboard(e.detail.value, 18);
    },

    /** 联系人列表Item点击 */
    contactItemClicked: function (e) {
        var index = e.currentTarget.dataset.index;
        this._contact && this._contact.selectedContact(Number(index));
    },

    /** 非其它Item取票人电话输入 */
    contactTelInput: function (e) {
        this._contact && this._contact.syncContactInput('tel', e.detail.value);
        this.hideKeyboard(e.detail.value, 11);
    },

    /** 取票人，其它Item，姓名输入 */
    contactOtherNameInput: function (e) {
        this._contact && this._contact.syncContactInput('name', e.detail.value);
        this.hideKeyboard(e.detail.value, 30);
    },

    /** 取票人，其它Item，身份证号码输入 */
    contactOtherIdCardInput: function (e) {
        this._contact && this._contact.syncContactInput('idcard', e.detail.value);
        this.hideKeyboard(e.detail.value, 18);
    },

    /** 取票人，其它Item，电话号码输入 */
    contactOtherTelInput: function (e) {
        this._contact && this._contact.syncContactInput('tel', e.detail.value);
        this.hideKeyboard(e.detail.value, 11);
    },

    hideKeyboard: function (content, length) {
        if (content && content.length >= length) {
            wx.hideKeyboard();
        }
    },

    showModal: function (options) {
        if (options.onConfirm || options.onCancel) {
            options.success = function (res) {
                if (res.confirm) {
                    options.onConfirm && options.onConfirm();
                } else {
                    options.onCancel && options.onCancel();
                }
            }
        }
        options.title = options.title ? options.title : '提示';
        options.content = options.content;
        options.confirmColor = options.cancelColor = "#1ba9ba";
        options.showCancel = options.showCancel ? true : false;

        try {
            wx.showModal(options);
        } catch (e) {
            console.log("弹窗错误", e);
        }
    }
});
