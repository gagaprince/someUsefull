//orderdetail.js
//获取应用实例
var EventEmitter = require('../../../common/EventEmitter.js');
var Requester = require('../../common/requester.js');
var Constant = require('../../config/Constant.js');
var DateUtil = require('../../utils/DateUtil.js');
var ParamUtil = require('../../utils/ParamUtil.js');
var Network = require('../../../common/comps/network/network.js');
var Pay = require("../../../common/pay.js");
var Watcher = require('../../../common/watcher.js');
var utils = require("../../../common/utils.js");

var BusFAQType = Constant.BUS_FAQ_TYPE;
var OrderDetail = Constant.WatcherValue.OrderDetail;

Page({
    data: {
        order: '',
        showDetail: false,
        manShow: false,
        barItems: [],
        contactInPassenger: false,
        refundTip: ''
    },

    onLoad: function (param) {
        // 参数预处理增加容错性
        param = ParamUtil.parseURLParam(param);
        this.setData({
            param: param
        });
        this.refresh();
    },

    onUnload: function () {
        Network.hideNetwork.call(this);
        wx.hideNavigationBarLoading();
    },

    onShow: function (param) {
        Watcher.pv({"page": OrderDetail.page});
    },

    refresh: function (showLoading) {
        var me = this;
        // Don't show dialog when showLoading is not true.
        !showLoading && Network.showNetwork.call(this, {
            status: 4
        });
        var reqParam = this.data.param;
        Requester.request({
                service: Requester.service.ORDER_DETAIL,
                data: reqParam,
                success: function (res) {
                    me.onSuccessRequest(res);
                },
                fail: function () {
                    Network.showNetwork.call(me, {
                        status: -1,
                        showButton: true,
                        loadingDesc: '网络失败，请重试',
                        networkRetry: 'reloadDetailData'
                    });
                }
            }
        );
    },

    reloadDetailData: function () {
        this.refresh();
    },

    // 下拉刷新
    onPullDownRefresh: function (e) {
        // 如果有数据，下拉刷新不显示loading
        wx.showNavigationBarLoading();
        this.refresh(true);
    },

    onShareAppMessage: function () {
        var userInfo = (getApp() && getApp().user.nickName);
        if (!userInfo) {
            userInfo = '宝宝';
        }

        var dep = this.data.order.coach.depCity;
        var arr = this.data.order.coach.arrCity;
        var date = this.data.order.coach.depDate;

        var navigateToUrl = '/bus/pages/searchlist/searchlist?dep='
            + dep + '&arr=' + arr + "&date=" + date.substr(0, 10);

        return utils.share.getParam({
            url: navigateToUrl,
            title: userInfo + ' 预订了汽车票 - 去哪儿旅行',
            desc: dep + ' → ' + arr + '  ' + date,
            jumpType: 'navigateTo'
        });
    },

    onSuccessRequest: function (res) {
        var me = this;
        wx.stopPullDownRefresh();
        wx.hideNavigationBarLoading();
        var order = res.data;
        var barItems = this.constructBarItem(order);
        var contactInPassenger = this.isContactInPassenger(order);
        var statusDes = this.fundStatusDes(order);

        if (order.status == 0) {
            wx.setNavigationBarTitle({
                title: order.orderStatusDes
            });
            var depDate = new Date(order.coach.depDate);
            var week = DateUtil.getWeekInDate(depDate);
            order.coach.originDate = order.coach.depDate;
            order.coach.depDate = order.coach.depDate + ' ' + (week ? week : '');

            Network.hideNetwork.call(me);
            setTimeout(function () {
                me.setData({
                    order: order,
                    barItems: barItems,
                    contactInPassenger: contactInPassenger,
                    refundTip: statusDes
                });
            }.bind(me), 500);
        } else {
            Network.showNetwork.call(me, {
                status: -1,
                showButton: true,
                loadingDesc: order.errorMsg || "获取订单信息失败, 点击重试",
                networkRetry: 'reloadDetailData',
                loadingDescColor: '#00BCD4'
            });
        }
    },

    fundStatusDes: function (order) {
        var passengers = order.passengers;
        if (passengers && passengers.length) {
            return passengers[0].refundTicketStatusDesc || '';
        }
        return '';
    },

    isContactInPassenger: function (order) {
        var passengers = order.passengers;
        var ticketPerson = order.ticketPerson;
        var inPassenger = false;

        if (!passengers) {
            return inPassenger;
        }

        for (var i = 0; i < passengers.length; i++) {
            var passenger = passengers[i];
            if (passenger.certNoObj.value == ticketPerson.certNoObj.value) {
                inPassenger = true;
                break;
            }
        }
        return inPassenger;
    },

    constructBarItem: function (order) {
        var items = [];
        if (order && order.status == 0) {
            items.push({img: '../../img/call.png', text: '代理商电话'});
            items.push({img: '../../img/notice.png', text: '取、退票须知'});
            if (order.ticketMsg) {
                items.push({img: '../../img/message.png', text: '查看取票短信'});
            }
        }
        return items;
    },

    tapItem: function (e) {
        var index = parseInt(e.currentTarget.dataset.index);
        console.log("index", index);
        switch (index) {
            case 0: {
                var phoneNumber = this.data.order.agent.phone;
                wx.showActionSheet({
                    itemList: [phoneNumber],
                    success: function (res) {
                        if (!res.cancel) {
                            console.log(res.tapIndex);
                            wx.makePhoneCall({
                                // 仅为示例，并非真实的电话号码
                                phoneNumber: phoneNumber
                            });
                        }
                    }
                });
            }
                break;
            case 1: {
                //showFAQ
                this.titleQuestionClicked(BusFAQType.TGQ, "取票、退票须知", this.data.param.orderNo);

            }
                break;
            case 2: {
                //showTicketMSGMSG
                var order = this.data.order;
                wx.showModal({
                    title: '出票短信',
                    content: (order.ticketMsg || "暂无信息"),
                    successText: '确定'
                });
            }
                break;
        }
    },

    tapQuestion: function (e) {
        var tag = parseInt(e.currentTarget.dataset.tag);
        var passengers = this.data.order.passengers;
        var travelInsurance = passengers[0].travelInsurance;
        var insurance = passengers[0].insurance;

        if (tag == 1) {
            this.titleQuestionClicked(3, '保险提示', travelInsurance);
        } else {
            this.titleQuestionClicked(3, '保险提示', insurance);
        }
    },

    /** 进入乘车意外险 FAQ PAGE */
    titleQuestionClicked: function (faqType, title, otherParam) {
        var param = {
            type: faqType,
            title: title
        };
        if (faqType == 3) {
            param.insurance = otherParam;
        }
        if (faqType == 1) {
            param.orderNo = otherParam;
        }
        wx.navigateTo({
            url: '../faq/faq?' + ParamUtil.stringifyURLParam(param)
        });
    },


    detailButtonTap: function (e) {
        var status = parseInt(e.currentTarget.dataset.status);
        if (status == 10) {
            // 去支付
            this.pay();
            Watcher.click({
                "page": OrderDetail.page,
                "action-type": OrderDetail.action.payRightTopClicked
            });
        } else {
            //返程预定
            var param = {
                dep: this.data.order.coach.arrCity,
                arr: this.data.order.coach.depCity,
                date: this.data.order.coach.originDate
            };
            this.redirectToSearchList(param);

            Watcher.click({
                "page": OrderDetail.page,
                "action-type": OrderDetail.action.returnCoachClick
            });
        }
    },

    redirectToSearchList: function (param) {
        var pages = getCurrentPages();
        var delta = pages.length - 1;
        var tab = {name: 'bus'};
        EventEmitter.dispatch(Constant.BUS_EVENT_NAME.DID_CHANGE_SEARCH_PARAM, param);
        EventEmitter.dispatch(Constant.BUS_EVENT_NAME.DID_SWITCH_TAB, tab);
        wx.navigateBack({
            // 回退前 delta(默认为1) 页面
            delta: delta
        })
    },

    showDetailTap: function (e) {
        var show = this.data.showDetail;
        show = !show;
        this.setData({
            showDetail: show,
            manShow: true
        });

        show && Watcher.click({
            "page": OrderDetail.page,
            "action-type": OrderDetail.action.showDetail
        });
    },

    // 取消订单点击
    cancelOrder: function (e) {
        var actionid = parseInt(e.currentTarget.dataset.actionid);
        var index = parseInt(e.currentTarget.dataset.index);
        var orderActions = this.data.order.orderActions
        var orderAction = orderActions[index];
        var me = this;
        orderAction && wx.showModal({
            title: (actionid == 3 ? '退票须知' : '提示'),
            content: (orderAction.msg || (actionid == 1 ? '确定要取消订单吗' : '确定要退票吗')),
            successText: orderAction.menu || "确定",
            mode: 'text',
            success: function (res) {
                res.confirm && me.requestCancel(actionid);
                Watcher.click({
                    "page": OrderDetail.page,
                    "action-type": OrderDetail.action.cancelOrderClicked
                });
            }
        });


    },

    // 请求取消网络
    requestCancel: function (actionid) {
        var me = this;
        var param = {
            orderNo: this.data.order.orderNo,
            opt: actionid,
            extParam: this.data.order.extParam
        };
        Requester.request({
            service: Requester.service.CANCEL_ORDER,
            data: param,
            success: function (res) {
                me.onCancelOrderSuccess(res.data);
            },
            fail: function () {
                Network.hideNetwork.call(me, function () {
                    Network.showNetwork.call(me, {
                        status: 2,
                        loadingDesc: '网络请求失败'
                    });
                });
            }
        });
    },

    onCancelOrderSuccess: function (res) {
        var me = this;
        var status = res.status;
        if (status == 0) {
            // Cancel success
            this.onPullDownRefresh();
        }
        else {
            wx.showModal({
                title: '提示',
                content: res.errorMsg || '网络请求失败',
                showCancel: false,
                confirmColor: "#1ba9ba",
                success: function (res) {
                    res.confirm && me.onPullDownRefresh();
                }
            });
        }
    },

    checkPayParam: function () {
        var cashierUrl = '';
        var orderActions = this.data.order.orderActions;
        for (var i = 0; i < orderActions.length; i++) {
            var action = orderActions[i];
            if (action.actId == 2) {
                cashierUrl = action.jumpUrl;
                break;
            }
        }
        var user = getApp().user;
        var openId = user.openId;
        return {
            cashierUrl: cashierUrl,
            openId: openId,
            source: 'wx'
        };
    },

    // 支付按钮点击
    payOrder: function (e) {
        this.pay();
        Watcher.click({
            "page": OrderDetail.page,
            "action-type": OrderDetail.action.payBottomClicked
        });
    },

    pay: function () {
        var payParam = this.checkPayParam();
        var me = this;
        var reqData = {
            cashierUrl: payParam.cashierUrl,
            openId: payParam.openId,
            bd_source: payParam.source,
            success: function (res) {
                // Pay success
                me.onPullDownRefresh();
                Watcher.click({
                    "page": OrderDetail.page,
                    "action-type": OrderDetail.action.paySuccess
                });
            },
            fail: function (error) {
                me.onPullDownRefresh();
                Network.hideNetwork.call(me, function () {
                    Network.showNetwork.call(me, {
                        status: 2,
                        loadingDesc: error || '支付失败'
                    });
                });
            },
            beforeOpen: function () {
                Network.hideNetwork.call(me);
            }
        };

        // Request pay...
        Network.showNetwork.call(me, {
            status: 3,
            loadingDesc: '正在请求支付...'
        });
        console.log("PAY-REQ-PARAM：", JSON.stringify(reqData));
        Pay.openCashier(reqData);

        Watcher.click({
            "page": OrderDetail.page,
            "action-type": OrderDetail.action.pay
        });
    }
});
