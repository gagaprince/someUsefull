// faq.js
var Network = require('../../../common/comps/network/network.js');
var Requester = require('../../common/requester.js');
var ParamUtil = require('../../utils/ParamUtil.js');
var Watcher = require('../../../common/watcher.js');
var Constant = require('../../config/Constant.js');
var Faq = Constant.WatcherValue.Faq;

Page({
    data: {
        faqData: ""
    },

    onLoad: function (options) {
        var param = ParamUtil.parseURLParam(options);
        this.setData({
            param: param
        });
        this.setNavigationBarTitle();
    },

    onReady: function () {
        this.requestFaq();
    },

    onShow: function (param) {
        Watcher.pv({"page": Faq.page});
    },

    onUnload: function () {
        Network.hideNetwork.call(this);
    },

    network_retry: function () {
        this.requestFaq();
    },

    setNavigationBarTitle: function () {
        var title = this.data.param.title;
        title = title ? title : "去哪儿汽车票";
        wx.setNavigationBarTitle({
            title: title
        })
    },

    requestFaq: function () {
        var me = this;
        Network.showNetwork.call(me, {
            status: 4
        });
        Requester.request({
            service: Requester.service.FAQ,
            data: me.data.param,
            success: function (res) {
                me.handleFaqResult(res);
            },
            fail: function (error) {
                // Network error
                me.networkStatus(res, "网络失败，请重试");
            }
        });
    },

    handleFaqResult: function (res) {
        var me = this;
        res = res.data;
        if (!res || res.status != 0) {
            // Network ok but No data
            me.networkStatus(res, "未找到FAQ信息");
        } else {
            // Data ok
            Network.hideNetwork.call(me);
            var faqData = {
                faqList: res.contents
            };
            me.setData({
                faqData: faqData
            });
        }
    },

    networkStatus: function (res, msg) {
        Network.showNetwork.call(this, {
            status: -1,
            loadingDesc: (res && res.errorMsg) || "未找到FAQ信息",
            networkRetry: 'requestFaq',
            loadingDescColor: '#00BCD4',
            showButton: true
        });
    }
});
