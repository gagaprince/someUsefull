var config = require("./common/config.js");
var trainConfig = require("./train/trainConfig.js");
require('./common/cacheImages.js');

App({
    config: config,
    user: {},
    cookies: {},
    onLaunch: function() {
        var that = this;
        wx.getSystemInfo({
            success: function(res) {
                // console.log(res);
                that.globalData.deviceInfo = res;
                if (res.model.indexOf('iPhone') != -1 || res.model.indexOf('iPad') != -1) {
                    that.globalData.deviceInfo.isIOS = true;
                } else {
                    that.globalData.deviceInfo.isIOS = false;
                }
            }
        });
    },
    globalData: {
        deviceInfo: {
            model: 'android'
        }
    }
});
