## 去哪儿 All in One 微信小程序

------

### 目录约定

```
.
├── src  # 源码目录
│   ├── app.js
│   ├── app.json
│   ├── app.wxss
│   ├── bus # 汽车票
│   ├── common # 公共
│   ├── flight # 机票
│   ├── home # 主页
│   ├── hotel # 酒店
│   ├── ticket # 门票
│   └── train # 火车票
├── dist
├── ykit.js
├── README.md
└── package.json
```

#### 开发命令

ykit g => 构建
ykit g -w => 构建 + 监听文件变化

ykit g -w -e beta 进入beta测试

ykit g -w -e beta,train:[betad]  火车票betad环境(betad 可以是其他环境，如devy，betaa等)

#### 打包命令

ykit pack => 打包
ykit pack -m => 压缩打包

ykit pack -m -e beta => 进入beta测试
ykit g -w -e beta,train:[betad] =>  火车票betad环境(betad 可以是其他环境，如devy，betaa等)

#### 环境依赖

ykit 版本 `>=0.3.0`
node 版本 `>=4.0.0`
npm 版本 `>=3.0.0`

npm install 安装模块

#### job

[http://qci.corp.qunar.com/view/m%E6%97%A0%E7%BA%BF/view/mobile/job/fe_qunarwechatapp/](http://qci.corp.qunar.com/view/m%E6%97%A0%E7%BA%BF/view/mobile/job/fe_qunarwechatapp/)
