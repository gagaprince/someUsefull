module.exports = {
    plugins: ['wmp'],
    config: function() {
        this.setConfig({
            wmp: {
                alias: {
                    Comps: 'src/common/comps'
                },
                asserts: [
                    'src/common/images', 'src/train/images', 'src/bus/img', 'src/flight/image'
                ]
            }
        })
    }
};
